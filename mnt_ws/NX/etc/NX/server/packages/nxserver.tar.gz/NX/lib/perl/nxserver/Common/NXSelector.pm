############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXSelector;no warnings;($NXSelector::globalSelector={});(
$NXSelector::timeoutCallbacks={});(@NXSelector::sortedTimeoutCallbacks=());(
$NXSelector::numberOfWaitingCallbacks=(0x14ed+ 3345-0x21fe));sub new{(my $self={
});($$self{"\x46\x44\x41\x52\x52\x41\x59"}=[]);bless ($self);return ($self);}sub
 add{(my $self=shift (@_));(my $FD_passed=shift (@_));(my $FD_correct=$FD_passed
);if (((not (defined ($FD_passed)))or ($FD_passed==(-(0x189a+ 1982-0x2057))))){(my (
$package,$filename,$line,$sub)=caller ((0x1d59+ 206-0x1e26)));if (($sub eq (""))
){($sub=$package);}Logger::error (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x46\x44\x23"
.$FD_passed)."\x20\x66\x72\x6f\x6d\x20\x27").$sub)."\x27\x2e"));main::nxexit ();
}if (ref ($FD_passed)){if (($$FD_passed=~ /\*main::(\d+)/ )){($FD_correct=$1);}
else{(my ($package,$filename,$line,$sub)=caller ((0x07e8+ 1066-0x0c11)));if ((
$sub eq (""))){($sub=$package);}Logger::error (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20\x27"
.$$FD_passed)."\x27\x20\x74\x6f\x20\x69\x6e\x74\x20\x66\x72\x6f\x6d\x20\x27").
$sub)."\x27\x2e"));main::nxexit ();}}if ($self->exists ($FD_correct)){(my (
$package,$filename,$line,$sub)=caller ((0x0639+ 2319-0x0f47)));if (($sub eq ("")
)){($sub=$package);}Logger::warning (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x73\x61\x6d\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$FD_correct)."\x20\x61\x67\x61\x69\x6e\x20\x66\x72\x6f\x6d\x20\x27").$sub).
"\x27\x2e"));return ((0x166c+ 1544-0x1c73));}Logger::debug2 (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x46\x44\x23"
.$FD_correct)."\x20\x74\x6f\x20\x27").$self)."\x27\x2e"));unshift (@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};},$FD_correct);}sub exists{(my $self=shift (@_))
;(my $fd_check=shift (@_));foreach my $fd (@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};}){if (($fd_check==$fd)){return (
(0x09ef+ 4822-0x1cc4));}}return ((0x045f+ 743-0x0746));}sub remove{(my $self=
shift (@_));(my $del_fd=shift (@_));if ((not (defined ($del_fd)))){(my ($package
,$filename,$line,$sub)=caller ((0x04bd+ 2882-0x0ffe)));if (($sub eq (""))){($sub
=$package);}Logger::error (((
"\x53\x65\x6c\x65\x63\x74\x6f\x72\x20\x72\x65\x6d\x6f\x76\x65\x20\x63\x61\x6c\x6c\x65\x64\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x61\x6e\x79\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x20\x66\x72\x6f\x6d\x3a\x20"
.$sub)."\x2e"));return ((0x0640+ 8219-0x265b));}(my (@tmp)=());foreach my $fd (@
{$$self{"\x46\x44\x41\x52\x52\x41\x59"};}){if (($fd!=$del_fd)){push (@tmp,$fd);}
else{Logger::debug2 (((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x46\x44\x23"
.$fd)."\x20\x66\x72\x6f\x6d\x20\x27").$self)."\x27\x2e"));}}(@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};}=@tmp);}sub can_read{(my $self=shift (@_));(my $timeout
=shift (@_));(my $silence=shift (@_));(my (@canRead)=@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};});addGlobalDescriptors ((\@canRead));if ((
scalar (@canRead)==(0x18ac+ 2797-0x2399))){return (());}my (@resultArray);
main::nxselect ((\@canRead),$timeout,(\@resultArray),$silence);return (
@resultArray);}sub handles{(my $self=shift (@_));return (@{$$self{
"\x46\x44\x41\x52\x52\x41\x59"};});}sub count{(my $self=shift (@_));return (
scalar (@{$$self{"\x46\x44\x41\x52\x52\x41\x59"};}));}sub addToGlobalSelector{(my $FD
=shift (@_));(my $caption=shift (@_));(my $callback=shift (@_));if ((not (
defined ($FD)))){Logger::warning (
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x46\x44\x2e"
);return ((0x06eb+ 4551-0x18b2));}if (($FD<(0x057f+ 8395-0x264a))){
Logger::warning (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x62\x61\x64\x20\x46\x44\x23"
.$FD)."\x2e"));return ((0x0c44+ 6836-0x26f8));}if (defined (
$$NXSelector::globalSelector{$FD})){Logger::debug (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x46\x44\x23"
.$FD)."\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x61\x64\x64\x65\x64\x2e"));return (
(0x0491+ 3979-0x141c));}Logger::debug (((((((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x61\x64\x64\x69\x6e\x67\x20\x46\x44\x23"
.$FD)."\x20\x2d\x20").$caption).
"\x20\x77\x69\x74\x68\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20").$callback).
"\x2e"));($$NXSelector::globalSelector{$FD}={});($$NXSelector::globalSelector{
$FD}{"\x63\x61\x70\x74\x69\x6f\x6e"}=$caption);($$NXSelector::globalSelector{$FD
}{"\x63\x61\x6c\x6c\x62\x61\x63\x6b"}=$callback);return ((0x0324+ 9109-0x26b8));
}sub removeFromGlobalSelector{(my $FD=shift (@_));if ((not (defined ($FD)))){
Logger::warning (
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x46\x44\x2e"
);return ((0x0aac+ 1638-0x1112));}if (($FD<(0x1091+ 362-0x11fb))){
Logger::warning (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x20\x62\x61\x64\x20\x46\x44\x23"
.$FD)."\x2e"));return ((0x1514+ 795-0x182f));}delete (
$$NXSelector::globalSelector{$FD});return ((0x0fb0+ 5290-0x2459));}sub 
addGlobalDescriptors{(my $descriptorArray_ref=shift (@_));foreach my $FD (keys (
%$NXSelector::globalSelector)){(my $exist=(0x06c2+ 2218-0x0f6c));foreach my $addedFD
 (@$descriptorArray_ref){if (($FD==$addedFD)){($exist=(0x0437+ 7196-0x2052));
last;}}if (($exist==(0x0482+ 1851-0x0bbd))){push (@$descriptorArray_ref,$FD);}}}
sub handleGlobalSelectorDescriptor{(my $FD=shift (@_));if (defined (
$$NXSelector::globalSelector{$FD})){(my $callback=$$NXSelector::globalSelector{
$FD}{"\x63\x61\x6c\x6c\x62\x61\x63\x6b"});if (defined ($callback)){(my $caption=
$$NXSelector::globalSelector{$FD}{"\x63\x61\x70\x74\x69\x6f\x6e"});Logger::debug
 (((((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x73\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23"
.$FD)."\x20\x2d\x20").$caption)."\x2e"));&{$callback;}($FD);return (
(0x0192+ 7398-0x1e77));}}return ((0x09db+ 6779-0x2456));}sub 
countNonGlobalHandlers{(my $descriptorArray_ref=shift (@_));(my $count=
(0x07a5+ 826-0x0adf));foreach my $FD (@$descriptorArray_ref){if ((not (defined (
$$NXSelector::globalSelector{$FD})))){(++$count);}}return ($count);}sub 
addTimestampCallback{(my $callback=shift (@_));(my $timestamp=shift (@_));(my $handler
=(shift (@_)||
"\x64\x65\x66\x61\x75\x6c\x74\x45\x76\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72"))
;unless (defined ($callback)){Logger::error (
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($handler)){
Logger::error (
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x68\x61\x6e\x64\x6c\x65\x72\x2e"
);Logger::stackTrace ();main::nxexit ();}unless (defined ($timestamp)){
Logger::error (
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x2e"
);Logger::stackTrace ();main::nxexit ();}if (($timestamp<
Common::NXTime::getSecondsSinceEpoch ())){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20"
.$callback).
"\x2c\x20\x62\x65\x63\x75\x61\x73\x65\x20\x67\x69\x76\x65\x6e\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20"
).$timestamp)."\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x70\x61\x73\x73\x2e"));
return ((0x13db+ 1121-0x183c));}if (defined ($$NXSelector::timeoutCallbacks{
$callback})){Logger::debug (((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20"
.$callback)."\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x61\x64\x64\x65\x64\x2e"));
return ((0x0e0d+ 4667-0x2048));}Logger::debug (((((((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72\x3a\x61\x64\x64\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x43\x61\x6c\x6c\x62\x61\x63\x6b\x3a\x20\x61\x64\x64\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback).
"\x27\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x27").
$timestamp)."\x27\x20\x61\x6e\x64\x20\x68\x61\x6e\x64\x6c\x65\x72\x20\x27").
$handler)."\x27\x2e"));($$NXSelector::timeoutCallbacks{$callback}={});(
$$NXSelector::timeoutCallbacks{$callback}{"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70"
}=$timestamp);($$NXSelector::timeoutCallbacks{$callback}{
"\x68\x61\x6e\x64\x6c\x65\x72"}=$handler);insertCallbackInSortedArray ($callback
,$timestamp);(++$NXSelector::numberOfWaitingCallbacks);return (
(0x1fc2+ 1049-0x23da));}sub getNumberOfElementsInTimestampCallbackHash{return (
$NXSelector::numberOfWaitingCallbacks);}sub getTimestampForCallback{(my $callback
=shift (@_));return ($$NXSelector::timeoutCallbacks{$callback}{
"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70"});}sub getFirstCallback{return (
$NXSelector::sortedTimeoutCallbacks[(0x0129+ 9303-0x2580)]);}sub 
handleAndRemoveTimestampCallback{(my $callback=shift (@_));if (defined (
$$NXSelector::timeoutCallbacks{$callback})){(my $handler=
$$NXSelector::timeoutCallbacks{$callback}{"\x68\x61\x6e\x64\x6c\x65\x72"});
removeFirstTimestampCallback ($callback);Logger::debug2 (((((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x68\x61\x6e\x64\x6c\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x20\x77\x69\x74\x68\x20\x66\x75\x6e\x63\x74\x6f\x6e\x20\x27").
$handler)."\x27\x2e"));if (defined ($handler)){if (($handler eq 
"\x64\x65\x66\x61\x75\x6c\x74\x45\x76\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72"))
{NXEvent::handleEvent ($callback);}else{&{$handler;}();}return (
(0x2056+ 1097-0x249e));}}return ((0x0336+ 1208-0x07ee));}sub 
removeFirstTimestampCallback{(my $callback=shift (@_));Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x2e"));(--$NXSelector::numberOfWaitingCallbacks);delete (
$$NXSelector::timeoutCallbacks{$callback});shift (
@NXSelector::sortedTimeoutCallbacks);return ((0x0444+ 7847-0x22ea));}sub 
removeTimestampCallback{(my $callback=shift (@_));Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x2e"));for ((my $index=(0x1d6a+ 2453-0x26ff));($index<
$NXSelector::numberOfWaitingCallbacks);(++$index)){if ((
$$NXSelector::timeoutCallbacks{$callback}{"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70"
}eq getTimestampForCallbackIndex ($index))){splice (
@NXSelector::sortedTimeoutCallbacks,$index,(0x0647+ 3645-0x1483));(--
$NXSelector::numberOfWaitingCallbacks);delete ($$NXSelector::timeoutCallbacks{
$callback});return;}}}sub findFirstHigherValueIndexInCallbackArray{(my $value=
shift (@_));if (($NXSelector::numberOfWaitingCallbacks==(0x0d5a+ 801-0x107b))){
return ((0x0481+ 2745-0x0f3a));}elsif (($NXSelector::numberOfWaitingCallbacks==
(0x0162+ 2473-0x0b0a))){if (($value<getFirstTimestampCallback ())){return (
(0x062c+ 138-0x06b6));}else{return ((0x06c4+ 2813-0x11c0));}}else{for ((my $index
=(0x0afb+ 2427-0x1476));($index<$NXSelector::numberOfWaitingCallbacks);(++$index
)){if (($value<getTimestampForCallbackIndex ($index))){return ($index);}}return 
($NXSelector::numberOfWaitingCallbacks);}}sub insertCallbackInSortedArray{(my $callback
=shift (@_));(my $timestamp=shift (@_));(my $index=
findFirstHigherValueIndexInCallbackArray ($timestamp));splice (
@NXSelector::sortedTimeoutCallbacks,$index,(0x085d+ 4038-0x1823),$callback);}sub
 getTimestampForCallbackIndex{(my $index=shift (@_));return (
getTimestampForCallback (getCallbackForIndex ($index)));}sub getCallbackForIndex
{(my $index=shift (@_));return ($NXSelector::sortedTimeoutCallbacks[$index]);}
sub getFirstTimestampCallback{(my $callback=getFirstCallback ());return (
getTimestampForCallback ($callback));}sub isAnyTimestampCallbackWaiting{return (
$NXSelector::numberOfWaitingCallbacks);}sub runFirstTimestampCallback{(my $callback
=getFirstCallback ());handleAndRemoveTimestampCallback ($callback);}sub 
changeCallback{(my $FD=shift (@_));(my $caption=shift (@_));(my $callback=shift 
(@_));if ((not (defined ($FD)))){Logger::warning (
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x68\x61\x6e\x67\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x46\x44\x2e"
);return ((0x0193+ 2288-0x0a83));}if (($FD<(0x00d0+ 9366-0x2566))){
Logger::warning (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x68\x61\x6e\x67\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x62\x61\x64\x20\x46\x44\x23"
.$FD)."\x2e"));return ((0x043a+ 8173-0x2427));}if ((not (defined (
$$NXSelector::globalSelector{$FD})))){Logger::debug (((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x68\x61\x6e\x67\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x46\x44\x23"
.$FD)."\x2e"));return ((0x1086+ 584-0x12ce));}Logger::debug (((((((
"\x47\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x3a\x20\x46\x44\x23"
.$FD)."\x20\x2d\x20").$caption).
"\x20\x77\x69\x74\x68\x20\x6e\x65\x77\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
).$callback)."\x27\x2e"));($$NXSelector::globalSelector{$FD}{
"\x63\x61\x70\x74\x69\x6f\x6e"}=$caption);($$NXSelector::globalSelector{$FD}{
"\x63\x61\x6c\x6c\x62\x61\x63\x6b"}=$callback);}"\x3f\x3f\x3f";
