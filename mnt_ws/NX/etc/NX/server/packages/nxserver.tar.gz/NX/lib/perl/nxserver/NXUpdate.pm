############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXUpdate::BEGIN{package NXUpdate;no warnings;require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXUpdate::BEGIN{package 
NXUpdate;no warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import (
"\x3a\x74\x72\x79")};}sub NXUpdate::BEGIN{package NXUpdate;no warnings;require 
NXTools;do{"\x4e\x58\x54\x6f\x6f\x6c\x73"->import};}package NXUpdate;no warnings
;($readSize=(0x101d+ 889-0x1316));($inited=(0x0f7d+ 1738-0x1647));($step=
(0x13a2+ 4647-0x25b5));($updatePid=(0x1a84+ 1694-0x2122));($clientPid=
(0x0b97+ 6862-0x2665));($pidFile=(""));($nodeSessionID=(""));($lastAskForUpdate=
(-(0x1e35+ 1077-0x2269)));($lastRepeatForUpdate=(-(0x0d04+ 1844-0x1437)));(
$pendingVersion="\x2d\x31");($ignoreVersion="\x2d\x31");($ignoreUpgradeVersion=
"\x2d\x31");($lastUpdate=(-(0x1483+ 3546-0x225c)));($updateMode=(-
(0x077f+ 7024-0x22ee)));($automaticInstall=(-(0x1931+ 160-0x19d0)));($hostName=
"\x2d\x31");($timestampIndex=(0x0858+ 375-0x09cf));($updateModeIndex=
(0x0c8b+ 3458-0x1a0c));($pendingVersionIndex=(0x21e8+ 733-0x24c3));(
$ignoreVersionIndex=(0x0dd2+ 4000-0x1d6f));($ignoreUpgradeVersionIndex=
(0x08b5+ 613-0x0b16));($automtaicInstallIndex=(0x06c6+ 2088-0x0ee9));(
$hostNameIndex=(0x0591+ 6906-0x2085));($pendingVersionInstallOnStartup=(-
(0x0dca+ 416-0x0f69)));($repeatCheckOnStartupCount=(-(0x058d+ 4295-0x1653)));(
$DefaultUpdateFrequency=172800);($DefaultAskUpdateFrequency=432000);(
$DefaultDownloadUpdateFrequency=(0x0f53+ 2276-0x0a27));(
$DefaultCheckOnStartupFrequency=(0x0cb4+ 311-0x0de6));(
$DefaultCheckOnStartupCounter=(0x04c7+ 8274-0x2515));($SilentUpdateMode=
(0x01d7+ 8406-0x22ac));($BackgroundUpdateMode=(0x0a90+ 2289-0x137f));(
$UpdateFrequency=(-(0x04fa+ 8172-0x24e5)));($UpdateFilePermissions=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));sub 
setUpdateFrequency{(my $time=(shift (@_)||(0x0ad9+ 2245-0x139e)));(
$UpdateFrequency=$time);}sub getUpdateFrequency{if (($UpdateFrequency!=(-
(0x17cb+ 1285-0x1ccf)))){return ($UpdateFrequency);}if ((
$GLOBAL::UpdateFrequency=~ /^\d+$/ )){($UpdateFrequency=$GLOBAL::UpdateFrequency
);return ($UpdateFrequency);}($UpdateFrequency=$DefaultUpdateFrequency);return (
$UpdateFrequency);}sub getAskUpdateFrequency{if (($GLOBAL::AskUpdateFrequency=~ /^\d+$/ )
){return ($GLOBAL::AskUpdateFrequency);}return ($DefaultAskUpdateFrequency);}sub
 getDownloadUpdateFrequency{if (($GLOBAL::DownloadUpdateFrequency=~ /^\d+$/ )){
return ($GLOBAL::DownloadUpdateFrequency);}return (
$DefaultDownloadUpdateFrequency);}sub getUpdateFilePath{if ((
$GLOBAL::UpdateFilePath eq (""))){($GLOBAL::UpdateFilePath=(((($GLOBAL::VAR_ROOT
.$GLOBAL::DIRECTORY_SLASH)."\x64\x62").$GLOBAL::DIRECTORY_SLASH).
"\x75\x70\x64\x61\x74\x65"));}return ($GLOBAL::UpdateFilePath);}sub 
checkIfTimeForCheckUpdate{if (((getLastCheck ()>=(0x1413+ 4625-0x2624))and ((
getLastCheck ()+getUpdateFrequency ())<=Common::NXTime::getSecondsSinceEpoch ())
)){return ((0x1e1a+ 1805-0x2526));}return ((0x153c+ 1904-0x1cac));}sub 
checkIfTimeForAskUpdate{if (((isUpdateEnabled ()==(0x0091+ 3244-0x0d3d))or (
isBackgroundMode ()==(0x1b7f+ 1662-0x21fd)))){return ((0x00ad+ 1135-0x051c));}if
 (((getLastAskForUpdate ()>(0x0491+ 5039-0x1840))and ((getLastAskForUpdate ()+
getAskUpdateFrequency ())<=Common::NXTime::getSecondsSinceEpoch ()))){return (
(0x1ad3+ 1623-0x2129));}return ((0x0f6b+ 2407-0x18d2));}sub checkIfRepeatUpdate{
if ((isBackgroundMode ()==(0x0c94+ 535-0x0eaa))){return ((0x0939+ 4013-0x18e6));
}if ((getLastRepeatForUpdate ()>(0x00b2+ 4994-0x1434))){return (
(0x063b+ 2167-0x0eb1));}return ((0x0735+ 6020-0x1eb9));}sub 
checkLastRepeatedUpdate{if (((getLastRepeatForUpdate ()+
getDownloadUpdateFrequency ())<=Common::NXTime::getSecondsSinceEpoch ())){return
 ((0x1228+ 897-0x15a8));}return ((0x0e87+ 2418-0x17f9));}sub 
checkIfRepeatOnStartup{if ((isBackgroundMode ()==(0x07db+ 813-0x0b07))){return (
(0x0940+ 993-0x0d21));}if ((($repeatCheckOnStartupCount==(-(0x04b7+ 3592-0x12be)
))or ($repeatCheckOnStartupCount>=$DefaultCheckOnStartupCounter))){return (
(0x1d78+ 2442-0x2702));}return ((0x0589+ 7740-0x23c4));}sub 
checkLastCheckOnStartup{if (((getLastRepeatCheckOnStartup ()+
$DefaultCheckOnStartupFrequency)<=Common::NXTime::getSecondsSinceEpoch ())){
return ((0x0bab+ 4722-0x1e1c));}return ((0x003a+ 2938-0x0bb4));}sub 
checkIfAskForInstallUpdate{(my $sessionID=shift (@_));if (($sessionID eq (""))){
return;}if ((isUpdateEnabled ()==(0x0a04+ 5668-0x2028))){return;}if ((
isBackgroundMode ()==(0x0089+ 8095-0x2028))){return;}if ((
$pendingVersionInstallOnStartup<(0x0ad1+ 6711-0x2508))){return;}
NXSession2::checkConsistence ();if ((
NXSession2::isLocalSessionDesktopBySessionId ($sessionID)==(0x02f6+ 6109-0x1ad3)
)){return;}__handleAskForUpdate ($sessionID);if ((
$pendingVersionInstallOnStartup>(0x0ffb+ 3231-0x1c9a))){(
$pendingVersionInstallOnStartup=(-(0x2153+ 1101-0x259f)));}return;}sub 
handleCheckUpdateOnSession{(my $sessionID=shift (@_));if (isUpdateRunning ()){
return ((0x04bd+ 6331-0x1d78));}saveTime ();if ((not ($inited))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x20\x6e\x6f\x74\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x2c\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x69\x74\x20\x66\x69\x72\x73\x74\x20\x61\x73\x20\x72\x6f\x6f\x74\x2e"
);return ((0x0847+ 2204-0x10e2));}Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x75\x6e\x64\x2c\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x63\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x75\x70\x64\x61\x74\x65\x2e"
);__sendUpdateMessage ($sessionID,"\x75\x70\x64\x61\x74\x65");return (
(0x03d2+ 8368-0x2482));}sub isUpdateRunning{(my $pidToCheck=$updatePid);if ((
$pidToCheck<=(0x0b36+ 268-0x0c42))){($pidToCheck=$clientPid);}if (($pidToCheck>
(0x0fe2+ 4333-0x20cf))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x72\x6f\x63\x65\x73\x73\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pidToCheck)."\x27\x2e"));return ((0x0d98+  71-0x0dde));}return (
(0x0370+ 4237-0x13fd));}sub checkUpdate{if ((NXLicense::isLicenseExpired ()==
(0x017d+ 3519-0x0f3b))){setUpdateFrequency ((0x19a0+ 2731-0x244b));return;}elsif
 (($UpdateFrequency!=$GLOBAL::UpdateFrequency)){setUpdateFrequency (
$GLOBAL::UpdateFrequency);}if ((isUpdateEnabled ()==(0x0c4d+ 1884-0x13a9))){
return;}if ((checkIfRepeatOnStartup ()==(0x0420+ 4864-0x171f))){if ((
checkLastCheckOnStartup ()==(0x02bf+ 4566-0x1494))){(++
$repeatCheckOnStartupCount);(my $sinceLastUpdate=(
Common::NXTime::getSecondsSinceEpoch ()-getLastRepeatCheckOnStartup ()));
Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x61\x73\x74\x20\x63\x68\x65\x63\x6b\x20\x6f\x6e\x20\x73\x74\x61\x72\x74\x75\x70\x20\x75\x70\x64\x61\x74\x65\x20\x77\x61\x73\x3a\x20"
.getLastRepeatCheckOnStartup ())."\x2c\x20\x74\x68\x61\x74\x20\x77\x61\x73\x20")
.$sinceLastUpdate)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x67\x6f\x2e"));
handleUpdate ();setLastRepeatCheckOnStartup ();}return;}elsif ((
checkIfRepeatUpdate ()==(0x0554+ 5086-0x1931))){if ((checkLastRepeatedUpdate ()
==(0x07ac+ 1192-0x0c53))){(my $sinceLastUpdate=(
Common::NXTime::getSecondsSinceEpoch ()-getLastRepeatForUpdate ()));
Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x61\x73\x74\x20\x63\x68\x65\x63\x6b\x20\x75\x70\x64\x61\x74\x65\x20\x77\x61\x73\x3a\x20"
.getLastRepeatForUpdate ())."\x2c\x20\x74\x68\x61\x74\x20\x77\x61\x73\x20").
$sinceLastUpdate)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x67\x6f\x2e"));
handleUpdate ();setLastRepeatForUpdate ();}return;}if ((
checkIfTimeForCheckUpdate ()==(0x07ba+ 4476-0x1935))){(my $sinceLastUpdate=(
Common::NXTime::getSecondsSinceEpoch ()-getLastCheck ()));Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x61\x73\x74\x20\x75\x70\x64\x61\x74\x65\x20\x77\x61\x73\x3a\x20"
.getLastCheck ())."\x2c\x20\x74\x68\x61\x74\x20\x77\x61\x73\x20").
$sinceLastUpdate).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x67\x6f\x2c\x20\x63\x68\x65\x63\x6b\x69\x6e\x67\x20\x66\x6f\x72\x20\x75\x70\x64\x61\x74\x65\x2e"
));handleUpdate ();}elsif ((checkIfTimeForAskUpdate ()==(0x14df+ 2916-0x2042))){
(my $sinceLastUpdate=(Common::NXTime::getSecondsSinceEpoch ()-
getLastAskForUpdate ()));Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x61\x73\x74\x20\x75\x70\x64\x61\x74\x65\x20\x77\x61\x73\x3a\x20"
.getLastAskForUpdate ())."\x2c\x20\x74\x68\x61\x74\x20\x77\x61\x73\x20").
$sinceLastUpdate)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x61\x67\x6f\x2e"));
__handleAskForUpdate ();}return;}sub getLastCheck{if (($lastUpdate<
(0x05c0+ 1491-0x0b93))){($lastUpdate=lastUpdateTime ());}return ($lastUpdate);}
sub getLastAskForUpdate{return ($lastAskForUpdate);}sub setLastAskForUpdate{(
$lastAskForUpdate=Common::NXTime::getSecondsSinceEpoch ());}sub 
getLastRepeatForUpdate{return ($lastRepeatForUpdate);}sub setLastRepeatForUpdate
{($lastRepeatForUpdate=Common::NXTime::getSecondsSinceEpoch ());}sub 
resetRepeatForUpdate{($lastRepeatForUpdate=(-(0x0043+ 3567-0x0e31)));}sub 
getLastRepeatCheckOnStartup{return ($lastRepeatCheckOnStartup);}sub 
setLastRepeatCheckOnStartup{($lastRepeatCheckOnStartup=
Common::NXTime::getSecondsSinceEpoch ());}sub setLastCheck{($lastUpdate=
Common::NXTime::getSecondsSinceEpoch ());}sub __getPhysicalSession{Logger::debug
 (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4c\x6f\x6f\x6b\x69\x6e\x67\x20\x66\x6f\x72\x20\x61\x20\x70\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x68\x61\x74\x20\x63\x61\x6e\x20\x72\x75\x6e\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65"
);(my (@allLocalPhysicalSessions)=NXSession2::getLocalPhysicalSessionsList ());
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x67\x6f\x74\x20\x6c\x69\x73\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20"
.join ($",@allLocalPhysicalSessions))."\x2e"));foreach my $session (
@allLocalPhysicalSessions){Logger::debug2 (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x63\x68\x65\x63\x6b\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20"
.$session)."\x2e"));if (NXSession2::isStatusRunning (
NXSession2::getStatusBySessionId ($session))){Logger::debug2 (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x27".
$session)."\x27\x20\x72\x65\x61\x64\x79\x2e"));return ($session);}else{
Logger::debug2 (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x27".
$session)."\x27\x20\x6e\x6f\x74\x20\x72\x65\x61\x64\x79\x2e"));}}return ((""));}
sub __sendUpdateMessage{(my $session=shift (@_));(my $mode=shift (@_));
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x5b"
.$session)."\x5d\x2e"));(my $message=((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_MAKE_UPDATE)."\x20").$mode)."\x20\x73\x65\x73\x73\x69\x6f\x6e\x3d")
.$session));if ((($mode eq "\x75\x70\x64\x61\x74\x65")and (
isCorrectedVersionFormat ($ignoreVersion)==(0x147c+ 2646-0x1ed1)))){
checkIgnoreVersion ();($message.=("\x20\x69\x67\x6e\x6f\x72\x65\x3d".
$ignoreVersion));}return (NXNodeExec::sendToNodeBySessionId ($message,$session))
;}sub __handleAskForUpdate{(my $sessionID=(shift (@_)||("")));if (((
isUpdateEnabled ()==(0x1443+ 1661-0x1ac0))or (isBackgroundMode ()==
(0x0e7f+ 3343-0x1b8e)))){return ((0x0015+ 9718-0x260b));}if (isUpdateRunning ())
{return ((0x12f6+ 416-0x1496));}setLastAskForUpdate ();if (($sessionID eq ("")))
{($sessionID=__getPhysicalSession ());if (($sessionID eq (""))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x66\x69\x6e\x64\x20\x70\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x0001+ 4911-0x132f));}}Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x75\x6e\x64\x2c\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x61\x73\x6b\x20\x66\x6f\x72\x20\x75\x70\x64\x61\x74\x65\x2e"
);(my $byte=__sendUpdateMessage ($sessionID,"\x61\x73\x6b"));if ((($byte==
(0x1410+ 700-0x16cc))or ($byte==(-(0x1843+ 3175-0x24a9))))){return ((-
(0x0b73+ 1332-0x10a6)));}return ((0x03b3+ 5039-0x1762));}sub handleUpdate{if ((
isBackgroundMode ()==(0x1530+ 1436-0x1acb))){handleBackgroundUpdate (
"\x63\x68\x65\x63\x6b");return ((0x23cd+  21-0x23e2));}if ((not ($inited))){
Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x20\x6e\x6f\x74\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x2c\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x69\x74\x20\x66\x69\x72\x73\x74\x20\x61\x73\x20\x72\x6f\x6f\x74\x2e"
);return ((0x0dd1+ 2618-0x180a));}if (isUpdateRunning ()){return (
(0x0129+ 7845-0x1fce));}saveTime ();(my $session=__getPhysicalSession ());if ((
$session eq (""))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x66\x69\x6e\x64\x20\x70\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);if (($repeatCheckOnStartupCount==(-(0x0c27+ 5560-0x21de)))){(
$repeatCheckOnStartupCount=(0x1247+ 2052-0x1a4b));}return ((0x0eda+ 2674-0x194b)
);}Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x75\x6e\x64\x2c\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x63\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x75\x70\x64\x61\x74\x65\x2e"
);__sendUpdateMessage ($session,"\x75\x70\x64\x61\x74\x65");(
$repeatCheckOnStartupCount=$DefaultCheckOnStartupCounter);return (
(0x1010+ 4061-0x1fed));}sub __getUpdateFileContentStringBaseOnCurrentGlobals{(my $defaultContent
=($lastUpdate."\x3a"));($defaultContent.=($updateMode."\x3a"));($defaultContent
.=($pendingVersion."\x3a"));($defaultContent.=($ignoreVersion."\x3a"));(
$defaultContent.=($ignoreUpgradeVersion."\x3a"));($defaultContent.=(
$automaticInstall."\x3a"));($defaultContent.=$hostName);return ($defaultContent)
;}sub __getDefaultUpdateFileContent{(my $initalizeFromMemory=(shift (@_)||
(0x07d2+ 2367-0x1111)));if (($initalizeFromMemory==(0x0fa7+ 5861-0x268c))){(
$lastUpdate=Common::NXTime::getSecondsSinceEpoch ());($updateMode=
NXLicense::getUpdateMode ());($pendingVersion="\x30");($ignoreVersion="\x30");(
$ignoreUpgradeVersion="\x30");($automaticInstall=(0x1915+ 1265-0x1e06));(
$hostName="\x30");}return (__getUpdateFileContentStringBaseOnCurrentGlobals ());
}sub __tryToGetUpdateFileContentFromMemory{(my $defaultContent=
__getDefaultUpdateFileContent ((0x0265+ 3341-0x0f71)));if (((not (defined (
$defaultContent)))or ($defaultContent eq ("")))){return (
__getDefaultUpdateFileContent ((0x0c7b+ 2781-0x1758)));}return (
validateUpdateFileContent ($defaultContent));}sub isCorrectedVersionFormat{(my $version
=shift (@_));if ((not (defined ($version)))){return ((0x02a7+ 2662-0x0d0d));}if 
((($version ne (""))and ((($version eq "\x30")||($version=~ /(\d+\.\d+\.\d+_\d+)/ )
)||($version=~ /(\d+\.\d+\.\d+)/ )))){return ((0x0254+ 1212-0x070f));}return (
(0x02fb+ 5337-0x17d4));}sub setTimestampField{(my $value=(shift (@_)||("")));if 
((($value=~ /^\d+$/ )and ($value>(0x0c50+ 2799-0x173f)))){($lastUpdate=$value);
return ((0x0cd5+ 6354-0x25a6));}else{($lastUpdate=
Common::NXTime::getSecondsSinceEpoch ());}return ((0x0c93+ 939-0x103e));}sub 
checkTimestampFromMemory{(my $oldTimestamp=(shift (@_)||(0x07ba+ 7771-0x2615)));
if (((not (($oldTimestamp=~ /^\d+$/ )))or ($oldTimestamp<=(0x03e9+ 3879-0x1310))
)){($oldTimestamp=Common::NXTime::getSecondsSinceEpoch ());}if (((($lastUpdate=~ /^\d+$/ )
and ($lastUpdate>(0x1a41+ 955-0x1dfc)))and ($lastUpdate>=$oldTimestamp))){return
;}else{setTimestampField ($oldTimestamp);}}sub setHostNameField{(my $value=shift
 (@_));if (((defined ($value)and ($value ne ("")))and ($value ne "\x2d\x31"))){(
$hostName=$value);return ((0x0341+ 1286-0x0846));}else{($hostName="\x30");}
return ((0x16c1+ 3216-0x2351));}sub setAutomaticInstallField{(my $value=shift (
@_));if ((defined ($value)and ($value=~ /^[0,1]$/ ))){($automaticInstall=$value)
;return ((0x0140+ 2480-0x0aef));}else{($automaticInstall=(0x0751+ 3754-0x15fb));
}return ((0x1a56+ 1585-0x2087));}sub validateUpdateFileContent{(my $content=(
shift (@_)||("")));(my $initialize=(shift (@_)||(0x1463+ 2769-0x1f34)));
Logger::debug2 (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x3a\x20\x27"
.$initialize)."\x27\x2c\x20\x63\x6f\x6e\x74\x65\x6e\x74\x3a\x20").$content).
"\x2e"));if ((defined ($content)and ($content eq ("")))){if (($initialize==
(0x0733+ 3291-0x140d))){(my $defaultContent=__getDefaultUpdateFileContent (
(0x0a99+ 5694-0x20d7)));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x27\x75\x70\x64\x61\x74\x65\x27\x20\x66\x69\x6c\x65\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x73\x3a\x20"
.$defaultContent)."\x2e"));saveInfoToFile ($defaultContent);return (
$defaultContent);}else{return (__tryToGetUpdateFileContentFromMemory ());}}(my (
@updateFileContentArray)=split ( /:/ ,$content,(0x0108+ 3708-0x0f84)));(my $changeUpdateFile
=(0x050b+ 5633-0x1b0c));if ((setTimestampField ($updateFileContentArray[
$timestampIndex])==(0x13cb+ 1615-0x1a19))){if (($initialize==
(0x1265+ 3506-0x2016))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x77\x69\x74\x68\x3a\x20"
.$lastUpdate)."\x2e"));}}else{Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x77\x69\x74\x68\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$lastUpdate)."\x2e"));($changeUpdateFile=(0x0013+ 6455-0x1949));}if (
isCorrectUpdateMode ($updateFileContentArray[$updateModeIndex])){($updateMode=
$updateFileContentArray[$updateModeIndex]);if (($initialize==
(0x0211+ 9265-0x2641))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x75\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$updateMode)."\x27\x2e"));}}else{($updateMode=NXLicense::getUpdateMode ());(
$changeUpdateFile=(0x0275+ 2753-0x0d35));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$updateMode)."\x27\x2e"));}if ((isCorrectedVersionFormat (
$updateFileContentArray[$pendingVersionIndex])==(0x0e36+ 5469-0x2392))){(
$pendingVersion=$updateFileContentArray[$pendingVersionIndex]);if (($initialize
==(0x0e8f+ 1595-0x14c9))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x70\x65\x6e\x64\x69\x6e\x67\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$pendingVersion)."\x27\x2e"));}}else{($pendingVersion="\x30");(
$changeUpdateFile=(0x0b13+ 4795-0x1dcd));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x70\x65\x6e\x64\x69\x6e\x67\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$pendingVersion)."\x2e"));}if ((isCorrectedVersionFormat (
$updateFileContentArray[$ignoreVersionIndex])==(0x018a+ 8162-0x216b))){(
$ignoreVersion=$updateFileContentArray[$ignoreVersionIndex]);if (($initialize==
(0x0669+ 6858-0x2132))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$ignoreVersion)."\x27\x2e"));}}else{($ignoreVersion="\x30");($changeUpdateFile=
(0x003d+ 6880-0x1b1c));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$ignoreVersion)."\x2e"));}if ((isCorrectedVersionFormat (
$updateFileContentArray[$ignoreUpgradeVersionIndex])==(0x16b0+ 3642-0x24e9))){(
$ignoreUpgradeVersion=$updateFileContentArray[$ignoreUpgradeVersionIndex]);if ((
$initialize==(0x09ab+ 2313-0x12b3))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x69\x67\x6e\x6f\x72\x65\x20\x75\x70\x67\x72\x61\x64\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$ignoreUpgradeVersion)."\x27\x2e"));}}else{($ignoreUpgradeVersion="\x30");(
$changeUpdateFile=(0x19c6+ 2029-0x21b2));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x69\x67\x6e\x6f\x72\x65\x20\x75\x70\x67\x72\x61\x64\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$ignoreUpgradeVersion)."\x27\x2e"));}if ((setAutomaticInstallField (
$updateFileContentArray[$automtaicInstallIndex])==(0x064f+ 1375-0x0bad))){if ((
$initialize==(0x0b38+ 5869-0x2224))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x75\x70\x64\x61\x74\x65\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x69\x6e\x73\x74\x61\x6c\x6c\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$automaticInstall)."\x27\x2e"));}}else{Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x69\x6e\x73\x74\x61\x6c\x6c\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x20\x27\x30\x27\x2e"
);($changeUpdateFile=(0x1021+ 5561-0x25d9));}if ((setHostNameField (
$updateFileContentArray[$hostNameIndex])==(0x0bc1+ 129-0x0c41))){if ((
$initialize==(0x0f5f+ 3958-0x1ed4))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x69\x6e\x69\x74\x61\x6c\x69\x7a\x65\x20\x68\x6f\x73\x74\x6e\x61\x6d\x65\x20\x75\x73\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$hostName)."\x27\x2e"));}}else{Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x3a\x20\x73\x65\x74\x20\x68\x6f\x73\x74\x6e\x61\x6d\x65\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x20\x27\x30\x27\x2e"
);($changeUpdateFile=(0x03e8+ 3807-0x12c6));}if (($changeUpdateFile==
(0x0d77+ 3978-0x1d00))){(my $defaultContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());if (($initialize==
(0x04e1+ 3176-0x1148))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x76\x61\x6c\x69\x64\x61\x74\x65\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x43\x6f\x6e\x74\x65\x6e\x74\x20\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x27\x75\x70\x64\x61\x74\x65\x27\x20\x66\x69\x6c\x65\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x73\x3a\x20"
.$defaultContent)."\x2e"));saveInfoToFile ($defaultContent);}return (
$defaultContent);}else{return (__getUpdateFileContentStringBaseOnCurrentGlobals 
());}}sub initializeByUpdateFile{readInfoFromFile ((0x02a3+ 2476-0x0c4e));return
;}sub checkAndCorrectUpdateFilePermission{(my $updateFile=getUpdateFilePath ());
if ((not (Common::NXFile::isExists ($updateFile)))){(my $defaultContent=
__getDefaultUpdateFileContent ((0x070c+ 4517-0x18b1)));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x63\x68\x65\x63\x6b\x41\x6e\x64\x43\x6f\x72\x72\x65\x63\x74\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x20\x75\x70\x64\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2c\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x69\x74\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$defaultContent)."\x2e"));saveInfoToFile ($defaultContent);}else{Logger::debug 
(((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x3a\x3a\x73\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x52\x65\x61\x64\x57\x72\x69\x74\x65\x46\x6f\x72\x4f\x77\x6e\x65\x72\x52\x65\x61\x64\x4f\x6e\x6c\x79\x46\x6f\x72\x41\x6c\x6c\x46\x6f\x72\x63\x65\x28"
.$updateFile)."\x29\x20\x73\x74\x61\x72\x74\x2e"));
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAllForce ($updateFile);
}}sub init{__setPidFilePath ();if ((not (Common::NXFile::isExists (
getUpdateFilePath ())))){(my $defaultContent=__getDefaultUpdateFileContent (
(0x0581+ 488-0x0769)));Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x69\x6e\x69\x74\x20\x75\x70\x64\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2c\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x69\x74\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$defaultContent)."\x2e"));saveInfoToFile ($defaultContent);}else{
initializeByUpdateFile ();}if ((not ($inited))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x69\x6e\x67\x2c\x20\x67\x65\x74\x74\x69\x6e\x67\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x20\x61\x62\x6f\x75\x74\x20\x73\x79\x73\x74\x65\x6d\x2e"
);($inited=(0x0f25+ 4203-0x1f8f));Logger::debug ((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x55\x70\x64\x61\x74\x65\x46\x72\x65\x71\x75\x65\x6e\x63\x79\x20\x73\x65\x74\x20\x74\x6f\x3a\x20"
.getUpdateFrequency ()));}if ((isUpdateEnabled ()==(0x04e8+ 3572-0x12dc))){
return ((0x0d58+ 2656-0x17b8));}if ((isUpdateEnabled ()==(0x1581+ 998-0x1966))){
if ((isBackgroundMode ()==(0x09a3+ 246-0x0a98))){checkIfReadyBackgroundUpdate ()
;}else{checkIgnoreVersion ();}}}sub __setPidFilePath{($pidFile=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x72\x75\x6e\x6e\x65\x72\x2e\x70\x69\x64"));}
sub __getPidFilePath{if (($pidFile eq (""))){__setPidFilePath ();}return (
$pidFile);}sub lastUpdateTime{(my $updateTime=__getInformationFromUpdateFile (
$timestampIndex));if (($updateTime ne (""))){return ($updateTime);}return (
(0x16b9+ 3522-0x247b));}sub saveTime{setLastCheck ();(my $oldTimestamp=
$lastUpdate);(my $updateFile=getUpdateFilePath ());(my $FH=main::nxopen (
$updateFile,($NXBits::O_RDWR+$NXBits::O_CREAT),$UpdateFilePermissions));if (((
not (defined ($FH)))or ($FH<=(0x110d+ 1981-0x18ca)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return;}if (
main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x1ad6+ 770-0x1dd5)));if (((not (
defined ($ret)))or ($ret<=(0x1063+ 4887-0x237a)))){Logger::warning (((
"\x73\x61\x76\x65\x54\x69\x6d\x65\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));main::nxclose ($FH);
return;}(my ($readBytes,$validatedContent)=readInfoFromFileFD ($FH,
(0x1214+ 3661-0x2061)));(my (@con)=split ( /:/ ,$validatedContent,
(0x11d0+ 4602-0x23ca)));checkTimestampFromMemory ();(my $newContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());saveInfoToFile ($newContent
,$FH,$readBytes);($updateFile=getUpdateFilePath ());Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x64\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x69\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$updateFile)."\x27\x3a\x20").$newContent)."\x2e"));}sub saveClientPid{(my $processPid
=shift (@_));(my $nodeSessionID=(shift (@_)||(0x0dba+ 2940-0x1936)));($clientPid
=$processPid);if (((!$nodeSessionID)==(0x0e82+ 4908-0x21ae))){(
$NXUpdate::nodeSessionID=$nodeSessionID);}return;}sub freeClientPidForNodeClose{
(my $nodeSessionID=(shift (@_)||"\x30"));if ((isUpdateEnabled ()==
(0x22a3+ 819-0x25d6))){return;}if (($nodeSessionID eq "\x30")){return;}if ((
$nodeSessionID eq $NXUpdate::nodeSessionID)){handleClientUpdateExit ();}return;}
sub handleClientUpdateExit{(my $isEAGAIN=(shift (@_)||(0x1647+ 3967-0x25c6)));(
$clientPid=(0x0e39+  61-0x0e76));($nodeSessionID="\x30");if (($isEAGAIN==
(0x0f71+ 2327-0x1888))){resetRepeatForUpdate ();}else{Logger::debug (
"\x43\x68\x65\x63\x6b\x20\x75\x70\x64\x61\x74\x65\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x45\x41\x47\x41\x49\x4e\x20\x65\x72\x72\x6f\x72\x2e"
);setLastRepeatForUpdate ();}return;}sub savePid{(my $processPid=shift (@_));if 
((($processPid eq (""))and ($processPid<=(0x01fa+ 5789-0x1897)))){return (
(0x060a+ 2274-0x0eeb));}($updatePid=$processPid);(my $filename=__getPidFilePath 
());Logger::debug ((((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x70\x69\x64\x3a\x20".
$processPid).
"\x2c\x20\x66\x6f\x72\x20\x27\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x27\x20\x69\x6e\x20"
).$filename));(my $FH=main::nxopen ($filename,($NXBits::O_RDWR+$NXBits::O_CREAT)
,$NXBits::UserReadWrite));if ((not (defined ($FH)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$filename).
"\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),
(0x13fc+ 4071-0x23e3));return ((0x0e0f+ 1037-0x121b));}if ((main::nxwrite ($FH,(
$processPid."\x0a"))==(-(0x1353+ 2300-0x1c4e)))){(my $error=libnxh::NXGetError 
());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),(0x2061+ 669-0x22fe));
main::nxclose ($FH);return ((0x1083+ 1278-0x1580));}main::nxclose ($FH);
Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x61\x76\x65\x64\x20\x50\x49\x44\x20\x27"
.$processPid)."\x27\x20\x69\x6e\x20\x27").$filename)."\x27\x2e"));return (
(0x0dca+ 4417-0x1f0b));}sub removePid{return (__removePidFile (
(0x201a+ 877-0x2386)));}sub __removePidFile{(my $silence=(shift (@_)||
(0x02f9+ 2778-0x0dd3)));($updatePid=(0x1363+ 1876-0x1ab7));(my $filename=
__getPidFilePath ());if (Common::NXFile::isExists ($filename)){if ((not (unlink 
($filename)))){Logger::warning (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x3a\x20").$!)."\x2e"));return ((0x00ea+ 4818-0x13bb));}}else{
if ((not ($silence))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x2e"))
;}return ((0x0614+ 6135-0x1e0b));}return ((0x00f2+ 7983-0x2021));}sub __readPid{
(my $silence=(shift (@_)||(0x06c7+ 4696-0x191f)));if (($updatePid>
(0x1642+ 3795-0x2515))){Logger::debug2 (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x70\x69\x64\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x2e"
,(0x0b98+ 1325-0x10c5));return ($updatePid);}(my $filename=__getPidFilePath ());
if ((not (Common::NXFile::isExists ($filename)))){if ((not ($silence))){
Logger::debug2 (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x46\x69\x6c\x65\x20\x27".$filename).
"\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"),
(0x1352+ 320-0x1492));}return ((0x0be1+ 6684-0x25fd));}(my $FH=main::nxopen (
$filename,$NXBits::O_RDONLY,(0x1862+ 2608-0x2292)));if ((not (defined ($FH)))){(my $error
=libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$filename).
"\x27\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),
(0x0360+ 1386-0x08ca));return ((0x0883+ 7637-0x2658));}my ($processPid);
main::nxreadLine ($FH,(\$processPid));main::nxclose ($FH);if (($processPid=~ /^(\d+)$/ )
){chomp ($processPid);Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x52\x65\x61\x64\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x3a\x20").$processPid)."\x2e"));($updatePid=$processPid);
return ($processPid);}Logger::warning (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x66\x6f\x72\x6d\x61\x74\x20\x6f\x66\x20\x50\x49\x44\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x3a\x20").$processPid)."\x2e"));return ((0x02f4+ 6458-0x1c2e))
;}sub __getPendingVersion{($pendingVersion=__getInformationFromUpdateFile (
$pendingVersionIndex));return ($pendingVersion);}sub __getIgnoreVersion{if (((
$ignoreVersion ne (""))and ($ignoreVersion ne "\x2d\x31"))){return (
$ignoreVersion);}return (__getInformationFromUpdateFile ($ignoreVersionIndex));}
sub __getInformationFromUpdateFile{(my $position=shift (@_));(my $validatedContent
=readInfoFromFile ());(my (@con)=split ( /:/ ,$validatedContent,
(0x0a82+ 4794-0x1d3c)));if (((length ($con[$position])!=(0x05b5+ 6782-0x2033))
and ($con[$position]ne "\x20"))){Logger::debug2 (((((
"\x5f\x5f\x67\x65\x74\x49\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x46\x72\x6f\x6d\x55\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x20\x70\x6f\x73\x69\x74\x69\x6f\x6e\x3a\x20\x27"
.$position)."\x27\x20\x76\x61\x6c\x75\x65\x3a\x20\x27").$con[$position]).
"\x27\x2e"));return ($con[$position]);}else{return ((""));}}sub 
__deletePendingVersion{(my $updateFile=getUpdateFilePath ());(my $FH=
main::nxopen ($updateFile,($NXBits::O_RDWR+$NXBits::O_CREAT),
$UpdateFilePermissions));if (((not (defined ($FH)))or ($FH<=(0x1116+ 659-0x13a9)
))){(my $error=libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());
(my $errorstring=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return;}if (
main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x0f47+ 3017-0x1b0d)));if (((not (
defined ($ret)))or ($ret<=(0x1da3+ 807-0x20ca)))){Logger::warning (((
"\x5f\x5f\x64\x65\x6c\x65\x74\x65\x50\x65\x6e\x64\x69\x6e\x67\x56\x65\x72\x73\x69\x6f\x6e\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));main::nxclose ($FH);
return;}(my ($readBytes,$validatedContent)=readInfoFromFileFD ($FH,
(0x105c+ 1455-0x160b)));(my (@con)=split ( /:/ ,$validatedContent,
(0x08a7+ 7003-0x2402)));($pendingVersion="\x30");(my $newContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());saveInfoToFile ($newContent
,$FH,$readBytes);}sub __deleteIgnoreVersion{(my $updateFile=getUpdateFilePath ()
);(my $FH=main::nxopen ($updateFile,($NXBits::O_RDWR+$$NXBits::O_CREAT),
$UpdateFilePermissions));if (((not (defined ($FH)))or ($FH<=
(0x1085+ 2815-0x1b84)))){(my $error=libnxh::NXGetError ());(my $errorname=
libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return ((-
(0x026c+ 8459-0x2376)));}if (main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x16ec+ 1584-0x1d19)));if (((not (
defined ($ret)))or ($ret<=(0x14a1+ 794-0x17bb)))){Logger::warning (((
"\x5f\x5f\x64\x65\x6c\x65\x74\x65\x49\x67\x6e\x6f\x72\x65\x56\x65\x72\x73\x69\x6f\x6e\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));($ignoreVersion=
"\x30");main::nxclose ($FH);return;}(my ($readBytes,$validatedContent)=
readInfoFromFileFD ($FH,(0x0203+ 5891-0x1906)));(my (@con)=split ( /:/ ,
$validatedContent,(0x057d+ 1924-0x0d01)));($ignoreVersion="\x30");(my $newContent
=__getUpdateFileContentStringBaseOnCurrentGlobals ());saveInfoToFile (
$newContent,$FH,$readBytes);}sub handleBackgroundUpdate{(my $mode=shift (@_));
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x75\x70\x64\x61\x74\x65\x20\x69\x6e\x20\x6d\x6f\x64\x65\x20\x27"
.$mode)."\x27\x2e"));my (@command,@parameters);main::nxrequire (
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e"
);if ((((isUpdateEnabled ()==(0x10db+ 292-0x11ff))||(isBackgroundMode ()==
(0x0a06+ 1160-0x0e8e)))and (NXSoftwareUpdateDaemon::isWorking ()==
(0x0c36+ 3086-0x1844)))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x42\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x75\x70\x64\x61\x74\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x06bd+ 8225-0x26dd));}if (isUpdateRunning ()){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x42\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x75\x70\x64\x61\x74\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);return ((0x024a+ 7985-0x217a));}if (($mode eq "\x63\x68\x65\x63\x6b")){
saveTime ();}(my $pid=(""));(my $home=NXPaths::getUserNXHomeDir ());(my $userName
=Common::NXCore::getEffectiveUsername ());(my $userGroup=
Common::NXCore::getEffectiveUserGroupID ());push (@command,
NXTools::getNXExecCommand ());push (@command,$GLOBAL::SCRIPT_NXUPDATE);push (
@command,$userGroup);push (@command,"\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64");
push (@command,$mode);push (@parameters,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");
push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");push
 (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".$GLOBAL::NODE_ROOT));push (
@parameters,"\x73\x65\x74\x20\x65\x6e\x76",((("\x4e\x58\x5f\x52\x4f\x4f\x54\x3d"
.$home).$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",((("\x4e\x58\x5f\x43\x4f\x4e\x46\x49\x47\x3d".
$home).$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x55\x53\x45\x52\x3d".$userName));
push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x47\x52\x4f\x55\x50\x3d".$userGroup));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".$home));push (@parameters
,"\x67\x65\x74\x20\x70\x69\x64",(\$pid));my ($updateOut);
Common::NXCore::nxPipeCreateBi ((\$stdout),(\$updateOut));push (@parameters,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",$updateOut);push (
@parameters,"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",$updateOut);
if (($mode eq "\x63\x68\x65\x63\x6b")){push (@parameters,
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e",
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x65\x74\x50\x69\x64\x46\x6f\x72\x43\x68\x65\x63\x6b\x55\x70\x64\x61\x74\x65"
);}elsif (($mode eq "\x64\x6f\x77\x6e\x6c\x6f\x61\x64")){push (@parameters,
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e",
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x65\x74\x50\x69\x64\x46\x6f\x72\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x55\x70\x64\x61\x74\x65"
);}elsif (($mode eq "\x69\x6e\x73\x74\x61\x6c\x6c")){push (@parameters,
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e",
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x65\x74\x50\x69\x64\x46\x6f\x72\x49\x6e\x73\x74\x61\x6c\x6c\x55\x70\x64\x61\x74\x65"
);}main::nxrequire (
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e"
);Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x27\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20"
.$mode)."\x20\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x27\x2e"));(my (
$cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@parameters)));
if (($mode eq "\x63\x68\x65\x63\x6b")){($checkStdOutBuffer=undef);(
$checkExitStatus=undef);(my $description=(
"\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20".$mode
));(my $handler=
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x74\x64\x4f\x75\x74\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x63\x68\x65\x63\x6b\x20\x46\x44\x23"
.$stdout)."\x2e"));Common::NXSelector::addToGlobalSelector ($stdout,$description
,$handler);}elsif (($mode eq "\x64\x6f\x77\x6e\x6c\x6f\x61\x64")){(my $description
=("\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20".
$mode));(my $handler=
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e\x3a\x3a\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x66\x6f\x72\x20\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x20\x46\x44\x23"
.$stdout)."\x2e"));Common::NXSelector::addToGlobalSelector ($stdout,$description
,$handler);}if ((($pid ne (""))and ($pid>(0x0304+ 2937-0x0e7d)))){if (($mode ne 
"\x69\x6e\x73\x74\x61\x6c\x6c")){savePid ($pid);}else{
NXSoftwareUpdateDaemon::saveInstallPid ($pid);saveClientPid ($pid);}
Logger::debug (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20"
.$mode).
"\x20\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x27\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
).$pid)."\x27\x2e"));if (($mode eq "\x63\x68\x65\x63\x6b")){
NXSoftwareUpdateDaemon::reportUpdateStartCheck ();
NXSoftwareUpdateDaemon::reportCheckInProgress ();}elsif (($mode eq 
"\x64\x6f\x77\x6e\x6c\x6f\x61\x64")){
NXSoftwareUpdateDaemon::reportUpdateStartDownload ();}elsif (($mode eq 
"\x69\x6e\x73\x74\x61\x6c\x6c")){
NXSoftwareUpdateDaemon::reportUpdateStartInstall ();
NXSoftwareUpdateDaemon::reportInstallInProgress ();}}else{Logger::warning (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x2d\x2d\x75\x70\x64\x61\x74\x65\x20"
.$mode).
"\x20\x2d\x2d\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x27\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x20\x27"
).$exit_value)."\x27\x2e"));if (($mode eq "\x63\x68\x65\x63\x6b")){
NXSoftwareUpdateDaemon::reportUpdateCheckFailed ($exit_value);}elsif (($mode eq 
"\x64\x6f\x77\x6e\x6c\x6f\x61\x64")){
NXSoftwareUpdateDaemon::reportUpdateDownloadFailed ($exit_value);}elsif (($mode 
eq "\x69\x6e\x73\x74\x61\x6c\x6c")){
NXSoftwareUpdateDaemon::reportUpdateInstallFailed ($exit_value);}}return (
(0x04d7+ 3297-0x11b8));}sub setPidForCheckUpdate{(my $pid=shift (@_));
Common::NXProcess::setCallbackSIGCHLD ($pid,(\&handleCheckUpdateExit));return;}
sub setPidForDownloadUpdate{(my $pid=shift (@_));
Common::NXProcess::setCallbackSIGCHLD ($pid,(\&handleDownloadUpdateExit));return
;}sub setPidForInstallUpdate{(my $pid=shift (@_));
Common::NXProcess::setCallbackSIGCHLD ($pid,(\&handleInstallUpdateExit));return;
}sub __processCheckUpdateExit{if (($checkExitStatus eq (""))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x2e"
);return ((0x035c+ 2847-0x0e7b));}if (($checkStdOutBuffer eq (""))){
Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x73\x74\x64\x6f\x75\x74\x20\x62\x75\x66\x66\x65\x72\x2e"
);return ((0x0b14+ 575-0x0d53));}__removePidFile ((0x0b6c+ 5996-0x22d7));
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x50\x72\x6f\x63\x65\x73\x73\x20\x63\x68\x65\x63\x6b\x20\x75\x70\x64\x61\x74\x65\x20\x62\x75\x66\x66\x65\x72\x20\x27"
.$checkStdOutBuffer)."\x27\x2e"));if (($checkStdOutBuffer=~ /Installation is up to date/ )
){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4e\x6f\x20\x75\x70\x64\x61\x74\x65\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"
);NXSoftwareUpdateDaemon::reportUpdateNotAvailable ();}elsif ((
$checkStdOutBuffer=~ /Update version (.*) available/ )){(my $version=$1);
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x27"
.$version)."\x27\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"));if (
NXSoftwareUpdateDaemon::isForceCheck ()){
NXSoftwareUpdateDaemon::reportUpdateAvailable ($version);}else{
handleBackgroundUpdate ("\x64\x6f\x77\x6e\x6c\x6f\x61\x64");}}elsif ((
$checkStdOutBuffer=~ /Software update check failed, error is: (.*)./ )){(my $error
=$1);NXSoftwareUpdateDaemon::reportUpdateCheckFailed ($error);}elsif ((
$checkExitStatus!=(0x20a6+  38-0x20cc))){
NXSoftwareUpdateDaemon::reportUpdateCheckFailed ($checkExitStatus);}else{
Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x63\x68\x65\x63\x6b\x20\x75\x70\x64\x61\x74\x65\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$checkStdOutBuffer)."\x27\x2e"));}($checkStdOutBuffer=undef);($checkExitStatus=
undef);return;}sub handleCheckUpdateExit{(my $pid=shift (@_));(my $code=shift (
@_));($checkExitStatus=$code);if ((($checkExitStatus==(0x0ebf+ 1441-0x1460))or (
$checkExitStatus==(0x095a+ 704-0x0b1b)))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
);}else{Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20\x27"
.$code)."\x27\x2e"));}__processCheckUpdateExit ();
NXSoftwareUpdateDaemon::resetUpdateMode ();}sub handleDownloadUpdateExit{(my $clientPid
=shift (@_));(my $exit_status=shift (@_));__removePidFile ((0x00ff+ 1277-0x05fb)
);NXSoftwareUpdateDaemon::resetUpdateMode ();if (($exit_status==
(0x0027+ 1626-0x0681))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
);NXSoftwareUpdateDaemon::reportUpdateDownloadSuccessfully ();if ((
getLastAskForUpdate ()<=(0x02b5+ 304-0x03e5))){__handleAskForUpdate ();if ((
$pendingVersionInstallOnStartup>(0x1aa4+ 2019-0x2287))){(
$pendingVersionInstallOnStartup=(-(0x0917+ 1997-0x10e3)));}}}else{
Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x44\x6f\x77\x6e\x6c\x6f\x61\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x20\x27"
.$exit_status)."\x27\x2e"));NXSoftwareUpdateDaemon::reportUpdateDownloadFailed (
$exit_status);}return;}sub handleInstallUpdateExit{(my $clientPid=shift (@_));(my $exit_status
=shift (@_));if (($exit_status==(0x0304+ 6874-0x1dde))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x49\x6e\x73\x74\x61\x6c\x6c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
);NXSoftwareUpdateDaemon::reportUpdateInstallFinished ($exit_status);}else{
Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x49\x6e\x73\x74\x61\x6c\x6c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x20\x27"
.$exit_status)."\x27\x2e"));NXSoftwareUpdateDaemon::reportUpdateInstallFailed (
$exit_status);}($NXUpdate::clientPid=(0x1154+ 3924-0x20a8));
NXSoftwareUpdateDaemon::resetUpdateMode ();
NXSoftwareUpdateDaemon::resetInstallPid ();__removePidFile (
(0x0c48+ 1012-0x103b));return;}sub checkIfReadyBackgroundUpdate{(my $serverMinorVersion
=(""));(my $serverPatchVersion=(""));if (($GLOBAL::SOFTWARE_MIN_VERSION=~ /(\d+)\.(\d+)/ )
){($serverMinorVersion=$1);($serverPatchVersion=$2);}(my $pendingVersion=
__getPendingVersion ());if ((($pendingVersion ne (""))and ($pendingVersion=~ /(\d+)\.(\d+)\.(\d+)/ )
)){(my $pendingMajorVersion=$1);(my $pendingMinorVersion=$2);(my $pendingPatchVersion
=$3);if (((($pendingMajorVersion>$GLOBAL::SOFTWARE_MAJ_VERSION)or ((
$pendingMajorVersion>=$GLOBAL::SOFTWARE_MAJ_VERSION)and ($pendingMinorVersion>
$serverMinorVersion)))or ((($pendingMajorVersion>=$GLOBAL::SOFTWARE_MAJ_VERSION)
and ($pendingMinorVersion>=$serverMinorVersion))and ($pendingPatchVersion>
$serverPatchVersion)))){Logger::debug (
"\x55\x70\x64\x61\x74\x65\x73\x20\x61\x72\x65\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x74\x6f\x20\x62\x65\x20\x69\x6e\x73\x74\x61\x6c\x6c\x65\x64\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x2e"
);if ((isAutomaticInstallEnabled ()==(0x1459+ 1599-0x1a98))){(my $sessionID=
__getPhysicalSession ());($pendingVersionInstallOnStartup=(0x0bb6+ 6741-0x260a))
;setLastCheck ();checkIfAskForInstallUpdate ($sessionID);undef ($sessionID);}
else{handleBackgroundUpdate ("\x69\x6e\x73\x74\x61\x6c\x6c");}}else{
Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x73\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x2c\x20\x72\x65\x6d\x6f\x76\x69\x6e\x67\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x75\x70\x64\x61\x74\x65\x20\x66\x69\x6c\x65\x2e"
);__deletePendingVersion ();}}return;}sub checkIgnoreVersion{(my $serverMinorVersion
=(""));(my $serverPatchVersion=(""));if (($GLOBAL::SOFTWARE_MIN_VERSION=~ /(\d+)\.(\d+)/ )
){($serverMinorVersion=$1);($serverPatchVersion=$2);}(my $ignoreVersion=
__getIgnoreVersion ());if ((($ignoreVersion ne (""))and ($ignoreVersion=~ /(\d+)\.(\d+)\.(\d+)/ )
)){(my $ignoreMajorVersion=$1);(my $ignoreMinorVersion=$2);(my $ignorePatchVersion
=$3);if (((($ignoreMajorVersion>$GLOBAL::SOFTWARE_MAJ_VERSION)or ((
$ignoreMajorVersion>=$GLOBAL::SOFTWARE_MAJ_VERSION)and ($ignoreMinorVersion>
$serverMinorVersion)))or ((($ignoreMajorVersion>=$GLOBAL::SOFTWARE_MAJ_VERSION)
and ($ignoreMinorVersion>=$serverMinorVersion))and ($ignorePatchVersion>
$serverPatchVersion)))){Logger::debug2 (((
"\x49\x6e\x69\x74\x61\x6c\x69\x7a\x65\x64\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x77\x69\x74\x68\x3a\x20"
.$ignoreVersion)."\x2e"));($NXUpdate::ignoreVersion=$ignoreVersion);}elsif ((
$ignoreVersion ne (""))){Logger::debug2 (
"\x52\x65\x6d\x6f\x76\x65\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x20\x61\x62\x6f\x75\x74\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);__deleteIgnoreVersion ();}}return;}sub isUpdateEnabled{if ((getUpdateFrequency
 ()>(0x00d7+ 5243-0x1552))){if (($updateMode==(-(0x1f0b+ 783-0x2219)))){
__getUpdateMode ();}if ((($updateMode==$SilentUpdateMode)or ($updateMode==
$BackgroundUpdateMode))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x6d\x6f\x64\x65\x20\x27"
.$updateMode)."\x27\x2e"));return ((0x037c+ 3307-0x1066));}}Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x182b+ 1236-0x1cff));}sub isBackgroundMode{if (($updateMode==(-
(0x01d5+ 2972-0x0d70)))){__getUpdateMode ();}if (($updateMode==
$BackgroundUpdateMode)){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x27\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x27\x2e"
);return ((0x00ab+ 2965-0x0c3f));}return ((0x03f4+ 4007-0x139b));}sub 
__isSilentMode{if (($updateMode==(-(0x0a04+ 5256-0x1e8b)))){__getUpdateMode ();}
if (($updateMode==$SilentUpdateMode)){return ((0x0e4f+ 4399-0x1f7d));}return (
(0x0b2a+ 4518-0x1cd0));}sub setUpdateMode{(my $mode=shift (@_));if (
isCorrectUpdateMode ($mode)){($updateMode=$mode);Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x76\x61\x6c\x75\x65\x20\x27"
.$updateMode)."\x27\x2e"));}else{($updateMode=NXLicense::getUpdateMode ());
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x6d\x6f\x64\x65\x20\x75\x73\x69\x6e\x67\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x27"
.$updateMode)."\x27\x2e"));}if ((not (Common::NXFile::isExists (
getUpdateFilePath ())))){(my $content=__tryToGetUpdateFileContentFromMemory ());
Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x73\x65\x74\x55\x70\x64\x61\x74\x65\x4d\x6f\x64\x65\x20\x75\x70\x64\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2c\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x69\x74\x20\x77\x69\x74\x68\x20\x76\x61\x6c\x75\x65\x3a\x20"
.$content)."\x2e"));saveInfoToFile ($content);return ((0x0809+ 6264-0x2081));}
else{return (__updateFile ());}}sub __getUpdateMode{if ((not (
Common::NXFile::isExists (getUpdateFilePath ())))){($updateMode=
NXLicense::getUpdateMode ());return ((0x0227+ 3264-0x0ee7));}(my $mode=
__getInformationFromUpdateFile ($updateModeIndex));if (isCorrectUpdateMode (
$mode)){($updateMode=$mode);return ($updateMode);}($updateMode=
NXLicense::getUpdateMode ());return ($updateMode);}sub isAutomaticInstallEnabled
{if (($automaticInstall==(-(0x14a7+ 1197-0x1953)))){__getAutomaticInstall ();}if
 (($automaticInstall==(0x0b9f+ 2173-0x141b))){return ((0x06a4+ 2177-0x0f24));}
return ((0x0168+ 9136-0x2518));}sub __getAutomaticInstall{if ((not (
Common::NXFile::isExists (getUpdateFilePath ())))){($automaticInstall=
(0x05cf+ 4497-0x1760));return ((0x0ed6+ 3191-0x1b4d));}(my $value=
__getInformationFromUpdateFile ($automtaicInstallIndex));if (($value ne (""))){
if (($value=~ /^[0,1]$/ )){($automaticInstall=$value);return ($automaticInstall)
;}}($automaticInstall=(0x00a1+ 8592-0x2231));return ($automaticInstall);}sub 
killUpdateIfPidFileExists{__setPidFilePath ();(my $filename=__getPidFilePath ())
;if ((not (Common::NXFile::isExists ($filename)))){return;}killUpdate ();return;
}sub killUpdate{main::nxrequire (
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e"
);if (((isUpdateEnabled ()==(0x1979+ 2028-0x2165))and (
NXSoftwareUpdateDaemon::isWorking ()==(0x150c+ 1294-0x1a1a)))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x6b\x69\x70\x20\x6b\x69\x6c\x6c\x20\x66\x6f\x72\x20\x6e\x6f\x74\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x2e"
);return ((0x0631+ 7202-0x2253));}__readPid ();(my $updatePid=$updatePid);if (
NXSoftwareUpdateDaemon::isForceInstall ()){($updatePid=
NXSoftwareUpdateDaemon::getInstallPid ());}if (($updatePid==
(0x08fc+ 4698-0x1b56))){Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x53\x6b\x69\x70\x20\x6b\x69\x6c\x6c\x20\x66\x6f\x72\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x50\x49\x44\x2e"
);NXSoftwareUpdateDaemon::reportUpdateCancelledFailed ();return (
(0x1df9+ 2271-0x26d8));}Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$updatePid)."\x27\x2e"));NXSoftwareUpdateDaemon::reportUpdateCancelled ();if (
Common::NXProcess::isProcessRunning ($updatePid)){
Common::NXProcess::signalProcessByRestrictedScript ($updatePid,
Common::NXProcess::getSignalKill ());}NXSoftwareUpdateDaemon::resetInstallPid ()
;__removePidFile ((0x0439+ 829-0x0775));}sub runNXPostUpdate{(my $nxexecCommand=
NXTools::getNXExecCommand ());if ((not (-x ($nxexecCommand)))){Logger::debug (((
"\x6e\x6f\x20".$nxexecCommand)."\x20\x66\x69\x6c\x65"));return;}if ((not (
Common::NXFile::isExists ($GLOBAL::SCRIPT_NXPOSTUPDATE)))){Logger::debug (((
"\x6e\x6f\x20\x5b".$GLOBAL::SCRIPT_NXPOSTUPDATE)."\x5d\x20\x66\x69\x6c\x65"));
return;}my (@command,@parameters);push (@parameters,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");push (@command,(("\x22".$nxexecCommand).
"\x22"));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");push
 (@command,(("\x22".$GLOBAL::SCRIPT_NXPOSTUPDATE)."\x22"));(my ($cmd_err,
$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));}sub 
shutdown{if ((isUpdateEnabled ()==(0x06a9+  14-0x06b7))){return (
(0x1246+ 3266-0x1f08));}if ((($updatePid>(0x01b5+ 9486-0x26c3))and 
Common::NXProcess::isProcessRunning ($updatePid))){killClient ($updatePid);
__removePidFile ((0x0b19+ 5455-0x2067));}}sub killClient{(my $clientPid=shift (
@_));Common::NXProcess::signalProcessByRestrictedScript ($clientPid,
Common::NXProcess::getSignalKill ());}sub readInfoFromFileFD{(my $FH=shift (@_))
;(my $initialize=(shift (@_)||(0x0571+ 7095-0x2128)));(my $info=(""));(my $readBytes
=(0x05c7+ 5390-0x1ad5));if (((not (defined ($FH)))or ($FH<=(0x05df+ 4658-0x1811)
))){(my $error=libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());
(my $errorstring=libnxh::NXGetErrorString ());Logger::debug (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x46\x44\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$infoType)."\x20\x66\x69\x6c\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").
$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));(my $content=
__tryToGetUpdateFileContentFromMemory ());Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x46\x44\x3a\x20\x55\x73\x65\x20\x76\x61\x6c\x75\x65\x73\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x3a\x20"
.$content)."\x2e"));return ((-(0x0a97+ 1058-0x0eb8)),$content);}else{($readBytes
=main::nxread ($FH,(\$info),$readSize));chomp ($info);}Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x46\x44\x3a\x20\x52\x65\x61\x64\x20"
.$readBytes)."\x20\x62\x79\x74\x65\x73\x3a\x20").$info)."\x2e"));(my $validatedContent
=validateUpdateFileContent ($info,$initialize));return ($readBytes,
$validatedContent);}sub readInfoFromFile{(my $initialize=(shift (@_)||
(0x02f2+ 7965-0x220f)));(my $updateFile=getUpdateFilePath ());(my $FH=
main::nxopen ($updateFile,($NXBits::O_RDWR+$NXBits::O_CREAT),
$UpdateFilePermissions));if (((not (defined ($FH)))or ($FH<=
(0x112a+ 1730-0x17ec)))){(my $error=libnxh::NXGetError ());(my $errorname=
libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return ((-
(0x077c+ 7772-0x25d7)));}if (main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x2255+  47-0x2281)));if (((not (
defined ($ret)))or ($ret<=(0x08ec+ 3926-0x1842)))){(my $error=libnxh::NXGetError
 ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH).
"\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));(my $content
=__tryToGetUpdateFileContentFromMemory ());Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x66\x6f\x46\x72\x6f\x6d\x46\x69\x6c\x65\x3a\x20\x55\x73\x65\x20\x76\x61\x6c\x75\x65\x73\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x3a\x20"
.$content)."\x2e"));main::nxclose ($FH);return ($content);}else{my ($lineRead);
main::nxread ($FH,(\$lineRead),$readSize);(my $info=$lineRead);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=libnxh::NXFileUnlock 
($FH));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$exit_value)."\x2e"));main::nxclose ($FH);if ((not (defined ($info)))){($info=
(""));}else{chomp ($info);}(my $validatedContent=validateUpdateFileContent (
$info,$initialize));return ($validatedContent);}}sub saveInfoToFile{(my $info=
shift (@_));(my $FH=(shift (@_)||(0x0689+ 2064-0x0e99)));(my $readBytes=(shift (
@_)||(0x1207+ 3056-0x1df7)));(my $unlock=(0x19a0+ 1063-0x1dc7));(my $updateFile=
getUpdateFilePath ());if (((not (defined ($FH)))or ($FH<=(0x0aa6+ 1327-0x0fd5)))
){($FH=main::nxopen ($updateFile,(($NXBits::O_WRONLY+$NXBits::O_CREAT)+
$NXBits::O_TRUNC),$UpdateFilePermissions));if (
main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}}else{($unlock=
(0x1567+ 4141-0x2593));}if ((not (defined ($FH)))){(my $error=libnxh::NXGetError
 ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$updateFile).
"\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
).$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),
(0x2550+ 334-0x269e));return ((0x11c1+ 3190-0x1e36));}if (($unlock==
(0x0d45+ 1639-0x13ab))){Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x42\x65\x67\x69\x6e\x28"
.$FH)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $ret=libnxh::NXFileBegin ($FH));
Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x42\x65\x67\x69\x6e\x28"
.$FH)."\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$ret)."\x2e"));}(my $data=$info);if (((($unlock==(0x00b7+ 5809-0x1767))and (
$readBytes>(0x1769+  20-0x177d)))and ($readBytes>length ($info)))){(my $fill=(
"\x00" x ($readSize-length ($info))));($data.=$fill);}if ((main::nxwrite ($FH,
$data)==(-(0x061b+ 3555-0x13fd)))){(my $error=libnxh::NXGetError ());(my $errorname
=libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((((((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"),(0x006a+ 393-0x01f3));
if (($unlock==(0x12ef+ 4886-0x2604))){Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=libnxh::NXFileUnlock 
($FH));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$exit_value)."\x2e"));}main::nxclose ($FH);return ((0x057d+ 6456-0x1eb4));}if ((
$unlock==(0x02b7+ 7133-0x1e93))){Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=libnxh::NXFileUnlock 
($FH));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x55\x6e\x6c\x6f\x63\x6b\x28"
.$FH)."\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$exit_value)."\x2e"));}main::nxclose ($FH);Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x73\x61\x76\x65\x49\x6e\x66\x6f\x54\x6f\x46\x69\x6c\x65\x3a\x20\x53\x61\x76\x65\x64\x20\x27"
.$info)."\x27\x20\x69\x6e\x20\x27").$updateFile)."\x27\x2e"));return (
(0x0920+ 7480-0x2658));}sub sendMessageToServerStartup{(my $ignore=shift (@_));(my $serverMonitorPid
=NXClientSystemDaemons::getServerDaemonPid ());if (($serverMonitorPid==(-
(0x0541+ 7665-0x2331)))){return (undef);}if (($serverMonitorPid==$ $)) {
 return
 ((-(0x1680+ 2942-0x21fd)));}(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPDATE_IGNORE_TO_SERVER_STARTUP_MONITOR)."\x20").$ignore)."\x0a"));my (
$response);if (NXClientSystemDaemons::openConnection ()){if (
NXClientSystemDaemons::sendMessage ($message)){($response=
NXClientSystemDaemons::parseMessageFromServer ((0x019d+ 7619-0x1f5b)));}else{
return (undef);}NXClientSystemDaemons::closeConnection ();}else{return (undef);}
Logger::debug2 (((
"\x48\x61\x6e\x64\x6c\x65\x72\x20\x75\x70\x64\x61\x74\x65\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x3a\x20\x27"
.$response)."\x27\x2e"));return ($response);}sub __saveIgnoreVersion{(my $ignore
=shift (@_));(my $updateFile=getUpdateFilePath ());(my $FH=main::nxopen (
$updateFile,($NXBits::O_RDWR+$NXBits::O_CREAT),$UpdateFilePermissions));if (((
not (defined ($FH)))or ($FH<=(0x0ca3+ 2060-0x14af)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x6c\x6f\x63\x6b\x20\x66\x69\x6c\x65\x20\x27"
.$updateFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return ((-
(0x07d0+ 5565-0x1d8c)));}if (main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x0f74+ 4251-0x200c)));if (((not (
defined ($ret)))or ($ret<=(0x0781+ 5984-0x1ee1)))){Logger::warning (((
"\x5f\x5f\x73\x61\x76\x65\x49\x67\x6e\x6f\x72\x65\x56\x65\x72\x73\x69\x6f\x6e\x3a\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));main::nxclose ($FH);
return;}(my ($readBytes,$validatedContent)=readInfoFromFileFD ($FH,
(0x19dc+ 2230-0x2292)));(my (@con)=split ( /:/ ,$validatedContent,
(0x0b93+ 5987-0x22f6)));($ignoreVersion=$ignore);(my $newContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());saveInfoToFile ($newContent
,$FH,$readBytes);}sub setUpdateIgnoreMessage{(my $ignore=shift (@_));
Logger::debug2 (((
"\x53\x65\x74\x20\x75\x70\x64\x61\x74\x65\x20\x69\x67\x6e\x6f\x72\x65\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x74\x6f\x3a\x20"
.$ignore)."\x2e"));($ignoreVersion=$ignore);return;}sub handeUpdateIgnoreMessage
{(my $ignore=shift (@_));__saveIgnoreVersion ($ignore);
sendMessageToServerStartup ($ignore);return;}sub isCorrectUpdateMode{(my $mode=
shift (@_));if (((not (defined ($mode)))or ($mode eq ("")))){return (
(0x0868+ 3523-0x162b));}if (($mode=~ /^[0,1,2]$/ )){return (
(0x020a+ 8663-0x23e0));}return ((0x0961+ 3195-0x15dc));}sub 
handleMessageUpdateRemovePid{(my $line=shift (@_));(my $pid=(""));(my $isEAGAIN=
(0x0646+ 4501-0x17db));if (($line=~ s/^NX> $GLOBAL::MSG_UPDATE_REMOVE_PID pid=(.*) eagain=(.*)$//g )
){($pid=main::urldecode ($1));($isEAGAIN=main::urldecode ($2));}elsif (($line=~ s/^NX> $GLOBAL::MSG_UPDATE_REMOVE_PID pid=(.*)$//g )
){($pid=main::urldecode ($1));}else{Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x4d\x65\x73\x73\x61\x67\x65\x2e"
);return ((0x1125+ 5511-0x26ab));}if ((($pid ne (""))and ($pid>
(0x0048+ 2609-0x0a79)))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x73\x65\x72\x76\x65\x72\x20\x67\x6f\x74\x20\x70\x69\x64\x3a\x20"
.$pid)."\x2e"));handleClientUpdateExit ($isEAGAIN);return ((0x14f7+ 2048-0x1cf7)
);}else{Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x4d\x65\x73\x73\x61\x67\x65\x2c\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x69\x64\x2e"
);return ((0x011b+ 5217-0x157b));}}sub handleMessageUpdatePid{(my $line=shift (
@_));(my $socket=shift (@_));my ($pid);Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x6c\x69\x6e\x65\x20\x3d\x20\x5b".$line
)."\x5d\x20\x73\x6f\x63\x6b\x65\x74\x20\x5b").$socket)."\x5d\x2e"));if (($line=~ s/^NX> $GLOBAL::MSG_UPDATE_PID (.*)$//g )
){($pid=main::urldecode ($1));}else{Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x4d\x65\x73\x73\x61\x67\x65\x2e"
);return ((0x03b2+ 645-0x0636));}(my $sessionID=
NXLocalSession::getSessionIdByNodeSocket ($socket));if (((not (defined (
$sessionID)))or ($sessionID eq ("")))){Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x49\x44\x2e"
);return ((0x1d43+ 1288-0x224a));}if ((($pid ne (""))and ($pid>
(0x09e8+ 301-0x0b15)))){Logger::debug (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x73\x65\x72\x76\x65\x72\x20\x67\x6f\x74\x20\x70\x69\x64\x3a\x20"
.$pid)."\x2e"));saveClientPid ($pid,$sessionID);return ((0x0e81+ 5433-0x23ba));}
else{Logger::error (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x4d\x65\x73\x73\x61\x67\x65\x2c\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x69\x64\x2e"
);return ((0x1bca+ 2113-0x240a));}}sub handleUpdateCommand{Logger::debug (
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x45\x78\x65\x63\x75\x74\x69\x6e\x67\x20\x75\x70\x64\x61\x74\x65\x20\x73\x63\x72\x69\x70\x74\x2e"
);(my $CommandSetup=(((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x63\x72\x69\x70\x74\x73").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x74\x75\x70"
).$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72"));(my (@command)=
());(@command=($GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",
main::shell_quote ($CommandSetup,"\x2d\x2d\x75\x70\x64\x61\x74\x65")));(my (
@options)=());(my $error=main::nxExecCommand ((\@command),(\@options)));if ((
$error ne (""))){Logger::warning ((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x75\x70\x64\x61\x74\x65\x20\x73\x63\x72\x69\x70\x74\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$error));Common::NXMsg::send_response (
"\x65\x47\x55\x49\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x4f\x66\x43\x6f\x6d\x6d\x61\x6e\x64\x46\x61\x69\x6c\x65\x64"
,$CommandSetup,$error);}}sub __updateFile{(my $file=getUpdateFilePath ());(my $FH
=main::nxopen ($file,($NXBits::O_RDWR+$NXBits::O_CREAT),$UpdateFilePermissions))
;if (((not (defined ($FH)))or ($FH<=(0x09f9+ 1011-0x0dec)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".$file
)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error)."\x2c\x20").
$errorname)."\x2c\x20").$errorstring)."\x2e"));return ((0x08ed+ 4071-0x18d3));}
if (main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($updateFile);}(my $ret=
main::tryToLockDescriptorUntilTimeout ($FH,(0x09fc+ 6414-0x2307)));if (((not (
defined ($ret)))or ($ret<=(0x0d30+ 955-0x10eb)))){Logger::warning (((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x3a\x75\x70\x64\x61\x74\x65\x46\x69\x6c\x65\x20\x74\x72\x79\x54\x6f\x4c\x6f\x63\x6b\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x55\x6e\x74\x69\x6c\x54\x69\x6d\x65\x6f\x75\x74\x28"
.$FH)."\x2c\x20\x33\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));main::nxclose ($FH);
return ((0x03b4+ 2610-0x0de5));}(my $newContent=
__getUpdateFileContentStringBaseOnCurrentGlobals ());return (saveInfoToFile (
$newContent,$FH,$readBytes));}sub stdOutCallback{(my $fd=shift (@_));(my $bytes=
main::nxread ($fd,(\$checkStdOutBuffer),65536));Logger::debug (((((
"\x4e\x58\x55\x70\x64\x61\x74\x65\x3a\x20\x43\x68\x65\x63\x6b\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$checkStdOutBuffer)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$fd)."\x2e"));(
$checkStdOutBuffer.="\x0a");Common::NXSelector::removeFromGlobalSelector ($fd);
main::nxclose ($fd);__processCheckUpdateExit ();}return ((0x04f2+ 7949-0x23fe));
