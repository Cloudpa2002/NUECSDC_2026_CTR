#!/bin/bash
######################################################################
#                                                                    #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.     #
#                                                                    #
#  All rights reserved.                                              #
#                                                                    #
######################################################################

RunDir=${0%nxcat.sh}
RestrictedDir=$(cd "${RunDir}" && pwd)

PARAMS_COUNT=6
USER="$4"
FILE="$6"

. "${RestrictedDir}"/nxfunct.sh

HOME_DIR=$(/bin/bash -c "cd ~${USER} 2>/dev/null && pwd")

if test -z "${HOME_DIR}"; then
  errorMsg "Cannot retrieve user home directory." "1"
fi

FILE_PATH="$HOME_DIR/.nx/$FILE"

if test -f "$FILE_PATH"; then
  ${COMMAND_CAT} "$FILE_PATH"
else
  errorMsg "Cannot stat file: $FILE_PATH." "1"
fi
