############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXReconnect;no warnings;($mainServerSocket=undef);(
$waitingForMainServerAnswer=(0x0061+ 264-0x0169));($__reconnectSocket=(-
(0x1267+ 910-0x15f4)));($__reconnectTimestamp=(-(0x011d+ 3971-0x109f)));(
$__reconnectSessionId=(-(0x0a07+ 4250-0x1aa0)));($__ref_monitorSelect=undef);(
@__waitingForReconnectToFinish=());($__isReconnectWaitingForDisconnectAnswer=
(0x0a20+ 2886-0x1566));($__agentReconnecting=(0x153c+ 3794-0x240e));sub 
requestDisconnect{($mainServerSessionId=shift (@_));(my $mainServerSocket=
sendRequestDisconnect ($mainServerSessionId));if ((defined ($mainServerSocket)
and ($mainServerSocket!=(-(0x1ba3+ 2776-0x267a))))){setMainServerSocket (
$mainServerSocket);startWaitingOnMainServerAnswer ();
setDisconnectSessionNotConfirmed ();return ((0x1460+ 3387-0x219b));}else{
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);return ((0x1533+  29-0x154f));}}sub sendRequestDisconnect{(my $sessionID=shift
 (@_));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x27\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x72\x65\x71\x75\x65\x73\x74\x27\x20\x74\x6f\x20"
.$sessionID)."\x20\x73\x65\x72\x76\x65\x72\x2e"));my ($message);if (
main::imRemoteServer ()){($message=($GLOBAL::MSG_REQUEST_SUSPEND_AND_WAIT.
"\x20\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x61\x6e\x64\x20\x77\x61\x69\x74\x20\x6f\x6e\x20\x72\x65\x6d\x6f\x74\x65\x2e"
));}else{($message=($GLOBAL::MSG_REQUEST_SUSPEND_AND_WAIT.
"\x20\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x61\x6e\x64\x20\x77\x61\x69\x74\x2e"
));}return (main::send_command_to_server ($sessionID,$message,
"\x6e\x6f\x74\x63\x6c\x6f\x73\x65"));}sub startWaitingOnMainServerAnswer{(
$waitingForMainServerAnswer=(0x11ed+ 2812-0x1ce8));}sub 
stopWaitingOnMainServerAnswer{($waitingForMainServerAnswer=(0x20b7+ 166-0x215d))
;}sub isWaitingForMainServerAnswer{if (($waitingForMainServerAnswer==
(0x012f+ 6308-0x19d2))){return ((0x00d7+ 2246-0x099c));}return (
(0x0576+ 5248-0x19f6));}sub isNotWaitingForMainServerAnswer{return ((!
isWaitingForMainServerAnswer ()));}sub __getStopWaitingMessage{return ((
$GLOBAL::MSG_REQUEST_SUSPEND_AND_WAIT.
"\x20\x53\x74\x6f\x70\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
));}sub getMessageConfirmDisconnect{return (
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x2c\x20\x72\x65\x61\x64\x79\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);}sub getMessageAnotherReconnectInProgress{return (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x69\x6e\x20\x70\x72\x6f\x67\x72\x65\x73\x73\x2e"
);}sub getMessageAnotherReconnectFinished{return (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2c\x20\x74\x72\x79\x20\x61\x67\x61\x69\x6e\x2e"
);}sub setMainServerSocket{($mainServerSocket=shift (@_));}sub 
getMainServerSocket{return ($mainServerSocket);}sub isAlreadySessionDisconnected
{if (isWaitingForMainServerAnswer ()){return ((0x2146+ 409-0x22df));}if (
isDisconnectSessionConfirmed ()){return ((0x0622+ 5368-0x1b19));}return (
(0x02a1+ 6081-0x1a62));}sub handleClientExit{(my $mainServerSocket=
getMainServerSocket ());if (defined ($mainServerSocket)){main::nxclose (
$mainServerSocket);setMainServerSocket (undef);}}sub 
setDisconnectSessionConfirmed{($disconnectSessionConfirmed=(0x0453+ 4282-0x150c)
);}sub setDisconnectSessionNotConfirmed{($disconnectSessionConfirmed=
(0x0bfb+ 1215-0x10ba));}sub isDisconnectSessionConfirmed{if ((
$disconnectSessionConfirmed==(0x1775+ 278-0x188a))){return (
(0x16a2+ 2591-0x20c0));}return ((0x09e1+ 2888-0x1529));}sub 
setDisconnectSessionTryAgain{($disconnectSessionTryAgain=(0x040d+ 6458-0x1d46));
}sub setDisconnectSessionNotTryAgain{($disconnectSessionTryAgain=
(0x101f+ 691-0x12d2));}sub isDisconnectSessionTryAgain{return (
$disconnectSessionTryAgain);}sub setServerError{($serverError=
(0x153b+ 1698-0x1bdc));}sub isServerError{if (($serverError==
(0x0db7+ 3311-0x1aa5))){return ((0x1653+ 2874-0x218c));}return (
(0x03dc+ 2183-0x0c63));}sub handleServerError{if (isServerError ()){return (
(0x123f+ 218-0x1318));}return ((0x03e6+ 6366-0x1cc4));}sub __callbackMainServer{
(my $self=shift (@_));(my $handleHash=shift (@_));(my $readBuffer=shift (@_));(my $readBytes
=shift (@_));($buffer.=$readBuffer);Logger::debug ((
"\x43\x75\x72\x72\x65\x6e\x74\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x62\x75\x66\x66\x65\x72\x3a\x20"
.$buffer));while (($buffer ne (""))){my ($line);(($buffer,$line)=
__getLineAndBufferLeft ($buffer));if (($line ne (""))){__handleMainServerMessage
 ($line,$handleHash,$self);}}}sub __callbackMainServerSocketClose{(my $self=
shift (@_));(my $handleHash=shift (@_));Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6d\x61\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);$self->removeAndCloseHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});if ((
not (isAlreadySessionDisconnected ()))){handleCannotDisconnectAnotherReconnect 
();}}sub isDisconnectSocket{(my $socket=shift (@_));if (($__reconnectSocket==
$socket)){Logger::debug ((("\x46\x44\x23".$socket).
"\x20\x69\x73\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));return ((0x187d+ 2085-0x20a1));}Logger::debug ((("\x46\x44\x23".$socket).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x6f\x63\x6b\x65\x74\x2e"
));return ((0x1686+ 682-0x1930));}sub isNotDisconnectSocket{(my $socket=shift (
@_));return ((!isDisconnectSocket ($socket)));}sub 
saveSocketForSusspendSessionAnswer{(my $socket=shift (@_));(my $ref_select=shift
 (@_));Logger::debug (((
"\x53\x74\x61\x72\x74\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x46\x44\x23"
.$socket)."\x2e"));($__reconnectSocket=$socket);($__ref_monitorSelect=
$ref_select);($__reconnectTimestamp=Common::NXTime::getSecondsSinceEpoch ());}
sub saveSocketWaitingForReconnectToFinish{(my $socket=shift (@_));Logger::debug 
(((
"\x53\x61\x76\x69\x6e\x67\x20\x61\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x46\x44\x23"
.$socket).
"\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x6f\x6e\x65\x20\x74\x6f\x20\x66\x69\x6e\x69\x73\x68\x2e"
));push (@__waitingForReconnectToFinish,$socket);}sub 
informReconnectSessionAboutDisconnect{Logger::debug (
"\x49\x6e\x66\x6f\x72\x6d\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x61\x62\x6f\x75\x74\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);if (($__reconnectSocket!=(-(0x0532+ 6775-0x1fa8)))){if (
__isReconnectWaitingForDisconnectAnswer ()){main::send_reply_to_socket (
$__reconnectSocket,(getMessageConfirmDisconnect ()."\x0a"));
__unsetIsReconnectWaitingForDisconnectAnswer ();}else{setReconnectOver ();}}}sub
 __callbackPlayer{(my $self=shift (@_));(my $handleHash=shift (@_));(my $readBuffer
=shift (@_));(my $readBytes=shift (@_));Logger::warning (((((
"\x55\x6e\x73\x75\x73\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x63\x6c\x69\x65\x6e\x74\x3a\x20"
.$readBytes)."\x20\x27").$readBuffer)."\x27\x2e"));}sub __callbackClosePlayer{
stopWaitingOnMainServerAnswer ();setDisconnectSessionNotConfirmed ();
handleClientExit ();}sub __callbackMainServerSocketTimeout{Logger::warning (
"\x54\x69\x6d\x65\x6f\x75\x74\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x72\x6f\x6d\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x72\x65\x61\x63\x68\x65\x64\x2e"
);stopWaitingOnMainServerAnswer ();setDisconnectSessionNotConfirmed ();
handleCannotDisconnectAnotherReconnect ();}sub isReconnectInProgress{if ((
$__reconnectSocket!=(-(0x04dc+ 3852-0x13e7)))){Logger::debug (((
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x69\x6e\x20\x70\x72\x6f\x67\x65\x73\x73\x20\x6f\x6e\x20\x46\x44\x23"
.$__reconnectSocket)."\x2e"));return ((0x04ed+ 7019-0x2057));}Logger::debug (
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x6e\x6f\x74\x20\x69\x6e\x20\x70\x72\x6f\x67\x65\x73\x73\x2e"
);return ((0x129c+ 3197-0x1f19));}sub setReconnectOver{Logger::debug (((
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x6f\x76\x65\x72\x20\x6f\x6e\x20\x46\x44\x23"
.$__reconnectSocket)."\x2e"));if (($__reconnectSocket!=(-(0x1245+ 4586-0x242e)))
){if (defined ($__ref_monitorSelect)){if ($$__ref_monitorSelect->exists (
$__reconnectSocket)){$$__ref_monitorSelect->remove ($__reconnectSocket);}}
Common::NXSelector::removeFromGlobalSelector ($__reconnectSocket);main::nxclose 
($__reconnectSocket);($__reconnectSocket=(-(0x0bb4+ 2338-0x14d5)));(
$__reconnectSessionId=(-(0x0942+ 4725-0x1bb6)));
__unsetIsReconnectWaitingForDisconnectAnswer ();__unsetAgentReconnecting ();}
__informWaitingSessionsWeAreReadyForReconnect ();}sub handleReconnectTimeout{
Logger::debug (((
"\x48\x61\x6e\x64\x6c\x65\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$__reconnectSocket)."\x2e"));if (($__reconnectSocket!=(-(0x0612+ 7858-0x24c3)))
){(my $time=Common::NXTime::getSecondsSinceEpoch ());if (($time>(
$__reconnectTimestamp+$GLOBAL::timeoutForSessionReconnect))){if (
__isAgentReconnecting ()){Logger::debug (
"\x41\x67\x65\x6e\x74\x20\x69\x73\x20\x73\x74\x69\x6c\x6c\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67\x20\x69\x67\x6e\x6f\x72\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);}else{Logger::warning ((("\x54\x69\x6d\x65\x6f\x75\x74\x20\x6f\x66\x20".
$GLOBAL::timeoutForSessionReconnect).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x66\x6f\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x72\x65\x61\x63\x68\x65\x64\x2e"
));if (($__reconnectSessionId!=(-(0x1600+ 2376-0x1f47)))){Logger::warning (((
"\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20".$__reconnectSessionId).
"\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x66\x69\x6e\x69\x73\x68\x20\x69\x6e\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x74\x69\x6d\x65\x2e"
));NXTerminate::emergencyKillHangedReconnect ($__reconnectSessionId);
NXNodeExec::deleteUser ($__reconnectSessionId,Server::getMySessionID ());(
$__reconnectSessionId=(-(0x1257+ 502-0x144c)));}setReconnectOver ();}}}}sub 
handleReconnectFinished{Logger::debug (
"\x48\x61\x6e\x64\x6c\x65\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2e"
);setReconnectOver ();(my $reconnectSocket=getMainServerSocket ());if (defined (
$reconnectSocket)){setMainServerSocket (undef);
Common::NXSelector::removeFromGlobalSelector ($reconnectSocket);main::nxclose (
$reconnectSocket);}}sub setReconnectSessionId{($__reconnectSessionId=shift (@_))
;Logger::debug (((
"\x53\x65\x74\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$__reconnectSessionId)."\x2e"));}sub setIsReconnectWaitingForDisconnectAnswer{(
$__isReconnectWaitingForDisconnectAnswer=(0x1463+ 4683-0x26ad));}sub 
__unsetIsReconnectWaitingForDisconnectAnswer{(
$__isReconnectWaitingForDisconnectAnswer=(0x1f29+ 234-0x2013));}sub 
__isReconnectWaitingForDisconnectAnswer{return (
$__isReconnectWaitingForDisconnectAnswer);}sub 
__informWaitingSessionsWeAreReadyForReconnect{while ((scalar (
@__waitingForReconnectToFinish)>(0x121a+ 2189-0x1aa7))){(my $socket=shift (
@__waitingForReconnectToFinish));main::send_reply_to_socket ($socket,(
getMessageAnotherReconnectFinished ()."\x0a"));
NXNodeExec::removeHandleFromMonitor ($socket);}}sub 
isSocketWaitingForReconnectFinish{(my $socket=shift (@_));foreach my $waitingSocket
 (@__waitingForReconnectToFinish){if (($socket==$waitingSocket)){return (
(0x0c9d+ 1239-0x1173));}}return ((0x0a9a+ 2795-0x1585));}sub 
isNotSocketWaitingForReconnectFinish{return ((!isSocketWaitingForReconnectFinish
 (@_)));}sub __getLineAndBufferLeft{(my $readBuffer=shift (@_));(my $line=
$readBuffer);if (($readBuffer=~ /^(.*?)\n(.*)$/s )){($line=$1);($readBuffer=$2);
}else{($readBuffer=(""));}return ($readBuffer,$line);}sub 
__handleMainServerMessage{(my $readBuffer=shift (@_));(my $handleHash=shift (@_)
);(my $self=shift (@_));if (($readBuffer eq getMessageConfirmDisconnect ())){
stopWaitingOnMainServerAnswer ();setDisconnectSessionConfirmed ();
SessionStartStateMachine::setNextState (
"\x73\x65\x73\x73\x69\x6f\x6e\x43\x6c\x6f\x73\x65\x64");$self->setExit (
$handleHash,(0x04ff+ 3283-0x11d2),(0x1c9a+ 2318-0x25a8));}elsif (($readBuffer eq
 getMessageAnotherReconnectFinished ())){setDisconnectSessionTryAgain ();(my $mainServerSocket
=getMainServerSocket ());if (defined ($mainServerSocket)){
NXShell::unregisterDescriptor (
"\x4e\x58\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x4d\x61\x69\x6e\x53\x65\x72\x76\x65\x72"
);NXShell::unregisterDescriptor (
"\x4e\x58\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x4d\x61\x69\x6e\x53\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x43\x6c\x6f\x73\x65"
);$self->removeAndCloseHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->
setExit ($handleHash,(0x0f1f+ 4510-0x20bd),(0x04bf+ 4078-0x14ad));
setMainServerSocket (undef);}Logger::debug (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x74\x72\x79\x20\x74\x6f\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x61\x67\x61\x69\x6e\x2e"
);SessionStartStateMachine::setNextState (
"\x74\x72\x79\x54\x6f\x44\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x41\x67\x61\x69\x6e"
);}elsif (($readBuffer eq getMessageAnotherReconnectInProgress ())){$self->
setTimeout ($GLOBAL::timeoutForAnotherReconnectDisconnect);$self->
setCallbackTimeout ((\&__callbackMainServerSocketTimeout));
stopWaitingOnMainServerAnswer ();Logger::debug (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x20\x69\x73\x20\x69\x6e\x20\x70\x72\x6f\x67\x72\x65\x73\x73\x2e"
);SessionStartStateMachine::setNextState (
"\x61\x6e\x6f\x74\x68\x65\x72\x52\x65\x63\x6f\x6e\x6e\x65\x63\x74\x49\x6e\x50\x72\x6f\x67\x72\x65\x73\x73"
);}}sub handleCannotDisconnectAnotherReconnect{setDisconnectSessionNotConfirmed 
();Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x62\x65\x66\x6f\x72\x65\x20\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x2e"
);NXMsg::error (
"\x65\x47\x55\x49\x4e\x6f\x74\x53\x75\x73\x70\x65\x6e\x64\x61\x62\x6c\x65",
"\x6d\x61\x69\x6e",$mainServerSessionId);NXShell::setExitRequest (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);SessionStartStateMachine::setNextState ("\x65\x72\x72\x6f\x72");}sub 
setAgentReconnecting{($__agentReconnecting=(0x0d82+ 2033-0x1572));}sub 
__unsetAgentReconnecting{($__agentReconnecting=(0x1670+ 914-0x1a02));}sub 
__isAgentReconnecting{return ($__agentReconnecting);}return (
(0x0ca3+ 4694-0x1ef8));
