#!/bin/bash
######################################################################
#                                                                    #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.     #
#                                                                    #
#  All rights reserved.                                              #
#                                                                    #
######################################################################

RunDir=${0%nxchmod.sh}
RestrictedDir=$(cd "${RunDir}" && pwd)

PARAMS_COUNT=3

FILE_NAME="$3"

MOD_STRING="a+rw"
FILE_PATH="/tmp/.X11-unix/${FILE_NAME}"

. "${RestrictedDir}"/nxfunct.sh

isRunByServer

${COMMAND_CHMOD} ${MOD_STRING} ${FILE_PATH}
