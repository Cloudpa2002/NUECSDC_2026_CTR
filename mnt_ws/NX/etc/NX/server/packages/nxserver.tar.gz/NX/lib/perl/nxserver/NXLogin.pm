############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXLogin::BEGIN{package NXLogin;no warnings;require NXUser;do{
"\x4e\x58\x55\x73\x65\x72"->import};}sub NXLogin::BEGIN{package NXLogin;no 
warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}
sub NXLogin::BEGIN{package NXLogin;no warnings;require Exception::Configuration;
do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->import};}sub NXLogin::BEGIN{package NXLogin;no warnings;require 
Exception::Internal;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
import};}sub NXLogin::BEGIN{package NXLogin;no warnings;require Exception::Log;
do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->import};}sub 
NXLogin::BEGIN{package NXLogin;no warnings;require Exception::InfoLog;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
import};}sub NXLogin::BEGIN{package NXLogin;no warnings;require 
Exception::NXUser::NotSystemUser;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72"
->import};}package NXLogin;no warnings;require NXMsg;my ($__nxuser);my (
$__foreign_addres);my ($__local_addres);my ($__password_type);my ($__sessionType
);(my $__flagUseNXUsers=(0x07fd+ 2204-0x1098));(my $__flagUseNXPasswords=
(0x1c90+ 991-0x206e));(my $__flagGuestIsLogged=(0x11ab+ 920-0x1543));(my $__flagWebLoginUnrestricted
=(0x1392+ 3061-0x1f87));(my $serverBrowseGuest=(0x1009+ 5367-0x2500));(my $trueGuestLogin
=(0x0e0c+ 2937-0x1985));(my $desktopGuestLogin=(0x0e0c+ 4994-0x218e));(my $virtualDesktopGuestLogin
=(0x0557+ 802-0x0879));(my $physicalDesktopGuestLogin=(0x0591+ 3543-0x1368));(
$loggedUserAdministratorProperty="\x6e\x6f");$absoluteName;$loginFromPlayer;(
$updateLogin=(0x05a2+ 5173-0x19d7));($AuthenticationMethod=(""));(
$AuthenticationMethodSSHSystem=
"\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x67\x69\x6e\x20\x61\x6e\x64\x20\x70\x61\x73\x73\x77\x6f\x72\x64"
);($AuthenticationMethodAnywhere=
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x4e\x65\x74\x77\x6f\x72\x6b");(
$AuthenticationMethodSSHSystemForwardKerberosKey=
"\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x67\x69\x6e\x20\x61\x6e\x64\x20\x4b\x65\x72\x62\x65\x72\x6f\x73"
);($AuthenticationMethodSSHSystemForwardAgentKey=
"\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x67\x69\x6e\x20\x61\x6e\x64\x20\x70\x72\x69\x76\x61\x74\x65\x20\x6b\x65\x79\x20"
);($AuthenticationMethodNXGSS="\x4e\x58\x2d\x6b\x65\x72\x62\x65\x72\x6f\x73");(
$AuthenticationMethodNXPublicKey=
"\x4e\x58\x2d\x70\x72\x69\x76\x61\x74\x65\x2d\x6b\x65\x79");(
$AuthenticationMethodNXQuick=
"\x4e\x58\x20\x51\x75\x69\x63\x6b\x20\x70\x61\x73\x73\x77\x6f\x72\x64");(
$AuthenticationMethodSSHQuick=
"\x53\x53\x48\x20\x51\x75\x69\x63\x6b\x20\x70\x61\x73\x73\x77\x6f\x72\x64");(
$AuthenticationMethodmd5="\x4d\x44\x35");($AuthenticationMethodPassword=
"\x50\x61\x73\x73\x77\x6f\x72\x64");($AuthenticationMethodPasswordDB=
"\x50\x61\x73\x73\x77\x6f\x72\x64\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x64\x61\x74\x61\x62\x61\x73\x65"
);($AuthenticationMethodNXpassword=
"\x4e\x58\x2d\x70\x61\x73\x73\x77\x6f\x72\x64");(
$AuthenticationMethodSSHpassword=
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x6c\x6f\x67\x69\x6e");(
$AuthenticationMethodNXpasswordDB=
"\x4e\x58\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x64\x61\x74\x61\x62\x61\x73\x65"
);($AuthenticationMethodSSHpasswordDB=
"\x53\x53\x48\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x64\x61\x74\x61\x62\x61\x73\x65"
);($AuthenticationMethodOneTimePassword=
"\x4f\x6e\x65\x2d\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x77\x6f\x72\x64");(
$AuthenticationMethodNotRequired=
"\x4e\x6f\x74\x20\x52\x65\x71\x75\x69\x72\x65\x64");(
$forwardingUserToRemoteServer=(0x03d4+ 4184-0x142c));($quasiAdminAuthRequired=
(0x0b12+ 2050-0x1314));($visitor=(""));($visitorHost=(""));($visitorLongName=
(""));($desktopGuest=(0x1ab0+ 2535-0x2497));(my $__connectionMethodSSH=
(0x0464+ 7575-0x21fb));(my $__userLoggedInThroughNXClient=(0x10e5+ 1804-0x17f1))
;($loginServerTypeName="\x6c\x6f\x67\x69\x6e");($userFullName=(""));(
$tokenAuthorizedUser=(""));sub init{(my $param=shift (@_));if ((not (defined (
$param)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->throw (
"\x6b\x65\x79\x20\x27\x45\x6e\x61\x62\x6c\x65\x55\x73\x65\x72\x44\x42\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((($param ne (0x0045+ 1095-0x048c))and ($param ne (0x05e5+ 5961-0x1d2d))))
{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->throw (((
"\x76\x61\x6c\x75\x65\x20\x6f\x66\x20\x6b\x65\x79\x20\x27\x45\x6e\x61\x62\x6c\x65\x55\x73\x65\x72\x44\x42\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$param)."\x27"));}($__flagUseNXUsers=$param);($param=shift (@_));if ((not (
defined ($param)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->throw (
"\x6b\x65\x79\x20\x27\x45\x6e\x61\x62\x6c\x65\x50\x61\x73\x73\x77\x6f\x72\x64\x44\x42\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((($param ne (0x0385+ 2105-0x0bbe))and ($param ne (0x002f+ 2079-0x084d))))
{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e"
->throw (((
"\x76\x61\x6c\x75\x65\x20\x6f\x66\x20\x6b\x65\x79\x20\x27\x45\x6e\x61\x62\x6c\x65\x50\x61\x73\x73\x77\x6f\x72\x64\x44\x42\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$param)."\x27"));}($__flagUseNXPasswords=$param);if ((not (
$__flagUseNXPasswords))){main::nxrequire (
"\x4e\x58\x4e\x73\x73\x55\x73\x65\x72\x4d\x61\x6e\x61\x67\x65\x72");
NXNssUserManager::init ($GLOBAL::AuthorizationTimeout);}}sub setForwardedUser{(my $login
=shift (@_));(my $address=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x75\x73\x65\x72\x20\x6c\x6f\x67\x69\x6e\x20\x27"
.$login)."\x27\x2e"));if ((not (defined ($login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x73\x65\x74\x46\x6f\x72\x77\x61\x72\x64\x65\x64\x55\x73\x65\x72\x3a\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x6c\x6f\x67\x69\x6e\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}my ($result);my ($password);my ($sessionFileData);(my $remoteIp=
NXClientConnection::getRemoteIp ());if ((NXGuestsManager::isGuestByUsername (
$login)or NXGuestsManager::isRequestForNewGuestAccount ($login))){
setGuestIsLogged ();(($result,$login,$password,$sessionFileData)=
NXGuestsManager::getGuestLoginPasswordAndSessionFileData ($login,$remoteIp,
$password));}else{unsetGuestIsLogged ();}($__nxuser=NXUser::new ($login,
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e"))
;setAdministratorPropertyForLoggedUser ();(my $authMethod=getAuthMethod ());
Logger::info ((((((("\x55\x73\x65\x72\x20\x27".$login).
"\x27\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x64\x20\x66\x72\x6f\x6d\x20\x27").
$__foreign_addres).
"\x27\x20\x75\x73\x69\x6e\x67\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20"
).$authMethod)."\x2e"));($__foreign_addres=$address);
checkPerUserNodeConfigurationFile ($login);__setAbsoluteNameForLoggedUser (
$login);}sub set{(my ($nxuser,$foreign_addres,$password_type,$local_addres,
$sessionType)=@_);Logger::debug (((((((((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x20\x6e\x78\x75\x73\x65\x72\x20\x27"
.$nxuser)."\x27\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x27").$foreign_addres).
"\x27\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x27").$password_type).
"\x27\x20\x6c\x6f\x63\x61\x6c\x20\x27").$local_addres)."\x27\x2e"));if ((not (
defined ($nxuser)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x4e\x58\x55\x73\x65\x72\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((not (defined ($foreign_addres)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x66\x6f\x72\x65\x69\x67\x6e\x5f\x61\x64\x64\x72\x65\x73\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((not (defined ($local_addres)))){($local_addres=());}if ((not (defined (
$password_type)))){($password_type="\x75\x6e\x6b\x6e\x6f\x77\x6e");}if ((not (
length ($foreign_addres)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (((
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x66\x6f\x72\x65\x69\x67\x6e\x5f\x61\x64\x64\x72\x65\x73\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$foreign_addres)."\x27"));}(my $login=$nxuser->getLogin);if ((not (length (
$login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (((
"\x27\x4e\x58\x55\x73\x65\x72\x2e\x4c\x6f\x67\x69\x6e\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$login)."\x27"));}if ((((isNotGuestLogged ()||(!isUseNXPasswords ()))and ((not 
(isServerBrowseGuest ()))and (not (
NXGuestsManager::isServerBrowseGuestAccountName ($login)))))and ((not (
isDesktopGuestLogin ()))and (not (NXGuestsManager::isDesktopGuestAccountName (
$login)))))){if ((not (Common::NXCore::isSystemUserExist ($login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72"
->throw ($login);}}Logger::debug (((((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x6e\x78\x75\x73\x65\x72\x20\x27"
.$login).
"\x27\x20\x77\x69\x74\x68\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x61\x64\x64\x72\x65\x73\x73\x20\x27"
).$foreign_addres)."\x27\x2e"));($__nxuser=$nxuser);($__foreign_addres=
$foreign_addres);($__local_addres=$local_addres);($__password_type=
$password_type);($__sessionType=$sessionType);
setAdministratorPropertyForLoggedUser ();(my $authMethod=getAuthMethod ());if ((
$authMethod eq (""))){Logger::error (
"\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"
);NXShell::handle_command ("\x65\x78\x69\x74");}if (($sessionType ne 
"\x76\x69\x72\x74\x75\x61\x6c")){(my $invited=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x49\x4e\x56\x49\x54\x45\x44"));(my $loginToLog=$login);if (
isAuthenticationMethodAnywhere ()){($loginToLog=NXAnywhereAuth::getUsername ());
}(my $text=(""));if (NXAnywhereAuth::isDefaultUser ()){($text=((((((
"\x55\x73\x65\x72\x20\x27".$loginToLog).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e\x20\x66\x72\x6f\x6d\x20\x27").
$__foreign_addres)."\x27").((
"\x20\x75\x73\x69\x6e\x67\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20"
.$authMethod).
"\x2e\x20\x55\x73\x65\x72\x20\x77\x69\x6c\x6c\x20\x63\x6f\x6e\x74\x69\x6e\x75\x65\x20"
)).(("\x77\x6f\x72\x6b\x69\x6e\x67\x20\x61\x73\x20\x27".$login).
"\x27\x20\x73\x79\x73\x74\x65\x6d\x20\x75\x73\x65\x72\x2e")));}elsif ((($invited
 ne (""))and ($invited ne "\x30"))){($text=(((((("\x55\x73\x65\x72\x20\x27".
$loginToLog).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e\x20\x66\x72\x6f\x6d\x20\x27").
$__foreign_addres)."\x27").((
"\x20\x75\x73\x69\x6e\x67\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20"
.$authMethod)."\x2e\x20")).
"\x55\x73\x65\x72\x20\x77\x61\x73\x20\x69\x6e\x76\x69\x74\x65\x64\x20\x62\x79\x20\x74\x68\x65\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x2e"
));}else{($text=((((("\x55\x73\x65\x72\x20\x27".$loginToLog).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e\x20\x66\x72\x6f\x6d\x20\x27").
$__foreign_addres)."\x27").((
"\x20\x75\x73\x69\x6e\x67\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20"
.$authMethod)."\x2e")));}Logger::info ($text);Logger::statusPush ($text);}else{
();}checkPerUserNodeConfigurationFile ($login);__setAbsoluteNameForLoggedUser (
$login);}sub checkPerUserNodeConfigurationFile{(my $username=shift (@_));if (((
$username ne "\x6e\x78")and (not (
NXGuestsManager::isServerBrowseGuestAccountName ($username))))){(my $userNodeConfigFile
=Common::NXPaths::getUserNodeCfgPath ($username));if (main::parse_config_file (
$userNodeConfigFile,main::getListOfNodeConfigurationKeysUsedByServer ())){
Logger::debug (((
"\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x75\x73\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x2e\x20\x46\x69\x6c\x65\x20\x27"
.$userNodeConfigFile).
"\x27\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x20\x6f\x72\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6f\x70\x65\x6e\x2e"
));}}}sub check{(my ($nxuser,$foreign_addres,$password_type,$local_addres)=@_);
if ((not (defined ($nxuser)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x4e\x58\x55\x73\x65\x72\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((not (defined ($foreign_addres)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x66\x6f\x72\x65\x69\x67\x6e\x5f\x61\x64\x64\x72\x65\x73\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6e\x75\x6c\x6c"
);}if ((not (defined ($local_addres)))){($local_addres=());}if ((not (defined (
$password_type)))){($password_type="\x75\x6e\x6b\x6e\x6f\x77\x6e");}if ((not (
length ($foreign_addres)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (((
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x66\x6f\x72\x65\x69\x67\x6e\x5f\x61\x64\x64\x72\x65\x73\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$foreign_addres)."\x27"));}(my $login=$nxuser->getLogin);if ((not (length (
$login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
throw (((
"\x27\x4e\x58\x55\x73\x65\x72\x2e\x4c\x6f\x67\x69\x6e\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$login)."\x27"));}if ((not (Common::NXCore::isSystemUserExist ($login)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72"
->throw ($login);}}sub get{unless (defined ($__nxuser)){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x67\x65\x74\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}return ($__nxuser);}sub getForeignAddres{if ((not (defined ($__nxuser)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x67\x65\x74\x46\x6f\x72\x65\x69\x67\x6e\x41\x64\x64\x72\x65\x73\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}return ($__foreign_addres);}sub getLocalAddres{if ((not (defined ($__nxuser))
)){"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x67\x65\x74\x4c\x6f\x63\x61\x6c\x41\x64\x64\x72\x65\x73\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}return ($__local_addres);}sub getPasswordType{if ((not (defined ($__nxuser)))
){"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x67\x65\x74\x50\x61\x73\x73\x77\x6f\x72\x64\x54\x79\x70\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}return ($__password_type);}sub reset{if ((not (defined ($__nxuser)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x66\x6f\x4c\x6f\x67"->
throw (
"\x6d\x65\x74\x68\x6f\x64\x20\x72\x65\x73\x65\x74\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x63\x61\x6c\x6c\x20\x62\x65\x66\x6f\x72\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e"
);}(my $tmp_nxuser=$__nxuser->getLogin);(my $tmp_foreign_addres=
$__foreign_addres);if (isAuthenticationMethodAnywhere ()){($tmp_nxuser=
NXAnywhereAuth::getUsername ());}if (NXAnywhereAuth::isDefaultUser ()){
Logger::info ((((("\x55\x73\x65\x72\x20\x27".$tmp_nxuser).
"\x27\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x61\x73\x20\x27").$__nxuser->getLogin)
.((
"\x27\x20\x20\x73\x79\x73\x74\x65\x6d\x20\x75\x73\x65\x72\x20\x66\x72\x6f\x6d\x20\x27"
.$tmp_foreign_addres)."\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x6f\x75\x74\x2e")));
}else{Logger::info ((((("\x55\x73\x65\x72\x20\x27".$tmp_nxuser).
"\x27\x20\x66\x72\x6f\x6d\x20\x27").$tmp_foreign_addres).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x6f\x75\x74\x2e"));}main::nxrequire (
"\x4e\x58\x55\x74\x6d\x70");NXUtmp::remove ();($__nxuser=());($__foreign_addres=
());resetAdministratorPropertyForLoggedUser ();resetQuasiAdminAuthRequired ();
considerAfterLogout ($tmp_nxuser);}sub isAuthenticated{if (
isWebLoginUnrestricted ()){return ((0x0273+ 4930-0x15b4));}if (defined (
$__nxuser)){(my $login=$__nxuser->getLogin);Logger::debug (((((
"\x43\x75\x72\x72\x65\x6e\x74\x20\x75\x73\x65\x72\x20\x69\x73\x20\x27".$login).
"\x27\x20\x66\x72\x6f\x6d\x20\x27").$__foreign_addres)."\x27"));return (
(0x1fb4+ 235-0x209e));}Logger::debug (
"\x6e\x6f\x20\x75\x73\x65\x72\x20\x63\x75\x72\x72\x65\x6e\x74\x6c\x79\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e"
);return ((0x03fa+ 1550-0x0a08));}sub userIsNxAdministrator{(my $user=shift (@_)
);if ((defined ($user)and ($user ne ("")))){return (
NXAdministratorsManager::userExistInDb ($user));}return ((0x1b8a+ 1899-0x22f5));
}sub isAdministrator{if (isAuthenticatedWithAdministratorProperty ()){return (
(0x1896+ 3577-0x268e));}if (NXPublicKeyAuth::isTrustedServerConnection ()){
return ((0x07f5+ 7084-0x23a0));}if (exceptionForWindowsCaseUserNX ()){return (
(0x0db4+ 3658-0x1bfe));}return (main::effectiveUserIsAdministrator ());}sub 
isAuthenticatedWithAdministratorProperty{if (isAuthenticated ()){if ((
$loggedUserAdministratorProperty eq "\x79\x65\x73")){Logger::debug (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x4c\x6f\x67\x67\x65\x64\x20\x75\x73\x65\x72\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e"
);return ((0x25b8+ 309-0x26ec));}}return ((0x03f7+ 8750-0x2625));}sub 
exceptionForWindowsCaseUserNX{return ((0x0e99+ 1826-0x15bb));}sub 
setAdministratorPropertyForLoggedUser{if (
NXAdministratorsManager::userIsAdministrator ($__nxuser->getLogin)){
setAdministratorPropertyForQuasiAdmin ();}else{
resetAdministratorPropertyForLoggedUser ();}}sub 
setAdministratorPropertyForQuasiAdmin{Logger::debug (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x20\x75\x73\x65\x72\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e"
);($loggedUserAdministratorProperty="\x79\x65\x73");}sub 
resetAdministratorPropertyForLoggedUser{Logger::debug (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x52\x65\x73\x65\x74\x20\x75\x73\x65\x72\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x2e"
);($loggedUserAdministratorProperty="\x6e\x6f");}sub getCurrentUser{
Logger::debug3 (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x47\x65\x74\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x75\x73\x65\x72\x2e"
);my ($user);if ((isAuthenticated ()and (not (isAdministrator ())))){($user=get 
()->getLogin);Logger::debug3 (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x55\x73\x65\x72\x20\x27".$user).
"\x27\x20\x69\x73\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x65\x64\x20\x28\x6e\x6f\x74\x20\x61\x64\x6d\x69\x6e\x29\x2e"
));if ((defined ($user)and length ($user))){return ($user);}}if (defined (
$__nxuser)){($user=$__nxuser->getLogin);Logger::debug3 (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x55\x73\x65\x72\x20\x27".$user).
"\x27\x20\x66\x72\x6f\x6d\x20\x6f\x62\x6a\x65\x63\x74\x2e"));}return ($user);}
sub getCurrentAdministrator{my ($user);if ((isAuthenticated ()and 
isAdministrator ())){($user=get ()->getLogin);}if ((defined ($user)and length (
$user))){return ($user);}return (());}sub isUseNXUsers{return ($__flagUseNXUsers
);}sub isUseNXPasswords{return ($__flagUseNXPasswords);}sub isGuestLogged{return
 ($__flagGuestIsLogged);}sub isNotGuestLogged{return ((!isGuestLogged ()));}sub 
setGuestIsLogged{($__flagGuestIsLogged=(0x138c+ 3547-0x2166));}sub 
unsetGuestIsLogged{($__flagGuestIsLogged=(0x0f01+ 600-0x1159));}sub 
isServerBrowseGuest{if (($serverBrowseGuest==(0x0476+ 2311-0x0d7c))){return (
(0x17d8+ 2598-0x21fd));}return ((0x14a6+ 359-0x160d));}sub setServerBrowseGuest{
($serverBrowseGuest=(0x0dd7+ 2545-0x17c7));}sub clearServerBrowseGuest{(
$serverBrowseGuest=(0x0d2f+ 6373-0x2614));}sub setTrueGuestLogin{(
$trueGuestLogin=(0x217c+ 1101-0x25c8));}sub isTrueGuestLogin{if ((
$trueGuestLogin==(0x0658+ 1951-0x0df6))){return ((0x0d7c+ 3888-0x1cab));}return 
((0x1233+ 645-0x14b8));}sub isDesktopGuestLogin{if (($desktopGuestLogin==
(0x0e15+ 3184-0x1a84))){return ((0x06c2+ 7346-0x2373));}return (
(0x2178+ 585-0x23c1));}sub setPhysicalDesktopGuestLogin{($desktopGuestLogin=
(0x1962+ 814-0x1c8f));($physicalDesktopGuestLogin=(0x120a+ 1088-0x1649));}sub 
isPhysicalDesktopGuestLogin{if (($physicalDesktopGuestLogin==
(0x13aa+ 3683-0x220c))){return ((0x00c4+ 9081-0x243c));}return (
(0x0c69+ 3666-0x1abb));}sub setVirtualDesktopGuestLogin{($desktopGuestLogin=
(0x0126+ 3260-0x0de1));($virtualDesktopGuestLogin=(0x0b58+ 1749-0x122c));}sub 
isVirtualDesktopGuestLogin{if (($virtualDesktopGuestLogin==(0x1157+ 5038-0x2504)
)){return ((0x1aeb+ 3054-0x26d8));}return ((0x1b70+ 1456-0x2120));}sub 
getLocalAccountName{Logger::error (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x3a\x67\x65\x74\x4c\x6f\x63\x61\x6c\x41\x63\x63\x6f\x75\x6e\x74\x4e\x61\x6d\x65\x3a\x20\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x69\x6d\x70\x6c\x65\x6d\x65\x6e\x74\x65\x64\x2e"
);}sub isInternalUsername{(my $username=shift (@_));if (
NXProfiles::isInternalKey ($username)){return ((0x0f60+ 379-0x10da));}if (
NXGuestsManager::isRequestForNewGuestAccount ($username)){return (
(0x08a6+ 3591-0x16ac));}if (NXGuestsManager::isServerBrowseGuestAccountName (
$username)){return ((0x0f6a+ 1898-0x16d3));}if (
NXGuestsManager::isDesktopGuestAccountName ($username)){return (
(0x11d0+ 2039-0x19c6));}main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");if (
NXUsersManager::isDMUser ($username)){return ((0x15da+ 123-0x1654));}return (
(0x160b+ 921-0x19a4));}sub getAbsoluteNameForUsername{(my $username=shift (@_));my (
$absoluteUsername);if (isInternalUsername ($username)){return ($username);}(
$absoluteUsername=Common::NXCore::userInfoGetLoginByUsername ($username));if ((
$absoluteUsername==(-(0x084f+ 3162-0x14a8)))){Logger::warning (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x61\x62\x73\x6f\x6c\x75\x74\x65\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x3a\x20"
.$username)."\x2e"));return ($username);}return ($absoluteUsername);}sub 
getAbsoluteNameForUsernameIfNotDisabled{(my $username=shift (@_));if ((
$GLOBAL::DisableUsernameConversion!=(0x02a5+ 225-0x0385))){return (
getAbsoluteNameForUsername ($username));}return ($username);}sub 
__setAbsoluteNameForLoggedUser{(my $loggedUser=shift (@_));($absoluteName=
getAbsoluteNameForUsername ($loggedUser));}sub getAbsoluteNameForLoggedUser{
return ($absoluteName);}sub __authMethodIsNotAllowed{if (
Server::isClientNxserver ()){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x69\x73\x20\x61\x6c\x77\x61\x79\x73\x20\x61\x6c\x6c\x6f\x77\x65\x64\x2e"
);return ((0x1125+ 2379-0x1a70));}if (isAuthenticationMethodAnywhere ()){if (
Server::isAnywhereDisabled ()){return ((0x15e0+ 3184-0x224f));}return (
(0x050c+ 5701-0x1b51));}(my (@allowed)=split ( /,/ ,lc (
$GLOBAL::AcceptedAuthenticationMethods),(0x1050+ 1144-0x14c8)));foreach my $method
 (@allowed){if (($method eq "\x61\x6c\x6c")){return ((0x182b+ 3646-0x2669));}if 
((($method eq "\x6e\x78\x2d\x70\x61\x73\x73\x77\x6f\x72\x64")and 
isAuthenticationMethodBasedOnNXPassword ())){return ((0x02c9+ 8331-0x2354));}if 
((($method eq "\x6e\x78\x2d\x70\x72\x69\x76\x61\x74\x65\x2d\x6b\x65\x79")and 
isAuthenticationMethodNXPublicKey ())){return ((0x1323+ 963-0x16e6));}if (((
$method eq "\x6e\x78\x2d\x6b\x65\x72\x62\x65\x72\x6f\x73")and 
isAuthenticationMethodNXGSS ())){return ((0x1e73+ 1297-0x2384));}if ((($method 
eq "\x73\x73\x68\x2d\x73\x79\x73\x74\x65\x6d")and 
isAuthenticationMethodBasedOnSSHSystem ())){return ((0x02a1+ 5473-0x1802));}if (
(($method eq "\x73\x73\x68\x2d\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65")and 
isAuthenticationMethodBasedOnSSHPassword ())){return ((0x0f4d+ 1524-0x1541));}}
if (isAuthenticationMethodOneTimePassword ()){return ((0x0f36+ 2934-0x1aac));}if
 (isAuthenticationMethodNotRequired ()){return ((0x0d38+ 5329-0x2209));}return (
(0x117d+ 1828-0x18a0));}sub __setAuthMethod{(my $method=shift (@_));(my $force=(
shift (@_)||("")));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x5f\x5f\x73\x65\x74\x41\x75\x74\x68\x4d\x65\x74\x68\x6f\x64\x20\x77\x69\x74\x68\x20\x74\x79\x70\x65\x3a\x20"
.$method)."\x2e"));if ((__isNotSetAuthenticationMethod ()or ($force eq 
"\x66\x6f\x72\x63\x65"))){($AuthenticationMethod=$method);}else{Logger::error ((
(((
"\x54\x72\x79\x20\x74\x6f\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20\x66\x72\x6f\x6d\x20"
.$AuthenticationMethod)."\x20\x74\x6f\x20").$method)."\x2e"));
NXShell::handle_command ("\x65\x78\x69\x74");}if (__authMethodIsNotAllowed ()){
NXMsg::error (
"\x65\x4e\x6f\x74\x41\x6c\x6c\x6f\x77\x65\x64\x41\x75\x74\x68\x4d\x65\x74\x68\x6f\x64"
,"\x4e\x58\x4c\x6f\x67\x69\x6e",__getAuthMethodToError ());
NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
setAuthenticationMethodNotRequired{__setAuthMethod (
$AuthenticationMethodNotRequired);}sub isAuthenticationMethodNotRequired{if ((
$AuthenticationMethodNotRequired eq getAuthMethod ())){return (
(0x0fec+ 4360-0x20f3));}return ((0x12e0+ 4117-0x22f5));}sub 
__isNotSetAuthenticationMethod{if (($AuthenticationMethod eq (""))){return (
(0x0c3d+ 4454-0x1da2));}return ((0x1809+ 2508-0x21d5));}sub getAuthMethod{return
 ($AuthenticationMethod);}sub setAuthenticationMethodSSHSystem{if (
__isNotSetAuthenticationMethod ()){__setAuthMethod (
$AuthenticationMethodSSHSystem);}elsif (isAuthenticationMethodBasedOnSSHSystem 
()){Logger::debug (((((
"\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x6d\x65\x74\x68\x6f\x64\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20"
.$AuthenticationMethod).
"\x2c\x20\x64\x6f\x6e\x27\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x69\x74\x20\x74\x6f\x20"
).$AuthenticationMethodSSHSystem)."\x2e"));}else{__setAuthMethod (
$AuthenticationMethodSSHSystem);}}sub isAuthenticationMethodBasedOnSSHSystem{if 
(isAuthenticationMethodSSHSystemForwardKerberosKey ()){return (
(0x1674+ 2812-0x216f));}if (isAuthenticationMethodSSHSystemForwardAgentKey ()){
return ((0x1030+ 5046-0x23e5));}if (($AuthenticationMethodSSHSystem eq 
getAuthMethod ())){return ((0x123b+ 4400-0x236a));}return ((0x0bd1+ 979-0x0fa4))
;}sub setAuthenticationMethodAnywhere{__setAuthMethod (
$AuthenticationMethodAnywhere);}sub isAuthenticationMethodAnywhere{if ((
$AuthenticationMethodAnywhere eq getAuthMethod ())){return (
(0x06e4+ 5211-0x1b3e));}return ((0x046c+ 5598-0x1a4a));}sub 
setAuthenticationMethodSSHSystemForwardKerberosKey{__setAuthMethod (
$AuthenticationMethodSSHSystemForwardKerberosKey);}sub 
isAuthenticationMethodSSHSystemForwardKerberosKey{if ((
$AuthenticationMethodSSHSystemForwardKerberosKey eq getAuthMethod ())){return (
(0x0938+ 2597-0x135c));}return ((0x1ac6+ 738-0x1da8));}sub 
setAuthenticationMethodSSHSystemForwardAgentKey{__setAuthMethod (
$AuthenticationMethodSSHSystemForwardAgentKey);}sub 
isAuthenticationMethodSSHSystemForwardAgentKey{if ((
$AuthenticationMethodSSHSystemForwardAgentKey eq getAuthMethod ())){return (
(0x09f4+ 2540-0x13df));}return ((0x0a1a+ 1269-0x0f0f));}sub 
setAuthenticationMethodNXGSS{__setAuthMethod ($AuthenticationMethodNXGSS);}sub 
isAuthenticationMethodNXGSS{if (($AuthenticationMethodNXGSS eq getAuthMethod ())
){return ((0x0a6b+ 2658-0x14cc));}return ((0x0549+ 6941-0x2066));}sub 
setAuthenticationMethodNXPublicKey{__setAuthMethod (
$AuthenticationMethodNXPublicKey);}sub isAuthenticationMethodNXPublicKey{if ((
$AuthenticationMethodNXPublicKey eq getAuthMethod ())){return (
(0x1636+ 1644-0x1ca1));}return ((0x0122+ 3746-0x0fc4));}sub 
setAuthenticationMethodQuick{if (Server::isConnectionTypeNXD ()){__setAuthMethod
 ($AuthenticationMethodNXQuick);}else{__setAuthMethod (
$AuthenticationMethodSSHQuick);}}sub isAuthenticationMethodNXQuick{if ((
$AuthenticationMethodNXQuick eq getAuthMethod ())){return ((0x1985+ 1259-0x1e6f)
);}return ((0x0d06+ 4070-0x1cec));}sub isAuthenticationMethodSSHQuick{if ((
$AuthenticationMethodSSHQuick eq getAuthMethod ())){return (
(0x060f+ 6084-0x1dd2));}return ((0x09f8+ 2349-0x1325));}sub 
isAuthenticationMethodBasedOnQuick{if (isAuthenticationMethodNXQuick ()){return 
((0x1f23+ 1651-0x2595));}if (isAuthenticationMethodSSHQuick ()){return (
(0x1170+ 5349-0x2654));}return ((0x0b20+ 5427-0x2053));}sub 
changeAuthenticationMethodPassword{setAuthenticationMethodPassword (
"\x66\x6f\x72\x63\x65");}sub setAuthenticationMethodPassword{(my $force=shift (
@_));if (Server::isConnectionTypeNXD ()){if (isUseNXPasswords ()){
__setAuthMethod ($AuthenticationMethodNXpasswordDB,$force);}else{__setAuthMethod
 ($AuthenticationMethodNXpassword,$force);}}elsif (Server::isConnectionTypeSSHD 
()){if (isUseNXPasswords ()){__setAuthMethod ($AuthenticationMethodSSHpasswordDB
,$force);}else{__setAuthMethod ($AuthenticationMethodSSHpassword,$force);}}else{
if (isUseNXPasswords ()){__setAuthMethod ($AuthenticationMethodPasswordDB,$force
);}else{__setAuthMethod ($AuthenticationMethodPassword,$force);}}}sub 
isAuthenticationMethodBasedOnPassword{if (
isAuthenticationMethodBasedOnNXPassword ()){return ((0x0a1f+ 1419-0x0fa9));}if (
isAuthenticationMethodBasedOnSSHPassword ()){return ((0x1875+ 3382-0x25aa));}if 
(($AuthenticationMethodPasswordDB eq getAuthMethod ())){return (
(0x0e54+ 6328-0x270b));}if (($AuthenticationMethodPassword eq getAuthMethod ()))
{return ((0x03a2+ 7116-0x1f6d));}return ((0x01cd+ 4864-0x14cd));}sub 
isAuthenticationMethodBasedOnNXPassword{if (($AuthenticationMethodNXpassword eq 
getAuthMethod ())){return ((0x081a+ 1439-0x0db8));}if ((
$AuthenticationMethodNXpasswordDB eq getAuthMethod ())){return (
(0x0eb4+ 1554-0x14c5));}if (isAuthenticationMethodNXQuick ()){return (
(0x1734+ 1655-0x1daa));}return ((0x0b07+ 2786-0x15e9));}sub 
isAuthenticationMethodBasedOnSSHPassword{if (($AuthenticationMethodSSHpassword 
eq getAuthMethod ())){return ((0x0f32+ 1953-0x16d2));}if ((
$AuthenticationMethodSSHpasswordDB eq getAuthMethod ())){return (
(0x0c03+ 464-0x0dd2));}if (isAuthenticationMethodSSHQuick ()){return (
(0x10c8+ 1020-0x14c3));}return ((0x0235+ 7847-0x20dc));}sub 
setAuthenticationMethodMD5{__setAuthMethod ($AuthenticationMethodmd5);}sub 
isAuthenticationMethodMD5{if (($AuthenticationMethodmd5 eq getAuthMethod ())){
return ((0x246f+ 200-0x2536));}return ((0x2028+ 820-0x235c));}sub 
setAuthenticationMethodOneTimePassword{__setAuthMethod (
$AuthenticationMethodOneTimePassword);}sub isAuthenticationMethodOneTimePassword
{if (($AuthenticationMethodOneTimePassword eq getAuthMethod ())){return (
(0x161b+ 655-0x18a9));}return ((0x027f+ 2879-0x0dbe));}sub 
__getAuthMethodToError{if (isAuthenticationMethodBasedOnSSHPassword ()){return (
$AuthenticationMethodSSHpassword);}if (isAuthenticationMethodBasedOnNXPassword 
()){return ($AuthenticationMethodNXpassword);}return ($AuthenticationMethod);}
sub saveLoginFromPlayer{(my $login=shift (@_));($loginFromPlayer=$login);}sub 
getLoginFromPlayer{return ($loginFromPlayer);}sub getUsernameForRemote{(my $login
=getLoginFromPlayer ());if ((defined ($login)and ("\x6c\x6f\x67\x69\x6e" ne ("")
))){return ($login);}if (defined ($__nxuser)){($login=$__nxuser->getLogin);if ((
defined ($login)and ("\x6c\x6f\x67\x69\x6e" ne ("")))){return ($login);}}
Logger::error (
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6c\x6f\x67\x67\x65\x64\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x2e"
);(my $backtrace=Carp::longmess ($_));($backtrace=~ s/\n[\s]+/\n/ );(my (@lines)
=split ( /\n/ ,$backtrace,(0x0416+ 5267-0x18a9)));Logger::multilineError (
"\x53\x74\x61\x63\x6b\x74\x72\x61\x63\x65\x3a",@lines);main::nxexit (
(0x0e98+ 4183-0x1eee));}sub setLoginConversionToAbsoluteNameAvailable{(
$updateLogin=(0x1693+ 1815-0x1da9));}sub 
__isLoginConversionToAbsoluteNameAvailable{return ($updateLogin);}sub 
__isLoginRequireConversionToAbsoluteName{(my $actualLogin=shift (@_));(my $newLogin
=getAbsoluteNameForUsername ($actualLogin));if (($newLogin ne $actualLogin)){
return ((0x08df+ 1919-0x105d));}return ((0x1de5+  14-0x1df3));}sub 
convertToAbsoluteNameNXUserIfNeeded{(my $username=shift (@_));(my $password=
shift (@_));(my $ref_nxUser=shift (@_));if (
__isLoginConversionToAbsoluteNameAvailable ()){if (
__isLoginRequireConversionToAbsoluteName ($username)){($$ref_nxUser=NXUser::new 
(getAbsoluteNameForUsername ($username),$password));}}}sub 
setConnectionMethodSSH{($__connectionMethodSSH=(0x0d26+ 5579-0x22f0));}sub 
isConnectionMethodSSH{if (($__connectionMethodSSH==(0x1864+ 3271-0x252a))){
return ((0x16df+ 777-0x19e7));}return ((0x220c+  76-0x2258));}sub isNotNXUser{(my $username
=shift (@_));if (((NXUsersManager::userExistInDb ($username)==
(0x1c36+ 924-0x1fd2))and (NXAdministratorsManager::userExistInDb ($username)==
(0x1518+ 3442-0x228a)))){return ((0x125f+ 1647-0x18cd));}return (
(0x045a+ 8871-0x2701));}sub __isAuthMethodReportedInFail2banFormat{if ((((
isAuthenticationMethodNXPublicKey ()or isAuthenticationMethodNXGSS ())or 
isAuthenticationMethodBasedOnNXPassword ())or isAuthenticationMethodAnywhere ())
){return ((0x0c75+ 6134-0x246a));}return ((0x037f+ 7036-0x1efb));}sub 
reportAuthError{(my $text=shift (@_));(my $remoteIp=
NXClientConnection::getRemoteIp ());(my $method=getAuthMethod ());if (
__isAuthMethodReportedInFail2banFormat ()){Logger::error (((((((
"\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x77\x69\x74\x68\x20\x27"
.$method)."\x27\x20\x66\x72\x6f\x6d\x20\x68\x6f\x73\x74\x20\x27").$remoteIp).
"\x27\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27"
).$text)."\x27\x2e"));}else{Logger::error (((((((
"\x41\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e\x20\x77\x69\x74\x68\x20\x27"
.$method).
"\x27\x20\x66\x72\x6f\x6d\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x73\x65\x72\x76\x65\x72\x20\x68\x6f\x73\x74\x20\x77\x69\x74\x68\x20\x49\x50\x20\x27"
).$remoteIp).
"\x27\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27"
).$text)."\x27\x2e"));}}sub __setUserLoggedInThroughNXClient{(
$__userLoggedInThroughNXClient=(0x00cd+ 9405-0x2589));}sub 
__setUserLoggedOutThroughNXClient{($__userLoggedInThroughNXClient=
(0x0386+ 8006-0x22cc));}sub isUserStillLoggedInThroughNXClient{return (
$__userLoggedInThroughNXClient);}sub considerBeforeLogin{if ((
Server::isClientNxclient ()or Server::isClientNxwebclient ())){
NXEvent::beforeLogin ();}}sub considerAfterLogin{(my $user=shift (@_));if ((
Server::isClientNxclient ()or Server::isClientNxwebclient ())){
NXEvent::afterLogin ($user);__setUserLoggedInThroughNXClient ();}}sub 
considerAfterLogout{(my $user=shift (@_));if ((
isUserStillLoggedInThroughNXClient ()or Server::isConnectionForwarded ())){if ((
$user eq (""))){($user=getCurrentUser ());}__setUserLoggedOutThroughNXClient ();
NXEvent::afterLogout ($user);}}sub addUserLoginToDB{NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x69\x6e\x63\x72\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x6c\x6f\x67\x69\x6e\x73\x0a"
);NXRedis::setServerType ($loginServerTypeName);}sub deleteUserLoginFromDB{
NXRedis::unsetServerType ($loginServerTypeName);}sub getUserLoginsCount{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x6c\x6f\x67\x69\x6e\x73\x0a"
);(my $count=NXRedis::get ());return ($count);}sub 
getCurrentlyLoggedInUsersCount{NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x63\x6c\x69\x65\x6e\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x66\x69\x65\x6c\x64\x3d\x6c\x69\x73\x74\x0a"
);(my $listString=NXRedis::get ());(my (@listArray)=split ( /\n/ ,$listString,
(0x036a+ 5789-0x1a07)));(my $count=(0x10e9+ 2402-0x1a4b));foreach my $client (
@listArray){(my (@fields)=split ( / / ,$client,(0x1c14+ 991-0x1ff3)));(my $serverTypes
=$fields[(0x07c3+ 1756-0x0e9c)]);if (($serverTypes=~ /\b$loginServerTypeName\b/ )
){(++$count);}}return ($count);}sub isWebAccessLogin{(my $shell=
Server::getShellData ());if (($shell eq "\x77\x65\x62\x6c\x6f\x67\x69\x6e")){
return ((0x0f63+ 4139-0x1f8d));}return ((0x009f+ 6666-0x1aa9));}sub 
isWebAccessUnrestricted{if (($GLOBAL::WebAccessType eq 
"\x75\x6e\x72\x65\x73\x74\x72\x69\x63\x74\x65\x64")){return (
(0x03c0+ 5364-0x18b3));}return ((0x0eb9+ 2817-0x19ba));}sub 
isWebAccessSystemLogin{if (($GLOBAL::WebAccessType eq 
"\x73\x79\x73\x74\x65\x6d\x6c\x6f\x67\x69\x6e")){return ((0x0418+ 1762-0x0af9));
}return ((0x163d+ 1058-0x1a5f));}sub isWebAccessNetworkLogin{if ((
$GLOBAL::WebAccessType eq "\x6e\x65\x74\x77\x6f\x72\x6b\x6c\x6f\x67\x69\x6e")){
return ((0x0dd5+ 1747-0x14a7));}return ((0x22d7+ 1029-0x26dc));}sub 
setWebLoginUnresticted{($__flagWebLoginUnrestricted=(0x1358+ 343-0x14ae));}sub 
isWebLoginUnrestricted{return ($__flagWebLoginUnrestricted);}sub 
isForwardingUserToRemoteServer{return ($forwardingUserToRemoteServer);}sub 
setForwardingUserToRemoteServer{($forwardingUserToRemoteServer=
(0x04d1+ 6044-0x1c6c));}sub setQuasiAdminAuthRequired{Logger::debug (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x53\x65\x74\x20\x71\x75\x61\x73\x69\x2d\x61\x64\x6d\x69\x6e\x20\x61\x75\x74\x68\x20\x72\x65\x71\x75\x69\x72\x65\x64\x2e"
);($quasiAdminAuthRequired=(0x139d+ 926-0x173a));}sub 
resetQuasiAdminAuthRequired{Logger::debug (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x52\x65\x73\x65\x74\x20\x71\x75\x61\x73\x69\x2d\x61\x64\x6d\x69\x6e\x20\x61\x75\x74\x68\x20\x72\x65\x71\x75\x69\x72\x65\x64\x2e"
);($quasiAdminAuthRequired=(0x00c0+ 591-0x030f));}sub isQuasiAdminAuthRequired{
if (($quasiAdminAuthRequired==(0x1036+ 2219-0x18e0))){Logger::debug (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x51\x75\x61\x73\x69\x20\x61\x64\x6d\x69\x6e\x20\x61\x75\x74\x68\x20\x72\x65\x71\x75\x69\x72\x65\x64\x2e"
);return ((0x0053+ 3443-0x0dc5));}return ((0x00e0+ 2383-0x0a2f));}sub 
checkIfClientIsQuasiAdmin{(my $username=shift (@_));main::nxrequire (
"\x4e\x58\x51\x75\x61\x73\x69\x41\x64\x6d\x69\x6e");if (($username ne "\x6e\x78"
)){if ((NXQuasiAdmin::check ($username)==(0x078d+ 5325-0x1c5a))){
setQuasiAdminAuthRequired ();}}}sub setVisitor{($visitor=shift (@_));
Logger::debug (((
"\x47\x75\x65\x73\x74\x41\x63\x63\x65\x73\x73\x3a\x20\x53\x65\x74\x20\x76\x69\x73\x69\x74\x6f\x72\x20\x27"
.$visitor)."\x27\x2e"));}sub getVisitor{return ($visitor);}sub isVisitor{if ((
$visitor ne (""))){return ((0x0642+ 5025-0x19e2));}return ((0x0263+ 2945-0x0de4)
);}sub setVisitorHost{($visitorHost=shift (@_));Logger::debug (((
"\x47\x75\x65\x73\x74\x41\x63\x63\x65\x73\x73\x3a\x20\x53\x65\x74\x20\x76\x69\x73\x69\x74\x6f\x72\x20\x68\x6f\x73\x74\x20\x27"
.$visitorHost)."\x27\x2e"));}sub getVisitorHost{return ($visitorHost);}sub 
setVisitorLongName{($visitorLongName=shift (@_));Logger::debug (((
"\x56\x69\x73\x69\x74\x6f\x72\x41\x63\x63\x65\x73\x73\x3a\x20\x53\x65\x74\x20\x76\x69\x73\x69\x74\x6f\x72\x20\x6c\x6f\x6e\x67\x20\x6e\x61\x6d\x65\x20\x27"
.$visitorLongName)."\x27\x2e"));setUserFullName ($visitorLongName);}sub 
getVisitorLongName{return ($visitorLongName);}sub setUserFullName{(my $fullName=
shift (@_));($fullName=main::urldecode ($fullName));Logger::debug (((
"\x53\x65\x74\x20\x75\x73\x65\x72\x20\x66\x75\x6c\x6c\x20\x6e\x61\x6d\x65\x3a\x20"
.$fullName)."\x2e"));($userFullName=$fullName);}sub getUserFullName{(my $fullName
=$userFullName);if (($fullName ne (""))){Logger::debug (((
"\x47\x65\x74\x20\x75\x73\x65\x72\x20\x66\x75\x6c\x6c\x20\x6e\x61\x6d\x65\x3a\x20"
.$fullName)."\x2e"));return ($fullName);}else{return (undef);}}sub 
setTokenAuthorizedUser{($tokenAuthorizedUser=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x69\x6e\x3a\x20\x53\x65\x74\x20\x74\x6f\x6b\x65\x6e\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x75\x73\x65\x72\x20\x27"
.$tokenAuthorizedUser)."\x27\x2e"));}sub isTokenAuthorizedUser{(my $user=shift (
@_));if (($user eq $tokenAuthorizedUser)){return ((0x0667+ 8091-0x2601));}return
 ((0x03bf+ 5959-0x1b06));}NXMsg::register_error ("\x4e\x58\x4c\x6f\x67\x69\x6e",
"\x65\x4e\x6f\x74\x41\x6c\x6c\x6f\x77\x65\x64\x41\x75\x74\x68\x4d\x65\x74\x68\x6f\x64"
,(0x0a3a+ 6828-0x22f2));return ((0x0794+ 6516-0x2107));
