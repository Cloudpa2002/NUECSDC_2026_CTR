#!/bin/bash
######################################################################
#                                                                    #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.     #
#                                                                    #
#  All rights reserved.                                              #
#                                                                    #
######################################################################

RunDir=${0%nxkill.sh}
RestrictedDir=$(cd "${RunDir}" && pwd)

PARAMS_COUNT_MIN=3
PARAMS_COUNT_MAX=5

. "${RestrictedDir}"/nxfunct.sh

isRunByServerOrNode

getNXRoot

if test "x$4" = "x"; then
  SIG="9"
else
  SIG="$4"
fi

if test "x$5" = "x1"; then
  ${COMMAND_KILL} -$SIG -- -$3
else
  ${COMMAND_KILL} -$SIG $3
fi
