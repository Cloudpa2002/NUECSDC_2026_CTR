############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::UserRefusedToAcceptConnection::BEGIN{package 
Exception::UserRefusedToAcceptConnection;no warnings;require base;do{
"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::UserRefusedToAcceptConnection::BEGIN{package 
Exception::UserRefusedToAcceptConnection;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::UserRefusedToAcceptConnection::notify{package 
Exception::UserRefusedToAcceptConnection;no warnings;(my $self=shift (@_));
NXMsg::send_response (
"\x65\x55\x73\x65\x72\x52\x65\x66\x75\x73\x65\x64\x54\x6f\x41\x63\x63\x65\x70\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e"
,
"\x53\x65\x73\x73\x69\x6f\x6e\x53\x74\x61\x72\x74\x53\x74\x61\x74\x65\x4d\x61\x63\x68\x69\x6e\x65"
);}package Exception::UserRefusedToAcceptConnection;no warnings;"\x3f\x3f\x3f";
