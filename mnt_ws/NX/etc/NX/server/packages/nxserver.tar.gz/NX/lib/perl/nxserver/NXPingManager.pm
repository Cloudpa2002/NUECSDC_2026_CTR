############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXPingManager;no warnings;(my $__pingRequestTime=(0x111a+ 3798-0x1ff0));
(my $__pingTime=(0x0190+  79-0x01df));(my $__interval=(0x0735+ 2128-0x0f85));(my $__timeout
=(0x02dd+ 1695-0x097c));(my $__errorTimeout=(0x20ab+ 980-0x247f));sub initialize
{__setTimeBetweenPingsFromNode ();__setTimeoutForPingAfterRequest ();
__setPingRequestTime ();}sub __setTimeBetweenPingsFromNode{($__interval=
(0x1bc7+ 1485-0x2149));Logger::debug (((
"\x4e\x58\x50\x69\x6e\x67\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x54\x69\x6d\x65\x20\x62\x65\x74\x77\x65\x65\x6e\x20\x70\x69\x6e\x67\x73\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x6e\x6f\x64\x65\x3a\x20"
.$__interval)."\x2e"));}sub __setTimeoutForPingAfterRequest{($__timeout=
NXNodeConfiguration::getNodeConnectionTimeout ());Logger::debug (((
"\x4e\x58\x50\x69\x6e\x67\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x54\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x70\x69\x6e\x67\x20\x61\x66\x74\x65\x72\x20\x72\x65\x71\x75\x65\x73\x74\x3a\x20"
.$__timeout)."\x2e"));}sub checkTimesAndRequestPingIfNecessary{if ((
__isPingEnabled ()==(0x1381+ 738-0x1663))){return;}if ((__isTimeout ()==
(0x1385+ 3513-0x213d))){if ((__isErrorTimeout ()==(0x0267+ 3895-0x119d))){(my $msg
=((
"\x4e\x6f\x64\x65\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x70\x69\x6e\x67\x20\x73\x69\x6e\x63\x65\x20"
.$__timeout).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e\x20\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
));Logger::error ($msg);Logger::statusPushError ($msg);die ($msg);}
__setErrorTimeout ();Logger::warning (((
"\x4e\x6f\x64\x65\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x70\x69\x6e\x67\x20\x73\x69\x6e\x63\x65\x20"
.$__timeout)."\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));__sendPingRequest ();
return;}if ((__isPingRequestTime ()==(0x0c1d+ 3702-0x1a92))){__sendPingRequest 
();return;}}sub handlePing{Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x70\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);__resetPingRequestTime ();__clearErrorTimeout ();Logger::debug (
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x6f\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);NXNodeExec::sendToNode ((((("\x4e\x58\x3e\x20".$GLOBAL::MSG_NODE_PONG)."\x20")
.$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_NODE_PONG})."\x0a"));__setPingTime ();}
sub __isPingRequestTime{if (($__pingTime==(0x0f66+ 2571-0x1971))){return (
(0x0bac+ 3372-0x18d8));}(my $time=Common::NXTime::getSecondsSinceEpoch ());if ((
$time>=($__pingTime+$__interval))){return ((0x0ba3+  78-0x0bf0));}return (
(0x054a+ 783-0x0859));}sub __resetPingRequestTime{($__pingRequestTime=
(0x0180+ 7171-0x1d83));}sub __setPingRequestTime{($__pingRequestTime=
Common::NXTime::getSecondsSinceEpoch ());}sub __sendPingRequest{Logger::debug (
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x20\x70\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);NXNodeExec::sendToNode ((((("\x4e\x58\x3e\x20".$GLOBAL::MSG_REQUEST_FOR_PING).
"\x20").$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_REQUEST_FOR_PING})."\x0a"));
__setPingRequestTime ();__resetPingTime ();}sub disable{($__timeout=
(0x01e7+ 5628-0x17e3));Logger::debug (
"\x4e\x58\x50\x69\x6e\x67\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x20\x70\x69\x6e\x67\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);}sub __isPingEnabled{if (($__timeout==(0x0522+ 1417-0x0aab))){return (
(0x06a7+ 4004-0x164b));}return ((0x1261+ 4584-0x2448));}sub __isTimeout{if ((
$__pingRequestTime==(0x08fc+ 4283-0x19b7))){return ((0x0000+ 7668-0x1df4));}(my $time
=Common::NXTime::getSecondsSinceEpoch ());if (($__pingRequestTime>$time)){(
$__pingRequestTime=Common::NXTime::getSecondsSinceEpoch ());}if (($time>=(
$__pingRequestTime+$__timeout))){return ((0x06cb+ 7328-0x236a));}return (
(0x133c+ 5030-0x26e2));}sub __setPingTime{($__pingTime=
Common::NXTime::getSecondsSinceEpoch ());}sub __resetPingTime{($__pingTime=
(0x049f+ 7395-0x2182));}sub __setErrorTimeout{($__errorTimeout=
(0x19e7+ 3328-0x26e6));}sub __isErrorTimeout{return ($__errorTimeout);}sub 
__clearErrorTimeout{($__errorTimeout=(0x04fc+ 4403-0x162f));}return (
(0x027a+ 5575-0x1840));
