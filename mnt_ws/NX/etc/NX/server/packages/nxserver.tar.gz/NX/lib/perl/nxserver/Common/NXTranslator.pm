############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXTranslator;no warnings;(my (%__translation)=());sub init{(my $language
=shift (@_));if (__isGerman ($language)){main::nxrequire (((
"\x43\x6f\x6d\x6d\x6f\x6e".$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x47\x65\x72\x6d\x61\x6e\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXGermanMessages::getGermanTranslations ());}elsif (
__isSpanish ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x53\x70\x61\x6e\x69\x73\x68\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXSpanishMessages::getSpanishTranslations ());}elsif (
__isFrench ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x46\x72\x65\x6e\x63\x68\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXFrenchMessages::getFrenchTranslations ());}elsif (
__isItalian ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x49\x74\x61\x6c\x69\x61\x6e\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXItalianMessages::getItalianTranslations ());}elsif (
__isPolish ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x50\x6f\x6c\x69\x73\x68\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXPolishMessages::getPolishTranslations ());}elsif (
__isPortuguese ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x50\x6f\x72\x74\x75\x67\x75\x65\x73\x65\x4d\x65\x73\x73\x61\x67\x65\x73"
));((%__translation)=Common::NXPortugueseMessages::getPortugueseTranslations ())
;}elsif (__isRussian ($language)){main::nxrequire ((("\x43\x6f\x6d\x6d\x6f\x6e".
$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x52\x75\x73\x73\x69\x61\x6e\x4d\x65\x73\x73\x61\x67\x65\x73"));((
%__translation)=Common::NXRussianMessages::getRussianTranslations ());}(
$Common::NXTranslator::language=$language);}sub translate{(my $message=shift (@_
));(my $result=shift (@_));(my $translation=$__translation{$message});if ((not (
defined ($translation)))){Logger::debug3 (((
"\x4d\x65\x73\x73\x61\x67\x65\x20\x27".$message).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x2e"
));return ((0x10cb+ 499-0x12be));}($$result=$translation);Logger::debug3 (((((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x20\x74\x6f\x20\x27").$translation)."\x27\x2e"));return (
(0x0175+ 3307-0x0e5f));}sub getLanguage{if (($language ne (""))){return (
$language);}else{return (undef);}}sub __isGerman{(my $language=shift (@_));if ((
$language eq "\x64\x65\x5f\x44\x45")){return ((0x014a+ 685-0x03f6));}return (
(0x0425+ 3467-0x11b0));}sub __isSpanish{(my $language=shift (@_));if (($language
 eq "\x65\x73\x5f\x45\x53")){return ((0x0707+ 2659-0x1169));}return (
(0x0424+ 6044-0x1bc0));}sub __isFrench{(my $language=shift (@_));if (($language 
eq "\x66\x72\x5f\x46\x52")){return ((0x0a4f+ 5812-0x2102));}return (
(0x18f1+ 2746-0x23ab));}sub __isItalian{(my $language=shift (@_));if (($language
 eq "\x69\x74\x5f\x49\x54")){return ((0x066b+ 4534-0x1820));}return (
(0x0373+ 2404-0x0cd7));}sub __isPolish{(my $language=shift (@_));if (($language 
eq "\x70\x6c\x5f\x50\x4c")){return ((0x0171+ 7453-0x1e8d));}return (
(0x0ee4+ 712-0x11ac));}sub __isPortuguese{(my $language=shift (@_));if ((
$language eq "\x70\x74\x5f\x50\x54")){return ((0x09bf+ 4945-0x1d0f));}return (
(0x05aa+ 6798-0x2038));}sub __isRussian{(my $language=shift (@_));if (($language
 eq "\x72\x75\x5f\x52\x55")){return ((0x0707+ 3778-0x15c8));}return (
(0x1385+ 1695-0x1a24));}sub __isEnglish{(my $language=shift (@_));if (($language
 eq "\x65\x6e\x5f\x55\x53")){return ((0x0964+ 1995-0x112e));}return (
(0x2106+ 1007-0x24f5));}sub translateTimestampForDateBaseOnLanguage{(my $timestamp
=shift (@_));(my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=
Common::NXTime::getLocalTimeFromTimestamp ($timestamp));($year+=
(0x105c+ 5378-0x1df2));(++$mon);my ($date);if (__isEnglish (getLanguage ())){
return (((((((((sprintf ("\x25\x30\x32\x64",$mon)."\x2f").sprintf (
"\x25\x30\x32\x64",$mday))."\x2f").$year)."\x2c\x20").sprintf (
"\x25\x30\x32\x64",$hour))."\x3a").sprintf ("\x25\x30\x32\x64",$min)));}else{
return (((((((((sprintf ("\x25\x30\x32\x64",$mday)."\x2f").sprintf (
"\x25\x30\x32\x64",$mon))."\x2f").$year)."\x2c\x20").sprintf ("\x25\x30\x32\x64"
,$hour))."\x3a").sprintf ("\x25\x30\x32\x64",$min)));}}return (
(0x00ea+ 6533-0x1a6e));
