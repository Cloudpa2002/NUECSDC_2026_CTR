############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXCore;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65"->import};}sub BEGIN{
no warnings;require Common::Logger;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4c\x6f\x67\x67\x65\x72"->import};}sub BEGIN{
no warnings;require Common::NXTranslator;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x54\x72\x61\x6e\x73\x6c\x61\x74\x6f\x72"
->import};}sub BEGIN{no warnings;require Common::NXMsg;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x4d\x73\x67"->import};}package NXMsg;
no warnings;(my $__silentMode=(0x0c0a+ 6569-0x25b3));(my $__eolAfterRequest=
(0x0012+ 6100-0x17e6));sub register_response{__register ($_[
(0x14cd+ 3348-0x21e1)],$_[(0x0844+ 3949-0x17b0)],$_[(0x0139+ 3635-0x0f6a)],
Common::NXMsg::getResponseType (),(""));}sub register_error{__register ($_[
(0x177b+ 2764-0x2247)],$_[(0x00f3+ 1457-0x06a3)],$_[(0x0674+ 3571-0x1465)],
Common::NXMsg::getErrorType (),$_[(0x0495+ 485-0x0677)]);}sub register_request{
__register ($_[(0x00e0+ 1676-0x076c)],$_[(0x192d+ 203-0x19f7)],$_[
(0x002c+ 9064-0x2392)],Common::NXMsg::getRequestType (),$_[(0x0086+ 692-0x0337)]
);}sub __register{(my $class=$_[(0x098a+ 5514-0x1f14)]);(my $name=$_[
(0x05a7+ 3538-0x1378)]);(my $number=$_[(0x0eba+ 2562-0x18ba)]);(my $type=$_[
(0x0a67+ 6244-0x22c8)]);(my $regExp=$_[(0x0c2a+ 6784-0x26a6)]);if (((not (
defined ($name)))or (not (($name=~ /^[\w\d\._-]{1,128}$/ ))))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x6e\x61\x6d\x65\x20"
.$name),(0x09ac+ 7344-0x265a));__error ();}if (((not (defined ($number)))or (not
 (($number=~ /^[\d]{3,4}$/ ))))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x6e\x75\x6d\x62\x65\x72\x20"
.$number),(0x01fd+ 4075-0x11e6));__error ();}if ((((!defined ($regExp))||(
$regExp eq ("")))and Common::NXMsg::isRequestType ($type))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x72\x65\x67\x45\x78\x70\x20"
.$regExp),(0x0e0b+ 1605-0x144e));__error ();}if (isMessageRegistered ($name)){
Logger::error ((("\x4e\x58\x4d\x73\x67\x3a\x20\x4d\x65\x73\x73\x61\x67\x65\x20".
$name).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x2e"
),(0x0f8d+ 5458-0x24dd));__error ();}Common::NXMsg::saveMessageData ($name,
$number,$type,$regExp);}sub __sprinf_reg_exp{(my $format=shift (@_));(my $name=
shift (@_));(my $class=shift (@_));(my (@message_parameters)=@_);for ((my $i=
(0x081c+ 5783-0x1eb3));($i<=$#message_parameters);(++$i)){($message_parameters[
$i]=~ s/^\n//gm );($message_parameters[$i]=~ s/\n$//gm );}(my $message=sprintf (
$format,@message_parameters));($message=~ s/\n/\n        /gm );return ($message)
;}sub check_msg{(my $index=shift (@_));(my $class=shift (@_));if (((not (defined
 ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){return (
(0x0f54+ 5172-0x2388));}(my $messageNumber=Common::NXMsg::getNumber ($index));if
 ((not (defined ($messageNumber)))){return ((0x0065+ 9616-0x25f5));}return (
(0x0a3f+ 2216-0x12e6));}sub get_msg{(my $index=shift (@_));(my $class=shift (@_)
);(my (@parameters)=@_);if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ )
)))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x6e\x64\x65\x78\x20\x73\x74\x72\x69\x6e\x67\x20"
.$index),(0x0880+ 6803-0x2312));__error ();}(my $messageNumber=
Common::NXMsg::getNumber ($index));if ((not (defined ($messageNumber)))){
Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x55\x6e\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$index),(0x14c8+ 4592-0x26b7));__error ();}for ((my $i=(0x24ad+  18-0x24bf));(
$i<=$#parameters);(++$i)){($parameters[$i]=~ s/^\n//gm );($parameters[$i]=~ s/\n$//gm )
;}(my $messageText=(""));if (Common::NXEnglishMessages::isCustomizableMessage (
$index)){(($messageNumber,$index,$messageText)=
Common::NXMsg::getCustomizedMessage ($index,$messageNumber,(\@parameters)));}
else{($messageText=Common::NXEnglishMessages::getMessage ($index));}(my $message
=(""));if (shouldPackMessage ($messageNumber)){($message=
Common::NXMsg::constructMessage ($messageNumber,$messageText,@parameters));(my $packedMessage
=Common::NXMsg::packResponse ($index,$message,@parameters));return ((""),
$packedMessage);}else{Common::NXTranslator::translate ($index,(\$messageText));}
($message=Common::NXMsg::constructMessage ($messageNumber,$messageText,
@parameters));if (($index eq 
"\x65\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72\x44\x65\x6c\x46\x61\x69\x6c\x65\x64"
)){($message=~ s/ERROR: // );}return (Common::NXMsg::getRegExp ($index),$message
);}sub get_text{(my $indexString=shift (@_));(my $class=shift (@_));(my (
@parameters)=@_);(my $translate=(0x0341+ 3259-0x0ffb));return (__getText (
$indexString,$translate,@parameters));}sub getEnglishText{(my $indexString=shift
 (@_));(my (@parameters)=@_);(my $translate=(0x04e5+ 5439-0x1a24));return (
__getText ($indexString,$translate,@parameters));}sub __getText{(my $index=shift
 (@_));(my $translate=shift (@_));(my (@parameters)=@_);my ($message);if (((not 
(defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){Logger::error 
((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x6e\x64\x65\x78\x20\x73\x74\x72\x69\x6e\x67\x20"
.$index),(0x1438+ 4602-0x2631));__error ();}unless (($translate and 
Common::NXTranslator::translate ($index,(\$message)))){($message=
Common::NXEnglishMessages::getMessage ($index));}for ((my $i=
(0x02f0+ 8855-0x2587));($i<=$#parameters);(++$i)){($parameters[$i]=~ s/^\n//gm )
;($parameters[$i]=~ s/\n$//gm );}if (($message ne (""))){($message=sprintf (
$message,@parameters));}return ($message);}sub send_response{(my $index=$_[
(0x0ad7+ 4983-0x1e4e)]);if (Common::NXMsg::isErrorTypeByIndex ($index)){return (
error (@_));}(my ($reg_exp,$message)=get_msg (@_));if (isSilentMode ()){return;}
if ((not (Server::isClientConnectionOpen ()))){return;}Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));($message.="\x0a");if ((main::nxwrite (main::nxgetSTDOUT (),
$message)==(-(0x0904+ 5867-0x1fee)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x0b9d+ 5865-0x2285)));}}sub 
send_response_no_newline{(my ($reg_exp,$message)=get_msg (@_));if (isSilentMode 
()){return;}if ((not (Server::isClientConnectionOpen ()))){return;}Logger::debug
 (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));main::nxwrite (main::nxgetSTDOUT (),$message);}sub 
send_response_without_number{(my $message=get_text (@_));if (isSilentMode ()){
return;}if ((not (Server::isClientConnectionOpen ()))){return;}Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x6e\x75\x6d\x62\x65\x72\x20\x27"
.$message)."\x27"));($message.="\x0a");if ((main::nxwrite (main::nxgetSTDOUT (),
$message)==(-(0x1741+ 1447-0x1ce7)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x0d29+ 637-0x0fa5)));}}sub 
sendLogMessage{(my $message=shift (@_));(my $level=shift (@_));(my $storeInHistory
=shift (@_));if (Logger::isErrorLevel ($level)){Logger::error ($message,
$storeInHistory);}elsif (Logger::isWarningLevel ($level)){Logger::warning (
$message,$storeInHistory);}elsif (Logger::isInfoLevel ($level)){Logger::info (
$message,$storeInHistory);}else{Logger::debug ($message,$storeInHistory);}}sub 
__warning{(my $log_level=shift (@_));(my ($reg_exp,$message)=get_msg (@_));if (
isSilentMode ()){return;}if ((defined ($reg_exp)and ($reg_exp eq 
(0x015c+ 5807-0x180a)))){($log_msg=__sprinf_reg_exp ($reg_exp,@_));
sendLogMessage ($log_msg,$log_level,(0x0857+ 4929-0x1b95));}if (((defined (
$reg_exp)and ($reg_exp ne ("")))and ($reg_exp ne (0x0bd3+ 2425-0x154b)))){(
$log_msg=__sprinf_reg_exp ($reg_exp,@_));sendLogMessage ($log_msg,$log_level,
(0x0f9d+ 4619-0x21a5));}if (((not (defined ($message)))or ($message eq ("")))){(
($reg_exp,$message)=Common::NXMsg::get_msg (
"\x65\x47\x55\x49\x47\x65\x6e\x65\x72\x61\x6c"));}if (
Common::NXMsg::isPackedMessage ($message)){Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x61\x63\x6b\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}elsif (Logger::isInfoLevel ($log_level)){Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x61\x6c\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}elsif (Logger::isWarningLevel ($log_level)){($message=~ s/(^NX> \d+) *(.*)$/$1 WARNING: $2/gm )
;Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x77\x61\x72\x6e\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}else{($message=~ s/(^NX> \d+) *(.*)$/$1 ERROR: $2/gm );
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x65\x72\x72\x6f\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}if (Server::isClientConnectionOpen ()){main::nxwrite (
main::nxgetSTDOUT (),($message."\x0a"));}}sub fatal{__warning (
Logger::getErrorLevel (),@_);NXShell::handle_command ("\x65\x78\x69\x74");}sub 
error{__warning (Logger::getErrorLevel (),@_);}sub warning{__warning (
Logger::getWarningLevel (),@_);}sub info{__warning (Logger::getInfoLevel (),@_);
}$GLOBAL::NXMsg::__inBuffer;sub send_requestWithAdditionalCallback{return (
__send_request (@_));}sub send_request{(my $index=shift (@_));(my $class=shift (
@_));(my $value=shift (@_));(my $additionalFd=(""));(my $callback=(""));return (
__send_request ($index,$class,$additionalFd,$callback,$value,@_));}sub 
__send_request{(my $pRegExp=shift (@_));(my $pMessage=shift (@_));(my $additionalFd
=shift (@_));(my $callback=shift (@_));(my $value=shift (@_));(my ($reg_exp,
$message)=get_msg ($pRegExp,$pMessage,@_));if (defined ($value)){if (($reg_exp 
eq "\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x63\x68\x61\x72")){if ((not (($value=~ /(^[^0-9A-Za-z_.+\-])$/ )
))){(my $tmp=$value);while (($tmp=~ s/(.)// )){if ((ord ($1)<
(0x0f12+ 1407-0x1471))){Logger::error ((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x5c"
.sprintf ("\x5c\x30\x25\x6f",ord ($1))).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x20").
"\x61\x6e\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x75\x73\x65\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x2e"
));return (());}}}}elsif ((not (($value=~ /$reg_exp/ )))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x76\x61\x6c\x75\x65\x20"
.$value));return (());}return ($value);}if (($message=~ /^NX> (\d\d\d)  $/ )){(
$message=(("\x4e\x58\x3e\x20".$1)."\x20"));}else{($message.="\x3a\x20");}if ((
sendEOL ()==(0x0a5c+ 5570-0x201d))){if ((main::nxwrite (main::nxgetSTDOUT (),(
$message."\x0a"))==(-(0x022b+ 3864-0x1142)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return (());}}else{if ((main::nxwrite (
main::nxgetSTDOUT (),$message)==(-(0x10bc+ 2259-0x198e)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));(my $parser=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);((
%parameters)=());($parameters{"\x64\x61\x74\x61"}=(""));($parameters{
"\x6d\x61\x78\x4c\x65\x6e\x67\x74"}=$GLOBAL::commandBufferLimit);($parameters{
"\x65\x6e\x64\x4f\x66\x4c\x69\x6e\x65"}=(0x1364+ 997-0x1749));($parameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}=
(0x0ffa+ 2203-0x1895));$parser->add ($$NXBegin::parser{
"\x53\x69\x67\x6e\x61\x6c"});$parser->add (main::nxgetSTDIN (),(
\&__globalReadnLine),
"\x4e\x58\x4d\x73\x67\x3a\x3a\x5f\x5f\x67\x6c\x6f\x62\x61\x6c\x52\x65\x61\x64\x6e\x4c\x69\x6e\x65"
,(\%parameters));$parser->setNotRead (main::nxgetSTDIN ());if (($additionalFd ne
 (""))){$parser->add ($additionalFd);$parser->setCallbackForHandle (
$additionalFd,"\x43\x6c\x6f\x73\x65",$callback);}$parser->setTimeout (
"\x69\x6e\x66");$parser->run;(my $data=$parameters{"\x64\x61\x74\x61"});if ((not
 (defined ($data)))){return (());}(my $log_data=$data);if (($pRegExp eq 
"\x72\x41\x73\x6b\x46\x6f\x72\x41\x74\x74\x61\x63\x68\x4d\x65\x73\x73\x61\x67\x65"
)){($data=main::urlencode ($data));($log_data=main::urldecode ($data));}if (
NXShell::isCurrentModeNotWords ()){($log_data=~ s/(password=)([^&]*)/do {
            ($1 . ('*' x length($2)));
        };/eg )
;($log_data=~ s/(cookie=)([^&]*)/do {
            ($1 . ('*' x length($2)));
        };/eg )
;}else{();}if (($pRegExp ne "\x63\x6f\x6d\x6d\x61\x6e\x64")){if ((((
$GLOBAL::PROTO_VERSION ne "\x73\x68\x65\x6c\x6c")and ($GLOBAL::PROTO_VERSION ne 
("")))and (NXShell::getNoEcho ()!=(0x0167+ 4728-0x13de)))){if ((main::nxwrite (
main::nxgetSTDOUT (),($data."\x0a"))==(-(0x0a68+ 5166-0x1e95)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}else{if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x09ea+ 1135-0x0e58)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}}
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$log_data)."\x27\x2e"));if (($reg_exp eq 
"\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x63\x68\x61\x72")){if ((not (($data=~ /(^[^0-9A-Za-z_.+\-])$/ )
))){(my $tmp=$data);while (($tmp=~ s/(.)// )){if ((ord ($1)<
(0x0bea+ 5126-0x1fd0))){Logger::error (((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$message)."\x2e\x20\x43\x68\x61\x72\x61\x63\x74\x65\x72\x20\x5c").sprintf (
"\x5c\x30\x25\x6f",ord ($1))).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x20\x61\x6e\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x75\x73\x65\x64\x20\x68\x65\x72\x65\x2e"
));return (());}}}}elsif ((not (($data=~ /$reg_exp/ )))){Logger::error (((((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e\x20\x44\x61\x74\x61\x20\x27").$data).
"\x27\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x6d\x61\x74\x63\x68\x20\x77\x69\x74\x68\x20\x72\x65\x67\x45\x78\x70\x20\x27"
).$reg_exp)."\x27\x2e"));if ((main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-
(0x1c3f+ 500-0x1e32)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT);}
return (());}if ((($data eq (""))and $GLOBAL::PROTO_VERSION)){if ((main::nxwrite
 (main::nxgetSTDOUT (),"\x0a")==(-(0x06bd+ 2119-0x0f03)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}return (
$data);}sub send_hrequestWithAdditionalCallback{return (__send_hrequest (@_));}
sub send_hrequest{(my $indexString=shift (@_));(my $class=shift (@_));(my $additionalFd
=(""));(my $callback=(""));return (__send_hrequest ($indexString,$class,
$additionalFd,$callback,@_));}sub __send_hrequest{(my $indexString=shift (@_));(my $class
=shift (@_));(my $additionalFd=shift (@_));(my $callback=shift (@_));(my (
$reg_exp,$message)=get_msg ($indexString,$class,@_));($message.="\x3a\x20");(my $parser
="\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);((
%parameters)=());($parameters{"\x64\x61\x74\x61"}=(""));($parameters{
"\x6d\x61\x78\x4c\x65\x6e\x67\x74"}=$GLOBAL::commandBufferLimit);($parameters{
"\x65\x6e\x64\x4f\x66\x4c\x69\x6e\x65"}=(0x1241+ 5181-0x267e));($parameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}=
(0x0f65+ 2688-0x19e5));$parser->add ($$NXBegin::parser{
"\x53\x69\x67\x6e\x61\x6c"});$parser->add (main::nxgetSTDIN (),(
\&__globalReadnLine),
"\x4e\x58\x4d\x73\x67\x3a\x3a\x5f\x5f\x67\x6c\x6f\x62\x61\x6c\x52\x65\x61\x64\x6e\x4c\x69\x6e\x65"
,(\%parameters));$parser->setNotRead (main::nxgetSTDIN ());if (($additionalFd ne
 (""))){$parser->add ($additionalFd);$parser->setCallbackForHandle (
$additionalFd,"\x43\x6c\x6f\x73\x65",$callback);}$parser->setTimeout (
"\x69\x6e\x66");blindInput ();if ((main::nxwrite (main::nxgetSTDOUT (),$message)
==(-(0x03df+ 7147-0x1fc9)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);showInput ();return (());}Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));$parser->run;showInput ();(my $data=$parameters{
"\x64\x61\x74\x61"});if ((not (defined ($data)))){main::nxwrite (
main::nxgetSTDOUT (),"\x0a");return (());}(my $hdata=$data);($hdata=~ s/./*/g );
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$hdata)."\x27"));if ((not (($data=~ /$reg_exp/ )))){if ((main::nxwrite (
main::nxgetSTDOUT (),"\x0a")==(-(0x0c60+ 4353-0x1d60)))){NXShell::setExitRequest
 ($ExitRequests::closedSTDOUT);}Logger::error (((((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$message)."\x2e\x20\x20").$hdata).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x6d\x61\x74\x63\x68\x20\x77\x69\x74\x68\x20"
).$reg_exp)."\x2e"));return (());}if (((($GLOBAL::PROTO_VERSION ne 
"\x73\x68\x65\x6c\x6c")and ($GLOBAL::PROTO_VERSION ne ("")))and (
NXShell::getNoEcho ()!=(0x05bd+ 2736-0x106c)))){if ((main::nxwrite (
main::nxgetSTDOUT (),($hdata."\x0a"))==(-(0x0218+ 4638-0x1435)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}else{if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x0224+ 4910-0x1551)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (());}}return (
$data);}sub __error{main::nxwrite (main::nxgetSTDERR (),
"\x45\x72\x72\x6f\x72\x3a\x20\x66\x61\x74\x61\x6c\x20\x65\x72\x72\x6f\x72\x20\x69\x6e\x20\x6d\x6f\x64\x75\x6c\x65\x20\x4e\x58\x4d\x73\x67\x2c\x20\x63\x68\x65\x63\x6b\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x6d\x6f\x72\x65\x20\x64\x65\x74\x61\x69\x6c\x73\x0a"
);NXShell::handle_command ("\x65\x78\x69\x74");main::nxexit (
(0x123a+ 3318-0x1f2f));}sub __readnLine{(my $maxLengt=(shift (@_)||
(0x229a+ 302-0x13c8)));(my $data=());(my $endOfLine=(0x0243+ 9215-0x2642));(my $ignoreUntileEOL
=(0x102b+ 4607-0x222a));while ((not ($endOfLine))){(my $readBuff=());(my $bytesToRead
=($maxLengt-length ($GLOBAL::NXMsg::__inBuffer)));if (($bytesToRead<=
(0x1eb4+ 1945-0x264d))){($GLOBAL::NXMsg::__inBuffer=(""));($ignoreUntileEOL=
(0x0898+ 1085-0x0cd4));(my $warning=((
"\x4e\x58\x4d\x73\x67\x3a\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6c\x69\x6e\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6c\x6f\x6e\x67\x65\x72\x20\x74\x68\x61\x6e\x20"
.$GLOBAL::commandBufferLimit)."\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x73\x2e"
));Logger::warning ($warning);(my ($reg_exp,$message)=get_msg (
"\x65\x54\x6f\x6f\x4c\x6f\x6e\x67\x43\x6f\x6d\x6d\x61\x6e\x64",
"\x4e\x58\x4d\x73\x67",$GLOBAL::commandBufferLimit));main::nxwrite (
main::nxgetSTDOUT (),$message);}(my $readBytes=main::nxread (main::nxgetSTDIN ()
,(\$readBuff),(0x00bc+ 341-0x0210)));if ((not (defined ($readBytes)))){(my $errorstring
=libnxh::NXGetErrorString ());(my $errorNumber=libnxh::NXGetError ());
main::nxwrite (main::nxgetSTDOUT (),"\x0a");NXShell::setExitRequest (((((
"\x46\x61\x69\x6c\x65\x64\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x74\x64\x69\x6e\x3a\x20"
.$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));return (());}if ((
$readBytes==(0x1735+ 192-0x17f5))){main::nxwrite (main::nxgetSTDOUT (),"\x0a");
NXShell::setExitRequest ($ExitRequests::closedSTDIN);return (());}if (($readBuff
 eq "\x0a")){(($ignoreUntileEOL eq (0x042d+ 5979-0x1b87))and ($ignoreUntileEOL=
(0x0894+ 1714-0x0f46)));($data=$GLOBAL::NXMsg::__inBuffer);($endOfLine=
(0x058b+ 2799-0x1079));($GLOBAL::NXMsg::__inBuffer=(""));}else{if ((
$ignoreUntileEOL eq (0x0307+ 8567-0x247e))){($GLOBAL::NXMsg::__inBuffer.=
$readBuff);}}}return ($data);}sub __globalReadnLine{(my $self=shift (@_));(my $handleHash
=shift (@_));(my $refParameters=$$handleHash{
"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});if ((not ($$refParameters{
"\x65\x6e\x64\x4f\x66\x4c\x69\x6e\x65"}))){(my $readBuff=());(my $bytesToRead=(
$$refParameters{"\x6d\x61\x78\x4c\x65\x6e\x67\x74"}-length (
$GLOBAL::NXMsg::__inBuffer)));if (($bytesToRead<=(0x0216+ 7980-0x2142))){(
$GLOBAL::NXMsg::__inBuffer=(""));($$refParameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}=
(0x1309+ 4185-0x2361));(my $warning=((
"\x4e\x58\x4d\x73\x67\x3a\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6c\x69\x6e\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6c\x6f\x6e\x67\x65\x72\x20\x74\x68\x61\x6e\x20"
.$GLOBAL::commandBufferLimit)."\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x73\x2e"
));Logger::warning ($warning);(my ($reg_exp,$message)=get_msg (
"\x65\x54\x6f\x6f\x4c\x6f\x6e\x67\x43\x6f\x6d\x6d\x61\x6e\x64",
"\x4e\x58\x4d\x73\x67",$GLOBAL::commandBufferLimit));if ((main::nxwrite (
main::nxgetSTDOUT (),$message)==(-(0x18ba+ 2378-0x2203)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);}}(my $readBytes=
main::nxread (main::nxgetSTDIN (),(\$readBuff),4096));if ((not (defined (
$readBytes)))){(my $errorstring=libnxh::NXGetErrorString ());if ((main::nxwrite 
(main::nxgetSTDOUT (),"\x0a")==(-(0x101a+ 3441-0x1d8a)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);}NXShell::setExitRequest (
((
"\x46\x61\x69\x6c\x65\x64\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x74\x64\x69\x6e\x3a\x20"
.$errorstring)."\x2e"));($$refParameters{"\x64\x61\x74\x61"}=());$self->
removeHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->setExit (
$handleHash,(0x11ef+ 4751-0x247e),(0x154b+ 2960-0x20db));return (());}if ((
$readBytes==(0x093d+ 2680-0x13b5))){if ((main::nxwrite (main::nxgetSTDOUT (),
"\x0a")==(-(0x10b9+ 4501-0x224d)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);}NXShell::setExitRequest (
$ExitRequests::closedSTDIN);($$refParameters{"\x64\x61\x74\x61"}=());$self->
removeHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->setExit (
$handleHash,(0x09aa+ 7193-0x25c3),(0x04cf+ 6327-0x1d86));return (());}if ((
$readBuff=~ /\n$/ )){($readBuff=~ s/\r?\n$// );($GLOBAL::NXMsg::__inBuffer.=
$readBuff);(($$refParameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}eq 
(0x0801+ 276-0x0914))and ($$refParameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}=
(0x1723+ 2757-0x21e8)));($$refParameters{"\x64\x61\x74\x61"}=
$GLOBAL::NXMsg::__inBuffer);($$refParameters{
"\x65\x6e\x64\x4f\x66\x4c\x69\x6e\x65"}=(0x1ae9+ 1043-0x1efb));(
$GLOBAL::NXMsg::__inBuffer=(""));$self->removeHandle ($$handleHash{
"\x48\x61\x6e\x64\x6c\x65"});$self->setExit ($handleHash,(0x00e7+ 8179-0x20da),
(0x11a1+ 4308-0x2275));return (());}else{if (($$refParameters{
"\x69\x67\x6e\x6f\x72\x65\x55\x6e\x74\x69\x6c\x65\x45\x4f\x4c"}eq 
(0x0287+ 9133-0x2634))){($GLOBAL::NXMsg::__inBuffer.=$readBuff);}}}else{$self->
removeHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->setExit (
$handleHash,(0x006c+ 844-0x03b8),(0x1731+ 200-0x17f9));}}sub setSilentMode{(
$__silentMode=(0x020f+ 8731-0x2429));}sub offSilentMode{($__silentMode=
(0x0689+ 3560-0x1471));}sub isSilentMode{if (($__silentMode==
(0x089f+ 2632-0x12e6))){return ((0x0d38+ 5078-0x210d));}return (
(0x0bc7+ 3437-0x1934));}sub setSendEOLAfterSendRequest{($__eolAfterRequest=
(0x10b0+ 1609-0x16f8));}sub sendEOL{if (($__eolAfterRequest==
(0x0ea3+ 6171-0x26bd))){return ((0x06c2+ 2956-0x124d));}return (
(0x0cc7+ 4571-0x1ea2));}sub clearDataParameter{($parameters{"\x64\x61\x74\x61"}=
(""));}sub blindInput{if ((not (Server::isConnectedToConsole ()))){Logger::debug
 (
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x65\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x63\x6f\x6e\x73\x6f\x6c\x65\x2e"
);return ((0x0119+ 1198-0x05c7));}Common::NXCore::disableConsoleEchoMode ();}sub
 showInput{if ((not (Server::isConnectedToConsole ()))){Logger::debug (
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x65\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x63\x6f\x6e\x73\x6f\x6c\x65\x2e"
);return ((0x0107+ 1054-0x0525));}Common::NXCore::enableConsoleEchoMode ();}sub 
getIndexStringByMessage{(my $message=shift (@_));(my $messageId=(-
(0x0616+ 4441-0x176e)));if (($message=~ /NX> (\d+) / )){($messageId=$1);}
removeMessageHeader ((\$message));if (($messageId==
$GLOBAL::BRAND_MESSAGE_LICENSE_NOT_FOUND)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_NOT_VALID)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_EXPIRED)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x45\x78\x70\x69\x72\x65\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_PRODUCT_NOT_MATCH)){return
 (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x50\x72\x6f\x64\x75\x63\x74\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_NEED_UPDATE)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4e\x65\x65\x64\x55\x70\x64\x61\x74\x65"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_GENERIC_SUPPORT)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x47\x65\x6e\x65\x72\x69\x63\x53\x75\x70\x70\x6f\x72\x74"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_PLATFORM_NOT_MATCH)){
return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x50\x6c\x61\x74\x66\x6f\x72\x6d\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_EVALUATION_EXPIRED)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_DATE_NOT_VALID)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x44\x61\x74\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_EXPIRY_NOT_VALID)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x78\x70\x69\x72\x79\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_LICENSE_UNSUBSCRIBED)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x55\x6e\x73\x75\x62\x73\x63\x72\x69\x62\x65\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_UPGRADE_EXPIRED)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x55\x70\x67\x72\x61\x64\x65\x45\x78\x70\x69\x72\x65\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_NODE_LICENSE_NOT_FOUND)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4e\x6f\x64\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_NODE_LICENSE_PRODUCT_NOT_MATCH)){
return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4e\x6f\x64\x65\x4c\x69\x63\x65\x6e\x63\x65\x50\x72\x6f\x64\x75\x63\x74\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);}elsif (($messageId==$GLOBAL::BRAND_MESSAGE_NODE_LICENSE_TYPE_NOT_MATCH)){
return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4e\x6f\x64\x65\x4c\x69\x63\x65\x6e\x63\x65\x54\x79\x70\x65\x4e\x6f\x74\x4d\x61\x74\x63\x68"
);}elsif (($messageId==
$GLOBAL::BRAND_MESSAGE_EVALUATION_UPGRADE_FROM_3_TO_4_NOT_POSSIBLE)){return (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x55\x70\x67\x72\x61\x64\x65\x46\x72\x6f\x6d\x33\x54\x6f\x34\x4e\x6f\x74\x50\x6f\x73\x73\x69\x62\x6c\x65"
);}elsif (($messageId==$GLOBAL::MSG_ERROR_NOT_ENOUGH_X_RESOURCES)){return (
"\x65\x4e\x6f\x46\x72\x65\x65\x44\x69\x73\x70\x6c\x61\x79");}elsif (($messageId
==$GLOBAL::MSG_ERROR_REACHED_SESSION_LIMIT)){if ((index ($message,getEnglishText
 (
"\x65\x47\x55\x49\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x73"
))!=(-(0x1540+ 2649-0x1f98)))){return (
"\x65\x47\x55\x49\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x73"
);}elsif ((index ($message,getEnglishText (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x53\x65\x73\x73\x69\x6f\x6e\x73"
))!=(-(0x05c8+ 7649-0x23a8)))){return (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x53\x65\x73\x73\x69\x6f\x6e\x73"
);}elsif ((index ($message,getEnglishText (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x47\x75\x65\x73\x74\x73\x4e\x75\x6d\x62\x65\x72"
))!=(-(0x127c+ 1861-0x19c0)))){return (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x47\x75\x65\x73\x74\x73\x4e\x75\x6d\x62\x65\x72"
);}}elsif ((index ($message,getEnglishText (
"\x65\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x4e\x6f\x74\x46\x6f\x75\x6e\x64"))!=(-
(0x19e8+ 1777-0x20d8)))){return (
"\x65\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x4e\x6f\x74\x46\x6f\x75\x6e\x64");}
return ((""));}sub removeMessageHeader{(my $ref_message=shift (@_));(
$$ref_message=~ s/NX> \d+ ERROR: //gm );($$ref_message=~ s/NX> \d+ WARNING: //gm )
;($$ref_message=~ s/NX> \d+ //gm );}sub isMessageRegistered{(my $index=shift (@_
));if (Common::NXMsg::isMessageRegistered ($index)){return (
(0x1046+ 2214-0x18eb));}return ((0x0657+ 7286-0x22cd));}sub getMessageNumber{
return (Common::NXMsg::getNumber (@_));}sub shouldPackMessage{(my $messageNumber
=shift (@_));if ((Common::NXMsg::isErrorMessageNumber ($messageNumber)and 
Server::isClientSupportsPackedMessages ())){return ((0x095d+ 7421-0x2659));}
return ((0x1b39+ 1766-0x221f));}sub errorDependsOnClientType{(my $message=shift 
(@_));(my (@params)=shift (@_));if (Server::isClientNxclient ()){($message=~ s/^eCMD/eGUI/ )
;}error ($message,"\x4e\x58\x4d\x73\x67",@params);}register_error (
"\x4e\x58\x4d\x73\x67",
"\x65\x54\x6f\x6f\x4c\x6f\x6e\x67\x43\x6f\x6d\x6d\x61\x6e\x64",
(0x11d1+ 4150-0x1fb1));return ((0x0e0c+ 6299-0x26a6));
