############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXAnywhereAuth;no warnings;($username=(""));($isDefaultUser=
(0x10fd+ 1476-0x16c1));sub checkToken{(my $request=shift (@_));Logger::debug (((
"\x63\x68\x65\x63\x6b\x43\x6c\x69\x65\x6e\x74\x52\x65\x71\x75\x65\x73\x74\x20\x5b"
.$request)."\x5d"));if (($request=~ /username=(.*)&token=(.*)/ )){(my $clientUsername
=main::urldecode ($1));(my $clientToken=main::urldecode ($2));if (
isSupportedToken ($clientToken,$clientUsername)){Logger::debug (
"\x63\x68\x65\x63\x6b\x43\x6c\x69\x65\x6e\x74\x52\x65\x71\x75\x65\x73\x74\x20\x54\x4f\x4b\x45\x4e\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64"
);($username=$clientUsername);NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x4e\x4d\x4e\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d\x6c\x61\x73\x74\x75\x73\x65\x72\x69\x64\x2c\x76\x61\x6c\x75\x65\x3d"
.$clientUsername)."\x0a"));return ((0x0ac4+ 3676-0x191f));}}(my $name=
Server::getAnywhereName ());Logger::warning (((($name.
"\x20\x41\x75\x74\x68\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x77\x72\x6f\x6e\x67\x20\x74\x6f\x6b\x65\x6e\x20\x27"
).$request)."\x27\x20\x2e"));return ((0x09bc+ 2350-0x12ea));}sub checkSecurityId
{(my $playerSecurityId=shift (@_));if (($playerSecurityId eq (""))){
Logger::error ((Server::getAnywhereName ().
"\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x73\x65\x63\x75\x72\x69\x74\x79\x20\x69\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e"
));return ((0x09a9+ 1151-0x0e28));}($playerSecurityId=
libnxhs::NXAnywhereDecodePassword ($playerSecurityId));main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");(my $securityId=
NXAnywhereRedis::getAccessKey ());if (($securityId eq $playerSecurityId)){
Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x72\x72\x65\x63\x74\x20\x73\x65\x63\x75\x72\x69\x74\x79\x20\x69\x64\x2e"
));return ((0x165c+ 1430-0x1bf1));}Logger::debug ((Server::getAnywhereName ().
"\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x73\x65\x63\x75\x72\x69\x74\x79\x20\x69\x64\x2e"
));return ((0x07c7+ 1266-0x0cb9));}sub isSupportedToken{(my $clientToken=shift (
@_));(my $clientUsername=shift (@_));(my $token=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x54\x4f\x4b\x45\x4e"));Logger::debug (((((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x74\x6f\x6b\x65\x6e\x20\x5b"
.$clientToken).
"\x5d\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x5b").
$clientUsername)."\x5d\x20\x77\x69\x74\x68\x20\x74\x6f\x6b\x65\x6e\x20\x5b").
$token)."\x5d"));if (($clientUsername eq (""))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x74\x6f\x6b\x65\x6e\x20\x66\x6f\x72\x20\x65\x6d\x70\x74\x79\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x2e"
);return ((0x0767+ 3364-0x148b));}if (($clientToken eq $token)){Logger::debug (
"\x69\x73\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x54\x6f\x6b\x65\x6e\x20\x4f\x4b");
return ((0x0227+ 443-0x03e1));}Logger::debug (
"\x69\x73\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x54\x6f\x6b\x65\x6e\x20\x46\x41\x49\x4c"
);return ((0x1f6a+ 968-0x2332));}sub getUsername{if (($username ne (""))){return
 ($username);}else{Logger::error ((Server::getAnywhereName ().
"\x20\x75\x73\x65\x72\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));
Common::NXCore::assertExit ();}}sub setDefaultUser{($isDefaultUser=
(0x1c6c+ 2621-0x26a8));}sub isDefaultUser{return ($isDefaultUser);}
"\x3f\x3f\x3f";
