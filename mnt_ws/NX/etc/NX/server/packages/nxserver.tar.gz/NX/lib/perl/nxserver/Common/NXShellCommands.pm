############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXShellCommands;no warnings;($pathNotFound=
"\x5f\x5f\x4e\x4f\x4e\x45\x5f\x5f");($commandSs="\x5f\x5f\x53\x53\x5f\x5f");(
$commandNetstat="\x5f\x5f\x4e\x45\x54\x53\x54\x41\x54\x5f\x5f");sub checkPath{(my $command
=shift (@_));if (-x (("\x2f\x62\x69\x6e\x2f".$command))){return ((
"\x2f\x62\x69\x6e\x2f".$command));}elsif (-x (("\x2f\x73\x62\x69\x6e\x2f".
$command))){return (("\x2f\x73\x62\x69\x6e\x2f".$command));}elsif (-x ((
"\x2f\x75\x73\x72\x2f\x62\x69\x6e\x2f".$command))){return ((
"\x2f\x75\x73\x72\x2f\x62\x69\x6e\x2f".$command));}elsif (-x ((
"\x2f\x75\x73\x72\x2f\x73\x62\x69\x6e\x2f".$command))){return ((
"\x2f\x75\x73\x72\x2f\x73\x62\x69\x6e\x2f".$command));}elsif (-x ((
"\x2f\x75\x73\x72\x2f\x6c\x6f\x63\x61\x6c\x2f\x62\x69\x6e\x2f".$command))){
return (("\x2f\x75\x73\x72\x2f\x6c\x6f\x63\x61\x6c\x2f\x62\x69\x6e\x2f".$command
));}elsif (-x (("\x2f\x75\x73\x72\x2f\x62\x69\x6e\x2f\x58\x31\x31\x2f".$command)
)){return (("\x2f\x75\x73\x72\x2f\x62\x69\x6e\x2f\x58\x31\x31\x2f".$command));}(my $path
=checkPathInPathVariable ($command));return ($path);}sub checkPathInPathVariable
{(my $command=shift (@_));(my $envPath=$ENV{"\x50\x41\x54\x48"});($envPath=~ s/^PATH=//gm )
;return ($pathNotFound);(my (@paths)=split ( /;/ ,$envPath,(0x0959+ 5514-0x1ee3)
));foreach my $path (@paths){(my $file=(($path.$GLOBAL::DIRECTORY_SLASH).
$command));if (-x ($file)){return ($file);}}return ($pathNotFound);}sub getPath{
(my $command=shift (@_));(my $ref_commandPath=getReferenceToSavedCommand (
$command));if ((not (defined ($$ref_commandPath)))){($$ref_commandPath=checkPath
 ($command));}(my $commandPath=$$ref_commandPath);return ($commandPath);}sub 
getCommand{(my (@args)=@_);(my $command=shift (@args));(my $ref_commandPath=
getReferenceToSavedCommand ($command));if ((not (defined ($$ref_commandPath)))){
($$ref_commandPath=checkPath ($command));}(my $commandPath=$$ref_commandPath);(my (
@reply)=());if (($commandPath ne $pathNotFound)){push (@reply,$commandPath,@args
);}else{push (@reply,$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e",
"\x2d\x63",main::shell_quote ($command,@args));}return (@reply);}sub 
getReferenceToSavedCommand{(my $command=shift (@_));(my $refCommand=((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x68\x65\x6c\x6c\x43\x6f\x6d\x6d\x61\x6e\x64\x73\x3a\x3a"
.$command)."\x5f\x63\x6f\x6d\x6d\x61\x6e\x64"));return ($refCommand);}sub 
getReferenceToSavedCommandParameters{(my $command=shift (@_));(my $type=shift (
@_));(my $refOptions=((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x68\x65\x6c\x6c\x43\x6f\x6d\x6d\x61\x6e\x64\x73\x3a\x3a"
.$command).("\x5f\x6f\x70\x74\x69\x6f\x6e\x73\x5f".$type)));return ($refOptions)
;}sub isApplicationInKnownPath{(my $command=shift (@_));(my $refCommand=
getReferenceToSavedCommand ($command));if ((not (defined ($$refCommand)))){(
$$refCommand=checkPath ($command));}(my $commandPath=$$refCommand);if ((
$commandPath ne $pathNotFound)){return ((0x08af+ 1383-0x0e15));}return (
(0x07a2+ 7551-0x2521));}sub isPasswordRequestMessage{(my $message=shift (@_));if
 ((((($message=~ /password for/ )or ($message=~ /Password/ ))or ($message=~ /'s password/ )
)or ($message=~ /assword:\ *$/ ))){return ((0x0ba4+ 2869-0x16d8));}return (
(0x09a6+ 5480-0x1f0e));}sub isNotInSudoersMessage{(my $message=shift (@_));if ((
($message=~ /is not in the sudoers file/ )or ($message=~ /is not allowed to execute/ )
)){return ((0x19a7+ 2878-0x24e4));}return ((0x0552+ 2626-0x0f94));}sub 
isNotAdministrator{(my $message=shift (@_));if (($message=~ /Only a user with administrative privileges can use option/ )
){return ((0x0462+ 696-0x0719));}return ((0x088c+ 2172-0x1108));}sub 
getConnectionsForXserversCheck{(my $ref_cmd_out=shift (@_));(my $ref_exit_value=
shift (@_));(my (@command)=getNetStatisticsCommandForListeningUnix ());if ((
$command[(0x1990+ 838-0x1cd6)]eq $pathNotFound)){($$ref_exit_value=
(0x0f07+ 3956-0x1e7a));return ((0x1439+ 3907-0x237c));}my ($cmd_err);(($cmd_err,
$$ref_cmd_out,$$ref_exit_value)=main::run_command ((\@command),("")));if (
$$ref_exit_value){Logger::warning (((
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x6e\x65\x74\x20\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$$ref_exit_value)."\x27\x2e"));Logger::warning (((
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x6e\x65\x74\x20\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x6f\x75\x74\x70\x75\x74\x20\x27"
.$$ref_cmd_out)."\x27\x2e"));Logger::warning (((
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x6e\x65\x74\x20\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x65\x72\x72\x6f\x72\x20\x27"
.$cmd_err)."\x27\x2e"));return ((0x1c64+  34-0x1c86));}return (
(0x12e2+ 3755-0x218c));}sub getListeningConnections{(my $ref_cmd_out=shift (@_))
;(my $ref_exit_value=shift (@_));(my (@command)=getNetStatisticsCommandForAllTcp
 ());if (($command[(0x1153+ 1999-0x1922)]eq $pathNotFound)){($$ref_exit_value=
(0x0278+ 8829-0x24f4));return ((0x0ae7+ 5537-0x2088));}my ($cmd_err);(($cmd_err,
$$ref_cmd_out,$$ref_exit_value)=main::run_command ((\@command),("")));if (
$$ref_exit_value){return ((0x129d+  99-0x1300));}return ((0x00ef+ 4708-0x1352));
}sub getExtendedListeningConnectionsForFontServerChecking{(my $ref_cmd_out=shift
 (@_));(my $ref_exit_value=shift (@_));(my (@command)=
getNetStatisticsCommandForListeningTcpExtended ());if (($command[
(0x0d42+ 4154-0x1d7c)]eq $pathNotFound)){($$ref_exit_value=(0x1515+ 4339-0x2607)
);return ((0x1b83+ 509-0x1d80));}my ($cmd_err);(($cmd_err,$$ref_cmd_out,
$$ref_exit_value)=main::run_command ((\@command),("")));if ($$ref_exit_value){
return ((0x161b+ 3961-0x2594));}return ((0x0743+ 8038-0x26a8));}sub 
getNetStatisticsComandWithPrioritySs{(my $commandPath=checkPath ("\x73\x73"));if
 (($commandPath eq $pathNotFound)){($commandPath=checkPath (
"\x6e\x65\x74\x73\x74\x61\x74"));if (($commandPath eq $pathNotFound)){
setNetStatisticsCommandIsNotFound ();}else{setNetStatisticsCommandIsNetstat ();}
}else{setNetStatisticsCommandIsSs ();}return ($commandPath);}sub 
getNetStatisticsComandWithPriorityNetstat{(my $commandPath=checkPath (
"\x6e\x65\x74\x73\x74\x61\x74"));if (($commandPath eq $pathNotFound)){(
$commandPath=checkPath ("\x73\x73"));if (($commandPath eq $pathNotFound)){
setNetStatisticsCommandIsNotFound ();}else{setNetStatisticsCommandIsSs ();}}else
{setNetStatisticsCommandIsNetstat ();}return ($commandPath);}sub 
setNetStatisticsCommand{(my $command=
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73");if (
isNetStatisticsCommandSet ()){return;}(my $ref_commandPath=
getReferenceToSavedCommand ($command));if (
Common::NXInfo::doesOsPreferSsOverNetstat ()){($$ref_commandPath=
getNetStatisticsComandWithPrioritySs ());}else{($$ref_commandPath=
getNetStatisticsComandWithPriorityNetstat ());}}sub 
getNetStatisticsCommandForListeningUnix{setNetStatisticsCommand ();if (
isNetStatisticsCommandNetstat ()){return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x6c\x6e",
"\x2d\x2d\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3d\x75\x6e\x69\x78"));}if (
isNetStatisticsCommandSs ()){return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x6c\x6e\x78"));}
return ($pathNotFound);}sub getNetStatisticsCommandForAllTcp{
setNetStatisticsCommand ();return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x61\x6e\x74"));}sub
 getNetStatisticsCommandForListeningTcpExtended{setNetStatisticsCommand ();if (
isNetStatisticsCommandNetstat ()){return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x6e\x65\x74\x6c"));
}if (isNetStatisticsCommandSs ()){return (getCommand (
"\x6e\x65\x74\x53\x74\x61\x74\x69\x73\x74\x69\x63\x73","\x2d\x6e\x74\x6c"));}
return ($pathNotFound);}sub isNetStatisticsCommandSet{if (defined (
$netStatisticsCommand)){return ((0x0305+ 3187-0x0f77));}return (
(0x1209+ 170-0x12b3));}sub setNetStatisticsCommandIsNotFound{Logger::warning (
"\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x6e\x65\x74\x20\x73\x74\x61\x74\x69\x73\x74\x69\x63\x73\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x2e"
);($netStatisticsCommand=$pathNotFound);}sub setNetStatisticsCommandIsSs{(
$netStatisticsCommand=$commandSs);}sub setNetStatisticsCommandIsNetstat{(
$netStatisticsCommand=$commandNetstat);}sub isNetStatisticsCommandNetstat{if ((
$netStatisticsCommand eq $commandNetstat)){return ((0x1c30+ 2129-0x2480));}
return ((0x07a4+ 265-0x08ad));}sub isNetStatisticsCommandSs{if ((
$netStatisticsCommand eq $commandSs)){return ((0x00fc+ 2810-0x0bf5));}return (
(0x05b4+ 2582-0x0fca));}sub isNetStatisticsCommandAvailable{
setNetStatisticsCommand ();if (($netStatisticsCommand eq $pathNotFound)){return 
((0x0f50+ 5632-0x2550));}return ((0x0930+ 2448-0x12bf));}sub 
isDbusDaemonCommandAvailable{(my $dbusDaemonPath=getPath (
"\x64\x62\x75\x73\x2d\x64\x61\x65\x6d\x6f\x6e"));if (($dbusDaemonPath eq 
$pathNotFound)){return ((0x0aca+ 725-0x0d9f));}return ((0x1ced+ 1912-0x2464));}
sub isDbusSendCommandAvailable{(my $dbusSendPath=getPath (
"\x64\x62\x75\x73\x2d\x73\x65\x6e\x64"));if (($dbusSendPath eq $pathNotFound)){
return ((0x1106+ 3308-0x1df2));}return ((0x00cb+ 5387-0x15d5));}sub 
isNotDbusSendCommandAvailable{return ((!isDbusSendCommandAvailable ()));}sub 
getDbusSendCommand{return (getPath ("\x64\x62\x75\x73\x2d\x73\x65\x6e\x64"));}
"\x3f\x3f\x3f";
