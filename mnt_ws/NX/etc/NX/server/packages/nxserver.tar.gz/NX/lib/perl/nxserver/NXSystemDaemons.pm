############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXSystemDaemons;no warnings;require NXLocate;require NXUpdate;require 
NXServerDaemon;require NXClientSystemDaemons;sub BEGIN{require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub BEGIN{require NXNodeInfo;do{
"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f"->import};}sub BEGIN{require 
Common::NXInfo;do{"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x49\x6e\x66\x6f"->
import};}((%daemonsRestartCounter)=());((%nxupnp)=());((%socket)=());(
$NetworkChangeFD_Read=(-(0x0665+ 5349-0x1b49)));($NetworkChangeFD_Write=(-
(0x0429+ 7731-0x225b)));($statusUninitialized=
"\x73\x65\x72\x76\x69\x63\x65\x5f\x75\x6e\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64"
);($statusStarting=
"\x73\x65\x72\x76\x69\x63\x65\x5f\x73\x74\x61\x72\x74\x69\x6e\x67");(
$statusRunning="\x73\x65\x72\x76\x69\x63\x65\x5f\x72\x75\x6e\x6e\x69\x6e\x67");(
$statusTerminating=
"\x73\x65\x72\x76\x69\x63\x65\x5f\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67");
($statusClosed="\x73\x65\x72\x76\x69\x63\x65\x5f\x63\x6c\x6f\x73\x65\x64");(
$nxhtdPidFile=(""));($restartPID=(""));($preshutdown=(0x0648+ 5869-0x1d35));sub 
BEGIN{require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub
 start{(my $serviceName=shift (@_));if (($serviceName eq "\x6e\x78\x64")){
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44")
;NXServices::NXD::start ();}elsif (($serviceName eq "\x6e\x78\x68\x74\x64")){
main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");
NXServices::NXHtd::start ();}}sub stop{(my $serviceName=shift (@_));if ((
$serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");
NXServices::NXD::stop ();}elsif (($serviceName eq "\x6e\x78\x68\x74\x64")){
main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");
NXServices::NXHtd::stop ();}elsif (($serviceName eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44\x61\x65\x6d\x6f\x6e"
);NXServices::NXDaemon::stop ();}}sub restart{(my $serviceName=shift (@_));if ((
$serviceName eq "\x6e\x78\x64")){stop ("\x6e\x78\x64");start ("\x6e\x78\x64");}
elsif (($serviceName eq "\x6e\x78\x68\x74\x64")){stop ("\x6e\x78\x68\x74\x64");
start ("\x6e\x78\x68\x74\x64");}}sub isEnabled{(my $serviceName=shift (@_));if (
($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::isEnabled ());}elsif (($serviceName eq "\x6e\x78\x68\x74\x64"))
{main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::isEnabled ());}}sub isDisabled{return ((!isEnabled (@_)));}
sub setEnabled{(my $serviceName=shift (@_));if (($serviceName eq "\x6e\x78\x64")
){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::setEnabled ());}elsif (($serviceName eq "\x6e\x78\x68\x74\x64")
){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::setEnabled ());}}sub setHandlingManualStart{(my $serviceName=
shift (@_));if (($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::setHandlingManualStart ());}elsif (($serviceName eq 
"\x6e\x78\x68\x74\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::setHandlingManualStart ());}}sub isSilenceMode{(my $serviceName
=shift (@_));if (($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::isSilenceMode ());}elsif (($serviceName eq 
"\x6e\x78\x68\x74\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::isSilenceMode ());}}sub setSilentMode{(my $serviceName=shift 
(@_));if (($serviceName eq "\x6e\x78\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44");return (
NXServices::NXD::setSilentMode ());}elsif (($serviceName eq 
"\x6e\x78\x68\x74\x64")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x48\x74\x64");return (
NXServices::NXHtd::setSilentMode ());}}sub __getPidFile{(my $serviceName=shift (
@_));(my $path=($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH));($path.=(
"\x72\x75\x6e".$GLOBAL::DIRECTORY_SLASH));($path.=($serviceName.
"\x2e\x70\x69\x64"));if (($serviceName eq "\x6e\x78\x68\x74\x64")){if ((
$nxhtdPidFile ne (""))){return ($nxhtdPidFile);}($nxhtdPidFile=
NXTools::getNxhtdPidFileFromCfg ());if (($nxhtdPidFile ne (""))){return (
$nxhtdPidFile);}else{($nxhtdPidFile=$path);Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6e\x78\x68\x74\x64\x2e\x70\x69\x64\x20\x66\x69\x6c\x65\x20\x66\x72\x6f\x6d\x20\x63\x6f\x6e\x66\x69\x67\x2c\x20\x66\x61\x69\x6c\x20\x62\x61\x63\x6b\x20\x74\x6f\x20\x64\x65\x66\x61\x75\x6c\x74\x3a\x20\x27"
.$path)."\x27"));}}return ($path);}sub __getStopFlagFileName{(my $serviceName=
shift (@_));if (($serviceName eq "\x6e\x78\x73\x65\x72\x76\x65\x72")){return (
$GLOBAL::ServerStopStatusFlagLink);}(my $path=($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH));($path.=("\x72\x75\x6e".$GLOBAL::DIRECTORY_SLASH));(
$path.=($serviceName."\x2e\x73\x74\x6f\x70"));return ($path);}sub 
stopServiceIfRunningWithoutNXServerDaemon{(my $serviceName=shift (@_));if ((not 
(isRunning ($serviceName)))){return ((0x0146+ 4655-0x1375));}if ((
NXServerDaemon::checkDaemonFlock ()!=(0x0e7d+ 1214-0x133b))){(my $servicePid=
readPid ($serviceName));(my $killProcessTree=(0x060c+ 310-0x0742));if ((
$serviceName eq "\x6e\x78\x68\x74\x64")){($killProcessTree=(0x0f41+ 1093-0x1385)
);}killServiceIfRunning ($servicePid,$serviceName,$killProcessTree);}return (
(0x0cc8+ 5462-0x221e));}sub killServiceIfRunning{(my $servicePid=shift (@_));(my $serviceName
=shift (@_));(my $processGroup=shift (@_));(my $silence=(shift (@_)||
(0x0548+ 2725-0x0fed)));if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($servicePid,
$serviceName)){if (main::effectiveUserIsAdministrator ()){if (
Common::NXProcess::sigkill ($servicePid,$processGroup)){Logger::debug (((((
"\x4b\x69\x6c\x6c\x65\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20".$serviceName).
"\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20").$servicePid)."\x2e"));}else{
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x73\x65\x72\x76\x69\x63\x65\x20"
.$serviceName)."\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20").$servicePid)."\x2e"))
;}}else{Common::NXProcess::signalProcessByRestrictedScript ($servicePid,
Common::NXProcess::getSignalKill (),$processGroup);Logger::debug (((((
"\x4b\x69\x6c\x6c\x65\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20".$serviceName).
"\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20").$servicePid)."\x2e"));}(my $waitTimeLimit
=(0x0f98+ 1179-0x142e));(my $waitInterval=0.1);(my $waitTime=
(0x00ea+ 3643-0x0f25));if (Common::NXProcess::isChildProcess ($servicePid)){
Common::NXProcess::nxwaitpid ($servicePid,$NXBits::WAIT_UNTRACED,$waitTimeLimit)
;}else{Logger::debug2 (((((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x27".$serviceName).
"\x27\x20\x74\x6f\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20\x27"
).$servicePid)."\x27\x2e"));while ((Common::NXProcess::isProcessRunning (
$servicePid)and ($waitTime<$waitTimeLimit))){main::nxsleep ($waitInterval);(
$waitTime+=$waitInterval);}}}if ((not (Common::NXProcess::isProcessRunning (
$servicePid)))){($daemonsPids{$serviceName}=(0x0763+ 3593-0x156c));removePidFile
 ($serviceName,$silence);}return;}sub savePid{(my $serviceName=shift (@_));(my $processPid
=shift (@_));(my $filename=__getPidFile ($serviceName));Logger::debug (((((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x50\x49\x44\x20\x66\x6f\x72\x20"
.$serviceName)."\x20\x69\x6e\x20\x27").$filename)."\x27\x2e"));(my $FH=
main::nxopen ($filename,($NXBits::O_RDWR+$NXBits::O_CREAT),(($NXBits::OthersRead
+$NXBits::UserReadWrite)+$NXBits::GroupRead)));if ((not (defined ($FH)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error ((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
).$filename)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring)."\x2e"));
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->throw (((((
"\x63\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$filename)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x3a\x20").
$errorstring)."\x2e"));}(my $write=main::nxwrite ($FH,($processPid."\x0a")));(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());if ((
$write==(-(0x073b+ 5920-0x1e5a)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));main::nxclose ($FH);return ((0x0ff1+ 3737-0x1e89));}
main::nxclose ($FH);Logger::debug ((((((("\x53\x65\x72\x76\x69\x63\x65\x20".
$serviceName)."\x20\x50\x49\x44\x20").$processPid).
"\x20\x73\x61\x76\x65\x64\x20\x69\x6e\x20\x27").$filename)."\x27\x2e"));return (
(0x1e90+ 545-0x20b1));}sub readPid{(my $serviceName=shift (@_));(my $pidFile=
__getPidFile ($serviceName));if ((not (Common::NXFile::isExists ($pidFile)))){
Logger::debug ((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x46\x69\x6c\x65\x20\x27").$pidFile).
"\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));return 
((0x042d+ 3261-0x10ea));}(my $FH=main::nxopen ($pidFile,$NXBits::O_RDONLY,
(0x0611+ 4457-0x177a)));if ((not (defined ($FH)))){return ((0x0bc1+ 4656-0x1df1)
);}my ($processPid);main::nxreadLine ($FH,(\$processPid));main::nxclose ($FH);if
 (($processPid=~ /^(\d+)$/ )){chomp ($processPid);Logger::debug (((((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x52\x65\x61\x64\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27"
).$pidFile)."\x27\x3a\x20").$processPid)."\x2e"));return ($processPid);}
Logger::warning ((((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x57\x72\x6f\x6e\x67\x20\x66\x6f\x72\x6d\x61\x74\x20\x6f\x66\x20\x50\x49\x44\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27"
).$pidFile)."\x27\x3a\x20").$processPid)."\x2e"));return ((0x17df+ 1980-0x1f9b))
;}sub removePidFile{(my $serviceName=shift (@_));(my $pidFile=__getPidFile (
$serviceName));if ((not (Common::NXFile::isExists ($pidFile)))){Logger::debug ((
((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27").$pidFile).
"\x27\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x2e"));return (
(0x08fb+ 726-0x0bd1));}if (($serviceName eq "\x6e\x78\x68\x74\x64")){return (
__removeNxhtdPidFile ($pidFile));}if ((not (unlink ($pidFile)))){Logger::warning
 ((((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27"
).$pidFile)."\x27\x3a\x20").$!)."\x2e"));return ((0x1781+ 1434-0x1d1a));}return 
((0x0322+ 662-0x05b8));}sub __removeNxhtdPidFile{(my $pidFile=shift (@_));(my (
@command)=($GLOBAL::CommandNXexec,$GLOBAL::SCRIPT_NXHTD,"\x63\x6c\x65\x61\x6e"))
;(my (@options)=());(my ($cmd_err,$cmd_out,$exit_value)=main::run_command ((
\@command),(\@options)));if (($exit_value!=(0x0598+ 5690-0x1bd2))){
Logger::warning (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27\x6e\x78\x68\x74\x64\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x50\x49\x44\x20\x66\x69\x6c\x65\x20\x27"
.$pidFile)."\x27\x2e"));}}sub isRunning{(my $serviceName=shift (@_));(my $servicePid
=readPid ($serviceName));return (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($servicePid,
$serviceName));}sub printStatus{(my $serviceName=shift (@_));(my $operation=
shift (@_));if (($serviceName eq "\x6e\x78\x6e\x6f\x64\x65")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x4e\x6f\x64\x65");
return (NXServices::NXNode::printStatus ($operation));}if (isRunning (
$serviceName)){if ((not (isSilenceMode ($serviceName)))){main::nxrequire (
"\x4e\x58\x53\x74\x61\x72\x74\x75\x70");if (NXStartup::serviceWasRunning (
$serviceName)){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x52\x75\x6e\x6e\x69\x6e\x67"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}
else{NXMsg::info ("\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
}else{if ((not (isSilenceMode ($serviceName)))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
return ((0x20af+ 181-0x2164));}sub isStopFlag{(my $serviceName=shift (@_));(my $silence
=(shift (@_)||(0x0c88+ 1014-0x107e)));(my $stopFlagFile=__getStopFlagFileName (
$serviceName));if (Common::NXFile::isExists ($stopFlagFile)){return (
(0x0a8d+ 617-0x0cf5));}return ((0x06f8+ 3153-0x1349));}sub setStopFlag{(my $serviceName
=shift (@_));(my $stopFlagFile=__getStopFlagFileName ($serviceName));(my $FH=
main::nxopen ($stopFlagFile,($NXBits::O_WRONLY+$NXBits::O_CREAT),((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead)));if ((not (
defined ($FH)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
).$stopFlagFile)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring)."\x2e"));return ((0x0a4c+ 5079-0x1e22));}else{
main::nxclose ($FH);}my ($errorName);my ($errorCode);if ((
Common::NXFile::setOwnershipForUserNX ($stopFlagFile,(\$errorName),(\$errorCode)
)==(-(0x056c+ 130-0x05ed)))){Logger::error (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x69\x6c\x65\x20"
.$stopFlagFile)."\x20\x74\x6f\x20\x75\x73\x65\x72\x20\x6e\x78\x2e\x20").
$errorCode)."\x2c\x20").$errorName)."\x2e"));return ((0x1202+ 3065-0x1dfa));}
return ((0x196d+ 964-0x1d31));}sub removeStopFlag{(my $serviceName=shift (@_));
Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x74\x6f\x70\x20\x66\x6c\x61\x67\x20\x66\x6f\x72\x20"
.$serviceName)."\x2e"));(my $stopFlagFile=__getStopFlagFileName ($serviceName));
if (Common::NXFile::isExists ($stopFlagFile)){if ((not (unlink ($stopFlagFile)))
){Logger::error (((((("\x53\x65\x72\x76\x69\x63\x65\x20\x27".$serviceName).
"\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x27").
$stopFlagFile)."\x27\x3a\x20").$!));return ((0x0a19+ 1010-0x0e0a));}}return (
(0x0d25+ 5369-0x221e));}sub isShutdownFlag{(my $shutdownFlagFile=
__getShutdownFlagFileName ());if (Common::NXFile::isExists ($shutdownFlagFile)){
return ((0x0465+ 4095-0x1463));}if (isPreshutdown ()){return (
(0x00b0+ 6225-0x1900));}return ((0x0cc2+ 1317-0x11e7));}sub setShutdownFlag{if (
isShutdownFlag ()){Logger::debug (
"\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x66\x6c\x61\x67\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74\x2e"
);return ((0x12f4+ 4672-0x2534));}(my $shutdownFlagFile=
__getShutdownFlagFileName ());(my $FH=main::nxopen ($shutdownFlagFile,(
$NXBits::O_WRONLY+$NXBits::O_CREAT),(($NXBits::UserReadWrite+$NXBits::GroupRead)
+$NXBits::OthersRead)));if ((not (defined ($FH)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x27\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$shutdownFlagFile)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"))
;Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring));}else{main::nxclose ($FH);}(my $chownReturn=
Common::NXFile::setOwnershipForUserNX ($shutdownFlagFile));if (($chownReturn==(-
(0x08b5+ 5311-0x1d73)))){return ((0x000a+ 4049-0x0fda));}Logger::info (
"\x53\x68\x75\x74\x74\x69\x6e\x67\x20\x64\x6f\x77\x6e\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x73\x65\x72\x76\x65\x72\x20\x61\x6e\x64\x20\x73\x65\x72\x76\x69\x63\x65\x73\x2e"
);}sub removeShutdownFlag{(my $shutdownFlagFile=__getShutdownFlagFileName ());if
 (Common::NXFile::isExists ($shutdownFlagFile)){if ((not (unlink (
$shutdownFlagFile)))){Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20\x27"
.$shutdownFlagFile)."\x27\x3a\x20").$!));return ((0x0fb0+ 1914-0x1729));}}return
 ((0x0005+ 4326-0x10eb));}sub __getShutdownFlagFileName{(my $path=(((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e").
$GLOBAL::DIRECTORY_SLASH));($path.=
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x73\x68\x75\x74\x64\x6f\x77\x6e");return (
$path);}sub initUPnPServices{main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");
NXUpnp::init ();if (NXUpnp::isUPnPEnabled ()){NXUpnp::checkIfAddPortMapping ();}
return;}sub stopUPnPServices{main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");
NXUpnp::deleteServiceRules ((0x0a64+ 3818-0x194d),(0x1563+  76-0x15af));
NXUpnp::destroy ();return;}sub initNXNetworkChangeService{main::nxrequire (
"\x4e\x58\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65");if (
NXNetworkChange::isNetworkChangeEnabled ()){
NXNetworkChange::startNetworkChangeThread ();}return;}sub 
stopNXNetworkChangeService{main::nxrequire (
"\x4e\x58\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65");
NXNetworkChange::destroy ();return;}sub waitOnSigchld{(my $processName=shift (@_
));(my $processPid=shift (@_));(my $timeout=shift (@_));if ((not (
Common::NXProcess::isChildProcess ($processPid)))){Logger::warning (((
"\x4e\x6f\x74\x20\x6d\x79\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x5b".$processPid).
"\x5d\x20\x69\x73\x20\x6e\x6f\x74\x20\x6d\x79\x20\x63\x68\x69\x6c\x64\x2e"));
return ((0x1131+ 4232-0x21b9));}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);(my $finish=(0x0357+ 4411-0x1492));(my $startTime=
Common::NXTime::getSecondsSinceEpoch ());while (($finish!=(0x07c6+ 830-0x0b03)))
{Logger::debug ((((("\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x27".
$processName).
"\x27\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x5b"
).$timeout)."\x5d"));(my (@ready)=$selector->can_read (($timeout *
(0x0a04+ 2495-0x0fdb))));if ((not (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($processPid,
$processName)))){($finish=(0x0375+ 185-0x042d));Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$processName).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2e"));}else{(my $timewait=(
Common::NXTime::getSecondsSinceEpoch ()-$startTime));($timeout-=$timewait);if ((
$timeout<=(0x02a9+ 5841-0x197a))){($finish=(0x1ced+ 302-0x1e1a));Logger::warning
 (((
"\x54\x69\x6d\x65\x6f\x75\x74\x20\x77\x68\x65\x6e\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x27"
.$processName)."\x27\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x2e"));}}}}sub 
handleServiceClosed{(my $serviceName=shift (@_));if ((not (__isSilenceMode (
$serviceName)))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}
removePidFile ($serviceName,(0x06e4+ 3960-0x165b));($daemonsPids{$serviceName}=
(0x0026+ 9083-0x23a1));NXLocate::requestToRemove ($serviceName);Logger::debug (
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x43\x6c\x6f\x73\x65\x64\x3a\x20\x64\x6f\x6e\x65\x2e"
);}sub handleServiceNotClosed{(my $serviceName=shift (@_));if ((not (
__isSilenceMode ($serviceName)))){NXMsg::info (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$serviceName);}}
sub waitForServiceClosure{(my $servicePid=shift (@_));(my $serviceName=shift (@_
));if (Common::NXProcess::isChildProcess ($servicePid)){waitOnSigchld (
$serviceName,$servicePid,getClosureTimeout ());}else{(my $waitTimeLimit=
getClosureTimeout ());Logger::debug (((((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x27".$serviceName).
"\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x3a\x20"
).$waitTimeLimit)."\x2e"));(my $waitInterval=0.1);(my $waitTime=
(0x06cb+ 557-0x08f8));while ((
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($servicePid,
$serviceName)and ($waitTime<$waitTimeLimit))){main::nxsleep ($waitInterval);(
$waitTime+=$waitInterval);}}}sub getClosureTimeout{return (
$GLOBAL::DefaultServiceClosureTimeout);}sub fixHttpdAfterUpdate{if (
NXLicense::isHttpdSupportFeature ()){(my $cloudConfigFile=($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH));($cloudConfigFile.=("\x65\x74\x63".
$GLOBAL::DIRECTORY_SLASH));($cloudConfigFile.=
"\x63\x6c\x6f\x75\x64\x2e\x63\x66\x67");if (Common::NXFile::isExists (
$cloudConfigFile)){return;}(my $portalConfigFile=($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH));($portalConfigFile.=("\x65\x74\x63".
$GLOBAL::DIRECTORY_SLASH));($portalConfigFile.=
"\x70\x6f\x72\x74\x61\x6c\x2e\x63\x66\x67");if (Common::NXFile::isExists (
$portalConfigFile)){(my ($retVal,$outMsg)=Common::NXCore::copyFile (
$portalConfigFile,$cloudConfigFile));if (($outMsg ne (""))){Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x63\x6c\x6f\x75\x64\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65\x20"
.$cloudConfigFile)."\x3a\x20").$outMsg)."\x2e"));return ((0x0916+ 2822-0x141c));
}Common::NXFile::setOwnershipForOwnerFile ($cloudConfigFile,$portalConfigFile);
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($cloudConfigFile);
}}}sub fixNXpamAfterUpdate{(my $pamdNXPath=($GLOBAL::DIRECTORY_SLASH.
"\x65\x74\x63"));($pamdNXPath.=($GLOBAL::DIRECTORY_SLASH."\x70\x61\x6d\x2e\x64")
);($pamdNXPath.=($GLOBAL::DIRECTORY_SLASH."\x6e\x78"));if (
Common::NXFile::isExists ($pamdNXPath)){return;}Common::NXCore::run_setup (
"\x69\x6e\x73\x74\x61\x6c\x6c\x2d\x70\x61\x6d");}sub fixUuidFile{(my $uuidFile=(
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH));($uuidFile.=("\x65\x74\x63".
$GLOBAL::DIRECTORY_SLASH));($uuidFile.="\x75\x75\x69\x64");if (
Common::NXFile::isExists ($uuidFile)){return;}Logger::debug (
"\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x75\x75\x69\x64\x20\x66\x69\x6c\x65\x2e");
(my $key=generateUuidKey ());if (($key eq (""))){Logger::warning (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20\x75\x75\x69\x64\x20\x66\x69\x6c\x65\x2e"
);return ((0x0f4b+ 5116-0x2346));}(my $FH=main::nxopen ($uuidFile,(
$NXBits::O_RDWR+$NXBits::O_CREAT),(($NXBits::OthersRead+$NXBits::UserReadWrite)+
$NXBits::GroupRead)));if ((not (defined ($FH)))){return ((0x05dd+ 6849-0x209d));
}if ((main::nxwrite ($FH,$key)==(-(0x0bbb+ 593-0x0e0b)))){main::nxclose ($FH);
return ((0x118c+ 691-0x143e));}main::nxclose ($FH);
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($uuidFile);chomp (
$key);main::redefine ("\x55\x55\x49\x44",$key);main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x73");(my ($currentUuid,$host,$port)=
NXNodes::getNodeHostAndPort ("\x6c\x6f\x63\x61\x6c\x68\x6f\x73\x74"));
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");NXServers::setNewUuid (
$key,$currentUuid);}sub generateUuidKey{(my (@command)=());push (@command,
$GLOBAL::COMMAND_NXKEYGEN);push (@command,"\x2d\x75");(my (@options)=());push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",(((
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));(my $homeDir=NXPaths::getUserNXHomeDir ());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".$homeDir));(my ($cmdErr,
$cmdOut,$exitValue)=main::nxRunCommand ((\@command),(\@options)));if ((
$exitValue!=(0x03ff+ 2197-0x0c94))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20\x75\x75\x69\x64\x20\x6b\x65\x79\x20"
.$exitValue).
"\x2e\x20\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($cmdOut);}sub askServerDaemonForServiceStatus{(my $service=shift (@_
));(my $response=NXClientSystemDaemons::askForServiceStatus ($service));if ((not
 (defined ($response)))){return (undef);}if (($response=~ /NX> $GLOBAL::MSG_ASK_FOR_SERVICES_STATUS (.*)\n/ )
){($response=$1);}return ($response);}sub 
askServerDaemonForServiceStatusAndRunServicesIfNeeded{(my $service=shift (@_));(my $response
=NXClientSystemDaemons::askForServiceStatusAndRunServicesIfNeeded ($service));if
 ((not (defined ($response)))){return (undef);}if (($response=~ /NX> $GLOBAL::MSG_ASK_FOR_SERVICES_STATUS_AND_RUN_IF_NEEDED (.*)\n/ )
){($response=$1);}return ($response);}sub printServiceStatusByReply{(my $response
=shift (@_));(my $operation=shift (@_));(my (@services)=split ( /, / ,$response,
(0x0262+ 6254-0x1ad0)));foreach my $service (@services){Logger::debug (((
"\x52\x65\x70\x6f\x72\x74\x69\x6e\x67\x3a\x20".$service)."\x2e"));if (($service
=~ /(.*) Enabled/ )){main::nxrequire ("\x4e\x58\x53\x74\x61\x72\x74\x75\x70");if
 (NXStartup::serviceWasRunning ($1)){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x52\x75\x6e\x6e\x69\x6e\x67"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$1);}else{
NXMsg::info ("\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$1);}}elsif ((
$service=~ /(.*) Disabled/ )){main::nxrequire (
"\x4e\x58\x53\x68\x75\x74\x64\x6f\x77\x6e");if (NXShutdown::serviceWasDisabled (
$1)){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$1);}else{
NXMsg::info ("\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$1);}}elsif ((
$service=~ /(.*) NotRunning/ )){if ((($1 eq "\x6e\x78\x6e\x6f\x64\x65")and (
$operation eq "\x73\x74\x61\x72\x74\x75\x70"))){sendMessagePhysicalSessionsError
 ();}}}}sub sendMessagePhysicalSessionsError{NXMsg::warning (
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");if ((
NXLicense::isVirtualSessionsFeature ()and (
NXLimits::getVirtualSessionLimitFromCfg ()>=(0x1c06+ 2182-0x248c)))){
NXMsg::warning (
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x56\x69\x72\x74\x75\x61\x6c\x73\x45\x6e\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");}elsif (
NXLicense::isNxFrameBufferFeature ()){NXMsg::warning (
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x57\x65\x43\x61\x6e\x52\x75\x6e\x58\x73\x65\x72\x76\x65\x72"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");}else{
NXMsg::warning (
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x56\x69\x72\x74\x75\x61\x6c\x73\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");}}sub 
addNetworkChangeFD{(my $ReadPipe=shift (@_));(my $WritePipe=shift (@_));if (((
$ReadPipe eq (""))or ($WritePipe eq ("")))){return;}
NXServerDaemon::addFdToSelector ($ReadPipe);($NetworkChangeFD_Read=$ReadPipe);(
$NetworkChangeFD_Write=$WritePipe);return;}sub removeNetworkChangeFD{if ((
$NetworkChangeFD_Read>=(-(0x1561+ 2739-0x2013)))){
NXServerDaemon::removeFdFromSelector ($NetworkChangeFD_Read);main::nxclose (
$NetworkChangeFD_Read);($NetworkChangeFD_Read=(-(0x0267+ 5480-0x17ce)));}(
$NetworkChangeFD_Write=(-(0x14da+ 683-0x1784)));return;}sub addUPnPFD{(my $type=
shift (@_));(my $read=shift (@_));(my $write=shift (@_));(my $port=(shift (@_)||
(0x1f2d+  29-0x1f4a)));if (((($type eq (""))or ($read eq ("")))or ($write eq 
("")))){Logger::warning (((((((
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x53\x6b\x69\x70\x20\x55\x50\x6e\x50\x20\x46\x44\x20\x61\x64\x64\x20\x74\x79\x70\x65\x20\x27"
.$type)."\x27\x20\x72\x65\x61\x64\x20\x27").$read).
"\x27\x20\x77\x72\x69\x74\x65\x20\x27").$write)."\x27\x2e"));return;}($nxupnp{
$read}{"\x74\x79\x70\x65"}=$type);($nxupnp{$read}{"\x66\x64"}=$read);($nxupnp{
$read}{"\x66\x64\x5f\x77\x72\x69\x74\x65"}=$write);($nxupnp{$read}{
"\x70\x6f\x72\x74"}=$port);Logger::debug (((((
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x41\x64\x64\x20\x4e\x58\x55\x70\x6e\x70\x20\x74\x79\x70\x65\x20\x27"
.$type)."\x27\x20\x66\x6f\x72\x20\x46\x44\x23").$read)."\x2e"));
NXServerDaemon::addFdToSelector ($read);}sub getUpPnPFDType{(my $fd=(shift (@_)
||("")));if (($fd eq (""))){return ((""));}return ($nxupnp{$fd}{
"\x74\x79\x70\x65"});}sub getUpPnPFDPort{(my $fd=(shift (@_)||("")));if (($fd eq
 (""))){return ((""));}return ($nxupnp{$fd}{"\x70\x6f\x72\x74"});}sub 
removeUPnPFD{(my $fd=(shift (@_)||("")));if (($fd eq (""))){return;}
NXServerDaemon::removeFdFromSelector ($fd);main::nxclose ($nxupnp{$fd}{
"\x66\x64\x5f\x77\x72\x69\x74\x65"});main::nxclose ($fd);delete ($nxupnp{$fd});}
sub isDefinedUPnPFD{(my $fd=shift (@_));if (defined ($nxupnp{$fd})){return (
(0x0c2b+ 2314-0x1534));}return ((0x0b32+ 1239-0x1009));}sub 
resetDaemonsRestartCounter{(my $service=shift (@_));($daemonsRestartCounter{
$service}=(0x2635+  49-0x2666));}sub isServiceEnabled{(my $serviceName=shift (@_
));if (($serviceName eq "\x6e\x78\x68\x74\x64")){return (
isHttpdEnabledInLicenceAndConfig ());}elsif (($serviceName eq 
"\x6e\x78\x73\x73\x68\x64")){return (isSSHEnabled ());}elsif (($serviceName eq 
"\x6e\x78\x64")){return (isNxdEnabled ());}return ((0x0508+ 234-0x05f1));}sub 
isServiceDisabled{return ((!isServiceEnabled (@_)));}sub isFeatureEnabled{(my $serviceName
=shift (@_));if (($serviceName eq "\x6e\x78\x73\x73\x68\x64")){return (
NXLicense::isSshFeature ());}return ((0x02da+ 3615-0x10f8));}sub 
isHttpdStartupKeyEnabled{if (NXLicense::isHttpdSupportFeature ()){if (
__isServiceSetToStartAutomatically ("\x6e\x78\x68\x74\x64")){return (
(0x181f+ 3464-0x25a6));}}return ((0x1421+ 398-0x15af));}sub 
isHttpdStartupKeyDisabled{return ((!isHttpdStartupKeyEnabled ()));}sub 
isHttpEnabledInConfig{if (($GLOBAL::ClientConnectionMethods=~ /HTTP/ )){return (
(0x0511+ 5747-0x1b83));}return ((0x1f8c+ 795-0x22a7));}sub 
isHttpdEnabledInLicenceAndConfig{if (NXLicense::isHttpdSupportFeature ()){
Logger::debug (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x4e\x58\x48\x74\x64\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6c\x69\x63\x65\x6e\x73\x65\x2e"
);if (isHttpEnabledInConfig ()){Logger::debug (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x4e\x58\x48\x74\x64\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x63\x6f\x6e\x66\x69\x67\x2e"
);return ((0x07b4+ 2099-0x0fe6));}}Logger::debug (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x4e\x58\x48\x74\x64\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x1823+ 2192-0x20b3));}sub isSSHStartupKeyEnabled{if (
NXLicense::isSshFeature ()){if (__isServiceSetToStartAutomatically (
"\x6e\x78\x73\x73\x68\x64")){return ((0x1681+ 2219-0x1f2b));}}return (
(0x07ea+ 5518-0x1d78));}sub isSSHEnabledInConfig{if ((
$GLOBAL::ClientConnectionMethods=~ /SSH/ )){Logger::debug (
"\x53\x53\x48\x20\x69\x73\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x65\x74\x68\x6f\x64\x73\x20\x6b\x65\x79\x2e"
);return ((0x0b99+ 4171-0x1be3));}Logger::debug (
"\x53\x53\x48\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x65\x74\x68\x6f\x64\x73\x20\x6b\x65\x79\x2e"
);return ((0x18c4+ 243-0x19b7));}sub isSSHEnabled{if (NXLicense::isSshFeature ()
){if (isSSHEnabledInConfig ()){return ((0x0c63+ 3395-0x19a5));}}return (
(0x0322+ 2900-0x0e76));}sub isNxdStartupKeyEnabled{if (
__isServiceSetToStartAutomatically ("\x6e\x78\x64")){return (
(0x05d8+ 3723-0x1462));}return ((0x0332+ 6693-0x1d57));}sub 
isNxdStartupKeyDisabled{return ((!isNxdStartupKeyEnabled ()));}sub 
isNxdEnabledinConfig{if (($GLOBAL::ClientConnectionMethods=~ /NX/ )){return (
(0x092b+ 2478-0x12d8));}return ((0x0c8c+ 1613-0x12d9));}sub isNxdEnabled{if (
isNxdEnabledinConfig ()){return ((0x0a14+ 2771-0x14e6));}return (
(0x1d85+ 1716-0x2439));}sub __isServiceSetToStartAutomatically{(my $service=
shift (@_));(my $key=uc ($service));if (($key eq "\x4e\x58\x44")){($key=
$GLOBAL::StartNXDaemon);}elsif (($key eq "\x4e\x58\x48\x54\x44")){($key=
$GLOBAL::StartHTTPDaemon);}elsif (($key eq "\x4e\x58\x53\x53\x48\x44")){($key=
$GLOBAL::StartSSHDaemon);}($key=uc ($key));if ((($key eq 
"\x41\x55\x54\x4f\x4d\x41\x54\x49\x43")or ($key eq "\x31"))){Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service).
"\x27\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x72\x75\x6e\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x61\x6c\x6c\x79\x2e"
));return ((0x011a+ 531-0x032c));}return ((0x03d2+ 2549-0x0dc7));}sub 
isSystemBasedOnSystemd{(my $systemdServiceFile=
Common::NXPaths::getSystemdServicePath ());if (defined ($systemdServiceFile)){
return ((0x0b8f+ 4442-0x1ce8));}return ((0x0c01+ 2746-0x16bb));}sub 
startupRequrieUpStartSwitch{if ((__nxserverUpstartServiceFileAvailable ()==
(0x18cd+   6-0x18d2))){return ((0x1035+ 205-0x1101));}return (
(0x141b+ 642-0x169d));}sub __nxserverUpstartServiceFileAvailable{(my $upstartFile
=((((($GLOBAL::DIRECTORY_SLASH."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).
"\x69\x6e\x69\x74").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x63\x6f\x6e\x66"));if (
Common::NXFile::isExists ($upstartFile)){return ((0x1b82+ 2560-0x2581));}return 
((0x05ab+ 6126-0x1d99));}sub doesRunSystemdExist{(my $dir=(((
$GLOBAL::DIRECTORY_SLASH."\x72\x75\x6e").$GLOBAL::DIRECTORY_SLASH).
"\x73\x79\x73\x74\x65\x6d\x64"));if (Common::NXFile::isExists ($dir)){return (
(0x0ef3+ 2839-0x1a09));}return ((0x2074+ 333-0x21c1));}sub handleRestartRequest{
(my $fd=shift (@_));(my $request=shift (@_));Logger::debug (((((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x72\x65\x73\x74\x61\x72\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$request)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$fd)."\x2e"));($request=~ /PID=(.*) / )
;(my $pid=$1);setRestartProcessPID ($pid);($GLOBAL::REQUEST_TERMINATE=
(0x1e20+ 1945-0x25b8));setShutdownFlag ();}sub setRestartProcessPID{($restartPID
=shift (@_));Logger::debug (((
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73\x3a\x20\x53\x61\x76\x69\x6e\x67\x20\x72\x65\x73\x74\x61\x72\x74\x20\x50\x49\x44\x20\x27"
.$restartPID)."\x27\x2e"));}sub getRestartProcessPID{return ($restartPID);}sub 
setPreshutdown{($preshutdown=(0x1e75+ 1990-0x263a));}sub resetPreshutdown{(
$preshutdown=(0x0d12+ 858-0x106c));}sub isPreshutdown{return ($preshutdown);}
NXMsg::register_error (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
(0x08f6+ 7104-0x22c2));NXMsg::register_error (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
(0x07c5+ 8162-0x25b3));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
(0x0b50+ 7069-0x264b));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64",
(0x0131+ 1567-0x06af));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x52\x75\x6e\x6e\x69\x6e\x67"
,(0x026f+ 4699-0x1429));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,(0x12c5+ 812-0x154f));NXMsg::register_error (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65\x46\x6f\x72\x55\x73\x65\x72"
,(0x1802+ 4115-0x2621));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64",
(0x0180+ 2517-0x0ab3));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x56\x69\x72\x74\x75\x61\x6c\x73\x44\x69\x73\x61\x62\x6c\x65\x64"
,(0x07cd+ 128-0x07ab));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x56\x69\x72\x74\x75\x61\x6c\x73\x45\x6e\x61\x62\x6c\x65\x64"
,(0x0946+ 903-0x0c2b));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x77\x4e\x6f\x58\x73\x65\x72\x76\x65\x72\x73\x46\x6f\x75\x6e\x64\x57\x65\x43\x61\x6e\x52\x75\x6e\x58\x73\x65\x72\x76\x65\x72"
,(0x0de2+ 2349-0x166d));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73"
,(0x14a6+ 2169-0x1cb0));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x31"
,(0x176f+ 3555-0x24e3));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x32"
,(0x05c9+ 6769-0x1fcb));NXMsg::register_response (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x33"
,(0x16d5+ 1848-0x1d9e));return ((0x0ce5+ 2302-0x15e2));
