############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Service::isNXHtdAvailable{package Service;no warnings;(my $command=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x68\x74\x64"));(my $command_bin=($command.
"\x2e\x62\x69\x6e"));if ((Common::NXFile::isExists ($command)and 
Common::NXFile::isExists ($command_bin))){return ((0x06dd+ 7885-0x25a9));}return
 ((0x0830+ 3675-0x168b));}sub Service::isNXDAvailable{package Service;no 
warnings;(my $command=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x62\x69\x6e").$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x64"));if (
Common::NXFile::isExists ($command)){return ((0x0387+ 4704-0x15e6));}return (
(0x047c+ 6984-0x1fc4));}sub Service::stop{package Service;no warnings;(my $ref_parameters
=shift (@_));if (($$ref_parameters{"\x74\x61\x72\x67\x65\x74"}ne (""))){
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");if ((
NXServers::normalizeTargetParameter ($ref_parameters)==(-(0x0dbf+ 1184-0x125e)))
){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x0630+ 7796-0x24a3));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x0f0c+ 5560-0x24c4));if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}ne (""))){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x008a+ 6762-0x1af3))){($isForwarded=
(0x0dcb+ 1063-0x11f1));}}($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x16eb+ 727-0x19c1));
NXServers::forwardCommand ("\x73\x65\x72\x76\x69\x63\x65\x73\x74\x6f\x70",
$ref_parameters);if (($isForwarded==(0x170f+ 1669-0x1d93))){
NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x13b2+ 976-0x1781));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x07c0+ 3792-0x168f))
){NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}}
main::nxrequire ("\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73")
;if (($$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x68\x74\x64")
){if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){if (isNXHtdAvailable
 ()){return (NXShell::handle_command ("\x6e\x78\x68\x74\x64",
"\x6e\x78\x68\x74\x64","\x73\x74\x6f\x70"));}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x68\x74\x64"));}return (NXMsg::error (
"\x65\x48\x74\x74\x70\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x53\x65\x72\x76\x69\x63\x65"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x64")){if (isNXDAvailable ()){return
 (NXShell::handle_command ("\x6e\x78\x64","\x6e\x78\x64","\x73\x74\x6f\x70"));}
return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x64"));}(my $error=setStopFlag ());if 
(($error==(0x1a11+ 2080-0x2231))){if (($$ref_parameters{
"\x73\x69\x6c\x65\x6e\x63\x65"}!=(0x1753+ 3050-0x233c))){NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x64\x69\x73\x61\x62\x6c\x65\x64");}main::sendServerStatus ("\x73\x74\x6f\x70")
;}else{if (($$ref_parameters{"\x73\x69\x6c\x65\x6e\x63\x65"}!=
(0x00ad+ 5155-0x14cf))){Common::NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x46\x69\x6c\x65"
,$GLOBAL::ServerStopStatusFlagLink,$errorString);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}}main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);NXNodeConnectionMonitor::informAboutServerStatusChange ();return (
(0x1043+ 1696-0x16e3));}sub Service::setStopFlag{package Service;no warnings;if 
(Common::NXFile::isExists ($GLOBAL::ServerStopStatusFlagLink)){return (
(0x06fc+ 3766-0x15b2));}(my $FH=main::nxopen ($GLOBAL::ServerStopStatusFlagLink,
($NXBits::O_WRONLY+$NXBits::O_CREAT),(($NXBits::UserReadWrite+$NXBits::GroupRead
)+$NXBits::OthersRead)));if ((not (defined ($FH)))){return (
(0x16b7+ 1847-0x1ded));}main::nxclose ($FH);return ((0x0ba7+ 317-0x0ce4));}sub 
Service::start{package Service;no warnings;(my $ref_parameters=shift (@_));if ((
$$ref_parameters{"\x74\x61\x72\x67\x65\x74"}ne (""))){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");if ((NXServers::normalizeTargetParameter
 ($ref_parameters)==(-(0x14d1+ 1609-0x1b19)))){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x0303+ 2739-0x0db5));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x0440+ 6109-0x1c1d));if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}ne (""))){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x1543+ 3620-0x2366))){($isForwarded=
(0x1b9a+ 2025-0x2382));}}($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x0873+ 5428-0x1da6));
NXServers::forwardCommand ("\x73\x65\x72\x76\x69\x63\x65\x73\x74\x61\x72\x74",
$ref_parameters);if (($isForwarded==(0x0a16+ 1523-0x1008))){
NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x0b21+ 4356-0x1c24));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x0a1a+ 4475-0x1b94))
){NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}}
main::nxrequire ("\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73")
;if (($$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x68\x74\x64")
){if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){if (isNXHtdAvailable
 ()){return (NXShell::handle_command ("\x6e\x78\x68\x74\x64",
"\x6e\x78\x68\x74\x64","\x73\x74\x61\x72\x74"));}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x68\x74\x64"));}return (NXMsg::error (
"\x65\x48\x74\x74\x70\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x53\x65\x72\x76\x69\x63\x65"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x64")){if (isNXDAvailable ()){return
 (NXShell::handle_command ("\x6e\x78\x64","\x6e\x78\x64","\x73\x74\x61\x72\x74")
);}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x64"));}main::nxrequire (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");main::nxrequire 
("\x4e\x58\x53\x74\x61\x72\x74\x75\x70");(my $silence=$$ref_parameters{
"\x73\x69\x6c\x65\x6e\x63\x65"});if (($$ref_parameters{
"\x73\x69\x6c\x65\x6e\x63\x65"}eq (""))){($silence=(0x0595+ 7590-0x233b));}if ((
not (Server::isClientConnectionOpen ()))){($silence=(0x0d5f+ 986-0x1138));}(my $error
=(0x03e8+ 2820-0x0eec));if (Common::NXFile::isExists (
$GLOBAL::ServerStopStatusFlagLink)){if ((not (Common::NXFile::removeFile (
$GLOBAL::ServerStopStatusFlagLink)))){if (($silence==(0x050a+ 124-0x0586))){(my $errorString
=libnxh::NXGetErrorString ());Common::NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x52\x65\x6d\x6f\x76\x65\x46\x69\x6c\x65"
,$GLOBAL::ServerStopStatusFlagLink,$errorString);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}($error=(0x04ef+ 1808-0x0bfe));}}if (((
$error==(0x0bc6+ 6421-0x24db))and ($silence==(0x0776+ 5330-0x1c48)))){if (
NXSystemDaemons::isShutdownFlag ()){NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x31"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x32"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73\x53\x68\x75\x74\x64\x6f\x77\x6e\x33"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");}else{
NXMsg::info (
"\x69\x43\x4d\x44\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x53\x74\x61\x74\x75\x73"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x65\x6e\x61\x62\x6c\x65\x64");}}main::sendServerStatus ("\x73\x74\x61\x72\x74"
);main::setSSHStatusStart ();main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);NXNodeConnectionMonitor::informAboutServerStatusChange ();return (
(0x1bc1+ 2162-0x2433));}sub Service::sudoStop{package Service;no warnings;(my $ref_parameters
=shift (@_));if (defined ($$ref_parameters{"\x74\x61\x72\x67\x65\x74"})){if ((
NXServers::normalizeTargetParameter ($ref_parameters)==(-(0x1a98+ 1081-0x1ed0)))
){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x0f38+ 1582-0x1566));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x1516+ 4504-0x26ae));if (defined ($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"})){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x07a9+ 5035-0x1b53))){($isForwarded=
(0x1564+   3-0x1566));}}($$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"
}=(0x0671+ 7595-0x241b));NXServers::forwardCommand (
"\x73\x65\x72\x76\x69\x63\x65\x73\x74\x6f\x70",$ref_parameters);if ((
$isForwarded==(0x0d36+ 3205-0x19ba))){NXShell::setCommandForwarded ();
NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x1008+ 2899-0x1b5a));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x0835+ 7392-0x2514))
){NXShell::setCommandForwarded ();}}main::nxrequire ("\x4e\x58\x53\x75\x64\x6f")
;NXSudo::setCommandForServer ();NXSudo::setRemoteNodeHost ($$ref_parameters{
"\x68\x6f\x73\x74"});NXSudo::setRemoteNodePort ($$ref_parameters{
"\x70\x6f\x72\x74"});(my $params=(""));foreach my $elem (keys (%$ref_parameters)
){($params.=((($elem."\x3d").$$ref_parameters{$elem})."\x26"));}($params.=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x74\x6f\x70\x26");NXNodes::runNodeForSudo 
($params);NXNodes::reloadNodesDB ();NXSudo::clearCommandForServer ();
NXShell::setExitRequestCommandFinished ();}sub Service::sudoStart{package 
Service;no warnings;(my $ref_parameters=shift (@_));if (defined (
$$ref_parameters{"\x74\x61\x72\x67\x65\x74"})){if ((
NXServers::normalizeTargetParameter ($ref_parameters)==(-(0x1585+ 1898-0x1cee)))
){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x0566+ 669-0x0803));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x0f39+ 4013-0x1ee6));if (defined ($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"})){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x0b5d+ 4199-0x1bc3))){($isForwarded=
(0x05aa+ 2909-0x1106));}}($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x0794+ 4938-0x1add));
NXServers::forwardCommand ("\x73\x65\x72\x76\x69\x63\x65\x73\x74\x61\x72\x74",
$ref_parameters);if (($isForwarded==(0x060d+ 395-0x0797))){
NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x0e22+ 116-0x0e95));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x0953+ 2784-0x1432))
){NXShell::setCommandForwarded ();}}main::nxrequire ("\x4e\x58\x53\x75\x64\x6f")
;NXSudo::setCommandForServer ();NXSudo::setRemoteNodeHost ($$ref_parameters{
"\x68\x6f\x73\x74"});NXSudo::setRemoteNodePort ($$ref_parameters{
"\x70\x6f\x72\x74"});(my $params=(""));foreach my $elem (keys (%$ref_parameters)
){($params.=((($elem."\x3d").$$ref_parameters{$elem})."\x26"));}($params.=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x74\x61\x72\x74\x26");
NXNodes::runNodeForSudo ($params);NXNodes::reloadNodesDB ();
NXSudo::clearCommandForServer ();NXShell::setExitRequestCommandFinished ();}sub 
Service::restart{package Service;no warnings;(my $ref_parameters=shift (@_));if 
(($$ref_parameters{"\x74\x61\x72\x67\x65\x74"}ne (""))){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");if ((NXServers::normalizeTargetParameter
 ($ref_parameters)==(-(0x1ff1+ 1511-0x25d7)))){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x53\x65\x72\x76\x69\x63\x65",$$ref_parameters{"\x74\x61\x72\x67\x65\x74"});
NXShell::setExitRequestCommandFinished ();return ((0x061f+ 6153-0x1e27));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and ($$ref_parameters{
"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded=
(0x0457+ 1851-0x0b92));if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}ne (""))){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x03cf+ 448-0x058e))){($isForwarded=
(0x0fcb+ 4577-0x21ab));}}($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}=(0x1a6f+ 2758-0x2534));
NXServers::forwardCommand (
"\x73\x65\x72\x76\x69\x63\x65\x72\x65\x73\x74\x61\x72\x74",$ref_parameters);if (
($isForwarded==(0x0770+ 2381-0x10bc))){NXShell::setCommandForwarded ();
NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x1210+ 3106-0x1e31));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x07e9+ 1148-0x0c64))
){NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}}
main::nxrequire ("\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73")
;if (($$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x68\x74\x64")
){if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){if (isNXHtdAvailable
 ()){return (NXShell::handle_command ("\x6e\x78\x68\x74\x64",
"\x6e\x78\x68\x74\x64","\x72\x65\x73\x74\x61\x72\x74"));}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x68\x74\x64"));}return (NXMsg::error (
"\x65\x48\x74\x74\x70\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x53\x65\x72\x76\x69\x63\x65"));}elsif (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x6e\x78\x64")){if (isNXDAvailable ()){return
 (NXShell::handle_command ("\x6e\x78\x64","\x6e\x78\x64",
"\x72\x65\x73\x74\x61\x72\x74"));}return (NXMsg::error (
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,"\x53\x65\x72\x76\x69\x63\x65","\x6e\x78\x64"));}if ((not (
NXMsg::isMessageRegistered (
"\x69\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x74\x61\x72\x74\x69\x6e\x67")))){
NXMsg::register_response ("\x53\x65\x72\x76\x69\x63\x65",
"\x69\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x74\x61\x72\x74\x69\x6e\x67",
$GLOBAL::MSG_SERVICE_RESTART);}NXMsg::send_response (
"\x69\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x74\x61\x72\x74\x69\x6e\x67",
"\x53\x65\x72\x76\x69\x63\x65","\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65");
main::nxrequire ("\x53\x65\x72\x76\x65\x72");Server::setServerIsRestart ();
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");
NXCluster::restartForUserNx ();if (($GLOBAL::isNXServerLoginProcess==
(0x12f7+ 1042-0x1708))){main::nxexit ((0x0725+ 6007-0x1e9c));}}package Service;
no warnings;NXMsg::register_error ("\x53\x65\x72\x76\x69\x63\x65",
"\x65\x53\x65\x72\x76\x69\x63\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
,$GLOBAL::MSG_ERROR);NXMsg::register_error ("\x53\x65\x72\x76\x69\x63\x65",
"\x65\x48\x74\x74\x70\x53\x65\x72\x76\x65\x72\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,$GLOBAL::MSG_ERROR);return ((0x0418+ 8240-0x2447));
