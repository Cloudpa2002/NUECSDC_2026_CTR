#
#  Expanding PATH
#
if [ -x /bin/grep ];
then
  GREPCOMMAND="/bin/grep"
else
  GREPCOMMAND="grep"
fi

if ! echo ${PATH} | $GREPCOMMAND -q INSTALL_PATH ; then
       export PATH=INSTALL_PATH/bin:${PATH}
fi

