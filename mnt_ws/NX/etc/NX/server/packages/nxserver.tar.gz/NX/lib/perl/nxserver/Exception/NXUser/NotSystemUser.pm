############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::NXUser::NotSystemUser::BEGIN{package 
Exception::NXUser::NotSystemUser;no warnings;require base;do{"\x62\x61\x73\x65"
->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x42\x61\x73\x65"
)};}sub Exception::NXUser::NotSystemUser::BEGIN{package 
Exception::NXUser::NotSystemUser;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::NXUser::NotSystemUser::notify{package 
Exception::NXUser::NotSystemUser;no warnings;(my $self=shift (@_));(my $text=
$self->text);(my $statusId=main::get_unique_id ());($statusId=~ s/(........).*/$1/ )
;if (defined ($GLOBAL::FLAG_SystemUserAdded)){return ((0x13ca+ 1302-0x18e0));}if
 ((not (defined ($GLOBAL::FLAG_SystemUserDeleted)))){(my $ErrrStr=((((((
"\x55\x73\x65\x72\x3a\x20".$text).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x20\x73\x79\x73\x74\x65\x6d\x20\x75\x73\x65\x72\x2e\x20\x54\x6f\x20\x61\x64\x64\x20\x75\x73\x65\x72\x3a\x20"
).$text).
"\x20\x6f\x6e\x20\x74\x68\x65\x20\x73\x79\x73\x74\x65\x6d\x2c\x20\x70\x6c\x65\x61\x73\x65\x20\x72\x75\x6e\x20\x74\x68\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x77\x69\x74\x68\x20\x6f\x70\x74\x69\x6f\x6e\x3a\x20\x2d\x2d\x73\x79\x73\x74\x65\x6d\x2e\x20\x45\x52\x52\x4f\x52\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x75\x73\x65\x72\x3a\x20"
).$text)."\x2e"));NXMsg::register_response ((""),
"\x65\x43\x68\x65\x63\x6b\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72",
(0x1c78+ 1362-0x1fb0));NXMsg::error (
"\x65\x43\x68\x65\x63\x6b\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72",
"\x67\x65\x6e\x65\x72\x61\x6c",$text,$text);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x55\x73\x65\x72",
"\x4e\x58\x53\x68\x65\x6c\x6c",$text);}else{(my $ErrStr=
"\x55\x73\x65\x72\x20\x72\x65\x6d\x6f\x76\x65\x64\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x73\x79\x73\x74\x65\x6d"
);}(my $trace=$self->stacktrace);($trace=~ s/\n[^\w]+/\n/ );($trace=~ s/\t//gm )
;(my (@aTrace)=split ( /\n/ ,$trace,(0x05c0+ 7790-0x242e)));shift (@aTrace);
Logger::multilineLog (((
"\x28\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x20\x69\x64\x20".$statusId)."\x29"),(
$ErrStr,@aTrace));}package Exception::NXUser::NotSystemUser;no warnings;
"\x3f\x3f\x3f";
