############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXNetInterfaces::BEGIN{package NXNetInterfaces;no warnings;require warnings;
do{"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub 
NXNetInterfaces::convertHex2Bin{package NXNetInterfaces;no warnings;(my $ipInHex
=shift (@_));(my $binary=unpack ("\x42\x33\x32",pack ("\x4e",hex ($ipInHex))));(
$binary=~ s/^0+(?=\d)// );return ($binary);}sub NXNetInterfaces::convertDec2Bin{
package NXNetInterfaces;no warnings;(my $ip=shift (@_));(my $binaryIP=undef);(my (
@ipArray)=split ( /\./ ,$ip,(0x0d78+ 5907-0x248b)));foreach my $ipChunk (
@ipArray){(my $binary=unpack ("\x42\x33\x32",pack ("\x4e",$ipChunk)));($binaryIP
.=sprintf ("\x25\x30\x38\x64",$binary));}return ($binaryIP);}sub 
NXNetInterfaces::convertBin2Dec{package NXNetInterfaces;no warnings;(my $binaryIP
=shift (@_));return (unpack ("\x4e",pack ("\x42\x33\x32",substr ((("\x30" x 
(0x07df+ 2288-0x10af)).$binaryIP),(-(0x0e85+ 6272-0x26e5))))));}sub 
NXNetInterfaces::checkIsLocal{package NXNetInterfaces;no warnings;(my $serverIp=
shift (@_));(my $destinationIp=shift (@_));(my $mask=shift (@_));if (($serverIp 
eq "\x30\x2e\x30\x2e\x30\x2e\x30")){Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x20\x49\x50\x3a\x20\x5b".$serverIp)."\x5d"));return (
(0x0723+ 1928-0x0eaa));}if (((((((not ($serverIp))or (not ($destinationIp)))or (
not ($mask)))or ($serverIp eq ("")))or ($destinationIp eq ("")))or ($mask eq 
("")))){Logger::debug (((((((
"\x4d\x69\x73\x73\x69\x6e\x67\x20\x6f\x6e\x65\x20\x6f\x66\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x3a\x20\x73\x65\x72\x76\x65\x72\x20\x49\x50\x3a\x20\x5b"
.$serverIp).
"\x5d\x20\x64\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e\x20\x49\x50\x3a\x20\x5b").
$destinationIp)."\x5d\x20\x6d\x61\x73\x6b\x3a\x20\x5b").$mask)."\x5d"));return (
(0x0bcd+ 3822-0x1aba));}(my $serverIpBin=convertDec2Bin ($serverIp));(my $destinationIpBin
=convertDec2Bin ($destinationIp));(my $maskBin=undef);if ((substr ($mask,
(0x07b2+ 3392-0x14f2),(0x07d4+ 5352-0x1cba))eq "\x30\x78")){($maskBin=
convertHex2Bin ($mask));}else{($maskBin=convertDec2Bin ($mask));}(my $andIpAndMask
=($serverIpBin&$maskBin));(my $andRemoteIpAndMask=($destinationIpBin&$maskBin));
if (($andIpAndMask eq $andRemoteIpAndMask)){Logger::debug (
"\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e\x20\x68\x6f\x73\x74\x20\x69\x73\x20\x6c\x6f\x63\x61\x6c"
);return ((0x0645+ 5867-0x1d2f));}Logger::debug (
"\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e\x20\x68\x6f\x73\x74\x20\x69\x73\x20\x6e\x6f\x74\x20\x6c\x6f\x63\x61\x6c"
);return ((0x0e46+ 5212-0x22a2));}sub NXNetInterfaces::getMask{package 
NXNetInterfaces;no warnings;(my $serverIp=shift (@_));(my $netmask=undef);(my $networkInterfaces
=libnxh::NXGetNetworkInterfaces ());(my (@lines)=split ( /\n/ ,
$networkInterfaces,(0x1e63+ 879-0x21d2)));foreach my $line (@lines){if (($line=~ /(^\w+)\s+AF_INET\s+([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})+\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/ )
){(my $ip=$4);if (($serverIp eq $ip)){($netmask=$5);Logger::debug2 ((
"\x46\x65\x74\x63\x68\x65\x64\x20\x6e\x65\x74\x6d\x61\x73\x6b\x3a\x20".$netmask)
);return ($netmask);}}}Logger::debug (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x67\x65\x74\x20\x6d\x61\x73\x6b\x2e");
return ($netmask);}package NXNetInterfaces;no warnings;return (
(0x0262+ 1359-0x07b0));
