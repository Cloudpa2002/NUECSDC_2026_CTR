############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXCore;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65"->import};}package 
Logger;no warnings;require Common::NXFile;($debugMode=
"\x64\x69\x73\x61\x62\x6c\x65");($flagPrintProcessNamesToErrorsAndWarnings=
(0x0a82+ 2091-0x12ad));(my $__whoami=
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x6c\x6f\x67");sub main::BEGIN{package main;
require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}sub 
BEGIN{require Common::NXTime;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x54\x69\x6d\x65"->import};}sub BEGIN{
require NXTools;do{"\x4e\x58\x54\x6f\x6f\x6c\x73"->import};}(my (
%__no_log_packages)=());(my $__failed_systemlogfile=(0x000f+ 5672-0x1637));(my $__previousLogMessage
=(""));(my $__previousLogMessageCount=(0x1140+ 3041-0x1d21));(my $__previousStatusMessage
=(""));(my $__previousStatusMessageCount=(0x022c+ 1726-0x08ea));(my $__doNotStoreInHistory
=(0x0a36+ 4683-0x1c81));(my $__storeInHistory=(0x0e15+ 4302-0x1ee2));(
@statusDumpBeginPart=());(@statusDumpEndPart=());($loggerWorking=
(0x01cf+ 991-0x05ad));($LOG_ERROR=(0x00b8+ 8925-0x2392));($LOG_WARNING=
(0x019f+ 341-0x02f0));($LOG_NOTICE=(0x17ef+ 951-0x1ba1));($LOG_INFO=
(0x070b+ 5554-0x1cb7));($LOG_DEBUG=(0x104a+ 596-0x1297));($LOG_DEBUG2=
(0x051f+ 6133-0x1d0c));($LOG_DEBUG3=(0x03cd+ 4239-0x1453));(my $__level=
$LOG_INFO);sub init{(($__whoami,$__level)=@_);($__failed_systemlogfile=
(0x08d1+ 1844-0x1005));openLog ();setLoggerInfo ();(my $message=((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x20\x77\x69\x74\x68\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x27"
.NXBegin::getProcessArgumentsString ())."\x27\x2e"));debug ($message);statusPush
 ($message);}sub initLevel{(my $variables=libnxh::NXInitSyslogConstants ());(
$LOG_ERROR=@$variables[(0x11fc+ 3464-0x1f84)]);($LOG_WARNING=@$variables[
(0x1307+ 3908-0x224a)]);($LOG_NOTICE=@$variables[(0x0627+ 1368-0x0b7d)]);(
$LOG_INFO=@$variables[(0x126b+ 2802-0x1d5a)]);($LOG_DEBUG=@$variables[
(0x1e5d+ 1424-0x23e9)]);($LOG_DEBUG2=@$variables[(0x2024+ 1404-0x259b)]);(
$LOG_DEBUG3=@$variables[(0x067a+ 5258-0x1afe)]);($__level=$LOG_INFO);}sub 
openLog{if (syslogEnabled ()){__openSyslog ();}else{__openLogFile ();}}sub 
reopenLog{(my $logFile=shift (@_));if ((not (syslogEnabled ()))){debug (((
"\x53\x77\x69\x74\x63\x68\x69\x6e\x67\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x74\x6f\x20\x27"
.$logFile)."\x27\x2e"));(my $handle=$logfile_fh);__openLogFile ($logFile);if (
defined ($handle)){__redirectDefaultStdoutToNewLogFileIfNeeded ($handle,
$logfile_fh);main::nxclose ($handle);}}}sub 
__redirectDefaultStdoutToNewLogFileIfNeeded{(my $oldHandle=shift (@_));(my $newHandle
=shift (@_));}sub disablePackage{($Logger::__no_log_packages{$_[
(0x0be8+ 2384-0x1538)]}="\x31");}sub __statusPush{(my $message=shift (@_));(my $line
=getFormattedLogLine ($message));if ((scalar (@statusDumpBeginPart)>=
(0x0777+ 1062-0x0b6b))){(my $length=push (@statusDumpEndPart,$line));if ((
$length>(0x0c28+ 6605-0x25c3))){shift (@statusDumpEndPart);}}else{push (
@statusDumpBeginPart,$line);}}sub statusPush{(my $message=shift (@_));if (
__suppressStatusDump ($message)){return;}__statusPush ($message);}sub 
statusPushError{(my $message=shift (@_));($message=setMessageType ($message,
$LOG_ERROR));statusPush ($message);}sub statusPushWarning{(my $message=shift (@_
));($message=setMessageType ($message,$LOG_WARNING));statusPush ($message);}sub 
statusReset{($__status=(""));}sub statusGet{(my $statusStr=join ((""),
@statusDumpBeginPart));if (scalar (@statusDumpEndPart)){($statusStr.=
"\x0a\x73\x6b\x69\x70\x70\x69\x6e\x67\x20\x2e\x2e\x2e\x0a\x0a");($statusStr.=
join ((""),@statusDumpEndPart));}return ($statusStr);}sub printStatus{(my ($msg,
$statusId,@status)=@_);main::nxwrite (main::nxgetSTDOUT (),((($msg."\x20\x5b").
$statusId)."\x5d\x0a"));while ((my $msg=shift (@status))){($msg=~ s/\n$//gm );(
$msg=~ s/\n/\n        /g );main::nxwrite (main::nxgetSTDOUT (),((
"\x20\x20\x20\x20".$msg)."\x0a"));}}sub logStatus{(my ($level,@msgs)=@_);(my (
$statusId,@status)=statusGet ());multilineLog ($statusId,@msgs,@status);return (
$statusId,@status);}sub __log{(my ($msg,$level,$storeInHistory)=@_);(my (
$package,$filename,$line,$sub)=caller ((0x03d1+ 219-0x04aa)));if ((not (defined 
($level)))){main::nxwrite (main::nxgetSTDERR (),((((((((((
"\x4d\x69\x73\x73\x69\x6e\x67\x20\x6c\x6f\x67\x20\x6c\x65\x76\x65\x6c\x20\x66\x72\x6f\x6d\x3a\x20\x28"
.$package)."\x2c\x20").$filename)."\x2c\x20").$line)."\x2c\x20").$sub).
"\x29\x20\x61\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20").$msg)."\x0a"));
return;}if (($__level<$level)){if (($storeInHistory==(0x0dbb+ 968-0x1182))){
storeInHistory ($msg,$level);}return;}if ((not (defined ($GLOBAL::CONFIG_FILE)))
){if (($level==$LOG_ERROR)){main::nxwrite (main::nxgetSTDERR (),($msg."\x0a"));}
return;}(my $logpackage=$package);($logpackage=~ s/^Common::// );if (defined (
$Logger::__no_log_packages{$logpackage})){if ((($level!=$LOG_ERROR)and ($level!=
$LOG_WARNING))){return;}}writeMessageToLog ($msg,$level,$storeInHistory,$sub);}
sub __multilineEntry{(my ($statusId,$level,$store,@msgs)=@_);if ((not (defined (
$statusId)))){warning (
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x5f\x5f\x6d\x75\x6c\x74\x69\x6c\x69\x6e\x65\x45\x6e\x74\x72\x79\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x3a\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x73\x74\x61\x74\x75\x73\x49\x64\x2e"
);return;}if ((not (@msgs))){warning (
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x5f\x5f\x6d\x75\x6c\x74\x69\x6c\x69\x6e\x65\x45\x6e\x74\x72\x79\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x3a\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);return;}foreach my $line (@msgs){__log (((("\x3c".$statusId)."\x3e\x20").$line
),$level,$store);}}sub multilineLog{(my ($statusId,@msgs)=@_);__multilineEntry (
$statusId,$LOG_DEBUG,$__doNotStoreInHistory,@msgs);}sub multilineError{(my (
$statusId,@msgs)=@_);__multilineEntry ($statusId,$LOG_ERROR,$__storeInHistory,
@msgs);}sub isMessageDefined{(my $msg=shift (@_));if ((not (defined ($msg)))){
main::nxwrite (main::nxgetSTDERR (),
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x6c\x6f\x67\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x6d\x73\x67\x0a"
);main::nxexit ((0x01da+ 7643-0x1fb5));}}sub isLevelDefined{(my $level=shift (@_
));if ((not (defined ($level)))){main::nxwrite (main::nxgetSTDERR (),
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x6c\x6f\x67\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x6c\x65\x76\x65\x6c\x0a"
);main::nxexit ((0x156b+ 4035-0x252d));}}sub isBacktraceDefined{(my ($backtrace,
$sub,$level)=@_);if ((not (defined ($backtrace)))){($sub=~ s/::__ANON__$/::Static/ )
;}return ($sub);}sub isDebugEnabled{return (($debugMode eq 
"\x65\x6e\x61\x62\x6c\x65"));}sub checkBacktrace{(my ($backtrace,$msg)=@_);
return;}sub setLoggerInfo{if ($GLOBAL::SessionLogLevel){($__level=
$GLOBAL::SessionLogLevel);}else{($__level=$LOG_INFO);}if ($GLOBAL::SOFTWARE_NAME
){($__whoami=$GLOBAL::SOFTWARE_NAME);}if (($GLOBAL::SessionLogLevel>
(0x021c+ 2632-0x0c5e))){($debugMode="\x65\x6e\x61\x62\x6c\x65");}}sub 
sendMessageToLogfile{(my ($msg,$level)=@_);if (defined ($logfile_fh)){
main::nxwrite ($logfile_fh,__getLogLine ($msg));}}sub __getLogLine{(my $text=
shift (@_));(my $timeline=Common::NXTime::getLoggerTimeline ());(my $pid=$ $);
 (my $tid
=$pid);(my $processName=sprintf ("\x25\x2d\x38\x73",$__whoami));(my $message=(((
(((((($pid."\x20").$tid)."\x20").$timeline)."\x20").$processName)."\x20").$text)
."\x0a"));return ($message);}sub getFormattedLogLine{(my $text=shift (@_));
replaceSpecialCharacters ((\$text));return (__getLogLine ($text));}sub 
setLogFile{(my $logfile=(""));($logfile=Common::NXPaths::getNXServerLogPath ());
if (($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){(my $logDir=
Common::NXPaths::getSpecialUsersLogFolderPath ());if ((not (-d ($logDir)))){(my $returnValue
=libnxh::NXMakePath ($logDir,("")));debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnValue)."\x27\x2e"));if (($returnValue!=(0x0b69+ 1438-0x1107))){(my $errorNumber
=libnxh::NXGetError ());(my $errorMessage=libnxh::NXGetErrorString ());($success
=(0x033b+ 6008-0x1ab3));error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$logDir)."\x2e"));error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorMessage)."\x27\x2e"));}}}return ($logfile);}
sub setMessageType{(my ($msg,$level)=@_);if (($level==$LOG_ERROR)){($msg=(
"\x45\x52\x52\x4f\x52\x21\x20".$msg));}elsif (($level==$LOG_WARNING)){($msg=(
"\x57\x41\x52\x4e\x49\x4e\x47\x21\x20".$msg));}return ($msg);}sub stackTrace{(my $backtrace
=Carp::longmess ($_));($backtrace=~ s/\n[\s]+/\n/ );(my (@lines)=split ( /\n/ ,
$backtrace,(0x0098+ 3670-0x0eee)));multilineLog (
"\x20\x53\x74\x61\x63\x6b\x74\x72\x61\x63\x65\x3a",@lines);return (());}sub 
logFilePath{return (Common::NXPaths::getNXServerLogPath ());}sub 
writeMessageToLog{(my ($msg,$level,$backtrace,$sub)=@_);($msg=prepareLogMessage 
($msg,$level));($sub=isBacktraceDefined ($backtrace,$sub,$level));($msg=
setMessageType ($msg,$level));if (syslogEnabled ()){sendMessageToSyslog ($msg,
$level);}else{if (__suppress ($msg,$level)){return;}sendMessageToLogfile ($msg,
$level);}return;}sub prepareLogMessage{(my ($msg,$level)=@_);
replaceSpecialCharacters ((\$msg));isMessageDefined ($msg);isLevelDefined (
$level);if (printProcessNamesToErrorsAndWarnings ()){if ((($level==$LOG_ERROR)or
 ($level==$LOG_WARNING))){(my $nameString=(("\x50\x72\x6f\x63\x65\x73\x73\x20".
NXBegin::getProcessName ())."\x20\x72\x65\x70\x6f\x72\x74\x65\x64\x3a\x20"));(
$msg=($nameString.$msg));}}return ($msg);}sub replaceSpecialCharacters{(my $ref_message
=shift (@_));chomp ($$ref_message);($$ref_message=~ s/%/%%/g );($$ref_message=~ s/\n/\\n/g )
;}sub storeInHistory{(my ($msg,$level)=@_);($msg=setMessageType ($msg,$level));
statusPush ($msg);}sub closeLogFile{if (syslogEnabled ()){libnxh::NXCloseLog ();
}else{if (defined ($logfile_fh)){main::nxclose ($logfile_fh);undef ($logfile_fh)
;}}}sub setLoggerNotWorking{($loggerWorking=(0x0012+ 5219-0x1475));}sub 
isLoggerWorking{return ($loggerWorking);}sub 
printProcessNamesToErrorsAndWarnings{return (
$flagPrintProcessNamesToErrorsAndWarnings);}sub debug{(my $message=shift (@_));(my $storeInHistory
=(shift (@_)||(0x01bc+ 5215-0x161b)));__log ($message,$LOG_DEBUG,$storeInHistory
);}sub debug2{(my $message=shift (@_));(my $storeInHistory=(shift (@_)||
(0x15f4+ 421-0x1799)));__log ($message,$LOG_DEBUG2,$storeInHistory);}sub debug3{
(my $message=shift (@_));(my $storeInHistory=(shift (@_)||(0x0eca+ 3224-0x1b62))
);__log ($message,$LOG_DEBUG3,$storeInHistory);}sub info{(my $message=shift (@_)
);(my $storeInHistory=(shift (@_)||(0x0a3f+ 4976-0x1daf)));__log ($message,
$LOG_INFO,$storeInHistory);}sub notice{(my $message=shift (@_));(my $storeInHistory
=(shift (@_)||(0x0ccb+ 2128-0x151b)));__log ($message,$LOG_NOTICE,
$storeInHistory);}sub warning{(my $message=shift (@_));(my $storeInHistory=(
shift (@_)||(0x0cbd+ 6509-0x262a)));__log ($message,$LOG_WARNING,$storeInHistory
);}sub error{(my $message=shift (@_));(my $storeInHistory=(shift (@_)||
(0x0eff+ 2416-0x186f)));__log ($message,$LOG_ERROR,$storeInHistory);}sub 
connection{(my $message=shift (@_));(my $storeInHistory=(shift (@_)||
(0x1094+ 2644-0x1ae8)));if (($GLOBAL::EnableConnectionLog==(0x099f+ 1070-0x0dcc)
)){__log ($message,$LOG_NOTICE,$storeInHistory);}else{__log ($message,$LOG_DEBUG
,$storeInHistory);}}sub getErrorLevel{return ($LOG_ERROR);}sub getInfoLevel{
return ($LOG_INFO);}sub getWarningLevel{return ($LOG_WARNING);}sub getDebugLevel
{return ($LOG_DEBUG);}sub getDebug2Level{return ($LOG_DEBUG2);}sub 
getDebug3Level{return ($LOG_DEBUG3);}sub getNoticeLevel{return ($LOG_NOTICE);}
sub isErrorLevel{(my $level=shift (@_));if (($level==$LOG_ERROR)){return (
(0x1e8f+ 1581-0x24bb));}else{return ((0x035a+ 6976-0x1e9a));}}sub isWarningLevel
{(my $level=shift (@_));if (($level==$LOG_WARNING)){return (
(0x034a+ 3285-0x101e));}else{return ((0x10e0+ 5516-0x266c));}}sub isInfoLevel{(my $level
=shift (@_));if (($level==$LOG_INFO)){return ((0x1c9a+ 1738-0x2363));}else{
return ((0x0043+ 1989-0x0808));}}sub isDebugLevel{(my $level=shift (@_));if ((
$level==$LOG_DEBUG)){return ((0x0a18+ 1041-0x0e28));}else{return (
(0x0636+ 2652-0x1092));}}sub isDebug2Level{(my $level=shift (@_));if (($level==
$LOG_DEBUG2)){return ((0x1615+ 2750-0x20d2));}else{return ((0x069d+ 4028-0x1659)
);}}sub isDebug3Level{(my $level=shift (@_));if (($level==$LOG_DEBUG3)){return (
(0x0850+ 3235-0x14f2));}else{return ((0x00b8+ 3907-0x0ffb));}}sub isNoticeLevel{
(my $level=shift (@_));if (($level==$LOG_NOTICE)){return ((0x02fb+ 6312-0x1ba2))
;}else{return ((0x1050+ 2404-0x19b4));}}sub syslogEnabled{if ((
$GLOBAL::EnableSyslogSupport eq "\x31")){return ((0x15d9+ 2744-0x2090));}else{
return ((0x0367+ 2266-0x0c41));}}sub __openSyslog{(my $moduletype=
NXBegin::getModuletype ());libnxh::NXOpenLog ($moduletype);}sub 
sendMessageToSyslog{(my ($msg,$level)=@_);libnxh::NXSysLog ($msg,$level);}sub 
__openLogFile{(my $logFile=(shift (@_)||("")));unless (isLoggerWorking ()){
return ((0x184a+ 2503-0x2211));}(my $__logfile=$logFile);if (($logFile eq ("")))
{($__logfile=setLogFile ());}(my $permissions=
Common::NXFile::getServerLogFilePermissions ());if ((not (
Common::NXFile::fileExists ($__logfile)))){(my $createLogFile=main::nxopen (
$__logfile,$NXBits::O_CREAT,$permissions,{"\x45\x41\x43\x43\x45\x53",
"\x73\x69\x6c\x65\x6e\x74"}));main::nxclose ($createLogFile);
Common::NXFile::setServerLogFilePermissions ($__logfile);}($logfile_fh=
main::nxopen ($__logfile,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND
),$permissions,{"\x45\x41\x43\x43\x45\x53","\x73\x69\x6c\x65\x6e\x74"}));if ((
not (defined ($logfile_fh)))){__handleOpenLogError ($__logfile);}else{
libnxh::NXDescriptorInheritable ($logfile_fh,(0x0d3a+ 5865-0x2423));}}sub 
__handleOpenLogError{(my $logfile=shift (@_));(my $error=libnxh::NXGetErrorName 
());(my $errorstring=libnxh::NXGetErrorString ());(my $path=
Common::NXFile::dirname ($logfile));(my $filename=Common::NXFile::basename (
$logfile));setLoggerNotWorking ();if (($error eq "\x45\x4e\x4f\x45\x4e\x54")){
main::nxwrite (main::nxgetSTDERR (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$filename)."\x20\x69\x6e\x20").$path).
"\x20\x2d\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x0a"
));main::nxwrite (main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$filename)."\x20\x69\x6e\x20").$path).
"\x20\x2d\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x0a"
));}else{main::nxwrite (main::nxgetSTDERR (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$logfile)."\x20\x2d\x20\x27").$errorstring)."\x27\x2e\x0a"));main::nxwrite (
main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$logfile)."\x20\x2d\x20\x27").$errorstring)."\x27\x2e\x0a"));}main::nxexit ();}
sub __suppressStatusDump{(my $message=shift (@_));(my $level=$LOG_DEBUG);(my $statusMessage
=(0x06a4+ 7413-0x2398));return (__suppress ($message,$level,$statusMessage));}
sub __suppress{(my $msg=shift (@_));(my $level=shift (@_));(my $statusMessage=
shift (@_));(my $ref_previousMessageCount=(\$__previousLogMessage));(my $ref_previousMessage
=(\$__previousLogMessageCount));if (($statusMessage==(0x0c55+ 3635-0x1a87))){(
$ref_previousMessage=(\$__previousStatusMessage));($ref_previousMessageCount=(
\$__previousStatusMessageCount));}if ((not ($$ref_previousMessage))){(
$$ref_previousMessage=$msg);($$ref_previousMessageCount=(0x1d61+ 1670-0x23e6));
return ((0x06e3+ 6691-0x2106));}if (($$ref_previousMessage eq $msg)){(
$$ref_previousMessageCount=($$ref_previousMessageCount+(0x0d3d+ 4643-0x1f5f)));
return ((0x028f+ 8461-0x239b));}else{if (($$ref_previousMessageCount>
(0x0aad+ 3898-0x19e6))){(my $count=($$ref_previousMessageCount-
(0x0b65+ 1798-0x126a)));(my $message=(""));if (($count==(0x10eb+ 4371-0x21fd))){
($message=((
"\x50\x72\x65\x76\x69\x6f\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x72\x65\x70\x65\x61\x74\x65\x64\x20"
.$count)."\x20\x74\x69\x6d\x65"));}else{($message=((
"\x50\x72\x65\x76\x69\x6f\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x72\x65\x70\x65\x61\x74\x65\x64\x20"
.$count)."\x20\x74\x69\x6d\x65\x73"));}if (($statusMessage==(0x00c5+ 873-0x042d)
)){__statusPush ($message);}else{sendMessageToLogfile ($message,$level);}(
$$ref_previousMessageCount=(0x17df+ 3362-0x2500));}($$ref_previousMessage=$msg);
return ((0x0fb5+ 4521-0x215e));}}sub getLogrotateLogTypeNxserverLog{return (
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67");}sub 
getLogrotateLogTypeNxdLog{return ("\x6e\x78\x64\x2e\x6c\x6f\x67");}sub 
getLogrotateLogTypeNwebclientLog{return (
"\x6e\x78\x77\x65\x62\x72\x75\x6e\x6e\x65\x72\x2e\x6c\x6f\x67");}sub 
getLogrotateLogTypeNxhtdErrorLog{return ("\x6e\x78\x68\x74\x64\x2e\x6c\x6f\x67")
;}sub getLogrotateLogTypeNxserviceLog{return (
"\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2e\x6c\x6f\x67");}sub updateLogLevel{(my $newLevel
=shift (@_));if (($newLevel!=$__level)){($__level=$newLevel);info (((
"\x53\x65\x74\x20\x6e\x65\x77\x20\x6c\x6f\x67\x20\x6c\x65\x76\x65\x6c\x20\x27".
$newLevel)."\x27\x2e"));}else{debug (((
"\x4c\x6f\x67\x20\x6c\x65\x76\x65\x6c\x20\x27".$newLevel).
"\x27\x20\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x64\x2e"));}}return (
(0x0ed5+ 2404-0x1838));
