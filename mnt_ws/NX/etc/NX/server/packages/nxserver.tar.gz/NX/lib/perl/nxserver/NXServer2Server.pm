############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXServer2Server::BEGIN{package NXServer2Server;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}package NXServer2Server;no
 warnings;($__startMode="\x4e\x58");($__serverPid=(""));($__cmdIn=(-
(0x02d0+ 1226-0x0799)));($__cmdOut=(-(0x0afb+ 5100-0x1ee6)));($__cmdErr=(-
(0x0076+ 8962-0x2377)));($__insidePipeFD=(-(0x0f45+ 5258-0x23ce)));(
$__outsidePipeFD=(-(0x05bf+ 4950-0x1914)));($__insideCallbackFD=(-
(0x088b+ 7162-0x2484)));($__outsideCallbackFD=(-(0x18cf+ 430-0x1a7c)));($__shell
=undef);($__tempIdentityDirectory=(""));($__responseBuffer="\x0a");(
$__unexpectedCode=(-(0x0032+ 8794-0x228b)));sub execute{(my (@sequence)=@_);(my $flag_exited
=(0x0e16+ 1535-0x1415));(my $flag_unexpected=(0x022b+ 982-0x0601));if ((
__startServer2Server ()!=(0x1200+ 4056-0x21d8))){($flag_exited=
(0x155a+ 3497-0x2302));($flag_unexpected=(0x102f+ 3662-0x1e7c));}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;__addCallbackToSelect ((\$selector));__addCommunicationToSelect ((\$selector));
(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});if (($selector->
count>(0x0f6b+ 2981-0x1b10))){$selector->add ($signalFd);}($$NXBegin::parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"}=(\&abort));while (($flag_exited
==(0x0a5a+ 2501-0x141f))){(my (@ready)=$selector->can_read ((
$GLOBAL::AuthorizationTimeout *(0x09ea+ 7209-0x222b))));if ((scalar (@ready)==
(0x1000+ 5368-0x24f8))){Logger::warning (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x72\x65\x61\x63\x68\x65\x64\x2e"
);($flag_exited=(0x1bf1+ 1800-0x22f8));last;}foreach my $fd (@ready){if (($fd==
__getCommunicationFD ())){my ($buffer);(my $bytes=main::nxread ($fd,(\$buffer),
(0x1198+ 3530-0x1d62)));if (($bytes>(0x1edb+ 981-0x22b0))){Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x3a\x20"
.$buffer)."\x2e"));($__responseBuffer.=$buffer);}else{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6f\x6d\x6d\x75\x6e\x69\x63\x61\x74\x69\x6f\x6e\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);__removeCallbackFromSelect ((\$selector));__removeCommunicationFromSelect ((
\$selector));if (($selector->count==(0x10e3+ 3347-0x1df5))){$selector->remove (
$signalFd);}($flag_exited=(0x00c4+ 794-0x03dd));last;}while (($__responseBuffer
=~ s/([^\n]*?)\n+NX> (\d+) (.*)/$3/ )){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x50\x61\x72\x73\x69\x6e\x67\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x62\x75\x66\x66\x65\x72\x2e"
);(my $__responseBody=$1);(my $__responseCode=$2);Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x63\x6f\x64\x65\x20"
.$__responseCode)."\x2c\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20").
$__responseBody)."\x2e"));if (($__responseCode eq $GLOBAL::MSG_DEBUG)){
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x64\x65\x62\x75\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);next;}if (($__responseCode eq $GLOBAL::REQUEST_FOR)){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);next;}if (($__responseCode eq $GLOBAL::MSG_RESPONSE_NODE_DISTRIBUTION_INFO)){
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x64\x69\x73\x74\x72\x69\x62\x75\x74\x69\x6f\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);next;}if (($__responseCode eq $GLOBAL::MSG_BYE)){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x72\x76\x65\x72\x20\x68\x61\x73\x20\x65\x78\x69\x74\x2e"
);($flag_exited=(0x13f0+ 340-0x1543));last;}if (($flag_unexpected==
(0x0df0+ 2692-0x1873))){Logger::warning (((((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x77\x69\x74\x68\x20\x63\x6f\x64\x65\x20"
.$__responseCode).
"\x20\x77\x68\x65\x6e\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20").
$GLOBAL::MSG_BYE)."\x2e"));($flag_exited=(0x21f4+ 665-0x248c));last;}if (defined
 ($sequence[(0x1a89+ 341-0x1bde)])){(my $sequenceExpected=shift (@sequence));(my $sequenceReply
=shift (@sequence));if (($__responseCode ne $sequenceExpected)){Logger::warning 
(((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x77\x69\x74\x68\x20\x63\x6f\x64\x65\x20"
.$__responseCode)."\x2e"));($flag_unexpected=(0x157b+ 564-0x17ae));(
$__unexpectedCode=$__responseCode);Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x74\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x65\x78\x69\x74\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x2e"
);__sendToServer ("\x65\x78\x69\x74\x0a\x71\x75\x69\x74\x0a");}else{
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x45\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$sequenceExpected)."\x2e"));if (($sequenceReply ne (""))){($sequenceReply=~ s/\n//g )
;Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x74\x20\x73\x65\x71\x75\x65\x6e\x63\x65\x20\x72\x65\x70\x6c\x79\x3a\x20"
.$sequenceReply)."\x2e"));__sendToServer (($sequenceReply."\x0a"));}else{
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x2e"
);}}}else{Logger::warning (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65\x6e\x64\x20\x6f\x66\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x71\x75\x65\x75\x65\x2e\x20\x53\x65\x6e\x74\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x65\x78\x69\x74\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72"
);($flag_unexpected=(0x08fb+ 5692-0x1f36));__sendToServer (
"\x65\x78\x69\x74\x0a\x71\x75\x69\x74\x0a");}Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x70\x61\x72\x73\x69\x6e\x67\x2e\x20\x52\x65\x6d\x61\x69\x6e\x73\x3a\x20"
.$__responseBuffer)."\x2e"));}}elsif (($fd==__getCallbackFD ())){my ($buffer);(my $readSize
=main::nxread ($fd,(\$buffer),(0x177f+ 1612-0x1bcb)));if (($readSize>
(0x08a4+ 2384-0x11f4))){Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x28\x63\x61\x6c\x6c\x62\x61\x63\x6b\x29\x3a\x20"
.$buffer)."\x2e"));}else{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6c\x6c\x62\x61\x63\x6b\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);__removeCallbackFromSelect ((\$selector));}if (($buffer=~ /UsernameCallback/ )
){(my $username="\x6e\x78");Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x2e"));__sendToCallback ($username);}elsif (($buffer=~ /event=2/ )
){(my $keyPassword="\x0a");Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x6b\x65\x79\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x2e"
);__sendToCallback ($keyPassword);}}}}__removeTempIdentityServerFileAndDirectory
 ();__closeCallback ();__closeCommunication ();__closeServer ();if (defined (
$sequence[(0x022b+ 4029-0x11e8)])){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65\x6e\x64\x20\x6f\x66\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x71\x75\x65\x75\x65\x2e"
);($flag_unexpected=(0x0bc1+ 5840-0x2290));}if ((($flag_unexpected==
(0x1030+ 1766-0x1716))and ($flag_exited==(0x00bb+ 8705-0x22bb)))){Logger::debug 
(
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x69\x6e\x69\x73\x68\x65\x64\x2e"
);return ((0x1aa9+ 2899-0x25fc),(0x04cf+ 7185-0x20e0));}($__responseBuffer=~ s/\n+(.*)\n+/$1/ )
;Logger::debug (
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x73\x2e"
);return ($__responseBuffer,$__unexpectedCode);}sub __startServer2ServerByNX{(my (
@command)=());push (@command,NXPaths::getServerLaunchPath ());push (@command,
"\x2d\x2d\x6c\x6f\x67\x69\x6e");(my (@options)=());push (@options,
"\x67\x65\x74\x20\x70\x69\x64",(\$__serverPid));push (@options,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x20\x30\x20\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x20\x30"
);main::nxRunCommandBg ((\@command),(\@options),(\$__cmdIn),(\$__cmdOut),(
\$__cmdErr));(my ($rcOut,$rcErr,$rcExit)=main::nxRunCommandBg ((\@command),(
\@options),(\$__cmdIn),(\$__cmdOut),(\$__cmdErr)));if (($rcExit==(-
(0x0355+ 5538-0x18f6)))){main::nxexit ((0x1ead+ 1737-0x2575));}}sub 
setServerStartMode{(my $mode=shift (@_));if (($mode eq "\x53\x53\x48")){(
$__startMode="\x53\x53\x48");}else{($__startMode="\x4e\x58");}}sub 
__getServerStartMode{return ($__startMode);}sub __isServerStartModeNX{if ((
__getServerStartMode ()eq "\x4e\x58")){return ((0x0527+ 7997-0x2463));}return (
(0x0a92+ 4392-0x1bba));}sub __isServerStartModeSSH{if ((__getServerStartMode ()
eq "\x53\x53\x48")){return ((0x0c6f+ 1287-0x1175));}return (
(0x0a39+ 4071-0x1a20));}sub __startServer2Server{return (
__startServer2ServerByNX ());}sub __setServerPid{($__serverPid=shift (@_));}sub 
__getServerPid{return ($__serverPid);}sub __getTempIdentityDirectory{return (
$__tempIdentityDirectory);}sub __getTempIdentityFile{return (((
$__tempIdentityDirectory.$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x6c\x6f\x67"));
}sub __setTempIdentityDirectory{($__tempIdentityDirectory=
Common::NXPaths::getNxDirectoryInEffectiveUserHomeDirectory ());(
$__tempIdentityDirectory.=($GLOBAL::DIRECTORY_SLASH."\x74\x65\x6d\x70"));(
$__tempIdentityDirectory.=($GLOBAL::DIRECTORY_SLASH.$ $));
 }sub 
__removeTempIdentityServerFileAndDirectory{if ((__getServerStartMode ()eq 
"\x53\x53\x48")){if (Common::NXFile::fileExists (__getTempIdentityFile ())){if (
(not (unlink (__getTempIdentityFile ())))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20".
__getTempIdentityFile ()).("\x3a\x20".$!)),(0x0a20+ 2717-0x14bd));}else{if (-d (
__getTempIdentityDirectory ())){if ((not (rmdir (__getTempIdentityDirectory ()))
)){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20"
.__getTempIdentityDirectory ()).("\x3a\x20".$!)),(0x194c+ 1684-0x1fe0));}}}}}}
sub __createCommunicationPipe{my ($error);if ((
Common::NXCore::nxPipeCreateBiWithError ((\$__insidePipeFD),(\$__outsidePipeFD),
(\$error))==(0x1926+ 1454-0x1ed4))){(my $errorMsg=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x63\x6f\x6d\x6d\x75\x6e\x69\x63\x61\x74\x69\x6f\x6e\x20\x70\x69\x70\x65\x3a\x20"
.$error)."\x2e"));Logger::error ($errorMsg);__setErrorMsg ($errorMsg);return (
(0x1307+ 3847-0x220d));}}sub __createCallbackPipe{my ($error);if ((
Common::NXCore::nxPipeCreateBiWithError ((\$__insideCallbackFD),(
\$__outsideCallbackFD),(\$error))==(0x0492+ 1074-0x08c4))){(my $errorMsg=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x70\x69\x70\x65\x3a\x20"
.$error)."\x2e"));Logger::error ($errorMsg);__setErrorMsg ($errorMsg);return (
(0x059b+ 967-0x0961));}}sub __getCommunicationFD{if (__isServerStartModeNX ()){
return ($__cmdOut);}else{return ($__insidePipeFD);}}sub __getCallbackFD{return (
$__insideCallbackFD);}sub abort{Logger::debug (
"\x54\x68\x65\x20\x75\x73\x65\x72\x20\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x2e");
__removeTempIdentityServerFileAndDirectory ();__closeCallback ();
__closeCommunication ();__closeServer ();Common::NXCore::nxexit ();}sub 
__sendToServer{(my $message=shift (@_));if (__isServerStartModeNX ()){
main::nxwrite ($__cmdIn,$message);}elsif (__isServerStartModeSSH ()){
main::nxwrite ($__insidePipeFD,$message);}}sub __sendToCallback{(my $message=
shift (@_));if (__isServerStartModeSSH ()){main::nxwrite ($__insideCallbackFD,
$message);}}sub __closeServer{if ((not (Common::NXProcess::isChildFinished (
__getServerPid ())))){(my $wait_result=Common::NXProcess::nxwaitpid (
__getServerPid (),$NXBits::WAIT_UNTRACED,(0x1a4b+ 2855-0x256d)));if ((
$wait_result==(0x0630+ 1255-0x0b17))){Logger::debug ((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x2c\x20\x6e\x6f\x72\x6d\x61\x6c\x20\x65\x78\x69\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x6b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x69\x64\x20"
.__getServerPid ()));if (Common::NXProcess::sigkill (__getServerPid ())){
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x2c\x20\x6e\x6f\x72\x6d\x61\x6c\x20\x65\x78\x69\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x6b\x69\x6c\x6c\x65\x64\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.__getServerPid ())."\x2e"));}else{Logger::error (((
"\x53\x65\x72\x76\x65\x72\x32\x53\x65\x72\x76\x65\x72\x2c\x20\x6e\x6f\x72\x6d\x61\x6c\x20\x65\x78\x69\x74\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.__getServerPid ())."\x2e"));}}}if (__isServerStartModeSSH ()){if (defined (
$__shell)){$__shell->disconnect;($__shell=undef);}}}sub __closeCallback{if (
__isServerStartModeSSH ()){if (($__insideCallbackFD!=(-(0x0843+ 4323-0x1925)))){
main::nxclose ($__insideCallbackFD);($__insideCallbackFD=(-(0x07bf+ 7070-0x235c)
));}}}sub __closeCommunication{if (__isServerStartModeNX ()){if (($__cmdIn!=(-
(0x14cc+ 1051-0x18e6)))){main::nxclose ($__cmdIn);($__cmdIn=(-
(0x0be2+ 1662-0x125f)));}if (($__cmdOut!=(-(0x003d+ 8075-0x1fc7)))){
main::nxclose ($__cmdOut);($__cmdOut=(-(0x1210+ 1505-0x17f0)));}if (($__cmdErr!=
(-(0x145b+ 306-0x158c)))){main::nxclose ($__cmdErr);($__cmdErr=(-
(0x1671+ 3860-0x2584)));}"\x5f\x5f\x63\x6c\x6f\x73\x65";}elsif (
__isServerStartModeSSH ()){if (($__insidePipeFD!=(-(0x0089+ 2142-0x08e6)))){
main::nxclose ($__insidePipeFD);($__insidePipeFD=(-(0x1d25+ 1711-0x23d3)));}}}
sub __addCallbackToSelect{(my $ref_selector=shift (@_));if (
__isServerStartModeSSH ()){if (($__insideCallbackFD!=(-(0x1d58+ 1644-0x23c3)))){
$$ref_selector->add ($__insideCallbackFD);}}}sub __addCommunicationToSelect{(my $ref_selector
=shift (@_));if (__isServerStartModeSSH ()){if (($__insidePipeFD!=(-
(0x1abd+ 360-0x1c24)))){$$ref_selector->add ($__insidePipeFD);}}if (
__isServerStartModeNX ()){if (($__cmdOut!=(-(0x03e5+ 8075-0x236f)))){
$$ref_selector->add ($__cmdOut);}}}sub __removeCallbackFromSelect{(my $ref_selector
=shift (@_));if ($$ref_selector->exists ($__insideCallbackFD)){$$ref_selector->
remove ($__insideCallbackFD);}}sub __removeCommunicationFromSelect{(my $ref_selector
=shift (@_));if ($$ref_selector->exists ($__insidePipeFD)){$$ref_selector->
remove ($__insidePipeFD);}}sub __setErrorMsg{(my $msg=shift (@_));(
$__unexpectedCode=$GLOBAL::MSG_ERROR);($__responseBuffer=$msg);}return (
(0x1e52+ 1642-0x24bb));
