############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXSelectNode::BEGIN{package NXSelectNode;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub NXSelectNode::BEGIN{
package NXSelectNode;no warnings;require NXNodes;do{
"\x4e\x58\x4e\x6f\x64\x65\x73"->import};}sub NXSelectNode::BEGIN{package 
NXSelectNode;no warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import (
"\x3a\x74\x72\x79")};}sub NXSelectNode::BEGIN{package NXSelectNode;no warnings;
require NXNodes;do{"\x4e\x58\x4e\x6f\x64\x65\x73"->import};}package NXSelectNode
;no warnings;(my $__multipleNodesAreAvailable=(0x1aeb+ 1384-0x2053));(my $__memoryThreshold
=300000);sub prepareNodeList{(my $sessionType=(shift (@_)||
NXSessionParameters::getSessionType ()));if (($sessionType eq (""))){
Logger::error (
"\x4d\x69\x73\x73\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x2e"
);NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x4d\x69\x73\x73\x69\x6e\x67\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65");
return (());}Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x65\x6c\x65\x63\x74\x20\x6e\x6f\x64\x65\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$sessionType)."\x27\x2e"));if ((__prepareNodeList ($sessionType)==
(0x016d+ 900-0x04f1))){return (());}(my $sortNodes=(0x0fac+ 3489-0x1d4d));(my (
@nodes)=());while (__nodesAreAvailable ()){(my $node=getNextNode ());(my $host=
$$node{"\x68\x6f\x73\x74"});(my $port=$$node{"\x70\x6f\x72\x74"});if ((not (
NXNodes::isSessionTypeAvailableForNode ($sessionType,(\$node))))){
Logger::warning (((((((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27".$sessionType).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x27"
).$host)."\x3a").$port)."\x27\x2e"));NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
);next;}if ((__checkProfilesForSelectedNode ($node,$sessionType)==
(0x2364+ 913-0x26f4))){next;}push (@nodes,$node);}(my $nodeList=(""));foreach my $node
 (@nodes){($nodeList.=((($$node{"\x68\x6f\x73\x74"}."\x3a").$$node{
"\x70\x6f\x72\x74"})."\x2c"));}($nodeList=~ s/,$// );Logger::debug (((
"\x50\x72\x65\x70\x61\x72\x65\x64\x20\x6e\x6f\x64\x65\x20\x6c\x69\x73\x74\x20\x27"
.$nodeList)."\x27\x2e"));if (isCustomLoadBalancing ()){
__updateNodesArrayByCustomLBScript ((\@nodes));}if (scalar (@nodes)){return (
@nodes);}return (());}sub __prepareNodeList{(my $sessionType=shift (@_));my (
$runningHostsList);(my $isMultiNodeEnabledInProfiles=(0x0514+ 5774-0x1ba2));if (
NXProfilesManager::isMultinodeEnabled ()){(my $nodeUUID=
NXSessionParameters::getNodeUUID ());if ((NXNodes::isManualSelectionFlag ()and (
$nodeUUID ne ("")))){($runningHostsList=$nodeUUID);}else{($runningHostsList=
NXNodes::getNodesList ());}($isMultiNodeEnabledInProfiles=(0x00f2+ 7938-0x1ff3))
;}else{(my ($uuid,$host,$port)=NXNodes::findLocalNode ());($runningHostsList=
$uuid);}(my (@runningHostArray)=split ( /,/ ,$runningHostsList,
(0x0fef+ 860-0x134b)));(my $runningNodes=scalar (@runningHostArray));if ((
$runningNodes==(0x1646+ 4054-0x261c))){Logger::error (
"\x4e\x6f\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x6e\x6f\x64\x65\x73\x20\x66\x6f\x75\x6e\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x2e"
);NXMsg::error (
"\x65\x52\x75\x6e\x6e\x69\x6e\x67\x4e\x6f\x64\x65\x73\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
,"\x4e\x58\x53\x65\x6c\x65\x63\x74\x4e\x6f\x64\x65");return (
(0x0cb0+ 3634-0x1ae2));}($AvailableHostList=$runningHostsList);if (((not (
NXNodes::isManualSelectionFlag ()))and $isMultiNodeEnabledInProfiles)){(
$AvailableHostList=(""));foreach my $node (@runningHostArray){if ((not (
NXProfilesManager::isNodeAvailableForLoggedUser ($node)))){Logger::debug (((
"\x4e\x6f\x64\x65\x20\x27".$node).
"\x27\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x2e"
));NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x4e\x6f\x64\x65\x73\x41\x72\x65\x44\x69\x73\x61\x62\x6c\x65\x64");}elsif (
(not (NXNodes::isMultinodeEnabledForNode ($node)))){Logger::debug (((
"\x4e\x6f\x64\x65\x20\x27".$node).
"\x27\x20\x69\x73\x20\x65\x78\x63\x6c\x75\x64\x65\x64\x20\x66\x72\x6f\x6d\x20\x6c\x6f\x61\x64\x20\x62\x61\x6c\x61\x6e\x63\x69\x6e\x67\x2e"
));NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x4e\x6f\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x4e\x6f\x64\x65\x73");}else{
Logger::debug (((
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x4e\x6f\x64\x65\x3a\x20\x4e\x6f\x64\x65\x20\x27"
.$node).
"\x27\x20\x69\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x6c\x6f\x67\x67\x65\x64\x20\x75\x73\x65\x72\x2e"
));($AvailableHostList.=($node."\x2c"));}}($AvailableHostList=~ s/,$// );}(my (
@nodeList)=split ( /,/ ,$AvailableHostList,(0x0a97+ 441-0x0c50)));($nodeCount=
scalar (@nodeList));if (($nodeCount==(0x002a+ 5836-0x16f6))){Logger::error (
"\x4e\x6f\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6e\x6f\x64\x65\x73\x20\x66\x6f\x75\x6e\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x2e"
);NXMsg::error (
"\x65\x4e\x6f\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x4e\x6f\x64\x65\x73",
"\x4e\x58\x4e\x6f\x64\x65\x45\x72\x72\x6f\x72");return ((0x08a2+ 1726-0x0f60));}
if (($nodeCount>(0x061a+ 1149-0x0a96))){__setMultipleNodesAvailable ();}(
$tryCounter=(0x01af+ 8427-0x2299));($nodeIndex=(0x0f17+ 1920-0x1697));if ((
$GLOBAL::LoadBalancingAlgorithm eq 
"\x6c\x6f\x61\x64\x2d\x61\x76\x65\x72\x61\x67\x65")){($AvailableHostList=
__getLoadAvgList ($AvailableHostList));}elsif (($GLOBAL::LoadBalancingAlgorithm 
eq "\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64")){($AvailableHostList=
__getSystemLoadList ($AvailableHostList));}else{if (
NXNodes::isNodesWeightAvailable ()){($AvailableHostList=
__getWeightRoundRobinList ($AvailableHostList));}else{($AvailableHostList=
__getSimpleRoundRobinList ($AvailableHostList));}}return ($nodeCount);}sub 
__getLoadAvgList{(my (%hashNodes)=());(my (@multinode_hosts)=split ( /,/ ,
$AvailableHostList,(0x0851+ 2957-0x13de)));foreach my $node (@multinode_hosts){(my $load
=NXNodes::getLoadAvg ($node));Logger::debug (((((
"\x4c\x6f\x61\x64\x20\x61\x76\x65\x72\x61\x67\x65\x20\x66\x6f\x72\x20".$node).
"\x3a\x20").$load)."\x2e"));($hashNodes{$node}=$load);}(my $nodeString=(""));
foreach my $key (sort ({($hashNodes{$a}<=>$hashNodes{$b});}keys (%hashNodes))){(
$nodeString.=($key."\x2c"));}chop ($nodeString);Logger::debug (((
"\x4e\x6f\x64\x65\x20\x6c\x6f\x61\x64\x20\x61\x76\x65\x72\x61\x67\x65\x20\x6c\x69\x73\x74\x3a\x20"
.$nodeString)."\x2e"));return ($nodeString);}sub __getSystemLoadList{(my (
%hashNodesCorrect)=());(my $incompatibleNodesString=(""));(my (@multinode_hosts)
=split ( /,/ ,$AvailableHostList,(0x1049+ 1807-0x1758)));foreach my $node (
@multinode_hosts){(my ($systemLoad,$availableMemory)=
NXNodes::getSystemLoadAndAvailableMemory ($node));Logger::debug (((((((
"\x53\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x66\x6f\x72\x20".$node).
"\x3a\x20").$systemLoad).
"\x2c\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6d\x65\x6d\x6f\x72\x79\x20").
$availableMemory)."\x2e"));if ((($systemLoad<(0x0b37+ 7008-0x2697))or (
$availableMemory<__getMemoryThreshold ()))){($incompatibleNodesString.=($node.
"\x2c"));}else{($hashNodesCorrect{$node}=$systemLoad);}}chop (
$incompatibleNodesString);(my $nodeString=(""));foreach my $key (sort ({(
$hashNodesCorrect{$a}<=>$hashNodesCorrect{$b});}keys (%hashNodesCorrect))){(
$nodeString.=($key."\x2c"));}if (($incompatibleNodesString ne (""))){if (scalar 
(keys (%hashNodesCorrect))){Logger::debug (
"\x41\x64\x64\x69\x6e\x67\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x69\x6e\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x20\x6e\x6f\x64\x65\x73\x20\x74\x6f\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x6c\x69\x73\x74\x2e"
);($nodeString.=__getSimpleRoundRobinList ($incompatibleNodesString));}else{
Logger::warning (
"\x41\x6c\x6c\x20\x6e\x6f\x64\x65\x73\x20\x68\x61\x76\x65\x20\x69\x6e\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x6f\x72\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6d\x65\x6d\x6f\x72\x79\x2e"
);Logger::warning (
"\x46\x61\x6c\x6c\x69\x6e\x67\x20\x62\x61\x63\x6b\x20\x74\x6f\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x6c\x69\x73\x74\x2e"
);($nodeString.=__getSimpleRoundRobinList ($AvailableHostList));}}else{chop (
$nodeString);}Logger::debug (((
"\x4e\x6f\x64\x65\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x6c\x69\x73\x74\x3a\x20"
.$nodeString)."\x2e"));return ($nodeString);}sub __getSimpleRoundRobinList{(my $availableHostList
=shift (@_));(my (@hostsAvaliable)=split ( /,/ ,$availableHostList,
(0x011a+ 7149-0x1d07)));(my $nodeCount=scalar (@hostsAvaliable));(my $index=
__takeNodeIndex ($nodeCount));if (($index>=$nodeCount)){($index=
(0x11e5+ 1247-0x16c4));}(my $i=(0x0783+ 4074-0x176d));(my $nodeString=(""));
while (($i<$nodeCount)){($nodeString.=($hostsAvaliable[$index]."\x2c"));($index=
__getNextNodeIndex ($index,$nodeCount));(++$i);}($nodeString=~ s/,$// );
Logger::debug (((
"\x53\x69\x6d\x70\x6c\x65\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x6e\x6f\x64\x65\x20\x6c\x69\x73\x74\x20\x27"
.$nodeString)."\x27\x2e"));return ($nodeString);}sub __getWeightRoundRobinList{(my $availableHostList
=shift (@_));(my (@hosts)=split ( /,/ ,$availableHostList,(0x0936+ 1885-0x1093))
);(my (%hashNodes)=());foreach my $node (@hosts){(my $nodeSessions=
NXLimits::getSessionsNode ($node));(my $nodeWeight=NXNodes::getWeight ($node));(my $weight
=($nodeWeight-$nodeSessions));Logger::debug ((((("\x4e\x6f\x64\x65\x20\x27".
$node).
"\x27\x20\x77\x65\x69\x67\x68\x74\x20\x74\x6f\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x27"
).$weight)."\x27\x2e"));($hashNodes{$weight}.=($node."\x2c"));}(my $nodeString=
(""));foreach my $key (sort ({$b<=>$a}keys (%hashNodes))){($nodeString.=
$hashNodes{$key});}($nodeString=~ s/,$// );Logger::debug (((
"\x57\x65\x69\x67\x68\x74\x20\x72\x6f\x75\x6e\x64\x20\x72\x6f\x62\x69\x6e\x20\x6e\x6f\x64\x65\x20\x6c\x69\x73\x74\x20\x27"
.$nodeString)."\x27\x2e"));return ($nodeString);}sub __takeNodeIndex{(my $nodeCount
=shift (@_));NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x72\x6f\x75\x6e\x64\x72\x6f\x62\x69\x6e\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x64\x65\x78\x0a"
);(my $index=NXRedis::get ());if (($index ne (""))){($index=__getNextNodeIndex (
$index,$nodeCount));}else{($index=(0x1807+ 2602-0x2231));}NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x72\x6f\x75\x6e\x64\x72\x6f\x62\x69\x6e\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x64\x65\x78\x2c\x76\x61\x6c\x75\x65\x3d"
.$index)."\x0a"));return ($index);}sub __getNextNodeIndex{(my $num=shift (@_));(my $nodeCount
=shift (@_));if ((($num>=(0x1c96+ 1487-0x2265))and ($num<($nodeCount-
(0x109a+ 1630-0x16f7))))){(++$num);}else{($num=(0x15d7+ 2591-0x1ff6));}return (
$num);}sub __checkProfilesForSelectedNode{(my $node=shift (@_));(my $sessionType
=shift (@_));(my $nodeToCheck=$$node{"\x75\x75\x69\x64"});Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x27"
.$nodeToCheck).
"\x27\x20\x61\x6e\x64\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
).$sessionType)."\x27\x2e"));if ((
NXProfilesManager::isSessionTypeAvailableForUserGroupSystemAndNode ($sessionType
,undef,$nodeToCheck)==(0x0872+ 4143-0x18a1))){Logger::debug (((((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27".$sessionType).
"\x27\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x27"
).$nodeToCheck)."\x27\x2e"));NXNodeError::saveErrorNameFromDroppedNode (
"\x65\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x4e\x6f\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65"
);return ((0x1247+ 4596-0x243a));}Logger::debug ((("\x4e\x6f\x64\x65\x20\x27".
$nodeToCheck).
"\x27\x20\x65\x6e\x61\x62\x6c\x65\x20\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e"
));return ((0x2484+ 536-0x269c));}sub getNextNode{my ($loadMultinodeHost);if (
NXProfilesManager::isMultinodeEnabled ()){($loadMultinodeHost=__getNodeByIndex (
__getNodeIndex ()));}else{Logger::debug (
"\x4d\x75\x6c\x74\x69\x6e\x6f\x64\x65\x20\x66\x65\x61\x74\x75\x72\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);($loadMultinodeHost=__getNodeByIndex ((0x1526+ 2261-0x1dfb)));}
__increaseNodeIndex ($loadMultinodeHost);return (NXNodes::get (
$loadMultinodeHost));}sub __getNodeListByLBScript{(my $ref_nodes=shift (@_));(my $cmd_err
=(""));(my $cmd_out=(""));(my $exit_value=(0x12d9+ 882-0x164b));if ((not (-x (
$GLOBAL::NodeSelectionScript)))){Logger::warning (((
"\x54\x68\x65\x20\x6e\x6f\x64\x65\x20\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$GLOBAL::NodeSelectionScript).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"))
;return ((""));}if ((not (Common::NXShellCommands::isApplicationInKnownPath (
"\x70\x65\x72\x6c")))){Logger::warning (
"\x50\x65\x72\x6c\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x69\x6e\x20\x74\x68\x69\x73\x20\x73\x79\x73\x74\x65\x6d\x2e"
);return ((""));}(my (@command)=Common::NXShellCommands::getCommand (
"\x70\x65\x72\x6c"));push (@command,$GLOBAL::NodeSelectionScript);push (@command
,__getParamsForLBScript ($ref_nodes));Logger::debug (((
"\x47\x65\x74\x20\x6e\x6f\x64\x65\x73\x20\x6c\x69\x73\x74\x20\x62\x79\x20\x4c\x42\x20\x73\x63\x72\x69\x70\x74\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27"
.join ($",@command))."\x27\x2e"));(my (@parameters)=());push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x55\x53\x45\x52\x4e\x41\x4d\x45\x3d".NXLogin::getCurrentUser ()));
push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x5f\x49\x50\x3d".
NXClientConnection::getRemoteIp ()));(($cmd_err,$cmd_out,$exit_value)=
main::run_command ((\@command),(\@parameters)));($cmd_out=~ s/\n$// );if ((
$exit_value!=(0x1200+ 4541-0x23bd))){return ((""));}return ($cmd_out);}sub 
__getParamsForLBScript{(my $ref_nodes=shift (@_));(my $paramsForLBScript=undef);
foreach my $node (@$ref_nodes){(my $countSession=
NXNodes::getSessionsCountForLBScript ($$node{"\x75\x75\x69\x64"}));(my $limit=
$$node{"\x6c\x69\x6d\x69\x74"});if (($limit eq (""))){($limit=
NXLimits::getMaxConnectionsLimit ());}(my $weight=$$node{
"\x77\x65\x69\x67\x68\x74"});if (($weight eq (""))){($weight=
(0x02f8+ 4393-0x1421));}(my $loadAvg=NXNodes::getLoadAvg ($$node{
"\x75\x75\x69\x64"}));($paramsForLBScript.=((((((((($$node{"\x75\x75\x69\x64"}.
"\x2c").$weight)."\x2c").$countSession)."\x2c").$limit)."\x2c").$loadAvg)."\x23"
));}return ($paramsForLBScript);}sub __nodesAreAvailable{if (($tryCounter<=
$nodeCount)){return ((0x0048+ 1878-0x079d));}return ((0x029f+ 7758-0x20ed));}sub
 __getNodeByIndex{(my $index=shift (@_));(my (@nodeList)=split ( /,/ ,
$AvailableHostList,(0x1464+ 4284-0x2520)));return ($nodeList[$index]);}sub 
__getNodeIndex{return ($nodeIndex);}sub __increaseNodeIndex{(++$nodeIndex);(
$tryCounter++);}sub __setMultipleNodesAvailable{($__multipleNodesAreAvailable=
(0x0004+ 8359-0x20aa));}sub multipleNodesAreAvailable{return (
$__multipleNodesAreAvailable);}sub isCustomLoadBalancing{if ((
$GLOBAL::LoadBalancingAlgorithm eq "\x63\x75\x73\x74\x6f\x6d")){if ((
$GLOBAL::NodeSelectionScript ne (""))){return ((0x03dc+ 2887-0x0f22));}else{
Logger::warning (
"\x4c\x6f\x61\x64\x20\x62\x61\x6c\x61\x6e\x63\x69\x6e\x67\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x27\x63\x75\x73\x74\x6f\x6d\x27\x20\x62\x75\x74\x20\x6e\x6f\x64\x65\x20\x73\x65\x6c\x65\x63\x74\x69\x6f\x6e\x20\x73\x63\x72\x69\x70\x74\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x44\x65\x66\x61\x75\x6c\x74\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x20\x69\x73\x20\x75\x73\x65\x64\x2e"
);}}return ((0x0bf3+ 5508-0x2177));}sub __updateNodesArrayByCustomLBScript{(my $ref_nodes
=shift (@_));(my $nodesList=__getNodeListByLBScript ($ref_nodes));if ((
$nodesList eq (""))){Logger::warning ((((
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x74\x72\x69\x65\x76\x69\x6e\x67\x20\x6e\x6f\x64\x65\x73\x20\x62\x79\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$GLOBAL::NodeSelectionScript)."\x27\x2e\x20").
"\x44\x65\x66\x61\x75\x6c\x74\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x20\x69\x73\x20\x75\x73\x65\x64\x2e"
));return;}(my (@nodesAddressArray)=split ( /#/ ,$nodesList,
(0x084b+ 3171-0x14ae)));(@$ref_nodes=());foreach my $address (@nodesAddressArray
){push (@$ref_nodes,NXNodes::get ($address));}}sub 
__getCommaSeparatedNodeListByCustomLBScript{(my $ref_nodes=shift (@_));(my $nodesList
=__getNodeListByLBScript ($ref_nodes));if (($nodesList eq (""))){Logger::warning
 ((((
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x74\x72\x69\x65\x76\x69\x6e\x67\x20\x6e\x6f\x64\x65\x73\x20\x62\x79\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$GLOBAL::NodeSelectionScript)."\x27\x2e\x20").
"\x44\x65\x66\x61\x75\x6c\x74\x20\x61\x6c\x67\x6f\x72\x69\x74\x68\x6d\x20\x69\x73\x20\x75\x73\x65\x64\x2e"
));return ((""));}($nodesList=~ s/#/,/g );return ($nodesList);}sub 
__getMemoryThreshold{return ($__memoryThreshold);}NXMsg::register_error (
"\x4e\x58\x53\x65\x6c\x65\x63\x74\x4e\x6f\x64\x65",
"\x65\x52\x75\x6e\x6e\x69\x6e\x67\x4e\x6f\x64\x65\x73\x4e\x6f\x74\x46\x6f\x75\x6e\x64"
,(0x208d+ 1447-0x2440));return ((0x0596+ 4866-0x1897));
