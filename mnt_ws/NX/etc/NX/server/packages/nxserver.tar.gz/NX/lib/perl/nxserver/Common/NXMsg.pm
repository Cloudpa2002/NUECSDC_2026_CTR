############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXMsg::BEGIN{package Common::NXMsg;no warnings;require 
Common::NXError;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x45\x72\x72\x6f\x72"->import};}package
 Common::NXMsg;no warnings;($GLOBAL::Common::NXMsg::__inBuffer=(""));(
$typeResponse=(0x11c7+ 3458-0x1f49));($typeRequest=(0x0ea2+ 3303-0x1b88));(
$typeError=(0x0ee6+ 580-0x1128));sub BEGIN{require Common::NXTranslator;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x54\x72\x61\x6e\x73\x6c\x61\x74\x6f\x72"
->import};}sub __sprinf_reg_exp{(my $format=shift (@_));(my $name=shift (@_));(my (
@message_parameters)=@_);for ((my $i=(0x194f+ 1166-0x1ddd));($i<=$#message_parameters
);(++$i)){($message_parameters[$i]=~ s/^\n//gm );($message_parameters[$i]=~ s/\n$//gm )
;}(my $message=sprintf ($format,@message_parameters));($message=~ s/\n/\n        /gm )
;return ($message);}sub check_msg{(my $index=shift (@_));(my (@parameters)=@_);
if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){
return ((0x1859+ 940-0x1c05));}(my $messageNumber=getNumber ($index));if ((not (
defined ($messageNumber)))){return ((0x1c66+ 256-0x1d66));}return (
(0x1464+ 629-0x16d8));}sub get_msg{(my $index=shift (@_));(my (@parameters)=@_);
if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){
return ((0x0e03+ 3981-0x1d90));}(my $messageNumber=getNumber ($index));if ((not 
(defined ($messageNumber)))){return ((0x0a85+ 3522-0x1847));}if (($messageNumber
==(0x197b+ 1356-0x1ec7))){($messageNumber=$GLOBAL::MSG_ERROR);}for ((my $i=
(0x03bc+ 7038-0x1f3a));($i<=$#parameters);(++$i)){($parameters[$i]=~ s/^\n//gm )
;($parameters[$i]=~ s/\n$//gm );}(my $message=(""));if (
Common::NXEnglishMessages::isCustomizableMessage ($index)){(($messageNumber,
$index,$message)=getCustomizedMessage ($index,$messageNumber,(\@parameters)));}
else{($message=Common::NXEnglishMessages::getMessage ($index));}if (
__shouldPackMessage ($index)){($message=constructMessage ($messageNumber,
$message,@parameters));(my $packedMessage=packResponse ($index,$message,
@parameters));return ((""),$packedMessage);}if ((not (
NXBegin::isModuletypeNxnode ()))){Common::NXTranslator::translate ($index,(
\$message));}($message=constructMessage ($messageNumber,$message,@parameters));(my $regExp
=getRegExp ($index));return ($regExp,$message);}sub constructMessage{(my $messageNumber
=shift (@_));(my $message=shift (@_));(my (@parameters)=@_);(my $fullMessage=
(""));(my $messageHead="\x4e\x58\x3e\x20");(my $messageFormat=(($messageHead.
"\x25\x69\x20").$message));if (($message ne (""))){($fullMessage=sprintf (
$messageFormat,$messageNumber,@parameters));($fullMessage=~ s/\n/\n$messageHead$messageNumber /gm )
;}return ($fullMessage);}sub send_response{(my $newline=(0x0522+ 990-0x08ff));
__sendResponse ($newline,@_);}sub send_response_no_newline{(my $newline=
(0x08e5+ 1564-0x0f01));__sendResponse ($newline,@_);}sub __sendResponse{(my $newline
=shift (@_));(my $index=$_[(0x01dd+ 6248-0x1a45)]);if (isErrorTypeByIndex (
$index)){return (error (@_));}(my ($reg_exp,$message)=get_msg (@_));
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));if ($newline){($message.="\x0a");}main::nxwrite (
main::nxgetSTDOUT (),$message);}sub get_text_msg{(my $index=shift (@_));(my $translate
=shift (@_));(my (@parameters)=@_);for ((my $i=(0x107d+ 369-0x11ee));($i<=$#parameters
);(++$i)){($parameters[$i]=~ s/^\n//gm );($parameters[$i]=~ s/\n$//gm );}if (((
not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ ))))){
Logger::warning (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x55\x6e\x6b\x6e\x6f\x77\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x69\x6e\x64\x65\x78\x20\x27"
.$index)."\x27\x2e"));return ((""));}(my $messageText=(""));if ((($translate==
(0x0904+ 3147-0x154f))or (Common::NXTranslator::translate ($index,(\$messageText
))==(0x0350+ 390-0x04d6)))){($messageText=Common::NXEnglishMessages::getMessage 
($index));Logger::debug3 (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$messageText)."\x27\x2e"));}(my $message=(""));if (($messageText ne (""))){(
$message=sprintf ($messageText,@parameters));}return ($message);}sub get_text{(my $indexString
=shift (@_));(my (@parameters)=@_);(my $translate=(0x1145+ 3603-0x1f57));return 
(get_text_msg ($indexString,$translate,@parameters));}sub getEnglishText{(my $indexString
=shift (@_));(my (@parameters)=@_);(my $translate=(0x0247+ 2918-0x0dad));return 
(get_text_msg ($indexString,$translate,@parameters));}sub getEnglishTextOneLine{
(my $text=getEnglishText (@_));($text=~ s/\n/ /gm );return ($text);}sub 
sendLogMessage{(my $message=shift (@_));(my $level=shift (@_));(my $storeInHistory
=shift (@_));if (Logger::isErrorLevel ($level)){Logger::error ($message,
$storeInHistory);}elsif (Logger::isWarningLevel ($level)){Logger::warning (
$message,$storeInHistory);}elsif (Logger::isInfoLevel ($level)){Logger::info (
$message,$storeInHistory);}else{Logger::debug ($message,$storeInHistory);}}sub 
__warning{(my $log_level=shift (@_));(my ($reg_exp,$message)=get_msg (@_));if ((
defined ($reg_exp)and ($reg_exp eq (0x0360+ 7872-0x221f)))){(my $log_msg=
__sprinf_reg_exp ($reg_exp,@_));sendLogMessage ($log_msg,$log_level,
(0x0a1d+ 2210-0x12bc));}if (((defined ($reg_exp)and ($reg_exp ne ("")))and (
$reg_exp ne (0x040a+ 5809-0x1aba)))){(my $log_msg=__sprinf_reg_exp ($reg_exp,@_)
);sendLogMessage ($log_msg,$log_level,(0x1c1a+ 2155-0x2482));}if (((not (defined
 ($message)))or ($message eq ("")))){(($reg_exp,$message)=get_msg (
"\x65\x47\x55\x49\x47\x65\x6e\x65\x72\x61\x6c"));}if (isPackedMessage ($message)
){Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x70\x61\x63\x6b\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}elsif (Logger::isInfoLevel ($log_level)){Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x61\x6c\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}elsif (Logger::isWarningLevel ($log_level)){($message=~ s/(^NX> \d+) *(.*)$/$1 WARNING: $2/gm )
;Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x77\x61\x72\x6e\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}else{($message=~ s/(^NX> \d+) *(.*)$/$1 ERROR: $2/gm );
Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x65\x72\x72\x6f\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));}main::nxwrite (main::nxgetSTDOUT (),($message."\x0a"));}sub
 fatal{__warning (Logger::getErrorLevel (),@_);NXShell::handle_command (
"\x65\x78\x69\x74");}sub error{__warning (Logger::getErrorLevel (),@_);}sub 
warning{__warning (Logger::getWarningLevel (),@_);}sub info{__warning (
Logger::getInfoLevel (),@_);}sub send_request{(my $pRegExp=shift (@_));(my $pMessage
=shift (@_));(my $value=shift (@_));(my ($reg_exp,$message)=get_msg ($pRegExp,
$pMessage,@_));if (defined ($value)){if (($reg_exp eq 
"\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x63\x68\x61\x72")){if ((not (($value=~ /(^[^0-9A-Za-z_.+\-])$/ )
))){(my $tmp=$value);while (($tmp=~ s/(.)// )){if ((ord ($1)<
(0x1d9d+ 1328-0x22ad))){Logger::error (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x5c"
.sprintf ("\x5c\x30\x25\x6f",ord ($1))).
"\x2e\x20\x4e\x6f\x6e\x20\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x75\x73\x65\x64\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72"
));return (());}}}}elsif ((not (($value=~ /$reg_exp/ )))){Logger::error (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x76\x61\x6c\x75\x65\x20\x27"
.$value)."\x27"));return (());}return ($value);}if (($message=~ /^NX> (\d\d\d)  $/ )
){($message=(("\x4e\x58\x3e\x20".$1)."\x20"));}else{($message.="\x3a\x20");}
main::nxwrite (main::nxgetSTDOUT (),$message);Logger::debug (((
"\x4e\x58\x4d\x73\x67\x3a\x20\x53\x65\x6e\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27"));(my $data=__readnLine ());if ((not (defined ($data)))){
return (());}(my $log_data=$data);($log_data=~ s/(password=)([^&]*)/do {
        ($1 . ('*' x length($2)));
    };/eg )
;($log_data=~ s/(cookie=)([^&]*)/do {
        ($1 . ('*' x length($2)));
    };/eg )
;if (($pRegExp ne "\x63\x6f\x6d\x6d\x61\x6e\x64")){if ((($GLOBAL::PROTO_VERSION 
ne "\x73\x68\x65\x6c\x6c")and ($GLOBAL::PROTO_VERSION ne ("")))){main::nxwrite (
main::nxgetSTDOUT (),($data."\x0a"));}else{main::nxwrite (main::nxgetSTDOUT (),
"\x0a");}}Logger::debug (((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x4d\x73\x67\x3a\x20\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$log_data)."\x27"));if (($reg_exp eq 
"\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x63\x68\x61\x72")){if ((not (($data=~ /(^[^0-9A-Za-z_.+\-])$/ )
))){(my $tmp=$data);while (($tmp=~ s/(.)// )){if ((ord ($1)<
(0x139b+ 2285-0x1c68))){Logger::error (((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x3a\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x5c").sprintf (
"\x5c\x30\x25\x6f",ord ($1))).
"\x20\x69\x73\x20\x61\x20\x6e\x6f\x74\x20\x70\x72\x69\x6e\x74\x61\x62\x6c\x65\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x20\x61\x6e\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x75\x73\x65\x64\x20\x68\x65\x72\x65"
));return (());}}}}elsif ((not (($data=~ /$reg_exp/ )))){Logger::error (((((((
"\x4e\x58\x4d\x73\x67\x3a\x20\x49\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x74\x6f\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$message)."\x3a\x20").$log_data).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x6d\x61\x74\x63\x68\x20\x77\x69\x74\x68\x20\x27"
).$reg_exp)."\x27"));main::nxwrite (main::nxgetSTDOUT (),"\x0a");return (());}if
 ((($data eq (""))and $GLOBAL::PROTO_VERSION)){main::nxwrite (main::nxgetSTDOUT 
(),"\x0a");}return ($data);}sub __error{main::nxwrite (main::nxgetSTDERR (),
"\x45\x72\x72\x6f\x72\x3a\x20\x66\x61\x74\x61\x6c\x20\x65\x72\x72\x6f\x72\x20\x69\x6e\x20\x6d\x6f\x64\x75\x6c\x65\x20\x4e\x58\x4d\x73\x67\x2c\x20\x63\x68\x65\x63\x6b\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x6d\x6f\x72\x65\x20\x64\x65\x74\x61\x69\x6c\x73\x0a"
);main::nxexit ((0x11f0+ 4558-0x23bd));}sub __readnLine{(my $maxLengt=(shift (@_
)||(0x1855+ 7650-0x2637)));(my $data=());(my $endOfLine=(0x084b+ 1544-0x0e53));(my $ignoreUntileEOL
=(0x094c+ 6246-0x21b2));while ((not ($endOfLine))){(my $readBuff=());(my $bytesToRead
=($maxLengt-length ($GLOBAL::Common::NXMsg::__inBuffer)));if (($bytesToRead<=
(0x029a+ 1243-0x0775))){($GLOBAL::Common::NXMsg::__inBuffer=(""));(
$ignoreUntileEOL=(0x1738+ 1047-0x1b4e));Logger::error (
"\x4e\x58\x4d\x73\x67\x3a\x20\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6c\x69\x6e\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6d\x6f\x72\x65\x20\x74\x68\x61\x6e\x20\x34\x30\x39\x36\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x73"
);main::nxwrite (main::nxgetSTDOUT (),(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ERROR_SERVING_REQUEST).
"\x20\x45\x52\x52\x4f\x52\x3a\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6c\x69\x6e\x65\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x6d\x6f\x72\x65\x20\x74\x68\x61\x6e\x20\x34\x30\x39\x36\x20\x63\x68\x61\x72\x61\x63\x74\x65\x72\x73\x3a\x20\x69\x67\x6e\x6f\x72\x69\x6e\x67\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x63\x6f\x6d\x6d\x61\x6e\x64"
));}(my $readBytes=main::nxread (main::nxgetSTDIN (),$readBuff,
(0x03a2+ 756-0x0695)));if ((not (defined ($readBytes)))){(my $errorstring=
libnxh::NXGetErrorString ());main::nxwrite (main::nxgetSTDOUT (),"\x0a");
NXShell::setExitRequest ((
"\x46\x61\x69\x6c\x65\x64\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x73\x74\x64\x69\x6e\x3a\x20"
.$errorstring));return (());}if (($readBytes==(0x1661+ 3013-0x2226))){
main::nxwrite (main::nxgetSTDOUT (),"\x0a");NXShell::setExitRequest (
$ExitRequests::closedSTDIN);return (());}if (($readBuff eq "\x0a")){((
$ignoreUntileEOL eq (0x0c4c+ 633-0x0ec4))and ($ignoreUntileEOL=
(0x0f0b+ 5385-0x2414)));($data=$GLOBAL::Common::NXMsg::__inBuffer);($endOfLine=
(0x08d0+ 131-0x0952));($GLOBAL::Common::NXMsg::__inBuffer=(""));}else{if ((
$ignoreUntileEOL eq (0x1f34+ 236-0x2020))){($GLOBAL::Common::NXMsg::__inBuffer.=
$readBuff);}}}return ($data);}sub getBrandedMessage{(my $name=shift (@_));(my (
@message_parameters)=@_);if (((not (defined ($name)))or (not (($name=~ /^[\w\d\._-]{1,128}$/ )
)))){return ((0x16af+ 3625-0x24d8));}(my $message=
Common::NXEnglishMessages::getMessage ($name));if (($message and scalar (
@message_parameters))){($message=sprintf ($message,@message_parameters));}(
$message=~ s/\n/ /gm );return ($message);}sub checkIfAnswerIsNo{(my $answer=
shift (@_));my ($currectShortAnswerForRequest);my ($currectLongAnswerForRequest)
;if (Common::NXTranslator::translate (
"\x61\x4c\x6f\x6e\x67\x41\x6e\x73\x77\x65\x72\x4e\x6f",(
\$currectLongAnswerForRequest))){Common::NXTranslator::translate (
"\x61\x53\x68\x6f\x72\x74\x41\x6e\x73\x77\x65\x72\x4e\x6f",(
\$currectShortAnswerForRequest));}else{($currectShortAnswerForRequest="\x6e");(
$currectLongAnswerForRequest="\x6e\x6f");}if ((($answer eq 
$currectShortAnswerForRequest)or ($answer eq $currectLongAnswerForRequest))){
return ((0x179a+ 279-0x18b0));}return ((0x1097+ 4746-0x2321));}sub 
checkIfAnswerIsYes{(my $answer=shift (@_));my ($currectShortAnswerForRequest);my (
$currectLongAnswerForRequest);if (Common::NXTranslator::translate (
"\x61\x4c\x6f\x6e\x67\x41\x6e\x73\x77\x65\x72\x59\x65\x73",(
\$currectLongAnswerForRequest))){Common::NXTranslator::translate (
"\x61\x53\x68\x6f\x72\x74\x41\x6e\x73\x77\x65\x72\x59\x65\x73",(
\$currectShortAnswerForRequest));}else{($currectShortAnswerForRequest="\x79");(
$currectLongAnswerForRequest="\x79\x65\x73");}if ((($answer eq 
$currectShortAnswerForRequest)or ($answer eq $currectLongAnswerForRequest))){
return ((0x0dbd+ 4340-0x1eb0));}return ((0x00dd+ 8839-0x2364));}sub 
register_response{__register ($_[(0x11d7+ 1599-0x1816)],$_[(0x09d7+ 6436-0x22fa)
],getResponseType (),(""));}sub register_error{__register ($_[
(0x17ac+ 115-0x181f)],$_[(0x2470+ 536-0x2687)],getErrorType (),$_[
(0x0e07+ 460-0x0fd1)]);}sub register_request{__register ($_[
(0x1122+ 5468-0x267e)],$_[(0x0e65+ 1525-0x1459)],getRequestType (),$_[
(0x04a6+ 8694-0x269a)]);}sub __register{(my $index=$_[(0x0369+ 4349-0x1466)]);(my $number
=$_[(0x1642+ 1796-0x1d45)]);(my $type=$_[(0x0008+ 3697-0x0e77)]);(my $regExp=$_[
(0x1055+ 5650-0x2664)]);if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ )
)))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x69\x6e\x64\x65\x78\x20\x73\x74\x72\x69\x6e\x67\x20"
.$index),(0x0da4+ 393-0x0f2b));__error ();}if (((not (defined ($number)))or (not
 (($number=~ /^[\d]{1,4}$/ ))))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x6e\x75\x6d\x62\x65\x72\x20"
.$number),(0x01e2+ 5441-0x1721));__error ();}if ((((!defined ($regExp))||(
$regExp eq ("")))and isRequestType ($type))){Logger::error ((
"\x4e\x58\x4d\x73\x67\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x72\x65\x67\x45\x78\x70\x20"
.$regExp),(0x0252+ 8656-0x2420));__error ();}if (isMessageRegistered ($index)){
Logger::error ((("\x4e\x58\x4d\x73\x67\x3a\x20\x4d\x65\x73\x73\x61\x67\x65\x20".
$index).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x2e"
),(0x0aad+ 1355-0x0ff6));__error ();}saveMessageData (@_);}sub getNumber{(my $index
=shift (@_));if (((not (defined ($index)))or (not (($index=~ /^[\w\d\._-]{1,128}$/ )
)))){return ((0x1d9d+ 1872-0x24ed));}(my $messageNumber=$__number{$index});
return ($messageNumber);}sub getRegExp{(my $index=shift (@_));return ($__regExp{
$index});}sub isMessageRegistered{(my $index=shift (@_));(my $messageNumber=
getNumber ($index));if (defined ($messageNumber)){return ((0x0536+ 6988-0x2081))
;}return ((0x19bb+ 516-0x1bbf));}sub __shouldPackMessage{(my $index=shift (@_));
if (isErrorMessage ($index)){if (NXBegin::isModuletypeNxnode ()){return (
NXShell::shellModeStarted ());}elsif (NXBegin::isModuletypeNxserver ()){return (
Server::isClientSupportsPackedMessages ());}}return ((0x1263+ 4861-0x2560));}sub
 packResponse{(my $indexString=shift (@_));(my $message=shift (@_));(my (
@parameters)=@_);(my $messageId=Common::NXEnglishMessages::getMessageId (
$indexString));(my $pack=$messageId);($pack.=("\x2c".main::urlencode ($message))
);foreach my $parameter (@parameters){($pack.=("\x2c".main::urlencode (
$parameter)));}(my $message=(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_PACKED_RESPONSE)
."\x20").$pack)."\x20"));return ($message);}sub unpackResponse{(my $message=
shift (@_));(my ($indexString,$rawMessage,@parameters)=__unpackResponse (
$message));return ($indexString,$rawMessage,@parameters);}sub 
constructAndPackResponse{(my $indexString=shift (@_));(my (@parameters)=@_);(my $messageNumber
=getNumber ($indexString));(my $message=Common::NXEnglishMessages::getMessage (
$indexString));($message=constructMessage ($messageNumber,$message,@parameters))
;(my $packedMessage=packResponse ($indexString,$message,@parameters));return (
$packedMessage);}sub __unpackResponse{(my $message=shift (@_));(my $pack=(""));
if (($message=~ /NX> $GLOBAL::MSG_PACKED_RESPONSE (.*) / )){($pack=$1);}else{
return ((""),(0x03fd+ 1716-0x0ab1),(""),());}(my (@list)=split ( /,/ ,$pack,
(0x0d33+ 5213-0x2190)));(my $messageId=shift (@list));(my $rawMessage=shift (
@list));($rawMessage=main::urldecode ($rawMessage));(my $indexString=
Common::NXEnglishMessages::getIndexString ($messageId));(my (@parameters)=());
foreach my $parameter (@list){push (@parameters,main::urldecode ($parameter));}
return ($indexString,$rawMessage,@parameters);}sub isErrorMessage{(my $indexString
=shift (@_));(my $messageNumber=getNumber ($indexString));return (
isErrorMessageNumber ($messageNumber));}sub isErrorMessageNumber{(my $messageNumber
=shift (@_));if ((($messageNumber>=(0x083d+ 8245-0x267e))and ($messageNumber<=
(0x04a0+ 3877-0x1114)))){return ((0x137c+ 1318-0x18a1));}return (
(0x0661+ 6116-0x1e45));}sub saveMessageData{(my $index=shift (@_));(my $number=
shift (@_));(my $type=shift (@_));(my $regExp=shift (@_));($__number{$index}=
$number);($__type{$index}=$type);($__regExp{$index}=$regExp);}sub 
isPackedMessage{(my $message=shift (@_));if (($message=~ /NX> (\d+)/ )){(my $number
=$1);return (isPackedMessageNumber ($number));}return ((0x048c+ 8009-0x23d5));}
sub isPackedMessageNumber{(my $number=shift (@_));if (($number==
$GLOBAL::MSG_PACKED_RESPONSE)){return ((0x0e87+ 5070-0x2254));}return (
(0x014f+ 7976-0x2077));}sub getErrorType{return ($typeError);}sub getRequestType
{return ($typeRequest);}sub getResponseType{return ($typeResponse);}sub 
isErrorTypeByIndex{(my $index=shift (@_));if (($__type{$index}==$typeError)){
return ((0x171d+ 689-0x19cd));}return ((0x1dc6+ 2058-0x25d0));}sub isRequestType
{(my $type=shift (@_));if (($type==$typeRequest)){return ((0x0ce5+ 1616-0x1334))
;}return ((0x150f+ 317-0x164c));}sub isLastParameterCustomErrorMessage{(my $index
=shift (@_));(my (@parameters)=@_);if ((Common::NXEnglishMessages::getParamCount
 ($index)<scalar (@parameters))){return ((0x04df+ 4002-0x1480));}return (
(0x04d9+ 2261-0x0dae));}sub getCustomizedMessageIndexNumber{(my $customizedMessageIndex
=Common::NXEnglishMessages::getCustomizedMessageIndex ());(my $messageNumber=
getNumber ($customizedMessageIndex));(my $customizedMessage=
Common::NXEnglishMessages::getMessage ($customizedMessageIndex));return (
$customizedMessageIndex,$messageNumber,$customizedMessage);}sub 
getCustomizedMessage{(my $index=shift (@_));(my $messageNumber=shift (@_));(my $ref_parameters
=shift (@_));if (($GLOBAL::CustomErrorMessages ne (""))){return (
getCustomizedMessageByScript ($index,$messageNumber,$ref_parameters));}elsif (
isLastParameterCustomErrorMessage ($index,@$ref_parameters)){return (
getCustomizedMessageByParameter ($index,$messageNumber,$ref_parameters));}else{(my $message
=Common::NXEnglishMessages::getMessage ($index));return ($messageNumber,$index,
$message);}}sub getCustomizedMessageByParameter{(my $initialIndex=shift (@_));(my $initialMessageNumber
=shift (@_));(my $ref_parameters=shift (@_));(my $initialMessage=
Common::NXEnglishMessages::getMessage ($initialIndex));
Common::NXTranslator::translate ($initialIndex,(\$initialMessage));(
$initialMessage=sprintf ($initialMessage,@$ref_parameters));(my $lastIndex=
scalar ((@$ref_parameters-(0x06ff+ 7187-0x2311))));($customMessage=
$$ref_parameters[$lastIndex]);(my ($customizedMessageIndex,$messageNumber,
$customizedMessage)=getCustomizedMessageIndexNumber ());($customizedMessage=
sprintf ($customizedMessage,$initialMessage,$customMessage));return (
$messageNumber,$customizedMessageIndex,$customizedMessage);}sub 
getCustomizedMessageByScript{(my $initialIndex=shift (@_));(my $initialMessageNumber
=shift (@_));(my $ref_parameters=shift (@_));(my $initialMessage=
Common::NXEnglishMessages::getMessage ($initialIndex));
Common::NXTranslator::translate ($initialIndex,(\$initialMessage));(
$initialMessage=sprintf ($initialMessage,@$ref_parameters));(my $messageIdForScript
=Common::NXEnglishMessages::getCustomizableMessageId ($initialIndex));
main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");(my $customMessage=
NXScripts::getCustomErrorMessage ($messageIdForScript));if (($customMessage ne 
(""))){(my ($customizedMessageIndex,$messageNumber,$customizedMessage)=
getCustomizedMessageIndexNumber ());if ((Server::isClientNxclient ()or 
Server::isClientNxwebclient ())){($customizedMessage=sprintf ($customizedMessage
,$initialMessage,$customMessage));return ($messageNumber,$customizedMessageIndex
,$customizedMessage);}else{push (@$ref_parameters,$customMessage);(
$customizedMessage=(($initialMessage."\x20").$customMessage));return (
$initialMessageNumber,$initialIndex,$customizedMessage);}}return (
$initialMessageNumber,$initialIndex,$initialMessage);}return (
(0x0433+ 4210-0x14a4));
