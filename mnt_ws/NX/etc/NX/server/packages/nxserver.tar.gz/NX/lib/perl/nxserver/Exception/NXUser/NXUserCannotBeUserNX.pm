############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::NXUser::NXUserCannotBeUserNX::BEGIN{package 
Exception::NXUser::NXUserCannotBeUserNX;no warnings;require base;do{
"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x42\x61\x73\x65"
)};}sub Exception::NXUser::NXUserCannotBeUserNX::BEGIN{package 
Exception::NXUser::NXUserCannotBeUserNX;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::NXUser::NXUserCannotBeUserNX::notify{package 
Exception::NXUser::NXUserCannotBeUserNX;no warnings;(my $self=shift (@_));(my $text
=$self->text);(my $statusId=main::get_unique_id ());($statusId=~ s/(........).*/$1/ )
;(my $ErrStr=((
"\x45\x52\x52\x4f\x52\x3a\x20\x4c\x6f\x67\x69\x6e\x20\x61\x73\x20\x27".$text).
"\x27\x20\x75\x73\x65\x72\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72"
));NXMsg::register_error ((""),
"\x65\x47\x55\x49\x4c\x6f\x67\x69\x6e\x44\x69\x73\x61\x62\x6c\x65\x64\x46\x6f\x72\x55\x73\x65\x72"
,(0x0ae6+ 6276-0x2150));NXMsg::error (
"\x65\x47\x55\x49\x4c\x6f\x67\x69\x6e\x44\x69\x73\x61\x62\x6c\x65\x64\x46\x6f\x72\x55\x73\x65\x72"
,"\x67\x65\x6e\x65\x72\x61\x6c",$text);(my $trace=$self->stacktrace);($trace=~ s/\n[^\w]+/\n/ )
;($trace=~ s/NXUser::new\('(.*)',[\ ]?'.*'/NXUser::new('$1', '******'/ );($trace
=~ s/\t//gm );(my (@aTrace)=split ( /\n/ ,$trace,(0x0387+ 628-0x05fb)));shift (
@aTrace);Logger::multilineLog (((
"\x28\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x20\x69\x64\x20".$statusId)."\x29"),(
$ErrStr,@aTrace));}package Exception::NXUser::NXUserCannotBeUserNX;no warnings;
"\x3f\x3f\x3f";
