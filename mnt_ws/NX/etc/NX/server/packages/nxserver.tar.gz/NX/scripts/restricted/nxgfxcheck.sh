#!/bin/bash
######################################################################
#                                                                    #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.     #
#                                                                    #
#  All rights reserved.                                              #
#                                                                    #
######################################################################

RunDir=${0%nxgfxcheck.sh}
RestrictedDir=$(cd "${RunDir}" && pwd)

PARAMS_COUNT=2

. "${RestrictedDir}"/nxfunct.sh

if test -x "/bin/lspci"; then
  COMMAND_LSPCI="/bin/lspci"
elif test -x "/usr/bin/lspci"; then
  COMMAND_LSPCI="/usr/bin/lspci"
elif test -x "/usr/sbin/lspci"; then
  COMMAND_LSPCI="/usr/sbin/lspci"
else
  COMMAND_LSPCI="lspci"
fi

${COMMAND_LSPCI} -nnk | ${COMMAND_GREP} -i vga -A3 | ${COMMAND_GREP} 'in use'

exit 0

