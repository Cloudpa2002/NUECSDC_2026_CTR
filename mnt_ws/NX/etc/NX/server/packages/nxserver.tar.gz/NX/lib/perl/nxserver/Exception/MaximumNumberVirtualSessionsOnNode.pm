############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::MaximumNumberVirtualSessionsOnNode::BEGIN{package 
Exception::MaximumNumberVirtualSessionsOnNode;no warnings;require base;do{
"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::MaximumNumberVirtualSessionsOnNode::BEGIN{package 
Exception::MaximumNumberVirtualSessionsOnNode;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::MaximumNumberVirtualSessionsOnNode::notify{package 
Exception::MaximumNumberVirtualSessionsOnNode;no warnings;(my $self=shift (@_));
(my $ref_parameters=$$self{
"\x72\x65\x66\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});NXMsg::error (
"\x65\x47\x55\x49\x4d\x61\x78\x69\x6d\x75\x6d\x4e\x75\x6d\x62\x65\x72\x56\x69\x72\x74\x75\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e\x73\x4f\x6e\x4e\x6f\x64\x65"
,"\x67\x65\x6e\x65\x72\x61\x6c",@$ref_parameters);}package 
Exception::MaximumNumberVirtualSessionsOnNode;no warnings;"\x3f\x3f\x3f";
