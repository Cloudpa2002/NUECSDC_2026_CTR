############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXCore;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65"->import};}sub BEGIN{
no warnings;require Common::Logger;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4c\x6f\x67\x67\x65\x72"->import};}sub BEGIN{
no warnings;require Common::NXWorkingDir;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x57\x6f\x72\x6b\x69\x6e\x67\x44\x69\x72"
->import};}sub BEGIN{no warnings;require Common::NXParser;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->import};}sub
 BEGIN{no warnings;require Common::NXRunCommand;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64"
->import};}sub BEGIN{no warnings;require Common::NXProcess;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x72\x6f\x63\x65\x73\x73"->import};
}sub BEGIN{no warnings;require Common::NXError;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x45\x72\x72\x6f\x72"->import};}no 
warnings;require Common::NXFile;package NXBegin;($parser=());($stderrFilePath=
(""));($moduletype=(""));($oldSTDIN=undef);($oldSTDOUT=undef);($oldSTDERR=undef)
;($processFinalized=(0x09bb+ 3374-0x16e8));($SocketsToClose={});(
$workingSessionFD=(-(0x088b+ 762-0x0b84)));($workingAgentFD=(-
(0x070a+ 7263-0x2368)));($ExitRequests::receivedSIGINT=
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x49\x4e\x54\x27\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x69\x74\x65\x72\x72\x75\x70\x74"
);($ExitRequests::receivedSIGTERM=
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x54\x45\x52\x4d\x27\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e"
);($GLOBAL::DefaultSTDINDescriptor=(0x1a61+ 217-0x1b3a));(
$GLOBAL::DefaultSTDOUTDescriptor=(0x1d44+ 573-0x1f80));($handlerSIGUSR1=(""));(
$MonitoredHandler=undef);($MonitoredHandlerCallback=undef);(
$processArgumentsString=(""));($emergencyCleanUp=(0x0704+ 3510-0x14ba));sub 
initializeProcess{Common::NXError::registerMessages ();($Carp::MaxEvalLen=
(0x0e2f+ 367-0x0f9b));Common::NXCore::closeSocketAtFinish ((0x007a+ 9349-0x24ff)
);Common::NXCore::closeSocketAtFinish ((0x0bab+ 4199-0x1c11));
Common::NXCore::closeSocketAtFinish ((0x03a6+ 8566-0x251a));($processFinalized=
(0x0857+ 3470-0x15e5));($oldSTDIN=undef);($oldSTDOUT=undef);($oldSTDERR=undef);
Common::NXCore::disableExitFromSelectOnFirstSignal ();($GLOBAL::SessionLogLevel=
(0x1680+ 1934-0x1e08));(my $module=shift (@_));($moduletype=$module);
Common::NXCore::loadAllModulesLibraries ();Common::NXCore::initNXPLVariables ();
Logger::initLevel ();if ((isModuletypeNxserver ()or isModuletypeNxnode ())){
Common::NXEnglishMessages::initEnglishMessages ();}setProcessName (@ARGV);(
$parser="\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new)
;registerSignals ();}sub initializeProcessAfterFork{Logger::error (
"\x46\x49\x58\x4d\x45\x20\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x61\x66\x74\x65\x72\x20\x66\x6f\x72\x6b\x2e"
);}sub registerSignals{$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}
{"\x48\x55\x50"});$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{
"\x49\x4e\x54"});$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{
"\x55\x53\x52\x31"});$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{
"\x55\x53\x52\x32"});$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{
"\x54\x45\x52\x4d"});$parser->registerSignal ($$parser{"\x73\x69\x67\x6e\x6f"}{
"\x43\x48\x4c\x44"});loadSignalHandlers ();}sub redirectSTDERRtoAgentSession{(my $path
=shift (@_));if (defined ($FD_nodeSessionFile)){main::nxclose (
$FD_nodeSessionFile);}($FD_nodeSessionFile=Common::NXCore::nxFileDuplicate (
(0x1906+ 938-0x1cae)));main::closeSocketAtFinish ($FD_nodeSessionFile);(
$FD_agentSessionFile=main::nxopen ($path,($NXBits::O_CREAT+$NXBits::O_WRONLY),
$NXBits::UserReadWrite));if (defined ($FD_agentSessionFile)){(my $fd_copy=
Common::NXCore::nxFileClone ($FD_agentSessionFile,(0x001a+ 4496-0x11a8)));
libnxh::NXDescriptorInheritable ($FD_agentSessionFile,(0x0cff+ 2563-0x1702));
main::closeSocketAtFinish ($FD_agentSessionFile);}}sub 
redirectSTDERRtoNodeSession{if (defined ($FD_agentSessionFile)){(my $fd_copy=
Common::NXCore::nxFileClone ($FD_nodeSessionFile,(0x1ba2+ 1645-0x220d)));
main::nxclose ($FD_agentSessionFile);($FD_agentSessionFile=undef);}else{(my $file
=(((((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x64\x62").
$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x72\x76\x65\x72").$GLOBAL::DIRECTORY_SLASH).
"\x66\x69\x6c\x65"));(my $dir=(((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x64\x62").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x72\x76\x65\x72"));if ((not (-d 
($dir)))){if (($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){(my $returnValue
=libnxh::NXMakePath ($dir,("")));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnValue)."\x27\x2e"));if (($returnValue!=(0x128b+  15-0x129a))){(my $errorNumber
=libnxh::NXGetError ());(my $errorMessage=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$dir)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorMessage)."\x27\x2e"));}}}(my $correctNXErrorLogPermissions
=(0x0fb3+ 4606-0x21b1));if (($GLOBAL::CommonLogDirectory eq (""))){(my $logDir=
Common::NXPaths::getDirectoryForLogsPath ());if ((not (-d ($logDir)))){if (
Common::NXCore::isEffectiveUserNXRootOrSystem ()){if (($ENV{
"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){(my $returnValue=
libnxh::NXMakePath ($logDir,("")));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnValue)."\x27\x2e"));if (($returnValue!=(0x12cf+ 1560-0x18e7))){(my $errorNumber
=libnxh::NXGetError ());(my $errorMessage=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$logDir)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$errorNumber)."\x2c\x20\x27").$errorMessage)."\x27\x2e"));main::nxwrite (
main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$logDir)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorMessage).
"\x27\x2e\x0a"));main::nxexit ();}}else{Logger::error (((
"\x4c\x6f\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20".$logDir).
"\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));
main::nxwrite (main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$logDir)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorMessage).
"\x27\x2e\x0a"));main::nxexit ();}}else{(my $user=
Common::NXCore::getEffectiveUsername ());my ($errorMessage);(my $returnValue=
Common::NXPaths::createAccessibleForUserDirectory ((\$errorMessage),$logDir,
$user));if (($returnValue!=(0x06d4+ 7105-0x2294))){main::nxwrite (
main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$logDir)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorMessage).
"\x27\x2e\x0a"));main::nxexit ();}($GLOBAL::THIS_IS_THE_FIRST_LOGIN=
(0x0540+ 2034-0x0d31));}}(my $errorPath=Common::NXPaths::getNXServerLogPath ());
if ((not (Common::NXFile::fileExists ($errorPath)))){(
$correctNXErrorLogPermissions=(0x165b+  94-0x16b8));}($FD_nodeSessionFile=
main::nxopen ($errorPath,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND
),$NXBits::UserReadWrite));($stderrFilePath=$errorPath);}else{(my $errorPath=
Common::NXPaths::getNXServerLogPath ());if ((not (Common::NXFile::fileExists (
$errorPath)))){($correctNXErrorLogPermissions=(0x0c11+ 1838-0x133e));}(
$FD_nodeSessionFile=main::nxopen ($errorPath,(($NXBits::O_CREAT+
$NXBits::O_WRONLY)+$NXBits::O_APPEND),(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersWrite)));($stderrFilePath=$errorPath);}
if (defined ($FD_nodeSessionFile)){libnxh::NXDescriptorInheritable (
$FD_nodeSessionFile,(0x003d+ 5417-0x1566));(my $fd_copy=
Common::NXCore::nxFileClone ($FD_nodeSessionFile,(0x03f4+ 8097-0x2393)));
main::closeSocketAtFinish ($FD_nodeSessionFile);if (
$correctNXErrorLogPermissions){Common::NXFile::setServerLogFilePermissions ();}}
else{(my $error=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());if (($error eq "\x45\x4e\x4f\x45\x4e\x54")){(my $path
=Common::NXFile::dirname ($stderrFilePath));(my $filename=
Common::NXFile::basename ($stderrFilePath));main::nxwrite (main::nxgetSTDOUT (),
((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20"
.$filename)."\x20\x69\x6e\x20").$path).
"\x20\x2d\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x0a"
));}else{main::nxwrite (main::nxgetSTDOUT (),((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20"
.$stderrFilePath)."\x20\x2d\x20\x27").$errorstring)."\x27\x2e\x0a"));}
main::nxexit ();}}}sub loadSignalHandlers{if (($moduletype eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){($$parser{"\x73\x69\x67\x62\x61\x63\x6b"}{
"\x49\x4e\x54"}=sub{NXShell::setExitRequest ($ExitRequests::receivedSIGINT);});(
$$parser{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x54\x45\x52\x4d"}=sub{
NXShell::setExitRequest ($ExitRequests::receivedSIGTERM);});}($$parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x48\x55\x50"}=sub{Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x48\x55\x50\x27\x20\x73\x69\x67\x6e\x61\x6c\x3a\x20\x74\x68\x69\x73\x20\x73\x69\x67\x6e\x61\x6c\x20\x69\x73\x20\x69\x67\x6e\x6f\x72\x65\x64\x20\x62\x79\x20\x4e\x58\x20\x53\x65\x72\x76\x65\x72"
);});($$parser{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x55\x53\x52\x31"}=sub{
Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x55\x53\x52\x31\x27\x20\x73\x69\x67\x6e\x61\x6c\x2e"
);Common::NXProcess::handleSIGUSR1 ();});($$parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x55\x53\x52\x32"}=sub{(
$GLOBAL::REQUEST_TERMINATE=(0x03fc+ 3203-0x107e));Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x55\x53\x52\x32\x27\x20\x73\x69\x67\x6e\x61\x6c\x3a\x20\x74\x68\x69\x73\x20\x6d\x65\x61\x6e\x73\x20\x2d\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x73\x65\x73\x73\x69\x6f\x6e"
);});($$parser{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x43\x48\x4c\x44"}=sub{
Logger::debug3 (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x43\x48\x4c\x44\x27\x20\x73\x69\x67\x6e\x61\x6c\x3a\x67\x6f\x69\x6e\x67\x20\x74\x6f\x20\x68\x61\x6e\x64\x6c\x65\x20\x69\x74"
);Common::NXProcess::handleSIGCHLD ();});}sub unregisterSignals{if ((not (
defined ($parser)))){return;}$parser->unregisterSignal ($$parser{
"\x73\x69\x67\x6e\x6f"}{"\x48\x55\x50"});$parser->unregisterSignal ($$parser{
"\x73\x69\x67\x6e\x6f"}{"\x49\x4e\x54"});$parser->unregisterSignal ($$parser{
"\x73\x69\x67\x6e\x6f"}{"\x55\x53\x52\x31"});$parser->unregisterSignal ($$parser
{"\x73\x69\x67\x6e\x6f"}{"\x55\x53\x52\x32"});$parser->unregisterSignal (
$$parser{"\x73\x69\x67\x6e\x6f"}{"\x54\x45\x52\x4d"});$parser->unregisterSignal 
($$parser{"\x73\x69\x67\x6e\x6f"}{"\x43\x48\x4c\x44"});}sub finalizeProcess{if (
(not ($processFinalized))){(my $firstCaller=(caller ((0x2253+ 265-0x235a)))[
(0x020d+ 4659-0x143d)]);($firstCaller=~ s/:.*//s );if (($firstCaller ne 
"\x4c\x6f\x67\x67\x65\x72")){Logger::debug (
"\x46\x69\x6e\x61\x6c\x69\x7a\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x2e");}(
$processFinalized=(0x0c6f+ 607-0x0ecd));if (($moduletype eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){if ((exists ($INC{
"\x53\x65\x72\x76\x65\x72\x2e\x70\x6d"})and (not (Server::isDaemonProcess ()))))
{if ((exists ($INC{"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x32\x2e\x70\x6d"})and (
$SessionStartStateMachine::statesInitialized==(0x0aa9+ 4126-0x1ac6)))){(my $status
=NXSession2::getStatusBySessionId (Server::getMySessionID ()));if ((((not (
NXSession2::isStatusRunning ($status)))and (not (NXSession2::isStatusForwarded (
$status))))and ($emergencyCleanUp==(0x1a7d+ 1797-0x2182)))){($emergencyCleanUp=
(0x1e4c+ 361-0x1fb4));NXSession2::cleanUpLeftoverSession (Server::getMySessionID
 (),((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x63\x6c\x65\x61\x6e\x65\x64\x20\x70\x72\x6f\x70\x65\x72\x6c\x79\x20\x62\x65\x66\x6f\x72\x65\x20\x63\x6c\x6f\x73\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$ $) .  "\x2e"));}}else{(my $sessionId=Server::getMySessionID ());if (((exists 
($INC{"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x32\x2e\x70\x6d"})and ($sessionId ne
 ("")))and ($emergencyCleanUp==(0x0039+ 9723-0x2634)))){($emergencyCleanUp=
(0x07ba+ 4773-0x1a5e));NXSession2::cleanNegotiatingSessionIfNeeded ($sessionId);
}}}if (exists ($INC{"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x2e\x70\x6d"})){if (
NXLocate::wasStarted ()){NXLocate::close ();}}if (exists ($INC{
"\x4e\x58\x52\x65\x64\x69\x73\x2e\x70\x6d"})){NXRedis::closeDb (
(0x0215+ 919-0x05ab));}if (((libnxh::NXShellReverseRunning ()==
(0x17ff+ 1194-0x1ca8))and (libnxhs::NXForwarderRunning ()==(0x00fb+ 7017-0x1c64)
))){Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x68\x65\x6c\x6c\x52\x65\x76\x65\x72\x73\x65\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x20\x73\x74\x61\x72\x74\x2e"
);(my $result=libnxh::NXShellReverseDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x68\x65\x6c\x6c\x52\x65\x76\x65\x72\x73\x65\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$result)."\x27\x2e"));}Server::shutdownClientConnection ();}if (($moduletype eq
 "\x6e\x78\x6e\x6f\x64\x65")){if (Common::NXCore::isNXLibraryLoaded (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67")){if (($INC{
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72\x2e\x70\x6d"}
eq (""))){Logger::debug (
"\x4d\x6f\x64\x75\x6c\x20\x27\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72\x2e\x70\x6d\x27\x20\x77\x61\x73\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x65\x64\x2e"
);}else{Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x52\x75\x6e\x6e\x69\x6e\x67\x28\x29\x2e"
);if (libnxdiag::NXAgentRunning ()){Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x52\x75\x6e\x6e\x69\x6e\x67\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27\x31\x27\x2e"
);NXSessionMonitor::send_terminate_to_agent ();
NXSessionMonitor::close_agent_socket ();Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x44\x65\x73\x74\x72\x6f\x79\x28\x29\x2e"
);libnxdiag::NXAgentDestroy ();Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x44\x65\x73\x74\x72\x6f\x79\x20\x73\x74\x6f\x70\x2e"
);}Logger::debug (
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x3a\x3a\x4e\x58\x41\x67\x65\x6e\x74\x52\x75\x6e\x6e\x69\x6e\x67\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27\x30\x27\x2e"
);}}else{Logger::debug (
"\x27\x6c\x69\x62\x6e\x78\x64\x69\x61\x67\x27\x20\x6c\x69\x62\x72\x61\x72\x79\x20\x77\x61\x73\x20\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x65\x64\x2e"
);}}if ($INC{("\x43\x6f\x6d\x6d\x6f\x6e".$GLOBAL::DIRECTORY_SLASH).
"\x4e\x58\x43\x6f\x6e\x73\x6f\x6c\x65\x2e\x70\x6d"}){NXConsole::closeConsole ();
}if (Common::NXCore::isNXLibraryLoadedForModule ()){unregisterSignals ();}if (
defined ($FD_nodeSessionFile)){main::nxclose ($FD_nodeSessionFile);undef (
$FD_nodeSessionFile);}Common::NXProcess::leaveOrphans ();foreach my $sock (keys 
(%$SocketsToClose)){if (((((($sock==(0x0564+ 7242-0x21ae))or ($sock==
(0x0042+ 6747-0x1a9c)))or ($sock==(0x0e78+ 6017-0x25f7)))or ($sock==$$parser{
"\x53\x69\x67\x6e\x61\x6c"}))or ($sock==$Logger::logfile_fh))){next;}
main::nxclose ($sock);}Logger::closeLogFile ();}}sub setProcessName{(my (
@arguments)=@_);setProcessArgumentsString ();my ($processName);foreach my $argument
 (@arguments){if (($moduletype eq "\x6e\x78\x73\x65\x72\x76\x65\x72")){if ((
$argument eq "\x2d\x2d\x73\x74\x61\x72\x74\x75\x70")){if (($arguments[
(0x1bf1+ 1768-0x22d9)]eq "\x72\x6f\x6f\x74")){($processName=
"\x73\x74\x61\x72\x74\x75\x70\x20\x6d\x6f\x6e\x69\x74\x6f\x72");}elsif ((
$arguments[(0x11b9+ 1801-0x18c1)]eq "\x2d\x2d\x6d\x6f\x6e\x69\x74\x6f\x72")){(
$processName="\x73\x74\x61\x72\x74\x75\x70\x20\x6d\x6f\x6e\x69\x74\x6f\x72");}
else{($processName="\x73\x74\x61\x72\x74\x75\x70");}}if (($argument eq 
"\x2d\x2d\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x6d\x6f\x6e\x69\x74\x6f\x72"))
{($processName=
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72");}if 
(($argument eq 
"\x2d\x2d\x76\x69\x72\x74\x75\x61\x6c\x73\x65\x73\x73\x69\x6f\x6e")){(
$processName="\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x69\x6f\x6e");}if ((
$argument eq "\x2d\x2d\x64\x61\x65\x6d\x6f\x6e")){($processName=
"\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e");}}if (($moduletype eq 
"\x6e\x78\x6e\x6f\x64\x65")){if (($argument eq "\x2d\x2d\x48")){($processName=
"\x61\x74\x74\x61\x63\x68\x20\x6e\x6f\x64\x65");}}}if ((not (defined (
$processName)))){(my $cmd_arg=lc ($GLOBAL::SOFTWARE_NAME));($processName=(((
"\x20".$cmd_arg)."\x20").getProcessArgumentsString ()));}($NXBegin::processName=
$processName);}sub getProcessName{(my $processName=$processName);return (
$processName);}sub getProcessArgumentsString{return ($processArgumentsString);}
sub setProcessArgumentsString{(my $string=(""));foreach my $arg (@ARGV){if ((
$string eq (""))){($string=$arg);}else{($string.=("\x20".$arg));}}(
$processArgumentsString=$string);}sub getSignalDescriptor{return ($$parser{
"\x53\x69\x67\x6e\x61\x6c"});}sub getModuletype{return ($moduletype);}sub 
isModuletypeNxserver{if ((getModuletype ()eq "\x6e\x78\x73\x65\x72\x76\x65\x72")
){return ((0x0d2f+ 3061-0x1923));}return ((0x0238+ 4734-0x14b6));}sub 
isModuletypeNxnode{if ((getModuletype ()eq "\x6e\x78\x6e\x6f\x64\x65")){return (
(0x1349+ 1284-0x184c));}return ((0x0c9d+ 4190-0x1cfb));}sub END{if ((not (
$processFinalized))){finalizeProcess ();}}"\x3f\x3f\x3f";
