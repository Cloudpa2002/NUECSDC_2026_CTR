############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::NXNodeExecNodeErrorSimple::BEGIN{package 
Exception::NXNodeExecNodeErrorSimple;no warnings;require 
Exception::NXNodeExecNodeError;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x4e\x6f\x64\x65\x45\x72\x72\x6f\x72"
->import};}sub Exception::NXNodeExecNodeErrorSimple::BEGIN{package 
Exception::NXNodeExecNodeErrorSimple;no warnings;require base;do{
"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x4e\x6f\x64\x65\x45\x72\x72\x6f\x72"
)};}sub Exception::NXNodeExecNodeErrorSimple::BEGIN{package 
Exception::NXNodeExecNodeErrorSimple;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::NXNodeExecNodeErrorSimple::notify{package 
Exception::NXNodeExecNodeErrorSimple;no warnings;(my $self=shift (@_));(my $indexString
=$$self{"\x69\x6e\x64\x65\x78\x53\x74\x72\x69\x6e\x67"});(my $ref_parameters=
$$self{"\x72\x65\x66\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});if (
Common::NXMsg::check_msg ($indexString)){if ((($indexString eq 
"\x65\x47\x55\x49\x49\x6e\x76\x61\x6c\x69\x64\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x56\x61\x6c\x75\x65"
)or ($indexString eq 
"\x65\x47\x55\x49\x49\x6e\x76\x61\x6c\x69\x64\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x56\x61\x6c\x75\x65"
))){Common::NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x6e\x6e\x65\x63\x74\x54\x6f\x54\x68\x65\x52\x65\x71\x75\x65\x73\x74\x65\x64\x4e\x6f\x64\x65"
);}else{Common::NXMsg::error ($indexString,@$ref_parameters);}}else{(my $text=
$self->text);NXMsg::send_response (
"\x65\x47\x55\x49\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x4e\x6f\x64\x65\x45\x72\x72\x6f\x72\x53\x69\x6d\x70\x6c\x65"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$text);}}package 
Exception::NXNodeExecNodeErrorSimple;no warnings;return ((0x0569+ 5332-0x1a3c));
