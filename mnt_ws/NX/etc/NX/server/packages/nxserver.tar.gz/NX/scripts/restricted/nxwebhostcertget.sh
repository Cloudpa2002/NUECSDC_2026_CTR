#!/bin/bash
######################################################################
#                                                                    #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.     #
#                                                                    #
#  All rights reserved.                                              #
#                                                                    #
######################################################################

RunDir=${0%nxwebhostcertget.sh}
RestrictedDir=$(cd "${RunDir}" && pwd)

PARAMS_COUNT=2

. "${RestrictedDir}"/nxfunct.sh

isRunByServer

WEB_HOST_CERT="${NX_ROOT}/etc/keys/host/ht_host_rsa_key"

if test ! -e "${WEB_HOST_CERT}"; then
  errorMsg "File ${WEB_HOST_CERT} doesn't exist." "1"
fi

${COMMAND_CAT} ${WEB_HOST_CERT}
