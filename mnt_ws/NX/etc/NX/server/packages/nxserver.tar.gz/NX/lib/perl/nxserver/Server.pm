############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Server::BEGIN{package Server;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}package Server;no warnings
;(my $__sessionID=(""));(my $__mainSessionID=(""));(my $__clientSupportLightweightMode
=(0x054d+ 8417-0x262d));(my $__clientSupportRootlessReconnect=
(0x1b18+  88-0x1b6f));(my $__overrideShadowProfileRule=(0x1e20+ 1517-0x240d));(my $__clientExtendedHelloHWinfo
=(0x03fc+ 462-0x05ca));(my $__clientExtendedHelloCpuRamInfo=
(0x0696+ 7347-0x2349));(my $__passErrorsToClient=(0x02e1+ 4895-0x15ff));(my $__sslContext
=(""));(my $__connectionType="\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44");(my $__connectionIN
=(-(0x1653+ 3258-0x230c)));(my $__connectionOUT=(-(0x19f6+ 3024-0x25c5)));(my $__subsystemConnectionIN
=(-(0x0789+ 4464-0x18f8)));(my $__subsystemConnectionOUT=(-(0x0326+ 8399-0x23f4)
));(my $__subsystemEncryptorIN=(-(0x138a+ 901-0x170e)));(my $__communicationNXD=
(-(0x00c7+ 5753-0x173f)));(my $__masterGoingToShutdown=(0x0399+ 1683-0x0a2c));(my $__foreignAddress
=(""));(my $__decodeUsernameFromClient=(0x0a32+ 1457-0x0fe3));(my $__encodeUsernameForClient
=(0x0892+ 5245-0x1d0f));(my $__myUuid=(""));(my $__isExistSessionFile=
(0x0525+ 243-0x0618));(my $__pureSession=(0x03da+ 5337-0x18b3));(my $__pureVirtualSession
=(0x0381+ 7057-0x1f12));(my $__clientName="\x6e\x6f\x74\x73\x65\x74");(my $__mainServerClientName
="\x6e\x6f\x74\x73\x65\x74");(my $__clientMajorVersion=
"\x6e\x6f\x74\x73\x65\x74");(my $__clientMinorVersion="\x6e\x6f\x74\x73\x65\x74"
);(my $__clientPatchVersion="\x6e\x6f\x74\x73\x65\x74");(my $__clientBrowser=
(""));(my $__clientPlatform="\x6e\x6f\x74\x73\x65\x74");(my $__clientSupportsSSLEncryption
=(0x0700+ 1055-0x0b1e));(my $__clientSupportsRedirecting=(0x1689+ 2711-0x2120));
(my $__clientSupportsGuests=(0x012b+ 5645-0x1738));(my $__clientSupportsNxpasswordService
=(0x03a5+ 2332-0x0cc1));(my $__clientSupportsPropertyRequest=
(0x0784+ 1586-0x0db6));(my $__clientSupportsOsInfo=(0x0792+ 7898-0x266c));(my $__clientSupportsListHistory
=(0x067a+ 5166-0x1aa8));(my $__clientSupportsFakeAuthentication=
(0x0266+ 5462-0x17bc));(my $__clientSupportsExtendedServices=
(0x0b6b+ 3950-0x1ad9));(my $__clientVersion3OrOlder=(0x15d0+ 547-0x17f3));(my $__clientVersion7OrOlder
=(0x1039+ 4895-0x2358));(my $__clientSupportsPlatformParameters=
(0x14a5+ 3254-0x215b));(my $__clientSupportsKbtypeParameter=
(0x0f52+ 2342-0x1878));(my $__clientSupportsDynamicColumnWidth=
(0x1c11+ 1013-0x2005));(my $__clientSupportsNodeAndLabelParameter=
(0x02a3+ 7376-0x1f73));(my $__clientSupportsNodeAndStatusParameter=
(0x04c5+ 8696-0x26bd));(my $__clientSupportsDialogInConnectionPolicy=
(0x199b+ 3203-0x261e));(my $__clientSupportsNxFrameBufferFeature=
(0x0ea7+ 2555-0x18a2));(my $__clientSupportsDesktopViewMode=
(0x0ea5+ 5953-0x25e6));(my $__clientSupportsSha256=(0x14b9+   1-0x14b9));(my $__clientSupportsHelloWithAdmin
=(0x03c4+ 3566-0x11b2));(my $__clientSupportingEncodedUserInHello=
(0x0588+ 4233-0x1611));(my $__clientSupportsProxyPacketPriority=
(0x0568+ 5114-0x1962));(my $__clientSupportsManualNodeSelection=
(0x0ff9+ 3963-0x1f74));(my $__clientSupportsDynamicFieldSizesInSessionList=
(0x16bf+ 1357-0x1c0b));(my $__clientSupportsExpiredPasswordChange=
(0x1199+ 3741-0x2036));(my $__clientSupportsIgnoreSessionTypeForListSession=
(0x0622+ 4722-0x1894));(my $__clientSupportingClientMenuConfiguration=
(0x1f72+ 476-0x214e));(my $__clientSupportingSeparateUsersOnSessionList=
(0x1aa3+ 284-0x1bbf));(my $__clientSupportingDisableCredentialsStoring=
(0x0635+ 4408-0x176d));(my $__clientSupportsPackedMessages=(0x0c09+ 2767-0x16d8)
);(my $__clientSupportsTranslatedMessages=(0x09b0+ 1479-0x0f77));(my $__clientSupportsErrorDuringPasswordChange
=(0x03f7+ 6526-0x1d75));(my $__clientSupportsMultiserver=(0x002a+ 3076-0x0c2d));
(my $__clientSupportsPasswordRequest=(0x0499+ 7582-0x2237));(my $__clientSupportsAutoreconnectSetting
=(0x115d+ 3090-0x1d6f));(my $__clientSupportsAgentMode=(0x082d+ 5247-0x1cac));(my $__clientSupportDuoAuth
=(0x12e9+ 3047-0x1ed0));(my $__clientSupportsAutomaticRecording=
(0x0c06+ 980-0x0fda));(my $__clientSupportNoMachineNetworkTwoFactor=
(0x0cec+ 5859-0x23ce));(my $__clientSupportsSeparateAuthInMultiServer=
(0x159d+ 4208-0x260c));(my $__clientSupportsAuthRequiredNamedAsFurtherAuth=
(0x0be0+ 2569-0x15e8));(my $__clientSupportsAnywhereAuthMethods=
(0x0928+ 3576-0x1720));(my $__clientSupportsCredentialsEncryption=
(0x1e48+ 359-0x1faf));(my $__clientSupportsServerListConnections=
(0x17bd+ 566-0x19f2));(my $__clientSupportSelectForwardMethod=
(0x05f7+  57-0x0630));(my $__clientSupportsErrorPublicKeyNotRecognized=
(0x0393+ 4231-0x141a));(my $__clientSupportsPooledServers=(0x0c11+ 4405-0x1d46))
;(my $__clientSupportsLocalSessionTypeAndOwner=(0x1c15+ 1987-0x23d8));(my $__clientSupportsDesktopSharing
=(0x0376+ 1478-0x093c));(my $__clientSupportsTerminateReason=
(0x0a13+ 2052-0x1217));(my $__clientSupportsSubserversNamedAsNodes=
(0x0411+ 3400-0x1158));(my $__clientSupportsGuestTypes=(0x0605+ 2701-0x1091));(my $__clientSupportsAttachRequestMessage
=(0x1572+ 875-0x18dd));(my $__clientSupportsExpireDateStatus=
(0x1293+ 2394-0x1bec));(my $__clientSupportsExpireInformation=
(0x0346+ 3374-0x1073));(my $__clientSupportsUpdateInNodeEdit=
(0x0d74+ 5161-0x219c));(my $__clientSupportsUuidChangeMessage=
(0x1834+ 504-0x1a2c));(my $__clientSupportsClientConnection=
(0x14fb+ 2152-0x1d62));(my $__clientSupportsInverseParameter=
(0x1b21+ 1625-0x2179));(my $__clientSupportsBrowseWithoutAuth=
(0x0357+ 8602-0x24f0));(my $__clientSupportsCommandsAfterStop=
(0x0cdb+ 3906-0x1c1c));(my $__clientSupportsParentCloudLimits=
(0x001f+ 7720-0x1e47));(my $__clientSupportsIgnoringWarnings=
(0x12d4+ 1651-0x1947));(my $__clientSupportsExtendedHelloProcessorInfo=
(0x18e7+ 2846-0x2405));(my $__clientSupportNewLabels=(0x04c7+ 5372-0x19c2));(my $__clientSupportServerlistWithNames
=(0x04d6+ 2870-0x100b));(my $__clientSupportsSeparateConnections=
(0x04b9+ 4846-0x17a6));(my $__clientSupportsDynamicParentConnections=
(0x12c4+ 4008-0x226c));(my $__clientSupportsMdnsMonitor=(0x0123+ 960-0x04e2));(my $__clientSupportsUdpServer
=(0x0167+ 8267-0x21b2));(my $__clientSupportsMissingLicenseFileOrWrongAcronym=
(0x1505+ 4408-0x263c));(my $__clientSupportsReportingAllConnections=
(0x1a16+ 2626-0x2457));(my $__clientSupportsFileTransferInfomation=
(0x04bd+ 7975-0x23e3));(my $__clientSupportsPhysicalDekstopAndClusterInfo=
(0x0f65+ 2520-0x193c));(my $__clientSupportsCurrentNodeAddress=
(0x0bb2+ 3540-0x1985));(my $__clientSupportsAllowGuest=(0x1100+ 2201-0x1998));(my $__clientSupportsCustomUdpPort
=(0x13ad+ 770-0x16ae));(my $__clientSupportWrongPlatformLicenseInfo=
(0x03e4+ 6282-0x1c6d));(my $__clientSupportNodeFlags=(0x1e40+ 2052-0x2643));(my $__clientSupportsCode555
=(0x21fa+ 776-0x2501));(my $__publicKeyMessageVersion=(0x1697+ 1804-0x1da2));(my $__downwardCompatibilitySudoVerification
=(0x0552+ 2058-0x0d5b));(my $__downwardCompatibilityEmptyCommand=
(0x078c+ 168-0x0833));(my $__mainServerSupportsHandleFirstAttach=
(0x0335+ 2232-0x0bed));(my $__connectedToConsole=(0x06d1+ 7349-0x2385));(my $__serverStartedBySystemd
=(0x0612+ 7765-0x2467));(my $__serverStartedByService=(0x1609+ 2248-0x1ed1));(my $__startupNeedPerformAdministrativeTasks
=(0x06ed+ 3965-0x1669));(my $__showAllResourceAvailableFlag=
(0x0840+ 6271-0x20bf));(my $__udpConnection=(0x1e69+ 1118-0x22c7));(my $__checkLocalBySystemdSessions
=(0x145f+ 3154-0x20b1));(my $__futureMainSession=(""));(my $__serverIsShutdownServer
=(0x089c+  50-0x08ce));(my $__serverIsRestartServer=(0x0b23+ 6962-0x2655));(my $__serverIsDaemon
=(0x174c+ 1698-0x1dee));(my $__connectionTunnelled=(0x0ee1+ 4786-0x2193));(my $__helloData
=(""));(my $__shellData=(""));my ($__timestamps);(my $__sessionRealConnecter=
(""));(my $__connectionForwarded=(0x0b27+ 3214-0x17b5));(my $__isMainSessionHeavyweight
=(0x00f7+ 5573-0x16bc));(my $__anywhereName=
"\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x20\x4e\x65\x74\x77\x6f\x72\x6b");(my $__accessOnlyToLocalPhysical
=(0x0f56+ 2314-0x1860));(my $__accessOnlyToAttach=(0x0023+ 4152-0x105b));(my $__remoteServer
=(0x0817+ 5734-0x1e7d));(my $__serverReverselogin=(0x02fc+ 5066-0x16c6));(my $__serverReverseProtocol
=(""));(my $__serverReverseHost=(""));(my $__fdIN=(-(0x06c5+ 4899-0x19e7)));(my $__fdOUT
=(-(0x075a+ 7976-0x2681)));(my $__directAccessFlag=(-(0x0274+ 7126-0x1e49)));(my $__skipClosingPassedSocket
=(0x2398+ 743-0x267f));(my $__disableUdpForwarder=(0x1da1+ 1145-0x221a));(my $__udpStatus
=(0x1c11+ 1672-0x2299));(my $__clientSupportsQuasiAdmin=(0x0f00+ 1354-0x1449));(my $__clientSupportsForwardWithTimeout
=(0x1b3d+ 1717-0x21f1));(my $__clientSupportHelloForVisitor=
(0x0dd2+ 1902-0x153f));(my $__clientSupportParentName=(0x0152+ 9429-0x2626));(my $__clientSupportCsNodePool
=(0x03cc+ 5971-0x1b1e));sub setMySessionID{(my $id=shift (@_));(my $isLocal=(
shift (@_)||(0x004f+ 8116-0x2003)));if (($__sessionID eq (""))){($__sessionID=
$id);Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x27"
.$__sessionID)."\x27\x2e"));}else{if ($isLocal){Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x68\x61\x6e\x67\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x66\x72\x6f\x6d\x20\x27"
.$__sessionID)."\x27\x20\x74\x6f\x20\x27").$id)."\x27\x2e"));($__sessionID=$id);
return ((0x0a55+ 4773-0x1cf9));}if (($id ne $__sessionID)){Logger::error (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x27"
.$__sessionID)."\x27\x2e"));main::nxexit ();}else{Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74\x20\x27"
.$__sessionID)."\x27\x2e"));}}}sub saveSslContext{if (defined (
$GLOBAL::IS_SESSION_H)){if (($GLOBAL::IS_SESSION_H==(0x062b+ 6172-0x1e46))){
setSslContext (libnxh::NXEncryptorGetContext ());}}}sub setSslContext{(my $sslContext
=shift (@_));Logger::debug ((
"\x53\x61\x76\x65\x20\x73\x73\x6c\x20\x63\x6f\x6e\x74\x65\x78\x74\x20".length (
$sslContext)));($__sslContext=$sslContext);}sub getSslContext{Logger::debug ((
"\x52\x65\x73\x74\x6f\x72\x65\x20\x73\x73\x6c\x20\x63\x6f\x6e\x74\x65\x78\x74\x20"
.length ($__sslContext)));return ($__sslContext);}sub isMySessionIdCreated{if ((
$__sessionID ne (""))){return ((0x1daf+ 588-0x1ffa));}return (
(0x01e9+ 3319-0x0ee0));}sub getMySessionID{if (($__sessionID eq (""))){
Logger::debug (
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"
);}else{Logger::debug (((
"\x47\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x27".$__sessionID)
."\x27\x2e"));}return ($__sessionID);}sub setMainSessionHeavyweightMode{(
$__isMainSessionHeavyweight=shift (@_));}sub setMainSessionID{(my $id=shift (@_)
);if (($__mainSessionID eq (""))){($__mainSessionID=$id);if ((
$__isMainSessionHeavyweight eq (""))){($__isMainSessionHeavyweight=
NXSession2::isHeavyweightModeSessionBySessionId ($__mainSessionID));}
Logger::debug (((
"\x53\x65\x74\x20\x6d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x27"
.$__mainSessionID)."\x27\x2e"));}else{if (($id ne $__mainSessionID)){
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x27"
.$id).
"\x27\x2c\x20\x69\x74\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x65\x78\x69\x73\x74\x73\x20\x27"
).$__mainSessionID)."\x27\x2e"));main::nxexit ();}else{Logger::debug (((
"\x4d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x69\x73\x20\x69\x64\x65\x6e\x74\x69\x63\x61\x6c\x20\x74\x6f\x20\x74\x68\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74\x20\x27"
.$__mainSessionID)."\x27\x2e"));}}}sub isMainSessionHeavyweightMode{return (
$__isMainSessionHeavyweight);}sub switchMainSessionID{(my $id=shift (@_));
Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x77\x69\x74\x63\x68\x65\x64\x20\x66\x72\x6f\x6d\x20\x27"
.$__mainSessionID)."\x27\x20\x74\x6f\x20\x27").$id)."\x27\x2e"));(
$__mainSessionID=$id);}sub getMainSessionID{if (($__mainSessionID eq (""))){
Logger::debug (
"\x4d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"
);}else{Logger::debug (((
"\x47\x65\x74\x20\x6d\x61\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x3a\x20"
.$__mainSessionID)."\x2e"));}return ($__mainSessionID);}(my $__direclyConnected=
(0x044d+ 2176-0x0ccd));sub isDireclyConnected{if (($__direclyConnected==
(0x0847+ 6472-0x218e))){return ((0x07d4+ 823-0x0b0a));}return (
(0x093d+ 1287-0x0e44));}sub isNotDireclyConnected{return ((!isDireclyConnected 
()));}sub setDirectlyConnected{($__direclyConnected=(0x05e1+ 2211-0x0e83));}(
$__removeNodeFromClient35=(0x022b+ 5103-0x161a));sub setRemoteNodeFromClient35{(
$__removeNodeFromClient35=(0x1220+ 3102-0x1e3d));}sub isRemoveNodeFromClient35{
return ($__removeNodeFromClient35);}($desktopPolicy=
"\x6e\x6f\x72\x6d\x61\x6c\x50\x6f\x6c\x69\x63\x79");($desktopPolicyKeyNotSet=
"\x66\x61\x6c\x73\x65");sub isReverseDefaultDesktopPolicy{if (($desktopPolicy eq
 "\x72\x65\x76\x65\x72\x73\x65\x50\x6f\x6c\x69\x63\x79")){return (
(0x1220+ 5121-0x2620));}return ((0x0510+ 2253-0x0ddd));}sub 
isNotReverseDefaultDesktopPolicy{return ((!isReverseDefaultDesktopPolicy ()));}
sub setReverseDefaultDesktopPolicy{($desktopPolicy=
"\x72\x65\x76\x65\x72\x73\x65\x50\x6f\x6c\x69\x63\x79");}sub 
setDefaultDesktopPolicyNotSet{($desktopPolicyKeyNotSet="\x74\x72\x75\x65");}sub 
isDefaultDesktopPolicyNotSet{if (($desktopPolicyKeyNotSet eq "\x74\x72\x75\x65")
){return ((0x2164+ 623-0x23d2));}return ((0x0c35+ 400-0x0dc5));}sub 
doesClientSupportLightMode{if (($__clientSupportLightweightMode==
(0x0537+ 5679-0x1b65))){Logger::debug (
"\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x6c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x20\x6d\x6f\x64\x65\x2e"
);return ((0x00d0+ 5244-0x154b));}Logger::debug (
"\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x6c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x20\x6d\x6f\x64\x65\x2e"
);return ((0x20c5+ 732-0x23a1));}sub setClientNotSupportLightMode{(
$__clientSupportLightweightMode=(0x0041+ 7053-0x1bce));}sub 
passErrorsToUserEnabled{return ($__passErrorsToClient);}sub 
setPassErrorsToUserEnabled{($__passErrorsToClient=(0x1110+ 2358-0x1a45));}sub 
setPassErrorsToUserDisabled{($__passErrorsToClient=(0x04f6+ 4666-0x1730));}sub 
resetMySessionID{($__sessionID=(""));}sub setClientNotSupportRootlessReconnect{(
$__clientSupportRootlessReconnect=(0x1acb+ 1680-0x215b));}sub 
isClientNotSupportRootlessReconnect{if (($__clientSupportRootlessReconnect==
(0x14b9+ 3808-0x2399))){return ((0x06b4+ 7756-0x24ff));}return (
(0x101b+ 2419-0x198e));}sub getMyUUID{if (($__myUuid eq (""))){(my $uuidFilePath
=(($GLOBAL::PathEtc.$GLOBAL::DIRECTORY_SLASH)."\x75\x75\x69\x64"));(my $FH=
main::nxopen ($uuidFilePath,$NXBits::O_RDONLY,(0x17cc+ 2757-0x2291)));if ((not (
defined ($FH)))){(my $error=libnxh::NXGetError ());(my $errorName=
libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$uuidFilePath)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorName)."\x2c\x20").$errorString)."\x2e"));return ((""));}my (
$uuid);main::nxreadLine ($FH,(\$uuid));main::nxclose ($FH);chomp ($uuid);
Logger::debug ((("\x47\x6f\x74\x20\x75\x75\x69\x64\x20\x27".$uuid).
"\x27\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x2e"));($__myUuid=
$uuid);}return ($__myUuid);}sub reloadMyUUID{($__myUuid=(""));getMyUUID ();}sub 
encryptorAlreadyStarted{Logger::debug2 (
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x53\x74\x61\x72\x74\x65\x64\x28\x29\x2e"
);(my $return=libnxhs::NXSubsystemStarted ());Logger::debug2 (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x53\x74\x61\x72\x74\x65\x64\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));return ($return);}sub setCachedMessagesFromClient{
Logger::debug2 (
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x47\x65\x74\x4d\x65\x73\x73\x61\x67\x65\x73\x28\x29\x2e"
);(my $messages=libnxhs::NXSubsystemGetMessages ());Logger::debug2 (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x47\x65\x74\x4d\x65\x73\x73\x61\x67\x65\x73\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$messages)."\x27"));main::nxrequire (
"\x47\x65\x74\x43\x6f\x6d\x6d\x61\x6e\x64\x53\x74\x61\x74\x65\x4d\x61\x63\x68\x69\x6e\x65"
);GetCommandStateMachine::setCachedClientMessagesBuffer ($messages);}sub 
setIODescriptors{Logger::debug (
"\x47\x6f\x69\x6e\x74\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x47\x65\x74\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x46\x64\x28\x29\x2e"
);(my $fd=libnxhs::NXSubsystemGetEncryptorFd ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x53\x75\x62\x73\x79\x73\x74\x65\x6d\x47\x65\x74\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x46\x64\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x46\x44\x23"
.$fd)."\x2e"));if (($fd==(-(0x0c9b+ 1764-0x137e)))){main::nxwrite (
main::nxgetSTDOUT (),
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x49\x4f\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e\x0a"
);main::nxexit ((0x1957+ 687-0x1c06));}($GLOBAL::SOCKET_PASSED=$fd);
Common::NXCore::nxsetSTDIN ($fd);Common::NXCore::nxsetSTDOUT ($fd);}sub 
setClientOverrideShadowProfileRule{($__overrideShadowProfileRule=
(0x0979+ 5329-0x1e49));}sub clientOverrideShadowProfileRule{return (
$__overrideShadowProfileRule);}sub setClientExtendedHelloHWinfo{(
$__clientExtendedHelloHWinfo=(0x0356+ 5353-0x183e));}sub isClientSupportHWInfo{
return ($__clientExtendedHelloHWinfo);}sub setClientExtendedHelloCpuRamInfo{(
$__clientExtendedHelloCpuRamInfo=(0x02a2+ 7967-0x21c0));}sub 
setClientSupportsExtendedHelloProcessorInfo{(
$__clientSupportsExtendedHelloProcessorInfo=(0x045d+ 500-0x0650));}sub 
isClientSupportCpuRamInfo{return ($__clientExtendedHelloCpuRamInfo);}sub 
isClientSupportsExtendedHelloProcessorInfo{return (
$__clientSupportsExtendedHelloProcessorInfo);}sub getForeignAddress{if ((
$__foreignAddress ne (""))){return ($__foreignAddress);}return (
NXLogin::getForeignAddres ());}sub setForeignAddress{($__foreignAddress=shift (
@_));}sub sudoShouldAskForUsername{return ((0x0db0+ 4002-0x1d51));}sub 
initConnectionSTD{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x62\x79\x20\x53\x54\x44\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x2e"
);setConnectionTypeSTD ();setConnectionDescriptors (main::nxgetSTDIN (),
main::nxgetSTDOUT ());setInheritConnectionDescriptor ("\x6e\x6f");}sub 
initServerConnectionSSHD{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x53\x53\x48\x44\x2e"
);setConnectionTypeSSHD ();setConnectionDescriptors (main::nxgetSTDIN (),
main::nxgetSTDOUT ());setInheritConnectionDescriptor ("\x6e\x6f");
setSubsystemConnectionIN (main::nxgetSTDIN ());setSubsystemConnectionOUT (
main::nxgetSTDOUT ());NXPublicKeyAuth::init ("\x73\x65\x72\x76\x65\x72");
NXPublicKeyAuth::setRemoteLogin ();}sub initClientConnectionReverse{(my $descriptor
=shift (@_));($__fdIN=shift (@_));($__fdOUT=shift (@_));(my $protocol=shift (@_)
);Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x76\x69\x61\x20\x72\x65\x76\x65\x72\x73\x65\x20\x6c\x6f\x67\x69\x6e\x2e"
);setConnectionType ("\x52\x65\x76\x65\x72\x73\x65");setReverseProtocol (
$protocol);setConnectionIN ($descriptor);setConnectionOUT ($descriptor);
setInheritConnectionDescriptor ("\x6e\x6f");}sub getReverseConnection{return (
$__connectionIN);}sub setReverseProtocol{($__serverReverseProtocol=shift (@_));}
sub getReverseProtocol{return ($__serverReverseProtocol);}sub 
initClientConnectionSSHD{Logger::debug (
"\x43\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x53\x53\x48\x44\x2e"
);setConnectionType ("\x53\x53\x48\x44");setConnectionDescriptors (
main::nxgetSTDIN (),main::nxgetSTDOUT ());setInheritConnectionDescriptor (
"\x6e\x6f");setSubsystemConnectionIN (main::nxgetSTDIN ());
setSubsystemConnectionOUT (main::nxgetSTDOUT ());}sub getNXEncryptorContext{(my $encryptorPipe
=shift (@_));(my $context=libnxh::NXEncryptorGetContext ());(my $maxTimeout=
(0x0836+ 7400-0x24a6));(my $timeout=$maxTimeout);(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->add ($encryptorPipe);while ((($context eq (""))and (
(0x0a86+ 5726-0x20e4)<$timeout))){(my $startTime=
Common::NXTime::getSecondsSinceEpoch ());(my (@ready)=$selector->can_read ((
$timeout *(0x0b91+ 4903-0x1ad0))));(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());($timeout=($timeout-($currentTime-
$startTime)));if ((scalar (@ready)==(0x0384+ 1528-0x097c))){Logger::warning (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x20"
.$maxTimeout).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x72\x65\x61\x63\x68\x65\x64\x2e"));return 
((0x0ba8+  60-0x0be4));}foreach my $f (@ready){if (($f==$encryptorPipe)){
Logger::debug (((
"\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x72\x65\x61\x74\x65\x20\x46\x44\x23"
.$f)."\x2e"));my ($read_buf);(my $bytes_read=main::nxread ($f,(\$read_buf),
(0x1766+ 4821-0x1a3b)));if (((not (defined ($bytes_read)))or ($bytes_read==
(0x0f2a+ 816-0x125a)))){Logger::debug (((
"\x43\x6c\x6f\x73\x65\x64\x20\x46\x44\x23".$f)."\x2e"));Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6c\x6f\x73\x74\x2e"
);main::nxclose ($f);$selector->remove ($f);$selector->remove ($signalFd);return
 ((0x0e6a+ 1361-0x13bb));}else{Logger::debug (((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x72\x65\x61\x74\x65\x3a\x20"
.$read_buf)."\x2e"));if (($read_buf=~ /1\n/ )){($context=
libnxh::NXEncryptorGetContext ());main::nxclose ($f);}elsif (($read_buf=~ /2\n/ )
){Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);main::nxclose ($f);$selector->remove ($encryptorPipe);$selector->remove (
$signalFd);return ((0x0c37+ 6406-0x253d));}else{Logger::warning (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x6f\x70\x74\x69\x6f\x6e\x20\x61\x70\x70\x65\x61\x72\x73\x2e"
);}}}}}($GLOBAL::NXD_SSL_CONTEXT=$context);(my $operationTime=($maxTimeout-
$timeout));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x47\x65\x74\x43\x6f\x6e\x74\x65\x78\x74\x20\x27"
.$context)."\x27\x20\x61\x66\x74\x65\x72\x20").$operationTime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));return ((0x0be4+ 4914-0x1f15));}sub 
initClientConnectionNXD{(my $inheritedDescriptor=shift (@_));Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x4e\x58\x44\x2e"
);($GLOBAL::IS_SESSION_H=(0x0f1b+ 1069-0x1347));if (encryptorAlreadyStarted ()){
setIODescriptors ();NXMsg::setSilentMode ();setCachedMessagesFromClient ();
setConnectionTypeNXD ();setConnectionDescriptors ($inheritedDescriptor);
setInheritConnectionDescriptor ("\x6e\x6f");return;}Logger::debug2 ((
"\x49\x6e\x68\x65\x72\x69\x74\x65\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20"
.$inheritedDescriptor));(my $descriptor=libnxh::NXDescriptorCreate (
$inheritedDescriptor));if (($descriptor<(0x0d42+ 3823-0x1c31))){Logger::error ((
(
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$inheritedDescriptor)."\x2e"));shutdownClientConnection ();main::nxexit ();}
setNxdCommunication ($descriptor);($inheritedDescriptor=getTcpDescriptor ());(my $result
=main::nxPipeCreateBi ((\$GLOBAL::LOCAL_NX_DESCRIPTOR_IN),(
\$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)));Logger::debug (((((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x6c\x6f\x63\x61\x6c\x5f\x69\x6e\x20\x46\x44\x23"
.$GLOBAL::LOCAL_NX_DESCRIPTOR_IN).
"\x20\x6c\x6f\x63\x61\x6c\x20\x6f\x75\x74\x20\x46\x44\x23").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)."\x20\x72\x65\x73\x75\x6c\x74\x20\x27").
$result)."\x27"));if (((($a<(0x1fa1+ 204-0x206d))or (
$GLOBAL::LOCAL_NX_DESCRIPTOR_IN<(0x0eb0+ 3637-0x1ce5)))or (
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT<(0x0692+ 5982-0x1df0)))){Logger::error (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x4e\x58\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x70\x69\x70\x65\x2e"
);shutdownClientConnection ();main::nxexit ();}main::doNotCloseSocketAtFinish (
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT);my ($encryptorCreateIn);my (
$encryptorCreateOut);($result=main::nxPipeCreateBi ((\$encryptorCreateIn),(
\$encryptorCreateOut)));Logger::debug (((((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x72\x65\x61\x74\x65\x49\x6e\x20\x46\x44\x23"
.$encryptorCreateIn).
"\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x72\x65\x61\x74\x65\x4f\x75\x74\x20\x46\x44\x23"
).$encryptorCreateOut)."\x20\x72\x65\x73\x75\x6c\x74\x20\x27").$result).
"\x27\x2e"));if (((($result<(0x0631+ 5689-0x1c6a))or ($encryptorCreateIn<
(0x0bb7+ 4441-0x1d10)))or ($encryptorCreateOut<(0x0cab+ 2848-0x17cb)))){
Logger::error (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x72\x65\x61\x74\x65\x20\x70\x69\x70\x65\x2e"
);shutdownClientConnection ();main::nxexit ();}main::doNotCloseSocketAtFinish (
$encryptorCreateOut);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x53\x65\x74\x50\x69\x70\x65\x28"
.$encryptorCreateOut)."\x29\x3b"));($result=libnxh::NXEncryptorSetPipe (
$encryptorCreateOut));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x53\x65\x74\x50\x69\x70\x65\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$result)."\x27\x2e"));main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");
if (((NXCluster::isEnabled ()and ($GLOBAL::ClusterHost ne ("")))and (not (
NXCluster::isSingleCert ())))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x2e"
);Logger::debug (((((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x6c\x75\x73\x74\x65\x72\x43\x72\x65\x61\x74\x65\x28"
.$inheritedDescriptor)."\x2c\x20").$inheritedDescriptor)."\x2c\x20").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)."\x2c\x20").$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT).
"\x2c\x20").$GLOBAL::ClusterHost)."\x29"));($result=
libnxh::NXEncryptorClusterCreate ($inheritedDescriptor,$inheritedDescriptor,
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,
$GLOBAL::ClusterHost));}else{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x2e"
);(my $nxRTEnv=libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x52\x54"));if ((
$nxRTEnv ne (""))){if (($nxRTEnv=~ /(.*):(.*):(.*):(.*)/ )){(my $host=$1);(my $port
=$2);(my $iv=$3);(my $key=$4);Logger::debug (((((((((((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x72\x65\x61\x74\x65\x52\x54\x28"
.$inheritedDescriptor)."\x2c\x20").$inheritedDescriptor)."\x2c\x20").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)."\x2c\x20").$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT).
"\x2c\x20").$host)."\x2c\x20").$port)."\x2c\x20").$iv)."\x2c\x20").$key)."\x29")
);($result=libnxh::NXEncryptorCreateRT ($inheritedDescriptor,
$inheritedDescriptor,$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,$host,$port,$iv,$key));}}else{Logger::debug (((
((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x72\x65\x61\x74\x65\x28"
.$inheritedDescriptor)."\x2c\x20").$inheritedDescriptor)."\x2c\x20").
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT)."\x2c\x20").$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT).
"\x29"));($result=libnxh::NXEncryptorCreate ($inheritedDescriptor,
$inheritedDescriptor,$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT,
$GLOBAL::LOCAL_NX_DESCRIPTOR_OUT));}}Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x72\x65\x73\x75\x6c\x74\x20\x27"
.$result)."\x27\x2e"));if (($result<(0x0236+ 6327-0x1aed))){
Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x65\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x66\x6f\x72\x20\x69\x6e\x68\x65\x72\x69\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$inheritedDescriptor)."\x2e"));shutdownClientConnection ();main::nxexit ();}(
$GLOBAL::SOCKET_PASSED=$GLOBAL::LOCAL_NX_DESCRIPTOR_IN);(
$GLOBAL::DefaultSTDINDescriptor=$GLOBAL::SOCKET_PASSED);(
$GLOBAL::DefaultSTDOUTDescriptor=$GLOBAL::SOCKET_PASSED);
setSubsystemConnectionIN ($GLOBAL::LOCAL_NX_DESCRIPTOR_IN);
setSubsystemConnectionOUT ($GLOBAL::LOCAL_NX_DESCRIPTOR_IN);
setSubsystemEncryptorIN ($GLOBAL::LOCAL_NX_DESCRIPTOR_OUT);Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4d\x6f\x64\x65\x20\x2d\x48\x20\x46\x44\x23".
$GLOBAL::SOCKET_PASSED)."\x2e"));setConnectionTypeNXD ();
setConnectionDescriptors ($inheritedDescriptor);setInheritConnectionDescriptor (
"\x6e\x6f");if ((getNXEncryptorContext ($encryptorCreateIn)==
(0x013a+ 352-0x029a))){Logger::error (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x6f\x6e\x74\x65\x78\x74\x20\x6e\x6f\x74\x20\x72\x65\x63\x65\x69\x76\x65\x64\x2e"
);shutdownClientConnection ();main::nxexit ();}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x63\x6f\x6e\x74\x65\x78\x74\x20\x72\x65\x63\x65\x69\x76\x65\x64\x2e"
);}sub shutdownClientConnection{if (isClientConnectionOpenOrNull ()){
Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
);if (isConnectionTypeNXD ()){shutdownClientConnectionNXD ();}elsif (
isConnectionTypeSSHD ()){shutdownClientConnectionSSHD ();}elsif ((
isConnectionTypeSTD ()or isConnectionTypeSTDNULL ())){
shutdownClientConnectionSTD ();}elsif (isReverselogin ()){
shutdownClientConnectionReverse ();}setClientConnectionClosed ();}}sub 
shutdownClientConnectionNXD{Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x4e\x58\x44\x2e"
);if (libnxh::NXEncryptorRunning ()){Logger::debug (
"\x46\x72\x65\x65\x20\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x43\x6f\x6e\x74\x65\x78\x74"
);(my $return=libnxh::NXEncryptorFreeContext ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x46\x72\x65\x65\x43\x6f\x6e\x74\x65\x78\x74\x20\x72\x65\x74\x75\x72\x6e\x20"
.$return)."\x2e"));($return=libnxh::NXEncryptorDestroy ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x44\x65\x73\x74\x72\x6f\x79\x20\x72\x65\x74\x75\x72\x6e\x20"
.$return)."\x2e"));if ((shouldSkipClosingPassedSocket ()==(0x1c06+ 1957-0x23ab))
){main::nxclose ($GLOBAL::SOCKET_PASSED);}NXShell::setConnectionClosed ();}else{
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x45\x6e\x63\x72\x79\x70\x74\x6f\x72\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);}main::nxclose (getConnectionIN ());}sub shutdownClientConnectionReverse{
Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x52\x65\x76\x65\x72\x73\x65\x2e"
);if (($__fdIN!=(-(0x10a4+ 5441-0x25e4)))){main::nxclose ($__fdIN);}if (((
$__fdOUT!=$__fdIN)and ($__fdOUT!=(-(0x0343+ 3307-0x102d))))){main::nxclose (
$__fdOUT);}($__fdIN=(-(0x133d+ 3336-0x2044)));($__fdOUT=(-(0x0783+ 7473-0x24b3))
);}sub shutdownClientConnectionSSHD{Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x53\x53\x48\x44\x2e"
);main::nxclose (getConnectionIN ());main::nxclose (getConnectionOUT ());}sub 
shutdownClientConnectionSTD{Logger::debug (
"\x43\x6c\x6f\x73\x69\x6e\x67\x20\x53\x54\x44\x49\x4e\x20\x61\x6e\x64\x20\x53\x54\x44\x4f\x55\x54\x2e"
);main::nxclose (main::nxgetSTDIN ());Common::NXCore::nxsetSTDIN ((-
(0x0f7b+ 1415-0x1501)));main::nxclose (main::nxgetSTDOUT ());
Common::NXCore::nxsetSTDOUT ((-(0x0386+ 689-0x0636)));}sub 
redirectClientConnectionToNull{if (isConnectionTypeSTD ()){(my $ret=
redirectClientConnectionSTDToNull ());Logger::debug (($ret.
"\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28\x73\x29\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x2e"
));setConnectionTypeSTDNULL ();return ($ret);}else{Logger::error (
"\x72\x65\x64\x69\x72\x65\x63\x74\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x54\x6f\x4e\x75\x6c\x6c\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x20\x66\x6f\x72\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x79\x70\x65"
);return ((-(0x026d+ 280-0x0384)));}}sub redirectClientConnectionSTDToNull{
Logger::debug (
"\x52\x65\x64\x69\x72\x65\x63\x74\x69\x6e\x67\x20\x53\x54\x44\x49\x4e\x20\x61\x6e\x64\x20\x53\x54\x44\x4f\x55\x54\x20\x74\x6f\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x2e"
);(my $in=main::nxgetSTDIN ());(my $out=main::nxgetSTDOUT ());(my $nullin=
main::nxopen ("\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c",$NXBits::O_RDONLY,
(0x11ed+ 5062-0x25b3)));if ((not (defined ($nullin)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));return ((0x16ab+ 3063-0x22a2))
;}(my $nullout=main::nxopen ("\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c",
$NXBits::O_WRONLY,(0x181a+  22-0x1830)));if ((not (defined ($nullout)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));main::nxclose ($nullin);return
 ((0x0582+ 6622-0x1f60));}(my $result=(0x0510+ 6095-0x1cdd));(my $ret=
Common::NXCore::nxFileClone ($nullin,$in));if ((not (defined ($ret)))){
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x69\x6e\x20\x74\x6f\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x2e"
);(--$result);}($ret=Common::NXCore::nxFileClone ($nullout,$out));if ((not (
defined ($ret)))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x6f\x75\x74\x20\x74\x6f\x20\x2f\x64\x65\x76\x2f\x6e\x75\x6c\x6c\x20\x2e"
);(--$result);}main::nxclose ($nullin);main::nxclose ($nullout);return ($result)
;}sub isClientConnectionOpen{if ((($__connectionType eq 
"\x44\x49\x53\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44")or ($__connectionType eq 
"\x53\x54\x44\x4e\x55\x4c\x4c"))){Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);return ((0x085b+ 4427-0x19a6));}else{Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x73\x74\x69\x6c\x6c\x20\x6f\x70\x65\x6e\x2e"
);return ((0x14e9+ 1378-0x1a4a));}}sub isClientConnectionOpenOrNull{if ((
$__connectionType eq "\x44\x49\x53\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44")){
Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6c\x6f\x73\x65\x64\x20\x28\x73\x74\x72\x69\x63\x74\x6c\x79\x2c\x20\x6e\x6f\x74\x20\x6e\x75\x6c\x6c\x65\x64\x29\x2e"
);return ((0x0bdd+ 5338-0x20b7));}else{Logger::debug (
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x6f\x70\x65\x6e\x20\x6f\x72\x20\x6e\x75\x6c\x6c\x65\x64\x2e"
);return ((0x0b3c+ 6006-0x22b1));}}sub isClientConnectionClosed{return ((!
isClientConnectionOpen ()));}sub setClientConnectionClosed{Logger::debug (
"\x53\x65\x74\x20\x63\x6c\x69\x65\x6e\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);if ((not (NXShell::byeMeansSwitch ()))){
NXClientConnection::informAboutDisconnect ();}setConnectionType (
"\x44\x49\x53\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44");}sub setConnectionType{(my $type
=shift (@_));($__connectionType=$type);}sub getConnectionType{(my $type=
$__connectionType);return ($type);}sub setConnectionIN{(my $fd=shift (@_));(
$__connectionIN=$fd);}sub setConnectionOUT{(my $fd=shift (@_));($__connectionOUT
=$fd);}sub getConnectionIN{return ($__connectionIN);}sub getConnectionOUT{return
 ($__connectionOUT);}sub setConnectionDescriptors{if (isConnectionTypeNXD ()){(my $conectionInOut
=shift (@_));setConnectionIN ($conectionInOut);setConnectionOUT ($conectionInOut
);}elsif ((isConnectionTypeSSHD ()or isConnectionTypeSTD ())){(my $conectionIn=
shift (@_));(my $conectionOut=shift (@_));setConnectionIN ($conectionIn);
setConnectionOUT ($conectionOut);}}sub setConnectionDescriptorsInheritable{(my $value
=shift (@_));if (isClientConnectionOpenOrNull ()){if (isConnectionTypeNXD ()){
libnxh::NXDescriptorInheritable (getConnectionIN (),$value);}elsif (((
isConnectionTypeSSHD ()or isConnectionTypeSTD ())or isConnectionTypeSTDNULL ()))
{libnxh::NXDescriptorInheritable (getConnectionIN (),$value);
libnxh::NXDescriptorInheritable (getConnectionOUT (),$value);}}}sub 
setInheritConnectionDescriptor{(my $value=shift (@_));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x69\x6e\x68\x65\x72\x69\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x74\x6f\x20\x27"
.$value)."\x27\x2e"));if (($value eq "\x6e\x6f")){
setConnectionDescriptorsInheritable ((0x07bf+ 4592-0x19af));}if (($value eq 
"\x79\x65\x73")){setConnectionDescriptorsInheritable ((0x13b4+ 4162-0x23f5));}(
$GLOBAL::inheritConnectionDescriptor=$value);}sub getInheritConnectionDescriptor
{return ($GLOBAL::inheritConnectionDescriptor);}sub 
isInheritConnectionDescriptor{if (($GLOBAL::inheritConnectionDescriptor eq 
"\x79\x65\x73")){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x49\x6e\x68\x65\x72\x69\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x2e"
);return ((0x0d81+ 5847-0x2457));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4e\x6f\x74\x20\x69\x6e\x68\x65\x72\x69\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x2e"
);return ((0x0681+ 5245-0x1afe));}sub setConnectionTypeNXD{setConnectionType (
"\x4e\x58\x44");}sub setConnectionTypeSSHD{setConnectionType ("\x53\x53\x48\x44"
);}sub setConnectionTypeSTD{setConnectionType ("\x53\x54\x44");}sub 
setConnectionTypeSTDNULL{setConnectionType ("\x53\x54\x44\x4e\x55\x4c\x4c");}sub
 isConnectionTypeNXD{if (($__connectionType eq "\x4e\x58\x44")){return (
(0x0c77+ 1217-0x1137));}else{return ((0x04e1+ 1929-0x0c6a));}}sub 
isConnectionTypeReverseNXD{if ((($__connectionType eq 
"\x52\x65\x76\x65\x72\x73\x65")and ($__serverReverseProtocol eq "\x4e\x58\x44"))
){return ((0x1df5+ 428-0x1fa0));}return ((0x1342+ 2518-0x1d18));}sub 
addCONNECTIONvariableToEnvArrayPassed{(my $ref_array=shift (@_));(my $nxConnectionEnv
=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if (($nxConnectionEnv 
ne (""))){push (@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".$nxConnectionEnv));
return ((0x0a64+ 4782-0x1d11));}(my $sshConnectionEnv=
libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if ((
$sshConnectionEnv ne (""))){push (@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".$sshConnectionEnv
));}(my $sshClientEnv=libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54"));if (($sshClientEnv ne (""))){push (
@$ref_array,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x53\x53\x48\x5f\x43\x4c\x49\x45\x4e\x54\x3d".$sshClientEnv));}}sub 
isConnectionTypeSSHD{if (($__connectionType eq "\x53\x53\x48\x44")){return (
(0x052c+ 5915-0x1c46));}else{return ((0x1009+ 3199-0x1c88));}}sub 
isConnectionTypeSTD{if (($__connectionType eq "\x53\x54\x44")){return (
(0x0f4f+ 3737-0x1de7));}else{return ((0x0b7d+ 1280-0x107d));}}sub 
isConnectionTypeSTDNULL{if (($__connectionType eq "\x53\x54\x44\x4e\x55\x4c\x4c"
)){return ((0x107b+ 1321-0x15a3));}else{return ((0x0a01+ 5057-0x1dc2));}}sub 
setSubsystemConnectionIN{(my $fd=shift (@_));($__subsystemConnectionIN=$fd);}sub
 setSubsystemConnectionOUT{(my $fd=shift (@_));($__subsystemConnectionOUT=$fd);}
sub getSubsystemConnectionIN{return ($__subsystemConnectionIN);}sub 
getSubsystemConnectionOUT{return ($__subsystemConnectionOUT);}sub 
setSubsystemEncryptorIN{($__subsystemEncryptorIN=shift (@_));}sub 
getSubsystemEncryptorIN{return ($__subsystemEncryptorIN);}sub 
setMasterGoingToShutdown{($__masterGoingToShutdown=(0x14ad+ 3261-0x2169));}sub 
isMasterGoingToShutdown{return ($__masterGoingToShutdown);}sub setPureSession{
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x70\x75\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);($__pureSession=(0x19ca+ 3330-0x26cb));}sub isPureSession{if (($__pureSession
==(0x24e1+ 287-0x25ff))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x50\x75\x72\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x0d80+ 5273-0x2218));}return ((0x055f+ 6036-0x1cf3));}sub 
terminateCommandReceived{return ($GLOBAL::REQUEST_TERMINATE);}sub 
setNotConnectedToConsole{($__connectedToConsole=(0x0405+ 2521-0x0dde));}sub 
setConnectedToConsole{($__connectedToConsole=(0x0f31+ 1260-0x141c));}sub 
isConnectedToConsole{return ($__connectedToConsole);}sub setStartedBySystemd{(
$__serverStartedBySystemd=(0x0f11+ 3364-0x1c34));}sub 
isCurrentServerDeamonStartedBySystemd{return ($__serverStartedBySystemd);}sub 
setStartedByService{($__serverStartedByService=(0x0339+ 7178-0x1f42));}sub 
isCurrentServerDeamonStartedByService{return ($__serverStartedByService);}sub 
setStartupNotNeedPerformAdministrativeTasks{(
$__startupNeedPerformAdministrativeTasks=(0x1ed8+ 1683-0x256b));}sub 
resetStartupNotNeedPerformAdministrativeTasks{(
$__startupNeedPerformAdministrativeTasks=(0x0ff6+ 585-0x123e));}sub 
startupNeedPerformAdministrativeTasks{return (
$__startupNeedPerformAdministrativeTasks);}sub handleClientTypeAndVersion{(my $clientName
=shift (@_));(my $clientMajorVersion=shift (@_));(my $clientMinorVersion=shift (
@_));(my $clientPatchVersion=shift (@_));Logger::debug ((((((((
"\x43\x6c\x69\x65\x6e\x74\x20\x73\x65\x74\x20\x74\x6f\x20".$clientName).
"\x20\x2d\x20").$clientMajorVersion)."\x2e").$clientMinorVersion)."\x2e").
$clientPatchVersion));setClientName ($clientName);setClientMajorVersion (
$clientMajorVersion);setClientMinorVersion ($clientMinorVersion);
setClientPatchVersion ($clientPatchVersion);setIfClientSupportsLightweight ();
setIfClientSupportsSSLEncryption ();setShowAllResourceAvailableFlag ();
setIfClientSupportsRedirecting ();setIfClientSupportsGuests ();
setIfClientSupportsNxpasswordService ();setIfClientSupportsPropertyRequest ();
setIfClientSupportsOsInfo ();setIfClientSupportsListHistory ();
setIfClientSupportsExtendedServices ();setIfClientIsVersion3OrOlder ();
setIfClientIsVersion7OrOlder ();setIfClientSupportsPlatformParameters ();
setIfClientSupportsKbtypeParameter ();setIfClientSupportsFakeAuthentication ();
setIfClientSupportsDynamicColumnWidth ();
setIfClientSupportsNodeAndLabelParameter ();
setIfClientSupportsNodeAndStatusParameter ();
setIfClientSupportsDialogInConnectionPolicy ();
setIfClientSupportsNxFrameBufferFeature ();setIfClientSupportsDesktopViewMode ()
;setIfClientSupportsSha256 ();setIfClientSupportsHelloWithAdmin ();
setIfClientSupportingEncodedUserInHello ();
setIfClientSupportsProxyPacketPriority ();setIfClientSupportsManualNodeSelection
 ();setIfClientIsSupportingDynamicFieldSizesInSessionList ();
setIfClientSupportsExpiredPasswordChange ();
setIfClientSupportsIgnoreSessionTypeForListSession ();
setIfClientSupportingClientMenuConfiguration ();
setIfClientSupportingDisableCredentialsStoring ();
setIfClientSupportsPackedMessages ();setIfClientSupportsTranslatedMessages ();
setIfClientSupportsErrorDuringPasswordChange ();
setIfClientSupportsPasswordRequest ();setIfClientSupportsDuoAuth ();
setIfClientSupportsLBTypeSystemLoad ();
setIfClientSupportsSystemDesktopsInConnectionPolicy ();
setIfClientSupportsErrorPublicKeyNotRecognized ();
setIfClientSupportsPooledServers ();setIfClientSupportsLocalSessionTypeAndOwner 
();setIfClientSupportsUdpInConnectionPolicy ();setIfClientSupportNewLabels ();
setIfClientSupportServerlistWithNames ();setIfClientSupportsCode555 ();
setDownwardCompatibilitySudoVerification ();setDownwardCompatibilityEmptyCommand
 ();setIfClientSupportsMultiserver ();setIfClientSupportAutoreconnectSetting ();
setIfClientSupportAgentMode ();setIfClientSupportsAutomaticRecording ();
setClientSupportsSeparateAuthInMultiServer ();
setClientSupportsAuthRequiredNamedAsFurtherAuth ();
setClientSupportsAnywhereAuthMethods ();setClientSupportsNoMachineTwoFactor ();
setClientSupportsCredentialsEncryption ();
setIfMainServerSupportsHandleFirstAttach ();
setClientSupportstServerListConnections ();
setIfClientSupportsSelectForwardMethod ();setIfClientSupportsDesktopSharing ();
setIfClientSupportsTerminateReason ();setIfClientSupportsSubserversNamedAsNodes 
();setClientSupportsGuestTypes ();setClientSupportsExpireDateStatus ();
setClientSupportsExpireInformation ();
setClientSupportsMissingLicenseFileOrWrongAcronym ();
setClientSupportWrongPlatformLicenseInfo ();setClientSupportNodeFlags ();
setClientSupportsAttachRequestMessage ();setClientSupportsInverseParameter ();
setClientSupportsUpdateInNodeEdit ();setClientSupportsClientConnection ();
setClientSupportsUuidChangeMessage ();setClientSupportsBrowseWithoutAuth ();
setPublicKeyMessageVersion ();setClientSupportsCommandsAfterStop ();
setClientSupportsParentCloudLimits ();setClientSupportsSeparateConnections ();
setClientSupportsDynamicParentConnections ();setClientSupportsIgnoringWarnings 
();setClientSupportsMdnsMonitor ();setClientSupportsForwardUdp ();
setClientSupportsDirectUdp ();setClientSupportsFileTransferInfomation ();
setClientSupportsPhysicalDestkopAndClusterInformation ();
setClientSupportsQuasiAdmin ();setClientSupportsForwardWithTimeout ();
setClientSupportsCurrentNodeAddress ();setClientSupportsAllowGuest ();
setClientSupportsCustomUdpPort ();setClientSupportHelloForVisitor ();
setClientSupportParentName ();setClientSupportCsNodePool ();if (
isClientVersionGreaterOrEqual ((0x11a2+ 3465-0x1f27))){if (isClientNxclient ()){
($GLOBAL::CLIENT_WITHOUT_UNENCRYPTION_MODE=(0x105f+ 1449-0x1607));}if ((((
isClientNxwebclient ()or isClientNxclient ())or isClientNxserver ())or 
isClientNxmanager ())){($GLOBAL::ConnectionMaxKeepAlive=(-(0x10a5+ 5011-0x2437))
);}}if ((isClientVersion ((0x10dc+ 2218-0x1982),(0x12b4+ 1407-0x1833))or 
isClientVersion ((0x1f25+ 418-0x20c3),(0x1be8+ 1918-0x2365)))){
setReverseDefaultDesktopPolicy ();}if (isClientNxclient ()){
NXShell::setCommandByeMeansExitSilent ();if (isClientVersionLesserOrEqual (
(0x16aa+ 1223-0x1b70),(0x06ba+ 6910-0x21b4))){(
$GLOBAL::conversionUnixApplicationToUnixDesktopNeededBecauseOldClient=
(0x05e8+ 4662-0x181d));}if (isClientVersionGreaterOrEqual ((0x1c59+ 2447-0x25e4)
,(0x0413+ 2115-0x0c53),(0x1601+ 175-0x16a0))){setClientExtendedHelloHWinfo ();}
if (isClientVersionGreaterOrEqual ((0x1845+ 1679-0x1ecd),(0x131f+ 4501-0x24b4),
(0x0224+ 4520-0x1303))){setClientExtendedHelloCpuRamInfo ();}if (
isClientVersionGreaterOrEqual ((0x0f56+ 4387-0x2071),(0x01cb+ 9104-0x255b),
(0x0929+ 3828-0x181d))){setClientSupportsExtendedHelloProcessorInfo ();}}if (
isClientNxwebclient ()){setEncodeUsernameForClient ();setNotConnectedToConsole 
();if (isClientVersionLesserOrEqual ((0x1ad2+ 1498-0x20a8),(0x096c+ 2744-0x1421)
,(0x0c4d+ 3165-0x1887))){setDecodeUsernameFromClient ();}if (
isClientVersionGreaterOrEqual ((0x021d+ 1451-0x07c1),(0x110d+ 1015-0x1504),
(0x0177+ 1451-0x065d))){setClientExtendedHelloHWinfo ();}if (
isClientVersionGreaterOrEqual ((0x1175+ 3572-0x1f62),(0x0e17+ 1942-0x15ad),
(0x1275+ 2668-0x1c19))){setClientExtendedHelloCpuRamInfo ();}if (
isClientVersionGreaterOrEqual ((0x0cfd+ 6666-0x26ff),(0x14f0+ 3738-0x238a),
(0x18e7+ 787-0x1b80))){setClientSupportsExtendedHelloProcessorInfo ();}}}sub 
setIfClientSupportsLightweight{if (isClientNxwebclient ()){Logger::debug (
"\x4c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x20\x6d\x6f\x64\x65\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x6e\x78\x77\x65\x62\x72\x75\x6e\x6e\x65\x72\x2e"
);setClientNotSupportLightMode ();setClientNotSupportRootlessReconnect ();
setClientOverrideShadowProfileRule ();}elsif (isClientVersion (
(0x1d52+ 2291-0x2641),(0x019b+ 3423-0x0efa))){Logger::debug (
"\x4c\x69\x67\x68\x74\x77\x65\x69\x67\x68\x74\x20\x6d\x6f\x64\x65\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x66\x6f\x72\x20\x6e\x78\x70\x6c\x61\x79\x65\x72\x20\x34\x2e\x30"
);setClientNotSupportLightMode ();}}sub setIfClientSupportsSSLEncryption{if (
isClientVersionLesserOrEqual ((0x0658+ 337-0x07a8),(0x1c7b+  16-0x1c88))){(
$__clientSupportsSSLEncryption=(0x0750+ 6316-0x1ffc));}else{(
$__clientSupportsSSLEncryption=(0x08fd+ 7430-0x2602));}}sub 
setShowAllResourceAvailableFlag{if (isClientVersionGreaterOrEqual (
(0x0acb+ 318-0x0c05),(0x150f+ 470-0x16e1),(0x082a+ 6829-0x22d2))){(
$__showAllResourceAvailableFlag=(0x0623+ 3785-0x14eb));}else{(
$__showAllResourceAvailableFlag=(0x15e3+ 1845-0x1d18));}}sub 
notShowAllResourceAvailable{if ($__showAllResourceAvailableFlag){return (
(0x02b3+ 828-0x05ef));}return ((0x0ccb+ 2227-0x157d));}sub 
isClientSupportingSSLEncryption{return ($__clientSupportsSSLEncryption);}sub 
setIfClientSupportsRedirecting{if (isClientVersionGreaterOrEqual (
(0x017a+ 1055-0x0595))){($__clientSupportsRedirecting=(0x14b7+   5-0x14bb));}
else{($__clientSupportsRedirecting=(0x18dd+ 2084-0x2101));}}sub 
isClientSupportingRedirecting{return ($__clientSupportsRedirecting);}sub 
setIfClientSupportsGuests{if (isClientVersionGreaterOrEqual (
(0x01e6+ 8007-0x2129),(0x0b37+ 6634-0x2520))){($__clientSupportsGuests=
(0x0a2a+ 207-0x0af8));}else{($__clientSupportsGuests=(0x06f6+ 2133-0x0f4b));}}
sub isClientSupportingGuests{return ($__clientSupportsGuests);}sub 
setIfClientSupportsMultiserver{if ((isClientNxclient ()or isClientNxwebclient ()
)){if (isClientVersionGreaterOrEqual ((0x119f+ 2987-0x1d44),
(0x0ad6+ 5416-0x1ffe))){($__clientSupportsMultiserver=(0x0928+ 2196-0x11bb));}
else{($__clientSupportsMultiserver=(0x0a1b+ 967-0x0de2));}}}sub 
isClientNotSupportingMultiserver{if (($__clientSupportsMultiserver==
(0x20b3+ 449-0x2274))){return ((0x1063+ 4896-0x2382));}return (
(0x0d9b+ 5663-0x23ba));}sub setIfClientSupportAutoreconnectSetting{if ((
isClientNxclient ()or isClientNxwebclient ())){if (isClientVersionGreaterOrEqual
 ((0x1e5b+ 2175-0x26d4),(0x1b29+ 1516-0x2113),(0x0246+ 4942-0x1588))){(
$__clientSupportsAutoreconnectSetting=(0x1b81+ 1795-0x2283));}else{(
$__clientSupportsAutoreconnectSetting=(0x1221+ 1614-0x186f));}}}sub 
isClientSupportAutoreconnectSetting{return (
$__clientSupportsAutoreconnectSetting);}sub setIfClientSupportAgentMode{if (
isClientNxclient ()){if (isClientVersionGreaterOrEqual ((0x0438+ 1918-0x0bb0),
(0x14fa+ 2949-0x207d),(0x1b34+ 692-0x1ddc))){($__clientSupportsAgentMode=
(0x0527+ 5554-0x1ad8));}else{($__clientSupportsAgentMode=(0x0159+ 6167-0x1970));
}}if (isClientNxwebclient ()){if (isClientVersionGreaterOrEqual (
(0x165b+ 2162-0x1ec6),(0x11ca+ 2413-0x1b37),(0x1303+ 3972-0x21d0))){(
$__clientSupportsAgentMode=(0x0705+ 2675-0x1177));}else{(
$__clientSupportsAgentMode=(0x1db2+  13-0x1dbf));}}}sub isClientSupportAgentMode
{return ($__clientSupportsAgentMode);}sub setIfClientSupportsNxpasswordService{
if (isClientVersionGreaterOrEqual ((0x072d+ 6897-0x2219),(0x0a15+ 6065-0x21c5),
(0x0e2b+ 1312-0x133f))){($__clientSupportsNxpasswordService=
(0x09e0+ 6644-0x23d3));}else{($__clientSupportsNxpasswordService=
(0x036c+ 6644-0x1d60));}}sub isClientSupportingNxpasswordService{return (
$__clientSupportsNxpasswordService);}sub setIfClientSupportsPropertyRequest{if (
isClientVersionGreaterOrEqual ((0x1418+ 223-0x14f3))){(
$__clientSupportsPropertyRequest=(0x160c+ 1211-0x1ac6));}else{(
$__clientSupportsPropertyRequest=(0x0fe1+ 1875-0x1734));}}sub 
isClientSupportingPropertyRequest{return ($__clientSupportsPropertyRequest);}sub
 setIfClientSupportsOsInfo{if (isClientVersionGreaterOrEqual (
(0x2147+ 966-0x2509))){($__clientSupportsOsInfo=(0x1714+ 1431-0x1caa));}else{(
$__clientSupportsOsInfo=(0x0203+ 2924-0x0d6f));}}sub isClientSupportingOsInfo{
return ($__clientSupportsOsInfo);}sub setIfClientSupportsListHistory{if (
isClientVersionGreaterOrEqual ((0x18db+ 1134-0x1d45))){(
$__clientSupportsListHistory=(0x0150+ 4263-0x11f6));}else{(
$__clientSupportsListHistory=(0x14c6+ 140-0x1552));}}sub 
isClientSupportingListHistory{return ($__clientSupportsListHistory);}sub 
setIfClientSupportsExtendedServices{if (isClientVersionGreaterOrEqual (
(0x05f0+ 3541-0x13c1),(0x06cd+ 2787-0x11af))){($__clientSupportsExtendedServices
=(0x04dd+ 6227-0x1d2f));}else{($__clientSupportsExtendedServices=
(0x0ae1+ 5762-0x2163));}}sub isClientSupportingExtendedServices{return (
$__clientSupportsExtendedServices);}sub setIfClientIsVersion3OrOlder{if (
isClientVersionLesserOrEqual ((0x01d4+ 141-0x025e))){($__clientVersion3OrOlder=
(0x01b6+ 4348-0x12b1));}else{($__clientVersion3OrOlder=(0x150b+ 2854-0x2031));}}
sub isClientVersion3OrOlder{return ($__clientVersion3OrOlder);}sub 
setIfClientIsVersion7OrOlder{if (isClientVersionLesserOrEqual (
(0x1de7+ 471-0x1fb7))){($__clientVersion7OrOlder=(0x1225+ 1147-0x169f));}else{(
$__clientVersion7OrOlder=(0x01d3+ 348-0x032f));}}sub isClientVersion7OrOlder{
return ($__clientVersion7OrOlder);}sub setIfClientSupportsPlatformParameters{if 
(isClientVersionGreaterOrEqual ((0x0e77+ 3778-0x1d35),(0x13c2+ 768-0x16c2),
(0x0f57+ 4913-0x21cd))){($__clientSupportsPlatformParameters=
(0x0ac7+ 2414-0x1434));}else{($__clientSupportsPlatformParameters=
(0x0344+ 7755-0x218f));}}sub isClientSupportingPlatformParameters{return (
$__clientSupportsPlatformParameters);}sub setIfClientSupportsKbtypeParameter{if 
(isClientVersion ((0x1d10+ 1081-0x2148))){($__clientSupportsKbtypeParameter=
(0x15ef+ 4348-0x26ea));}else{($__clientSupportsKbtypeParameter=
(0x1c5c+ 265-0x1d65));}}sub isClientSupportingKbtypeParameter{return (
$__clientSupportsKbtypeParameter);}sub setIfClientSupportsFakeAuthentication{if 
((isClientVersionLesserOrEqual ((0x040a+ 6659-0x1e0c))and 
isClientVersionGreaterOrEqual ((0x0864+ 3672-0x16bb),(0x01bd+ 2669-0x0c25)))){(
$__clientSupportsFakeAuthentication=(0x00fa+ 4901-0x141e));}else{(
$__clientSupportsFakeAuthentication=(0x07b1+  94-0x080f));}}sub 
isClientSupportingFakeAuthentication{return ($__clientSupportsFakeAuthentication
);}sub setIfClientSupportsDynamicColumnWidth{if (isClientVersionLesserOrEqual (
(0x16ec+ 3358-0x2407))){($__clientSupportsDynamicColumnWidth=
(0x048a+ 1274-0x0984));}}sub isClientSupportingDynamicColumnWidth{return (
$__clientSupportsDynamicColumnWidth);}sub setIfClientSupportsSha256{if (
isClientVersionLesserOrEqual ((0x0659+ 3143-0x129b),(0x009d+ 5014-0x1433),
(0x1094+ 708-0x134b))){($__clientSupportsSha256=(0x02e3+ 5108-0x16d7));}else{(
$__clientSupportsSha256=(0x0525+ 7933-0x2421));}}sub isClientSupporingSha256{
return ($__clientSupportsSha256);}sub setIfClientSupportsHelloWithAdmin{if ((
isClientNxclient ()or isClientNxwebclient ())){if (isClientVersionGreaterOrEqual
 ((0x19df+ 2313-0x22e3),(0x0cf3+ 5176-0x212b),(0x0569+ 1048-0x096c))){(
$__clientSupportsHelloWithAdmin=(0x07d2+ 6507-0x213c));}}else{(
$__clientSupportsHelloWithAdmin=(0x1265+ 4119-0x227c));}}sub 
isClientSupportingHelloWithAdmin{if (($__clientSupportsHelloWithAdmin==
(0x0704+ 1532-0x0cff))){return ((0x0cf9+ 5389-0x2205));}return (
(0x07dd+ 7612-0x2599));}sub setIfClientSupportingEncodedUserInHello{if ((
isClientNxclient ()or isClientNxwebclient ())){if (isClientVersionGreaterOrEqual
 ((0x0112+ 1834-0x0834),(0x09f8+ 1739-0x10c3),(0x0aff+ 266-0x0b69))){(
$__clientSupportingEncodedUserInHello=(0x1416+ 1595-0x1a50));}}else{(
$__clientSupportingEncodedUserInHello=(0x027d+ 4693-0x14d2));}}sub 
isClientSupportingEncodedUserInHello{if (($__clientSupportingEncodedUserInHello
==(0x0716+ 4340-0x1809))){return ((0x024b+ 3070-0x0e48));}return (
(0x1233+ 5193-0x267c));}sub setDownwardCompatibilitySudoVerification{if (
isClientNxserver ()){if (isClientVersionGreaterOrEqual ((0x196a+ 2307-0x2268),
(0x0369+ 3527-0x1130),(0x00b9+ 1708-0x0744))){(
$__downwardCompatibilitySudoVerification=(0x0878+ 3643-0x16b3));}}}sub 
isDownwardCompatibilitySudoVerification{return (
$__downwardCompatibilitySudoVerification);}sub 
setDownwardCompatibilityEmptyCommand{if (isClientNxserver ()){if (
isClientVersionGreaterOrEqual ((0x10d0+ 624-0x133b),(0x228d+   4-0x2291),
(0x12e9+ 3715-0x214b))){($__downwardCompatibilityEmptyCommand=
(0x0273+ 2324-0x0b87));}}}sub isDownwardCompatibilityEmptyCommand{return (
$__downwardCompatibilityEmptyCommand);}sub isClientVersion{(my $major=shift (@_)
);(my $minor=shift (@_));(my $patch=shift (@_));if ((not (isClientVersionSet ())
)){return ((0x02e8+ 2339-0x0c0b));}if ((not (defined ($major)))){Logger::debug (
"\x55\x73\x65\x6c\x65\x73\x73\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);return ((0x0147+ 1267-0x0639));}elsif ((not (defined ($minor)))){($minor=
"\x61\x6e\x79");($patch="\x61\x6e\x79");}elsif ((not (defined ($patch)))){(
$patch="\x61\x6e\x79");}if (($major==$__clientMajorVersion)){if (($minor eq 
"\x61\x6e\x79")){return ((0x0104+ 8692-0x22f7));}if (($minor==
$__clientMinorVersion)){if ((($patch eq "\x61\x6e\x79")or ($patch==
$__clientPatchVersion))){return ((0x0a83+ 1263-0x0f71));}}}return (
(0x003f+ 5550-0x15ed));}sub isClientVersionGreaterOrEqual{(my $major=shift (@_))
;(my $minor=shift (@_));(my $patch=shift (@_));if ((not (isClientVersionSet ()))
){return ((0x0688+ 356-0x07ec));}if ((not (defined ($major)))){Logger::debug (
"\x55\x73\x65\x6c\x65\x73\x73\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);return ((0x16cb+ 3716-0x254e));}elsif ((not (defined ($minor)))){($minor=
"\x61\x6e\x79");($patch="\x61\x6e\x79");}elsif ((not (defined ($patch)))){(
$patch="\x61\x6e\x79");}if (($__clientMajorVersion>$major)){return (
(0x11eb+ 5143-0x2601));}if (($__clientMajorVersion==$major)){if ((($minor eq 
"\x61\x6e\x79")or ($__clientMinorVersion>$minor))){return ((0x0519+ 5012-0x18ac)
);}if (($__clientMinorVersion==$minor)){if ((($patch eq "\x61\x6e\x79")or (
$__clientPatchVersion>=$patch))){return ((0x0024+ 9291-0x246e));}}}return (
(0x0ff2+ 1359-0x1541));}sub isClientVersionLesserOrEqual{(my $major=shift (@_));
(my $minor=shift (@_));(my $patch=shift (@_));if ((not (isClientVersionSet ())))
{return ((0x1567+ 1716-0x1c1b));}if ((not (defined ($major)))){Logger::debug (
"\x55\x73\x65\x6c\x65\x73\x73\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);return ((0x20ea+ 1167-0x2578));}elsif ((not (defined ($minor)))){($minor=
"\x61\x6e\x79");($patch="\x61\x6e\x79");}elsif ((not (defined ($patch)))){(
$patch="\x61\x6e\x79");}if (($__clientMajorVersion<$major)){return (
(0x039d+ 822-0x06d2));}if (($__clientMajorVersion==$major)){if ((($minor eq 
"\x61\x6e\x79")or ($__clientMinorVersion<$minor))){return ((0x0b43+ 699-0x0dfd))
;}if (($__clientMinorVersion==$minor)){if ((($patch eq "\x61\x6e\x79")or (
$__clientPatchVersion<=$patch))){return ((0x164c+ 3015-0x2212));}}}return (
(0x007c+ 1969-0x082d));}sub isClientNxclient{if (($__clientName eq 
"\x6e\x78\x63\x6c\x69\x65\x6e\x74")){return ((0x0109+ 7711-0x1f27));}else{return
 ((0x0ad2+ 1125-0x0f37));}}sub isClientNxserver{if (($__clientName eq 
"\x6e\x78\x73\x65\x72\x76\x65\x72")){return ((0x1521+ 2510-0x1eee));}else{return
 ((0x0d18+ 1238-0x11ee));}}sub isClientNxwebclient{if (($__clientName eq 
"\x6e\x78\x77\x65\x62\x63\x6c\x69\x65\x6e\x74")){return ((0x0a6a+ 1592-0x10a1));
}else{return ((0x24c6+ 328-0x260e));}}sub isClientNxmanager{if (($__clientName 
eq "\x6e\x78\x6d\x61\x6e\x61\x67\x65\x72")){return ((0x05ff+ 896-0x097e));}else{
return ((0x1c98+ 780-0x1fa4));}}sub isClientNameSet{if ((($__clientName eq 
"\x6e\x6f\x74\x73\x65\x74")or ($__clientName eq ("")))){return (
(0x2271+ 617-0x24da));}return ((0x13b0+ 3598-0x21bd));}sub isClientVersionSet{if
 ((((((($__clientMajorVersion eq "\x6e\x6f\x74\x73\x65\x74")or (
$__clientMajorVersion eq ("")))or ($__clientMinorVersion eq 
"\x6e\x6f\x74\x73\x65\x74"))or ($__clientMinorVersion eq ("")))or (
$__clientPatchVersion eq "\x6e\x6f\x74\x73\x65\x74"))or ($__clientPatchVersion 
eq ("")))){return ((0x16b7+ 2029-0x1ea4));}return ((0x06d9+ 2682-0x1152));}sub 
setClientName{($__clientName=shift (@_));($GLOBAL::CLIENT_NAME=$__clientName);}
sub setMainServerClientName{($__mainServerClientName=shift (@_));}sub 
setClientMajorVersion{($__clientMajorVersion=shift (@_));(
$GLOBAL::CLIENT_MAJOR_VERSION=$__clientMajorVersion);}sub setClientMinorVersion{
($__clientMinorVersion=shift (@_));($GLOBAL::CLIENT_MINOR_VERSION=
$__clientMinorVersion);}sub setClientPatchVersion{($__clientPatchVersion=shift (
@_));($GLOBAL::CLIENT_PATCH_VERSION=$__clientPatchVersion);}sub setClientBrowser
{($__clientBrowser=shift (@_));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x3a\x73\x65\x74\x43\x6c\x69\x65\x6e\x74\x42\x72\x6f\x77\x73\x65\x72\x3a\x20"
.$__clientBrowser)."\x2e"));}sub getClientBrowser{return ($__clientBrowser);}sub
 setClientPlatform{($__clientPlatform=shift (@_));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x3a\x73\x65\x74\x43\x6c\x69\x65\x6e\x74\x50\x6c\x61\x74\x66\x6f\x72\x6d\x3a\x20"
.$__clientPlatform)."\x2e"));}sub getClientPlatform{return ($__clientPlatform);}
sub getClientName{return ($__clientName);}sub getMainServerClientName{
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4d\x61\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x63\x6c\x69\x65\x6e\x74\x20\x6e\x61\x6d\x65\x20\x27"
.$__mainServerClientName)."\x27\x2e"));return ($__mainServerClientName);}sub 
getClientMajorVersion{return ($__clientMajorVersion);}sub getClientMinorVersion{
return ($__clientMinorVersion);}sub getClientPatchVersion{return (
$__clientPatchVersion);}sub getClientVersion{(my $client=((((
getClientMajorVersion ()."\x2e").getClientMinorVersion ())."\x2e").
getClientPatchVersion ()));return ($client);}sub setEncodeUsernameForClient{(
$__encodeUsernameForClient=(0x05f1+ 4536-0x17a8));}sub encodeUsernameForClient{
if (($__encodeUsernameForClient==(0x1818+ 3388-0x2553))){return (
(0x2036+ 485-0x221a));}return ((0x059a+ 3009-0x115b));}sub 
setDecodeUsernameFromClient{($__decodeUsernameFromClient=(0x0a67+ 5252-0x1eea));
}sub decodeUsernameFromClient{if (($__decodeUsernameFromClient==
(0x089a+ 4991-0x1c18))){return ((0x0402+ 2366-0x0d3f));}return (
(0x059f+ 8060-0x251b));}sub setSessionRealConnected{($__sessionRealConnecter=
shift (@_));}sub removeSessionRealConnected{($__sessionRealConnecter=(""));}sub 
isSessionRealConnected{(my $sessionID=shift (@_));if (($__sessionRealConnecter 
eq $sessionID)){return ((0x1054+ 1436-0x15ef));}return ((0x0244+ 4754-0x14d6));}
sub saveTimestamp{(my $id=shift (@_));(my $caption=shift (@_));(my ($sec,
$microsec)=Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=
sprintf ("\x25\x30\x36\x64",$microsec));($milisec=substr ($milisec,
(0x1ac3+ 1012-0x1eb7),(0x1bbf+ 1391-0x212b)));Logger::debug2 (((((((
"\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x27".$caption).
"\x27\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x61\x74\x20\x27").$sec).
"\x2c").$milisec)."\x27"));($$__timestamps{$id}={});($$__timestamps{$id}{
"\x63\x61\x70\x74\x69\x6f\x6e"}=$caption);($$__timestamps{$id}{
"\x73\x74\x61\x72\x74\x53\x65\x63\x6f\x6e\x64\x73"}=$sec);($$__timestamps{$id}{
"\x73\x74\x61\x72\x74\x4d\x69\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73"}=$milisec);}
sub getTimePassedFromSavedTimestamp{(my $id=shift (@_));if ((not (defined (
$$__timestamps{$id})))){return ((0x0614+ 3495-0x13bb));}(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));($milisec=substr ($milisec,(0x03ef+ 8653-0x25bc),
(0x1acb+ 1202-0x1f7a)));(my $startSeconds=$$__timestamps{$id}{
"\x73\x74\x61\x72\x74\x53\x65\x63\x6f\x6e\x64\x73"});(my $startMiliseconds=
$$__timestamps{$id}{
"\x73\x74\x61\x72\x74\x4d\x69\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73"});(my $liveTimeSeconds
=($sec-$startSeconds));(my $liveTimeMiliseconds=($milisec-$startMiliseconds));if
 (($liveTimeMiliseconds<(0x2277+ 111-0x22e6))){($liveTimeMiliseconds=(
$liveTimeMiliseconds+(0x12cf+ 656-0x1177)));($liveTimeSeconds=($liveTimeSeconds-
(0x031b+ 2400-0x0c7a)));}($liveTimeMiliseconds=sprintf ("\x25\x30\x33\x64",
$liveTimeMiliseconds));if (($liveTimeMiliseconds eq "\x30\x30\x30")){(
$liveTimeMiliseconds=(0x1084+ 2549-0x1a79));}(my $liveTime=(($liveTimeSeconds.
"\x2e").$liveTimeMiliseconds));Logger::debug (((
"\x54\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x27".$$__timestamps{$id}{
"\x63\x61\x70\x74\x69\x6f\x6e"}).((
"\x27\x20\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x65\x64\x20\x27".$liveTime).
"\x27\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e\x20")));delete ($$__timestamps{$id});
return ($liveTime);}sub setIfClientSupportsNodeAndLabelParameter{if (
isClientVersionGreaterOrEqual ((0x09dd+ 3088-0x15e9),(0x17dd+ 1861-0x1f1e),
(0x1238+ 4989-0x25ac))){($__clientSupportsNodeAndLabelParameter=
(0x15f3+ 1874-0x1d44));}else{($__clientSupportsNodeAndLabelParameter=
(0x13ba+ 773-0x16bf));}}sub isClientSupportingNodeAndLabelParameter{if ((
$__clientSupportsNodeAndLabelParameter==(0x0ac9+ 4950-0x1e1e))){return (
(0x0638+ 7394-0x2319));}return ((0x185c+ 441-0x1a15));}sub 
setIfClientSupportsNodeAndStatusParameter{if (isClientVersionGreaterOrEqual (
(0x0e29+ 5047-0x21da),(0x0fc6+ 1721-0x167f),(0x0ac1+ 2830-0x15a9))){(
$__clientSupportsNodeAndStatusParameter=(0x1197+ 2579-0x1ba9));}else{(
$__clientSupportsNodeAndStatusParameter=(0x23ca+ 303-0x24f9));}}sub 
isClientSupportingNodeAndStatusParameter{if ((
$__clientSupportsNodeAndStatusParameter==(0x0e28+ 5047-0x21de))){return (
(0x0b81+ 3359-0x189f));}return ((0x12b5+ 100-0x1319));}sub 
setIfClientSupportsDialogInConnectionPolicy{if (isClientVersionGreaterOrEqual (
(0x1a9c+ 1861-0x21dd),(0x13df+ 3171-0x203e),(0x0601+ 5910-0x1d0d))){(
$__clientSupportsDialogInConnectionPolicy=(0x1399+ 4081-0x2389));}else{(
$__clientSupportsDialogInConnectionPolicy=(0x0226+ 247-0x031d));}}sub 
isClientSupportingDialogInConnectionPolicy{if ((
$__clientSupportsDialogInConnectionPolicy==(0x15f5+  73-0x163d))){return (
(0x0bf2+ 3551-0x19d0));}return ((0x0dcd+ 1927-0x1554));}sub 
setIfClientSupportsSystemDesktopsInConnectionPolicy{if (
isClientVersionGreaterOrEqual ((0x0d1a+ 6009-0x248c),(0x09c1+ 928-0x0d61),
(0x1acd+ 1041-0x1e75))){($__clientSupportsSystemDesktopsInConnectionPolicy=
(0x0a92+ 2769-0x1562));}else{($__clientSupportsSystemDesktopsInConnectionPolicy=
(0x102f+ 2077-0x184c));}}sub isClientSupportsSystemDesktopsInConnectionPolicy{if
 (($__clientSupportsSystemDesktopsInConnectionPolicy==(0x18a3+ 3366-0x25c8))){
return ((0x19e7+ 3223-0x267d));}return ((0x06d8+ 417-0x0879));}sub 
setIfClientSupportsNxFrameBufferFeature{if (isClientVersionGreaterOrEqual (
(0x0698+ 4685-0x18e0),(0x073d+ 3766-0x15f3),(0x07c4+ 1653-0x0e25))){(
$__clientSupportsNxFrameBufferFeature=(0x22db+ 258-0x23dc));}else{(
$__clientSupportsNxFrameBufferFeature=(0x00b6+ 2037-0x08ab));}}sub 
isClientSupportingNxFrameBufferFeature{if ((
$__clientSupportsNxFrameBufferFeature==(0x0af4+ 1754-0x11cd))){return (
(0x1831+ 1296-0x1d40));}return ((0x0b92+ 6551-0x2529));}sub 
getDisconnectedSessionExpiryLimitValue{if ((($GLOBAL::DisconnectedSessionExpiry 
eq "\x6e\x6f\x74\x53\x65\x74")or ($GLOBAL::DisconnectedSessionExpiry eq ("")))){
if ((main::imRemoteServer ()and 
NXSessionParameters::isMainServerDisconnectedSessionExpiryKeySet ())){return (
NXSessionParameters::getMainServerDisconnectedSessionExpiryLimitValue ());}else{
return ((0x04a8+ 4726-0x171e));}}else{return ($GLOBAL::DisconnectedSessionExpiry
);}}sub isDisconnectedSessionExpiryKeySet{if (
getDisconnectedSessionExpiryLimitValue ()){return ((0x0e2c+ 3519-0x1bea));}else{
return ((0x0e30+ 2007-0x1607));}}sub setIfClientSupportsDesktopViewMode{if (
isClientVersionGreaterOrEqual ((0x0984+ 3223-0x1617),(0x00b7+ 8019-0x2005),
(0x0131+ 3736-0x0fc8))){($__clientSupportsDesktopViewMode=(0x0012+ 1655-0x0688))
;}else{($__clientSupportsDesktopViewMode=(0x1883+ 985-0x1c5c));}}sub 
isClientSupportDesktopViewMode{if (($__clientSupportsDesktopViewMode==
(0x1497+ 1026-0x1898))){return ((0x1b84+ 987-0x1f5e));}return (
(0x134f+ 4301-0x241c));}sub setIfClientSupportsProxyPacketPriority{if (
isClientVersionGreaterOrEqual ((0x021c+ 5971-0x196a),(0x0581+ 7777-0x23e2),
(0x1e3f+   9-0x1e27))){($__clientSupportsProxyPacketPriority=
(0x0036+ 8509-0x2172));}}sub isClientSupportingProxyPacketPriority{return (
$__clientSupportsProxyPacketPriority);}sub 
setIfClientSupportsManualNodeSelection{if (isClientVersionGreaterOrEqual (
(0x0a87+ 4436-0x1bd7))){($__clientSupportsManualNodeSelection=
(0x134c+ 4097-0x234c));}}sub isClientSupportsManualNodeSelection{return (
$__clientSupportsManualNodeSelection);}sub waitForNetlogonServiceIfNeeded{if ((
$GLOBAL::NetLogonDependency==(0x026d+ 4105-0x1276))){Logger::debug (
"\x43\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x65\x20\x74\x75\x72\x6e\x65\x64\x20\x6f\x66\x66\x2e"
);return ((0x0518+ 8406-0x25ed));}(my $notifyAboutWaitingForNetLogonRunningSent=
(0x1e45+ 920-0x21dc));while ((0x0434+ 4037-0x13f8)){(my $state=
libnxhs::NXIsWinDomainLogon ());Logger::debug (((
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x53\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x65\x20\x69\x73\x20\x27"
.$state)."\x27\x2e"));if (($state==(-(0x00d6+ 1013-0x04ca)))){
Common::NXCore::reportErrorFromNXPL (
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x49\x73\x57\x69\x6e\x44\x6f\x6d\x61\x69\x6e\x4c\x6f\x67\x6f\x6e\x20\x66\x61\x69\x6c\x65\x64\x2e"
);return ((0x12b4+ 4709-0x2519));}elsif (($state==(0x0d53+ 6479-0x26a2))){
Logger::debug (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x6f\x74\x20\x69\x6e\x73\x74\x61\x6c\x6c\x65\x64\x2e"
);return ((0x1974+ 3273-0x263c));}elsif (($state==(0x05d4+ 2265-0x0eac))){
Logger::debug (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
);return ((0x11fa+ 673-0x149b));}elsif (((($state==(0x124b+ 3650-0x208b))or (
$state==(0x021d+ 4747-0x14a3)))or ($state==(0x0641+ 4695-0x1891)))){if ((
$notifyAboutWaitingForNetLogonRunningSent==(0x2181+ 706-0x2442))){
Logger::warning (
"\x57\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x74\x61\x72\x74\x20\x6f\x66\x20\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x2e"
);if (($state==(0x0066+ 3570-0x0e56))){NXMsg::send_response (
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x53\x65\x72\x76\x69\x63\x65\x73"
,"\x53\x65\x72\x76\x65\x72","\x73\x74\x61\x72\x74\x65\x64");}elsif (($state==
(0x1193+ 3289-0x1e67))){NXMsg::send_response (
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x65\x74\x4c\x6f\x67\x6f\x6e\x54\x6f\x53\x74\x61\x72\x74"
,"\x53\x65\x72\x76\x65\x72","\x72\x65\x73\x75\x6d\x65\x64");}else{
NXMsg::send_response (
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x65\x74\x4c\x6f\x67\x6f\x6e\x54\x6f\x53\x74\x61\x72\x74"
,"\x53\x65\x72\x76\x65\x72","\x70\x61\x75\x73\x65\x64");}(
$notifyAboutWaitingForNetLogonRunningSent=(0x0086+ 2729-0x0b2f));}main::nxsleep 
((0x0716+ 7834-0x25ad));}elsif (($state==(0x00fd+ 488-0x02e2))){Logger::error (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x6f\x70\x70\x69\x6e\x67\x2c\x20\x6e\x65\x65\x64\x20\x6d\x61\x6e\x75\x61\x6c\x20\x73\x74\x61\x72\x74\x75\x70\x20\x6f\x66\x20\x73\x65\x72\x76\x69\x63\x65\x2e"
);return ((0x0ad3+ 2191-0x1362));}elsif (($state==(0x06ed+ 1251-0x0bcc))){
Logger::debug (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);return ((0x00a3+ 685-0x034f));}elsif (($state==(0x11b8+ 5435-0x26ed))){
Logger::error (
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x73\x65\x72\x76\x69\x63\x65\x20\x70\x61\x75\x73\x65\x64\x2c\x20\x6e\x65\x65\x64\x20\x6d\x61\x6e\x75\x61\x6c\x20\x63\x6f\x6e\x74\x69\x6e\x75\x65\x20\x6f\x66\x20\x73\x65\x72\x76\x69\x63\x65\x2e"
);return ((0x0525+ 928-0x08c5));}else{Logger::error (((
"\x4e\x65\x74\x6c\x6f\x67\x6f\x6e\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x73\x74\x61\x74\x75\x73\x20"
.$state)."\x2e"));return ((0x0067+ 5163-0x1492));}}}sub setIsUdpConnection{(
$__udpConnection=(0x0da6+ 3792-0x1c75));}sub isUdpConnection{return (
$__udpConnection);}sub setFutureMainSession{($__futureMainSession=shift (@_));}
sub getFutureMainSession{return ($__futureMainSession);}sub setServerIsRestart{(
$__serverIsRestartServer=(0x13d4+ 827-0x170e));}sub isServerRestart{return (
$__serverIsRestartServer);}sub setServerIsShutdown{($__serverIsShutdownServer=
(0x1030+ 4860-0x232b));}sub isServerShutdown{return ($__serverIsShutdownServer);
}sub serverIsNotSessionServer{if (isServerShutdown ()){return (
(0x25b9+  83-0x260b));}return ((0x197b+ 1913-0x20f4));}sub isRedirectSupported{
if (isClientSupportingRedirecting ()){return ((0x1165+ 470-0x133a));}return (
(0x1fd8+ 1055-0x23f7));}sub getHostnameForPropertyRequest{(my $hostInfo=
Common::NXInfo::getHostInfo ());return (Common::NXCore::urlencode ($hostInfo));}
sub setIfClientIsSupportingDynamicFieldSizesInSessionList{if (((not (
isClientNxclient ()))or isClientVersionGreaterOrEqual ((0x1436+ 949-0x17e6),
(0x1c77+ 1482-0x2241),(0x04f4+ 3944-0x142c)))){(
$__clientSupportsDynamicFieldSizesInSessionList=(0x1263+ 1561-0x187b));}else{(
$__clientSupportsDynamicFieldSizesInSessionList=(0x074d+ 7465-0x2476));}}sub 
isClientSupportingDynamicFieldSizesInSessionList{return (
$__clientSupportsDynamicFieldSizesInSessionList);}sub 
isClientSupportingClientMenuConfiguration{return (
$__clientSupportingClientMenuConfiguration);}sub 
setIfClientSupportingClientMenuConfiguration{if (isClientNxserver ()){return (
(0x0a6a+ 4816-0x1d3a));}if (isClientVersionGreaterOrEqual ((0x04d9+ 3752-0x137c)
,(0x0712+ 2090-0x0f3b),(0x1b00+ 135-0x1b76))){(
$__clientSupportingClientMenuConfiguration=(0x0147+ 4440-0x129e));}}sub 
isClientSupportingSeparateUsersOnSessionList{return (
$__clientSupportingSeparateUsersOnSessionList);}sub 
setIfClientSupportingDisableCredentialsStoring{if ((
isClientVersionGreaterOrEqual ((0x025a+ 1997-0x0a22),(0x0e8c+  81-0x0edc),
(0x08d7+ 3718-0x1734))and (not (isClientNxserver ())))){(
$__clientSupportingDisableCredentialsStoring=(0x0c99+ 5056-0x2058));}else{(
$__clientSupportingDisableCredentialsStoring=(0x0a7f+ 1075-0x0eb2));}}sub 
isClientSupportingDisableCredentialsStoring{return (
$__clientSupportingDisableCredentialsStoring);}sub 
setIfClientSupportingSeparateUsersOnSessionList{if (
isClientVersionGreaterOrEqual ((0x0e9c+ 5309-0x2354),(0x1ac3+ 1949-0x225f),
(0x06f3+ 3455-0x1452))){($__clientSupportingSeparateUsersOnSessionList=
(0x0600+ 8360-0x26a7));}else{($__clientSupportingSeparateUsersOnSessionList=
(0x043c+ 332-0x0588));}}sub setDaemonProcess{($__serverIsDaemon=
(0x1243+ 759-0x1539));}sub isDaemonProcess{return ($__serverIsDaemon);}sub 
isAdministrator{if (NXLogin::isAuthenticated ()){return (
NXLogin::isAdministrator ());}else{return (main::effectiveUserIsAdministrator ()
);}}sub setIfClientSupportsExpiredPasswordChange{if (
isClientVersionGreaterOrEqual ((0x08aa+ 3036-0x1481),(0x168c+ 252-0x1787),
(0x0940+ 6937-0x244e))){($__clientSupportsExpiredPasswordChange=
(0x0713+ 7767-0x2569));}else{($__clientSupportsExpiredPasswordChange=
(0x02a7+ 969-0x0670));}}sub isClientSupportsExpiredPasswordChange{return (
$__clientSupportsExpiredPasswordChange);}sub setIfClientSupportsDuoAuth{if (
isClientVersionGreaterOrEqual ((0x11ac+ 4808-0x246e),(0x019a+ 6452-0x1ac9),
(0x21ec+ 573-0x2428))){($__clientSupportDuoAuth=(0x20d2+ 671-0x2370));}else{(
$__clientSupportDuoAuth=(0x0a0c+ 509-0x0c09));}}sub isClientSupportsDuoAuth{
return ($__clientSupportDuoAuth);}sub setClientSupportsNoMachineTwoFactor{(
$__clientSupportNoMachineNetworkTwoFactor=(0x0951+ 5349-0x1e36));if ((
isClientNxclient ()and isClientVersionGreaterOrEqual ((0x0dfd+  15-0x0e05),
(0x1dc2+ 1814-0x24d8),(0x1acc+ 1743-0x2109)))){(
$__clientSupportNoMachineNetworkTwoFactor=(0x21bc+  30-0x21d9));}}sub 
isClientSupportsNoMachineTwoFactor{return (
$__clientSupportNoMachineNetworkTwoFactor);}sub 
setIfClientSupportsIgnoreSessionTypeForListSession{if (
isClientVersionLesserOrEqual ((0x0bd7+ 3451-0x194f),(0x0fb3+ 3996-0x1f4a),
(0x0fb9+  51-0x0fec))){($__clientSupportsIgnoreSessionTypeForListSession=
(0x000a+ 3931-0x0f64));}else{($__clientSupportsIgnoreSessionTypeForListSession=
(0x0aa5+ 1831-0x11cc));}}sub isClientSupportsIgnoreSessionTypeForListSession{
return ($__clientSupportsIgnoreSessionTypeForListSession);}sub 
setIfClientSupportsPackedMessages{if ((isClientNxserver ()and 
isClientVersionGreaterOrEqual ((0x1ac6+ 1050-0x1eda),(0x0be6+  99-0x0c49),
(0x0417+ 913-0x078b)))){($__clientSupportsPackedMessages=(0x0ba0+ 3935-0x1afe));
}else{($__clientSupportsPackedMessages=(0x0170+ 7365-0x1e35));}}sub 
setClientSupportsPackedMessages{($__clientSupportsPackedMessages=
(0x0024+ 4151-0x105a));}sub isClientSupportsPackedMessages{return (
$__clientSupportsPackedMessages);}sub setIfClientSupportsTranslatedMessages{if (
(not (isClientNxserver ()))){($__clientSupportsTranslatedMessages=
(0x19ac+ 3253-0x2660));}else{($__clientSupportsTranslatedMessages=
(0x13cf+ 2729-0x1e78));}}sub isClientSupportsTranslatedMessages{return (
$__clientSupportsTranslatedMessages);}sub 
setIfClientSupportsErrorDuringPasswordChange{if (isClientVersionGreaterOrEqual (
(0x08db+ 7297-0x2556),(0x1a0b+ 2010-0x21e5),(0x0056+ 5101-0x1422))){(
$__clientSupportsErrorDuringPasswordChange=(0x0aa3+ 5128-0x1eaa));}else{(
$__clientSupportsErrorDuringPasswordChange=(0x052b+ 4564-0x16ff));}}sub 
isClientSupportsErrorDuringPasswordChange{return (
$__clientSupportsErrorDuringPasswordChange);}sub 
setIfClientSupportsPasswordRequest{if (((isClientNxclient ()and 
isClientVersionGreaterOrEqual ((0x19f0+ 2342-0x2310),(0x0fb2+ 2500-0x1974),
(0x00e0+ 4750-0x136e)))or isClientNxwebclient ())){(
$__clientSupportsPasswordRequest=(0x0383+ 5592-0x195a));}else{(
$__clientSupportsPasswordRequest=(0x0bfa+ 5045-0x1faf));}}sub 
isClientSupportsPasswordRequest{return ($__clientSupportsPasswordRequest);}sub 
setClientSupportsSeparateAuthInMultiServer{(
$__clientSupportsSeparateAuthInMultiServer=(0x09b4+ 1764-0x1098));if (
isClientVersionGreaterOrEqual ((0x1048+ 4462-0x21af),(0x0c33+ 6517-0x25a8),
(0x0c6a+ 5895-0x22ba))){($__clientSupportsSeparateAuthInMultiServer=
(0x0810+ 5826-0x1ed1));}}sub doesClientSupportSeparateAuthInMultiServer{return (
$__clientSupportsSeparateAuthInMultiServer);}sub 
setClientSupportsAuthRequiredNamedAsFurtherAuth{if ((not (
isClientVersionGreaterOrEqual ((0x11e8+ 995-0x15c3),(0x10d0+ 4039-0x2097),
(0x0540+ 4635-0x16fe))))){($__clientSupportsAuthRequiredNamedAsFurtherAuth=
(0x0f30+ 1894-0x1696));}}sub doesClientSupportsAuthRequiredNamedAsFurtherAuth{
return ($__clientSupportsAuthRequiredNamedAsFurtherAuth);}sub 
setClientSupportstServerListConnections{($__clientSupportsServerListConnections=
(0x1993+ 1728-0x2053));if (isClientVersionGreaterOrEqual ((0x09ef+ 4993-0x1d6a),
(0x12cb+ 1737-0x198a),(0x0501+ 5394-0x1a0c))){(
$__clientSupportsServerListConnections=(0x0485+ 4955-0x17df));}}sub 
doesClientSupportServerListConnections{return (
$__clientSupportsServerListConnections);}sub 
setIfClientSupportsAutomaticRecording{if (isClientVersionGreaterOrEqual (
(0x2124+ 733-0x23fa),(0x0520+ 1733-0x0be5),(0x0620+ 7592-0x2329))){(
$__clientSupportsAutomaticRecording=(0x05ef+ 5620-0x1be2));}else{(
$__clientSupportsAutomaticRecording=(0x06ab+ 2068-0x0ebf));}}sub 
isClientSupportingAutomaticRecording{if (($__clientSupportsAutomaticRecording==
(0x01c0+ 6601-0x1b88))){return ((0x18da+ 1522-0x1ecb));}return (
(0x081f+ 4508-0x19bb));}sub setClientSupportsAnywhereAuthMethods{if (((
isClientNxclient ()and isClientVersionGreaterOrEqual ((0x05a2+ 2475-0x0f46),
(0x0867+ 6938-0x2381),(0x16ac+ 4119-0x2638)))or isClientNxwebclient ())){(
$__clientSupportsAnywhereAuthMethods=(0x01b9+ 3473-0x0f49));}}sub 
isClientSupportsAnywhereAuthMethods{return ($__clientSupportsAnywhereAuthMethods
);}sub setClientSupportsCredentialsEncryption{if ((isClientNxwebclient ()and 
isClientVersionGreaterOrEqual ((0x0b85+ 3457-0x18ff),(0x2437+ 632-0x26af),
(0x03b3+ 3204-0x0fa7)))){($__clientSupportsCredentialsEncryption=
(0x0849+ 2439-0x11cf));}}sub isClientSupportsCredentialsEncryption{return (
$__clientSupportsCredentialsEncryption);}sub 
setIfClientSupportsSelectForwardMethod{if (isClientVersionGreaterOrEqual (
(0x1d50+ 1201-0x21fa),(0x0d79+ 4452-0x1edd),(0x0699+ 4103-0x15f8))){(
$__clientSupportSelectForwardMethod=(0x0592+ 1563-0x0bac));}}sub 
isClientSupportsSelectForwardMethod{return ($__clientSupportSelectForwardMethod)
;}sub isClientSupportingDesktopSharing{return ($__clientSupportsDesktopSharing);
}sub setIfClientSupportsDesktopSharing{if (isClientVersionGreaterOrEqual (
(0x1583+ 2629-0x1fc0),(0x11c7+ 3719-0x204e),(0x038d+ 7514-0x20d3))){
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x2e"
);($__clientSupportsDesktopSharing=(0x0107+ 9057-0x2467));return;}Logger::debug 
(
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x2e"
);($__clientSupportsDesktopSharing=(0x0b91+ 3464-0x1919));}sub 
isClientSupportsTerminateReason{return ($__clientSupportsTerminateReason);}sub 
setIfClientSupportsTerminateReason{if (isClientVersionGreaterOrEqual (
(0x1326+ 2637-0x1d6c),(0x1169+ 4793-0x2421),(0x01a0+ 2883-0x0cde))){(
$__clientSupportsTerminateReason=(0x04b5+ 152-0x054c));}}sub 
isClientSupportsSubserversNamedAsNodes{return (
$__clientSupportsSubserversNamedAsNodes);}sub 
setIfClientSupportsSubserversNamedAsNodes{if (isClientVersionLesserOrEqual (
(0x1704+ 309-0x1831),(0x10b3+ 1161-0x153c),(0x0b60+ 1325-0x1037))){(
$__clientSupportsSubserversNamedAsNodes=(0x0121+ 400-0x02b1));}else{(
$__clientSupportsSubserversNamedAsNodes=(0x0dc0+ 2019-0x15a2));}}sub 
isUseNodeAsSubserver{if ((isClientSupportsSubserversNamedAsNodes ()and 
NXLicense::isMultiServerFeature ())){return ((0x0f5a+ 2790-0x1a3f));}return (
(0x0552+ 4221-0x15cf));}sub setClientSupportsExpireDateStatus{if (
isClientVersionLesserOrEqual ((0x16dc+ 3602-0x24e7),(0x160c+ 1963-0x1db4),
(0x1f97+ 575-0x21d6))){($__clientSupportsExpireDateStatus=(0x1af3+ 2314-0x23fd))
;}else{($__clientSupportsExpireDateStatus=(0x1535+ 4277-0x25e9));}}sub 
setClientSupportsExpireInformation{if (isClientVersionLesserOrEqual (
(0x24b2+ 421-0x264f),(0x0a4f+ 1171-0x0ee2),(0x1060+ 1203-0x14a1))){(
$__clientSupportsExpireInformation=(0x2008+ 136-0x2090));}else{(
$__clientSupportsExpireInformation=(0x167d+ 1393-0x1bed));}}sub 
setClientSupportsMissingLicenseFileOrWrongAcronym{if (
isClientVersionLesserOrEqual ((0x0ed0+ 1001-0x12b1),(0x1716+ 3611-0x2531),
(0x0a76+ 5515-0x1f70))){($__clientSupportsMissingLicenseFileOrWrongAcronym=
(0x1a80+ 1329-0x1fb1));}else{($__clientSupportsMissingLicenseFileOrWrongAcronym=
(0x11e4+ 5297-0x2694));}}sub setClientSupportWrongPlatformLicenseInfo{if (
isClientVersionLesserOrEqual ((0x0b54+ 6168-0x2364),(0x091b+ 5995-0x2086),
(0x02c5+ 3748-0x10cb))){($__clientSupportWrongPlatformLicenseInfo=
(0x041b+ 532-0x062f));}else{($__clientSupportWrongPlatformLicenseInfo=
(0x06ea+ 6949-0x220e));}}sub setClientSupportNodeFlags{if (
isClientVersionLesserOrEqual ((0x03d4+ 8336-0x245c),(0x0dcd+ 1543-0x13d4),
(0x0fb2+ 1193-0x13b7))){($__clientSupportNodeFlags=(0x09f5+ 2101-0x122a));}else{
($__clientSupportNodeFlags=(0x089a+ 236-0x0985));}}sub 
setClientSupportsReportingAllConnections{if (isClientVersionLesserOrEqual (
(0x0507+ 3193-0x1178),(0x0da3+ 5086-0x2181),(0x1d06+ 838-0x1fba))){(
$__clientSupportsReportingAllConnections=(0x0455+ 5039-0x1804));}else{(
$__clientSupportsReportingAllConnections=(0x0460+ 2934-0x0fd5));}}sub 
setClientSupportsFileTransferInfomation{if (isClientVersionLesserOrEqual (
(0x0087+ 9373-0x251c),(0x0ce4+ 2549-0x16d9),(0x06ad+ 5116-0x1a16))){(
$__clientSupportsFileTransferInfomation=(0x0626+ 4193-0x1687));}else{(
$__clientSupportsFileTransferInfomation=(0x065c+ 5405-0x1b78));}}sub 
setClientSupportsPhysicalDestkopAndClusterInformation{if (
isClientVersionLesserOrEqual ((0x0bb3+ 5404-0x20c7),(0x0d72+ 5554-0x2324),
(0x18d8+ 2427-0x21bd))){($__clientSupportsPhysicalDekstopAndClusterInfo=
(0x0174+ 4402-0x12a6));}else{($__clientSupportsPhysicalDekstopAndClusterInfo=
(0x1f60+ 855-0x22b6));}}sub setClientSupportsGuestTypes{(
$__clientSupportsGuestTypes=(0x12c5+ 5132-0x26d1));}sub 
doesClientSupportGuestTypes{return ($__clientSupportsGuestTypes);}sub 
doesClientSupportsExpireDateStatus{return ($__clientSupportsExpireDateStatus);}
sub doesClientSupportsExpireInformation{return (
$__clientSupportsExpireInformation);}sub 
doesClientSupportWrongLicenseOrMissingFile{return (
$__clientSupportsMissingLicenseFileOrWrongAcronym);}sub 
doesClientSupportWrongPlatformLicenseInfo{return (
$__clientSupportWrongPlatformLicenseInfo);}sub doesClientSupportNodeFlags{return
 ($__clientSupportNodeFlags);}sub doesClientSupportsReportingAllConnections{
return ($__clientSupportsReportingAllConnections);}sub 
doesClientSupportsFileTransferInfomation{return (
$__clientSupportsFileTransferInfomation);}sub 
doesClientSupportsPhysicalDesktopRunningInformationAndClusterStats{return (
$__clientSupportsPhysicalDekstopAndClusterInfo);}sub 
setClientSupportsInverseParameter{($__clientSupportsInverseParameter=
(0x22af+  66-0x22f1));if (isClientVersionGreaterOrEqual ((0x0278+ 8360-0x2318),
(0x2452+  49-0x2483),(0x0680+ 2238-0x0ee1))){($__clientSupportsInverseParameter=
(0x014a+ 6897-0x1c3a));}}sub doesClientSupportInverseParameter{return (
$__clientSupportsInverseParameter);}sub setClientSupportsBrowseWithoutAuth{(
$__clientSupportsBrowseWithoutAuth=(0x0500+ 6051-0x1ca3));if (
isClientVersionGreaterOrEqual ((0x1c8d+ 956-0x2041),(0x00dd+ 165-0x0182),
(0x1295+ 834-0x1574))){($__clientSupportsBrowseWithoutAuth=(0x14c0+ 2882-0x2001)
);}}sub doesClientSupportBrowseWithoutAuth{return (
$__clientSupportsBrowseWithoutAuth);}sub setClientSupportsMdnsMonitor{(
$__clientSupportsMdnsMonitor=(0x15f4+ 2470-0x1f9a));if (
isClientVersionGreaterOrEqual ((0x1336+ 3744-0x21ce),(0x05bf+ 3416-0x1317),
(0x15b6+ 2438-0x1eb9))){($__clientSupportsMdnsMonitor=(0x09bd+ 2443-0x1347));}}
sub doesClientSupportMdnsMonitor{return ($__clientSupportsMdnsMonitor);}sub 
setClientSupportsCurrentNodeAddress{($__clientSupportsCurrentNodeAddress=
(0x0331+ 8975-0x2640));if (isClientVersionGreaterOrEqual ((0x0641+ 5959-0x1d80),
(0x0ad6+ 1214-0x0f94),(0x033b+ 842-0x05ea))){(
$__clientSupportsCurrentNodeAddress=(0x0af2+ 5290-0x1f9b));}}sub 
doesClientSupportCurrentNodeAddress{return ($__clientSupportsCurrentNodeAddress)
;}sub setClientSupportsAllowGuest{($__clientSupportsAllowGuest=
(0x1629+ 2232-0x1ee1));if (isClientVersionGreaterOrEqual ((0x0a31+ 3883-0x1954),
(0x0621+ 1403-0x0b9c),(0x13b8+ 3511-0x20d4))){($__clientSupportsAllowGuest=
(0x10ef+ 1080-0x1526));}}sub doesClientSupportAllowGuest{return (
$__clientSupportsAllowGuest);}sub setClientSupportsCustomUdpPort{(
$__clientSupportsCustomUdpPort=(0x1506+ 4413-0x2643));if (
isClientVersionGreaterOrEqual ((0x055d+ 4450-0x16b7),(0x0090+ 4329-0x1179),
(0x082a+ 2899-0x12e0))){($__clientSupportsCustomUdpPort=(0x114c+ 703-0x140a));}
return ((0x160d+ 4340-0x2700));}sub doesClientSupportCustomUdpPort{return (
$__clientSupportsCustomUdpPort);}sub sendMonitorOnMessage{(my $socket=shift (@_)
);(my $login=shift (@_));(my $name=shift (@_));(my $type=shift (@_));(my $sessionType
=shift (@_));Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x49\x6e\x69\x74\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);($login=NXLogin::getAbsoluteNameForUsernameIfNotDisabled ($login));
sendLocalRecordingValue ($socket,$login,$name);sendServerVersion ($socket);
sendPhysicaldesktopSharing ($socket,$login,$type,$sessionType);
sendFileTransferValue ($socket,$login,$name);my ($message);if ($type){($message=
(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ATTACHED_USER_MONITOR).
"\x20\x4d\x4f\x4e\x49\x54\x4f\x52\x20\x4f\x4e\x20\x74\x79\x70\x65\x3d").$type).
"\x20\x0a"));}else{($message=(("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ATTACHED_USER_MONITOR).
"\x20\x4d\x4f\x4e\x49\x54\x4f\x52\x20\x4f\x4e\x20\x74\x79\x70\x65\x3d\x6e\x6f\x44\x65\x73\x6b\x74\x6f\x70\x20\x0a"
));}(my $ret=NXNodeExec::sendToNode ($message,$socket));if ((($ret==(-
(0x05d8+ 3863-0x14ee)))or ($ret==(0x102c+ 3997-0x1fc9)))){Logger::warning (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$message)."\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2e"));}else{Logger::debug (((
"\x4d\x65\x73\x73\x61\x67\x65\x20\x27".$message).
"\x27\x20\x77\x61\x73\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2e"))
;}}sub sendLocalRecordingValue{(my $socket=shift (@_));(my $login=shift (@_));(my $name
=shift (@_));(my $localRec=undef);if (main::imRemoteServer ()){($localRec=
NXSessionParameters::getLocalRecording ());}if ((not (defined ($localRec)))){(
$localRec=NXProfilesManager::isLocalRecordingAvailableForUserAndNode ($login,
$name));}(my $ret=NXNodeExec::sendToNode (((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_LOCAL_RECORDING).
"\x20\x6c\x6f\x63\x61\x6c\x2d\x72\x65\x63\x6f\x72\x64\x69\x6e\x67\x20").
$localRec),$socket));if ((($ret==(-(0x135d+ 2421-0x1cd1)))or ($ret==
(0x1e62+ 1944-0x25fa)))){Logger::warning (((
"\x4c\x6f\x63\x61\x6c\x20\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x20"
.$localRec).
"\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"
));}else{Logger::debug (((
"\x4c\x6f\x63\x61\x6c\x20\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x20"
.$localRec)."\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"));}}sub 
sendServerVersion{(my $socket=shift (@_));(my $ret=NXNodeExec::sendToNode ((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_SERVER_VERSION).
"\x20\x73\x65\x72\x76\x65\x72\x2d\x76\x65\x72\x73\x69\x6f\x6e\x20").
main::urlencode ((($GLOBAL::PRODUCT_NAME."\x2c").$GLOBAL::SOFTWARE_RELEASE))),
$socket));if ((($ret==(-(0x22e3+ 496-0x24d2)))or ($ret==(0x07ef+ 3457-0x1570))))
{Logger::warning (((((
"\x53\x65\x72\x76\x65\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x3a\x20".
$GLOBAL::PRODUCT_NAME)."\x2c").$GLOBAL::SOFTWARE_RELEASE).
"\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"
));}else{Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x3a\x20".
$GLOBAL::PRODUCT_NAME)."\x2c").$GLOBAL::SOFTWARE_RELEASE).
"\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"));}}sub 
sendPhysicaldesktopSharing{(my $socket=shift (@_));(my $login=shift (@_));(my $type
=shift (@_));(my $sessionType=shift (@_));(my $session=getMySessionID ());
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$sessionType)."\x27\x2e"));if (defined ($type)){if (
Common::NXSessionType::isPhysical ($sessionType)){(my $physicalSharing=
(0x0ab0+ 3732-0x1943));if (NXLocalSession::isPhysicalDesktopAccessDisabledInCfg 
()){($physicalSharing=(0x07fa+ 3615-0x1619));}Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x27"
.$session).
"\x27\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x27").
$physicalSharing)."\x27\x2e"));if (($physicalSharing!=(0x0ac8+ 1990-0x128e))){(
$physicalSharing=NXUsersManager::isPhysicalDesktopSharingEnabled ($login));
Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x55\x73\x65\x72\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x27"
.$physicalSharing)."\x27\x2e"));}NXSession2::setDesktopShareValue ($session,
$physicalSharing);(my $ret=NXNodeExec::sendToNode (((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_DESKTOP_SHARING).
"\x20\x44\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3d"
).$physicalSharing),$socket));if ((($ret==(-(0x11b6+ 2305-0x1ab6)))or ($ret==
(0x0464+ 8203-0x246f)))){Logger::warning (((
"\x50\x68\x79\x73\x69\x63\x61\x6c\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$login).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x2e"
));}}else{(my $virtualSharing=(0x04da+ 4890-0x17f3));if (
NXSessionParameters::isVirtualDesktopAccessDisabledInCfg ()){($virtualSharing=
(0x0e35+ 5878-0x252b));}Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x56\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x27"
.$session).
"\x27\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x27").
$virtualSharing)."\x27\x2e"));(my $ret=NXNodeExec::sendToNode ((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_DESKTOP_SHARING).
"\x20\x44\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x3d"
).$virtualSharing),$socket));if ((($ret==(-(0x14d7+ 2237-0x1d93)))or ($ret==
(0x08ad+ 1349-0x0df2)))){Logger::warning (((
"\x56\x69\x72\x74\x75\x61\x6c\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$login).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x6e\x78\x6e\x6f\x64\x65\x2e"
));}NXSession2::setDesktopShareValue ($session,$virtualSharing);}}}sub 
sendFileTransferValue{(my $socket=shift (@_));(my $login=shift (@_));(my $name=
shift (@_));(my $fileTransfer=undef);if (main::imRemoteServer ()){($fileTransfer
=NXSessionParameters::getFileTransfer ());}if ((not (defined ($fileTransfer)))){
($fileTransfer=NXProfilesManager::isFileTransferAvailablePerUserAndNode ($login,
$name));}(my $ret=NXNodeExec::sendToNode (((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_FILE_TRANSFER).
"\x20\x66\x69\x6c\x65\x74\x72\x61\x6e\x73\x66\x65\x72\x20").$fileTransfer),
$socket));if ((($ret==(-(0x15e6+ 2225-0x1e96)))or ($ret==(0x18a2+ 1956-0x2046)))
){Logger::warning (((
"\x46\x69\x6c\x65\x20\x74\x72\x61\x6e\x73\x66\x65\x72\x20\x76\x61\x6c\x75\x65\x20"
.$fileTransfer).
"\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"
));}else{Logger::debug (((
"\x46\x69\x6c\x65\x20\x74\x72\x61\x6e\x73\x66\x65\x72\x20\x76\x61\x6c\x75\x65\x20"
.$fileTransfer)."\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65"));}}sub 
isSessionFile{return ($__isExistSessionFile);}sub setSessionFileCreated{(
$__isExistSessionFile=(0x0b39+ 3867-0x1a53));}sub setSessionFileRemoved{(
$__isExistSessionFile=(0x0aba+ 6953-0x25e3));}sub isDirectAccessEnabled{if (
isClientNxserver ()){($__directAccessFlag=(0x17d1+ 1771-0x1ebb));return (
(0x0e99+ 571-0x10d3));}if (($__directAccessFlag!=(-(0x1626+ 3410-0x2377)))){
return ($__directAccessFlag);}if (NXLicense::isIgnoreRolesConfigKeys ()){(
$__directAccessFlag=(0x01d0+ 832-0x050f));return ((0x0b28+ 1612-0x1173));}if ((
$GLOBAL::EnableDirectConnections==(0x0599+ 1535-0x0b97))){($__directAccessFlag=
(0x05fa+ 2823-0x1100));return ((0x0f3c+ 1255-0x1422));}($__directAccessFlag=
(0x054f+ 4549-0x1714));return ((0x0171+ 1340-0x06ad));}sub 
isDirectAccessDisabled{return ((!isDirectAccessEnabled ()));}sub 
setConnectionForwarded{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x64\x2e"
);($__connectionForwarded=(0x0f53+ 2661-0x19b7));}sub isConnectionForwarded{if (
($__connectionForwarded==(0x0315+ 8519-0x245b))){return ((0x0e3c+ 3814-0x1d21));
}return ((0x08ad+ 385-0x0a2e));}sub setIfMainServerSupportsHandleFirstAttach{if 
(isClientNxserver ()){if (isClientVersionGreaterOrEqual ((0x0d01+ 480-0x0edb),
(0x1220+ 3164-0x1e7c),(0x1705+ 2180-0x1f7b))){(
$__mainServerSupportsHandleFirstAttach=(0x0ca0+ 2366-0x15dd));}}}sub 
isMainServerSupportsHandleFirstAttach{return (
$__mainServerSupportsHandleFirstAttach);}sub saveHelloData{($__helloData=shift (
@_));}sub getHelloData{return ($__helloData);}sub saveShellData{($__shellData=
shift (@_));}sub getShellData{return ($__shellData);}sub getVisibleUUID{my (
$uuid);main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if (
NXCluster::hasClusterGUID ()){Logger::debug (
"\x50\x61\x72\x74\x20\x6f\x66\x20\x61\x20\x63\x6c\x75\x73\x74\x65\x72\x2e\x20\x49\x6e\x74\x72\x6f\x64\x75\x63\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x47\x55\x49\x44\x2e"
);($uuid=NXCluster::getClusterGUID ());}else{($uuid=getMyUUID ());}return ($uuid
);}sub getAnywhereName{return ($__anywhereName);}sub 
setIfClientSupportsLBTypeSystemLoad{if ((isClientNxserver ()and 
isClientVersionGreaterOrEqual ((0x0138+ 1419-0x06bd),(0x06c3+   2-0x06c1),
(0x0724+ 4445-0x187a)))){($__clientSupportsLBTypeSystemLoad=
(0x0023+ 1824-0x0742));}else{($__clientSupportsLBTypeSystemLoad=
(0x1126+ 5145-0x253f));}}sub isClientSupportsLBTypeSystemLoad{return (
$__clientSupportsLBTypeSystemLoad);}sub setAccessOnlyToLocalPhysical{(
$__accessOnlyToLocalPhysical=(0x0379+ 2965-0x0f0d));}sub 
isAccessOnlyToLocalPhysical{return ($__accessOnlyToLocalPhysical);}sub 
setAccessOnlyToAttach{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x61\x63\x63\x65\x73\x73\x20\x6f\x6e\x6c\x79\x20\x74\x6f\x20\x61\x74\x74\x61\x63\x68\x2e"
);($__accessOnlyToAttach=(0x10b1+ 4496-0x2240));}sub isAccessOnlyToAttach{return
 ($__accessOnlyToAttach);}sub isAnywhereDisabled{if (($GLOBAL::EnableNMN eq 
"\x31")){return ((0x1db3+ 1871-0x2502));}return ((0x0b90+ 6704-0x25bf));}sub 
isClientSupportsErrorPublicKeyNotRecognized{return (
$__clientSupportsErrorPublicKeyNotRecognized);}sub 
setIfClientSupportsErrorPublicKeyNotRecognized{if (((isClientNxclient ()or 
isClientNxwebclient ())or isClientNxserver ())){if (
isClientVersionGreaterOrEqual ((0x04b0+ 1621-0x0afe),(0x0663+ 2854-0x1189),
(0x09e3+ 2588-0x1356))){($__clientSupportsErrorPublicKeyNotRecognized=
(0x0c3a+ 6224-0x2489));}else{($__clientSupportsErrorPublicKeyNotRecognized=
(0x00f2+ 3973-0x1077));}}}sub isClientSupportsPooledServers{return (
$__clientSupportsPooledServers);}sub setIfClientSupportsPooledServers{if ((
isClientNxclient ()or isClientNxwebclient ())){if (isClientVersionGreaterOrEqual
 ((0x0e86+ 3406-0x1bcd),(0x1a17+ 230-0x1afd),(0x064f+ 3819-0x1482))){(
$__clientSupportsPooledServers=(0x0b41+ 475-0x0d1b));}else{(
$__clientSupportsPooledServers=(0x0936+ 4039-0x18fd));}}}sub 
setIfClientSupportsLocalSessionTypeAndOwner{if ((isClientNxserver ()and 
isClientVersionGreaterOrEqual ((0x0705+ 2945-0x127f),(0x13da+ 1175-0x1871),
(0x077f+ 1970-0x0e78)))){($__clientSupportsLocalSessionTypeAndOwner=
(0x0b1f+ 5296-0x1fce));}else{($__clientSupportsLocalSessionTypeAndOwner=
(0x03ec+ 8852-0x2680));}}sub isNotClientSupportsLocalSessionTypeAndOwner{return 
((!$__clientSupportsLocalSessionTypeAndOwner));}sub 
isClientSupportsCorrectlyFormattedUnicodeInListCommands{if (isConnectedToConsole
 ()){return ((0x0e99+ 2750-0x1956));}else{return ((0x1c10+ 374-0x1d86));}}sub 
setIfClientSupportsUdpInConnectionPolicy{if (isClientVersionGreaterOrEqual (
(0x1119+ 4345-0x220b),(0x0499+ 7744-0x22d9),(0x16d6+ 2006-0x1de8))){(
$__clientSupportsUdpInConnectionPolicy=(0x00d9+ 892-0x0454));}else{(
$__clientSupportsUdpInConnectionPolicy=(0x065f+ 2279-0x0f46));}}sub 
isClientSupportsUdpInConnectionPolicy{if ((
$__clientSupportsUdpInConnectionPolicy==(0x1907+ 1034-0x1d10))){return (
(0x0409+   1-0x0409));}return ((0x0222+ 6092-0x19ee));}sub setImRemoteServer{(
$__remoteServer=(0x06a5+ 3745-0x1545));}sub isRemoteServerSet{if ((
$__remoteServer==(0x0239+ 2065-0x0a49))){return ((0x13bd+ 4008-0x2364));}return 
((0x1ad4+ 161-0x1b75));}sub setClientSupportsUuidChangeMessage{if (
isClientVersionGreaterOrEqual ((0x0d05+ 234-0x0de7),(0x0557+ 5242-0x19d1),
(0x0c63+ 6706-0x2637))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x75\x75\x69\x64\x20\x63\x68\x61\x6e\x67\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);($__clientSupportsUuidChangeMessage=(0x0286+ 3352-0x0f9d));return;}
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x75\x75\x69\x64\x20\x63\x68\x61\x6e\x67\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);}sub isClientSupportsUuidChangeMessage{return (
$__clientSupportsUuidChangeMessage);}sub setClientSupportsAttachRequestMessage{
if (isClientVersionGreaterOrEqual ((0x1a58+  25-0x1a69),(0x122d+  87-0x1284),
(0x1001+ 3636-0x1dd9))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x61\x74\x74\x61\x63\x68\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);($__clientSupportsAttachRequestMessage=(0x000b+ 6305-0x18ab));return;}
Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x61\x74\x74\x61\x63\x68\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);($__clientSupportsAttachRequestMessage=(0x055f+ 773-0x0864));}sub 
isClientSupportsAttachRequestMessage{return (
$__clientSupportsAttachRequestMessage);}sub setServerReverselogin{(
$__serverReverselogin=(0x01a3+ 3126-0x0dd8));}sub isReverselogin{if ((
$__serverReverselogin==(0x13af+ 709-0x1673))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x76\x65\x72\x73\x65\x20\x6c\x6f\x67\x69\x6e\x2e"
);return ((0x0613+ 6872-0x20ea));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x4e\x6f\x74\x20\x72\x65\x76\x65\x72\x73\x65\x20\x6c\x6f\x67\x69\x6e\x2e"
);return ((0x0903+ 4324-0x19e7));}sub setReverseHost{($__serverReverseHost=shift
 (@_));}sub getReverseHost{return ($__serverReverseHost);}sub 
setClientSupportsUpdateInNodeEdit{if (isClientVersionGreaterOrEqual (
(0x196b+ 883-0x1cd6),(0x0244+ 1677-0x08d1),(0x0201+ 4138-0x11ce))){(
$__clientSupportsUpdateInNodeEdit=(0x19ea+ 2074-0x2203));}else{(
$__clientSupportsUpdateInNodeEdit=(0x08c8+ 5529-0x1e61));}}sub 
isClientSupportsUpdateInNodeEdit{return ($__clientSupportsUpdateInNodeEdit);}sub
 setClientSupportsClientConnection{($__clientSupportsClientConnection=
(0x089d+ 248-0x0995));if ((((isClientVersionGreaterOrEqual (
(0x010b+ 3272-0x0dcb),(0x1230+ 3506-0x1fe2),(0x0c84+ 4235-0x1ca1))and (not (
isClientNxwebclient ())))or (isClientVersionGreaterOrEqual (
(0x06bb+ 6121-0x1e9c),(0x1588+ 2041-0x1d81),(0x12e2+ 2508-0x1c27))and 
isClientNxwebclient ()))or ($GLOBAL::ClientSupportsClientConnection==
(0x1aef+ 1529-0x20e7)))){($__clientSupportsClientConnection=
(0x01bd+ 5732-0x1820));}}sub doesClientSupportClientConnection{return (
$__clientSupportsClientConnection);}sub updateMyCurrentUUID{(my $uuid=shift (@_)
);main::redefine ("\x55\x55\x49\x44",$uuid);($__myUuid=$uuid);}sub 
isServerStopped{if (Common::NXFile::isExists ($GLOBAL::ServerStopStatusFlagLink)
){return ((0x011c+ 4170-0x1165));}return ((0x0e09+ 3079-0x1a10));}sub 
isClientSupportsCommandsAfterStop{return ($__clientSupportsCommandsAfterStop);}
sub setClientSupportsCommandsAfterStop{($__clientSupportsCommandsAfterStop=
(0x0509+ 2095-0x0d38));if (isClientNxserver ()){(
$__clientSupportsCommandsAfterStop=(0x0471+ 3068-0x106c));}}sub 
setClientSupportsParentCloudLimits{($__clientSupportsParentCloudLimits=
(0x18b8+ 821-0x1bed));if ((isClientNxserver ()and isClientVersionGreaterOrEqual 
((0x0011+ 3402-0x0d53),(0x1aad+ 1907-0x2220),(0x0bd7+ 6403-0x2465)))){(
$__clientSupportsParentCloudLimits=(0x0647+ 5276-0x1ae2));}}sub 
isClientSupportsParentCloudLimit{return ($__clientSupportsParentCloudLimits);}
sub setClientSupportsDynamicParentConnections{(
$__clientSupportsDynamicParentConnections=(0x1f2d+ 950-0x22e3));if ((
isClientNxserver ()and isClientVersionGreaterOrEqual ((0x08d5+ 2302-0x11cb),
(0x12a1+ 1790-0x199f),(0x026d+ 694-0x047d)))){(
$__clientSupportsDynamicParentConnections=(0x03a9+ 2280-0x0c90));}}sub 
isClientSupportsDynamicParentConnections{return (
$__clientSupportsDynamicParentConnections);}sub 
setClientSupportsSeparateConnections{if (isClientVersionGreaterOrEqual (
(0x0503+ 435-0x06ae),(0x0775+ 8021-0x26ca),(0x11f1+ 1719-0x1829))){(
$__clientSupportsSeparateConnections=(0x0ac3+ 5232-0x1f32));}else{(
$__clientSupportsSeparateConnections=(0x106a+ 1125-0x14cf));}}sub 
isClientSupportsSeparateConnections{return ($__clientSupportsSeparateConnections
);}sub setClientSupportsIgnoringWarnings{($__clientSupportsIgnoringWarnings=
(0x1c65+ 1760-0x2345));if ((isClientNxclient ()and isClientVersionGreaterOrEqual
 ((0x1a8d+ 969-0x1e4e),(0x0271+ 1074-0x06a3),(0x03e2+ 2356-0x0ca0)))){(
$__clientSupportsIgnoringWarnings=(0x0616+ 6927-0x2124));}}sub 
doesClientSupportIgnoringWarnings{return ($__clientSupportsIgnoringWarnings);}
sub isPublicKeyMessageVersion{return ($__publicKeyMessageVersion);}sub 
setPublicKeyMessageVersion{if (isClientVersionLesserOrEqual (
(0x0221+ 5053-0x15d7))){($__publicKeyMessageVersion=(0x1cdc+ 1370-0x2236));}}sub
 setIfClientSupportNewLabels{if (isClientVersionLesserOrEqual (
(0x0c0c+ 2576-0x1614),(0x18d2+ 2380-0x221e),(0x0902+ 5315-0x1d46))){(
$__clientSupportNewLabels=(0x20e5+ 157-0x2182));}}sub doesClientSupportNewLabels
{return ($__clientSupportNewLabels);}sub setIfClientSupportServerlistWithNames{
if (isClientVersionLesserOrEqual ((0x084c+ 6060-0x1ff0),(0x14b8+ 2415-0x1e27),
(0x0fa4+ 585-0x1166))){($__clientSupportServerlistWithNames=(0x1a42+ 694-0x1cf8)
);}else{($__clientSupportServerlistWithNames=(0x1b7f+ 2540-0x256a));}}sub 
doesClientSupportServerlistWithNames{return ($__clientSupportServerlistWithNames
);}sub setIfClientSupportsCode555{if (isClientVersionGreaterOrEqual (
(0x1a21+  29-0x1a36),(0x05c5+ 5268-0x1a57),(0x0b42+ 2350-0x1470))){(
$__clientSupportsCode555=(0x0784+ 5564-0x1d3f));}else{($__clientSupportsCode555=
(0x01ef+ 3326-0x0eed));}}sub doesClientSupportCode555{return (
$__clientSupportsCode555);}sub updateMyCfg{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x63\x6f\x6e\x66\x69\x67\x20\x75\x70\x64\x61\x74\x65\x2e"
);($GLOBAL::REFRESH_CFG=(0x09c6+ 5232-0x1e35));
NXLicense::clearLicenseDependantConfigKeys ();main::loadDefaultConfigValues ();
main::init_by_config_file ($GLOBAL::CONFIG_FILE);
NXLicense::updateLicenseDependantConfigKeys ();NXLicense::checkLegacyPortKeys ()
;($GLOBAL::REFRESH_CFG=(0x2079+ 347-0x21d4));main::parse_config_file (
$GLOBAL::NODE_CONFIG_FILE,main::getListOfNodeConfigurationKeysUsedByServer ());
Logger::updateLogLevel ($GLOBAL::SessionLogLevel);main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");
NXLocalSession::checkScreenBlankingOnConfigUpdate ();
NXLocalSession::checkScreenBlankingEffectOnConfigUpdate ();
NXLocalSession::informAboutDisplayMonitorIconStatus ();
NXLocalSession::informAboutSoundAlertStatus ();
NXLocalSession::informAboutDesktopViewedStatus ();main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72");
NXConnectionMonitor::handleRefreshCfg ();main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);NXNodeConnectionMonitor::handleRefreshCfg ();return;}sub 
__setKeyInNodeConfigFile{(my $key=shift (@_));(my $ref_options=shift (@_));(my $value
=$$ref_options{$key});Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x6b\x65\x79\x20\x27"
.$key)."\x27\x20\x74\x6f\x20\x76\x61\x6c\x75\x65\x20\x27").$value).
"\x27\x20\x69\x6e\x20\x6e\x6f\x64\x65\x2e\x63\x66\x67\x2e"));&try (sub{
Common::NXCommonNodeConfiguration::setKey ("\x6b\x65\x79",$key,
"\x76\x61\x6c\x75\x65",$value);},
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x6f\x72"
->catch (&with (sub{($e=shift (@_));$e->notify;},
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x49\x6e\x74\x65\x72\x6e\x61\x6c"->
catch (&with (sub{($e=shift (@_));$e->notify;})))));}sub 
setSkipClosingPassedSocket{($__skipClosingPassedSocket=(0x0393+ 3192-0x100a));}
sub shouldSkipClosingPassedSocket{return ($__skipClosingPassedSocket);}sub 
getTcpDescriptor{(my $message=(("\x4e\x58\x3e\x20".$GLOBAL::TCP_COMMUNICATION).
"\x20\x54\x43\x50\x20\x63\x6f\x6d\x6d\x75\x6e\x69\x63\x61\x74\x69\x6f\x6e\x20\x0a"
));Logger::debug (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x52\x65\x71\x75\x65\x73\x74\x69\x6e\x67\x20\x54\x43\x50\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x27"
.$message)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$__communicationNXD)."\x2e"));if 
((main::nxwrite ($__communicationNXD,$message)==(-(0x0982+ 5242-0x1dfb)))){
Logger::error (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x4e\x58\x44\x20\x6f\x6e\x20\x46\x44\x23"
.$__communicationNXD)."\x2e"));shutdownClientConnection ();main::nxexit ();}(my $answer
=getAnswer ($__communicationNXD,$GLOBAL::TcpDescriptorReadTimeout));if (($answer
=~ /^NX> $GLOBAL::TCP_HANDLE TCP handle pid=(.*) socket=(.*) cookie=(.*) fd=(.*) / )
){(my $pid=$1);(my $fd=$4);(my $path=main::urldecode ($2));(my $cookie=$3);(my $descriptor
=Common::NXDescriptor::acquire ($pid,$fd,$path,$cookie));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x54\x43\x50\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$descriptor)."\x2e"));if (($descriptor<(0x088a+ 491-0x0a75))){Logger::error (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x61\x63\x71\x75\x69\x72\x65\x20\x54\x43\x50\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x2e"
);shutdownClientConnection ();main::nxexit ();}main::closeSocketAtFinish (
$descriptor);return ($descriptor);}Logger::error (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x57\x72\x6f\x6e\x67\x20\x54\x43\x50\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$answer)."\x27\x2e"));shutdownClientConnection ();main::nxexit ();}sub 
setNxdCommunication{($__communicationNXD=shift (@_));Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x4e\x58\x44\x20\x63\x6f\x6d\x6d\x75\x6e\x69\x63\x61\x74\x69\x6f\x6e\x20\x70\x69\x70\x65\x20\x46\x44\x23"
.$__communicationNXD).
"\x20\x74\x6f\x20\x63\x6c\x6f\x73\x65\x20\x61\x74\x20\x65\x78\x69\x74\x2e"));
main::closeSocketAtFinish ($__communicationNXD);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x49\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x28"
.$__communicationNXD)."\x2c\x20\x30\x29"));libnxh::NXDescriptorInheritable (
$__communicationNXD,(0x0071+ 3116-0x0c9d));}sub getNxdConnection{return (
$__communicationNXD);}sub getAnswer{(my $handle=shift (@_));(my $timeout=shift (
@_));(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->add ($handle);(my $finish=(0x0530+ 7154-0x2122));(my $time
=$timeout);(my $answer=(""));while ((($finish==(0x07bd+ 2684-0x1239))and ($time>
(0x0648+ 762-0x0942)))){(my $startTime=Common::NXTime::getSecondsSinceEpoch ());
(my (@ready)=$selector->can_read (($time *(0x09ac+ 124-0x0640))));(my $currentTime
=Common::NXTime::getSecondsSinceEpoch ());($time=($time-($currentTime-$startTime
)));if ((scalar (@ready)==(0x01ef+ 2840-0x0d07))){Logger::warning (((((
"\x52\x65\x61\x64\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x6f\x66\x20".$timeout).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x20\x72\x65\x61\x63\x68\x65\x64\x20\x66\x6f\x72\x20\x46\x44\x23"
).$handle)."\x2e"));($finish=(0x08bf+ 2336-0x11de));}foreach my $fh (@ready){if 
(($fh==$handle)){my ($buffer);(my $bytes=main::nxread ($fh,(\$buffer),4096));(
$answer.=$buffer);if (((not (defined ($bytes)))or ($bytes==(0x0393+ 6885-0x1e78)
))){Logger::debug (((
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x46\x44\x23"
.$fh)."\x2e"));$selector->remove ($fh);$selector->remove ($signalFd);($finish=
(0x195b+ 2073-0x2173));}else{Logger::debug ((((("\x52\x65\x61\x64\x20".$bytes).
"\x20\x62\x79\x74\x65\x73\x20\x66\x72\x6f\x6d\x20\x46\x44").$fh)."\x2e"));if ((
$buffer=~ /\n/ )){$selector->remove ($fh);$selector->remove ($signalFd);chomp (
$buffer);($buffer=~ s/\r//g );($finish=(0x1b02+ 3068-0x26fd));}}}}}return (
$answer);}sub passUdpDescriptorToNode{my ($in);my ($out);main::nxPipeCreateBi ((
\$in),(\$out));(my $cookie=main::get_unique_id ());(my $path=((
NXPaths::getTmpDir ().$GLOBAL::DIRECTORY_SLASH).main::get_unique_id ()));(my $params
=("\x75\x64\x70\x50\x69\x64\x3d".$ $));
 ($params.=(
"\x26\x75\x64\x70\x50\x61\x74\x68\x3d".main::urlencode ($path)));($params.=(
"\x26\x75\x64\x70\x43\x6f\x6f\x6b\x69\x65\x3d".$cookie));($params.=(
"\x26\x75\x64\x70\x46\x64\x3d".$out));(my ($stdout,$childPid)=
NXNodeExec::askNode ("\x70\x61\x73\x73\x55\x64\x70\x48\x61\x6e\x64\x6c\x65",
$params,NXSessionParameters::getNodeUUID (),NXSessionParameters::getUsername ())
);Logger::debug (((
"\x53\x65\x73\x73\x69\x6f\x6e\x53\x74\x61\x72\x74\x53\x74\x61\x74\x65\x4d\x61\x63\x68\x69\x6e\x65\x3a\x20\x50\x61\x73\x73\x20\x55\x44\x50\x20\x68\x61\x6e\x64\x6c\x65\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$stdout)."\x27\x2e"));if (($stdout=~ /ready/ )){if ((
Common::NXDescriptor::yield ($out,$path,$cookie)==(-(0x15c3+ 1888-0x1d22)))){
Logger::warning (((((
"\x53\x65\x72\x76\x65\x72\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x70\x61\x73\x73\x20\x55\x44\x50\x20\x68\x61\x6e\x64\x6c\x65\x20\x46\x44\x23"
.$out).
"\x20\x77\x69\x74\x68\x20\x73\x6f\x63\x6b\x65\x74\x20\x70\x61\x74\x68\x20\x27").
$path)."\x27\x2e"));}}}sub setClientSupportsForwardUdp{(
$__clientSupportsUdpServer=(0x0031+ 319-0x0170));if (isClientNxwebclient ()){
return;}if (isClientVersionGreaterOrEqual ((0x1c26+ 2631-0x2665),
(0x1065+ 1728-0x1725),(0x11a2+ 3707-0x1f90))){($__clientSupportsUdpServer=
(0x1596+ 2279-0x1e7c));}}sub doesClientSupportUdpServer{if ((
$__clientSupportsUdpServer==(0x0290+ 3828-0x1183))){Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x55\x44\x50\x2e"
);return ((0x0af1+ 235-0x0bdb));}Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x55\x44\x50\x2e"
);return ((0x0d96+ 4530-0x1f48));}sub disableUdpForwarder{Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x44\x69\x73\x61\x62\x6c\x69\x6e\x67\x20\x55\x44\x50\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x72\x2e"
);($__disableUdpForwarder=(0x1534+ 2764-0x1fff));}sub isUdpForwarderEnabled{if (
($__disableUdpForwarder==(0x0f16+ 3299-0x1bf8))){Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x55\x44\x50\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x72\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x1d2c+ 709-0x1ff1));}Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x55\x44\x50\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x72\x20\x69\x73\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"
);return ((0x00f5+ 4819-0x13c7));}sub setUdpStatus{($__udpStatus=shift (@_));
Logger::debug (((
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x6e\x78\x61\x67\x65\x6e\x74\x20\x55\x44\x50\x20\x73\x74\x61\x74\x75\x73\x20\x27"
.$__udpStatus)."\x27\x2e"));}sub isUdpDisabled{if (($__udpStatus==
(0x04da+ 8271-0x2529))){Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x6e\x78\x61\x67\x65\x6e\x74\x20\x55\x44\x50\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x0335+ 1939-0x0ac7));}return ((0x0d23+ 5193-0x216c));}sub 
setClientSupportsDirectUdp{($__clientSupportsDirectUdp=(0x1df5+ 1801-0x24fe));if
 (isClientNxwebclient ()){return;}if (isClientVersionGreaterOrEqual (
(0x1099+ 2048-0x1891))){return;}($__clientSupportsDirectUdp=
(0x07f0+ 2426-0x1169));}sub doesClientSupportDirectUdp{if ((
$__clientSupportsDirectUdp==(0x23c6+ 429-0x2572))){Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x64\x69\x72\x65\x63\x74\x20\x55\x44\x50\x2e"
);return ((0x0022+ 2340-0x0945));}Logger::debug (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x64\x69\x72\x65\x63\x74\x20\x55\x44\x50\x2e"
);return ((0x10f2+ 4692-0x2346));}sub setClientSupportsQuasiAdmin{(
$__clientSupportsQuasiAdmin=(0x02df+ 6374-0x1bc5));if ((isClientNxclient ()or 
isClientNxwebclient ())){if (isClientVersionGreaterOrEqual ((0x0f3d+ 496-0x1125)
)){($__clientSupportsQuasiAdmin=(0x124d+ 2905-0x1da5));}}}sub 
doesClientSupportQuasiAdmin{if (($__clientSupportsQuasiAdmin==
(0x0898+ 6424-0x21af))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x71\x75\x61\x73\x69\x20\x61\x64\x6d\x69\x6e\x2e"
);return ((0x00d5+ 3804-0x0fb0));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x71\x75\x61\x73\x69\x20\x61\x64\x6d\x69\x6e\x2e"
);return ((0x079a+ 1720-0x0e52));}sub setClientSupportsForwardWithTimeout{(
$__clientSupportsForwardWithTimeout=(0x0910+ 4166-0x1956));if (
isClientVersionGreaterOrEqual ((0x04cc+ 4704-0x1724),(0x1746+ 3705-0x25bf),
(0x1227+ 2664-0x1bf8))){($__clientSupportsForwardWithTimeout=
(0x0647+ 1763-0x0d29));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);return ((0x0774+ 578-0x09b6));}sub doesClientSupportsForwardWithTimeut{if ((
$__clientSupportsForwardWithTimeout==(0x0f37+ 1304-0x144e))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);return ((0x090c+ 2489-0x12c4));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x77\x61\x72\x64\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);return ((0x07b8+ 2055-0x0fbf));}sub getMyLocalIP{(my $gatewayIP=("\x20" x 
(0x1515+ 2663-0x1b94)));(my $localIP=("\x20" x (0x1bc5+ 2338-0x20ff)));(my $externalIP
=("\x20" x (0x114a+ 5880-0x245a)));libnxhs::NXUpnpGetNetworkInfo ($gatewayIP,
$localIP,$externalIP);($localIP=~ s/\0// );($localIP=main::trimLine ($localIP));
return ($localIP);}sub setClientSupportHelloForVisitor{(
$__clientSupportHelloForVisitor=(0x0af5+ 4181-0x1b4a));if (
isClientVersionGreaterOrEqual ((0x1ac1+ 2573-0x24c6),(0x0210+ 3792-0x10e0),
(0x076d+ 2948-0x1254))){($__clientSupportHelloForVisitor=(0x1866+ 1859-0x1fa8));
}}sub doesClientSupportHelloForVisitor{if (($__clientSupportHelloForVisitor==
(0x025d+ 3883-0x1187))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x68\x65\x6c\x6c\x6f\x20\x66\x6f\x72\x20\x76\x69\x73\x69\x74\x6f\x72\x2e"
);return ((0x0065+ 4214-0x10da));}Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x68\x65\x6c\x6c\x6f\x20\x66\x6f\x72\x20\x76\x69\x73\x69\x74\x6f\x72\x2e"
);return ((0x0279+ 5377-0x177a));}sub setClientSupportParentName{(
$__clientSupportParentName=(0x12d4+ 365-0x1441));if (
isClientVersionGreaterOrEqual ((0x0b3b+ 1611-0x117e),(0x0631+ 2272-0x0f11),
(0x1377+ 3909-0x221d))){($__clientSupportParentName=(0x09bb+ 3115-0x15e5));}}sub
 doesClientSupportParentName{if (($__clientSupportParentName==
(0x0dbc+ 6360-0x2693))){return ((0x093a+ 4675-0x1b7c));}return (
(0x0dbf+ 1749-0x1494));}sub setClientSupportCsNodePool{(
$__clientSupportCsNodePool=(0x215c+ 756-0x2450));if (
isClientVersionGreaterOrEqual ((0x07d0+ 2402-0x112a),(0x11ab+ 4118-0x21c1),
(0x08b5+ 4888-0x1b26))){($__clientSupportCsNodePool=(0x040f+ 1087-0x084d));}}sub
 doesClientSupportCsNodePool{if (($__clientSupportCsNodePool==
(0x1051+ 4117-0x2065))){return ((0x0a09+ 1506-0x0fea));}return (
(0x0287+ 6539-0x1c12));}sub isClusterNotSetUp{if (
NXLicense::isClusterCreateFeature ()){main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((not (NXCluster::isClusterConfigured
 ()))){return ((0x01c8+ 8057-0x2140));}return ((0x0fc0+ 1244-0x149c));}return (
(0x0410+ 7843-0x22b3));}sub isCluster{if (NXLicense::isClusterFeature ()){if (
NXLicense::isClusterCreateFeature ()){return ((0x06a9+ 3577-0x14a1));}
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if (
NXCluster::isClusterConfigured ()){return ((0x1a78+ 1183-0x1f16));}}return (
(0x0c76+ 5242-0x20f0));}sub setPureVirtualSession{Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x65\x74\x20\x70\x75\x72\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);($__pureVirtualSession=(0x109d+ 1066-0x14c6));}sub isPureVirtualSession{if ((
$__pureVirtualSession==(0x029b+ 8902-0x2560))){Logger::debug (
"\x53\x65\x72\x76\x65\x72\x3a\x20\x50\x75\x72\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x11cd+ 1005-0x15b9));}return ((0x0492+ 6638-0x1e80));}
NXMsg::register_response ("\x53\x65\x72\x76\x65\x72",
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x65\x74\x4c\x6f\x67\x6f\x6e\x54\x6f\x53\x74\x61\x72\x74"
,(0x13cd+ 1607-0x1820));NXMsg::register_response ("\x53\x65\x72\x76\x65\x72",
"\x77\x57\x61\x69\x74\x69\x6e\x67\x46\x6f\x72\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x53\x65\x72\x76\x69\x63\x65\x73"
,(0x0933+ 6581-0x20f4));return ((0x07e2+ 1491-0x0db4));
