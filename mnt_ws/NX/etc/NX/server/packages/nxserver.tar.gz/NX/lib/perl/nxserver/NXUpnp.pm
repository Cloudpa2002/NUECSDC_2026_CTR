############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXUpnp::BEGIN{package NXUpnp;no warnings;require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXUpnp::BEGIN{package NXUpnp;no
 warnings;require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};
}sub NXUpnp::BEGIN{package NXUpnp;no warnings;require NXMsg;do{
"\x4e\x58\x4d\x73\x67"->import};}sub NXUpnp::BEGIN{package NXUpnp;no warnings;
require NXNodeInfo;do{"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f"->import};}sub 
NXUpnp::BEGIN{package NXUpnp;no warnings;require NXClientSystemDaemons;do{
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
->import};}package NXUpnp;no warnings;($setTime=(0x095d+ 6066-0x1eb7));(
$defaultTimeout=(0x085c+ 1287-0x0b47));($timeout=$defaultTimeout);(
@timeoutForRepeatMapping=((0x037a+ 8298-0x23da),(0x21dc+ 272-0x22ce),
(0x02e1+ 9004-0x25d1)));(@allPossibleTimeoutForRepeat=((0x032d+ 890-0x069d),
(0x008f+ 5835-0x173c),(0x0371+ 2033-0x0b26)));($repeatMappingDisabled=
(0x1412+ 900-0x1796));($repeatMappingStarted=(0x0b60+ 7045-0x26e4));(
$repeatMapping=$repeatMappingDisabled);($protocolsCountForRepeatMapping=
(0x09bd+ 3160-0x1615));($directoryPath=(""));($UPnPStartTime=
(0x0ca5+  89-0x0cfe));(@UPnPServices=("\x75\x70\x6e\x70\x6e\x78\x74\x63\x70",
"\x75\x70\x6e\x70\x6e\x78\x75\x64\x70","\x75\x70\x6e\x70\x73\x73\x68",
"\x75\x70\x6e\x70\x68\x74\x74\x70\x73"));((%serviceUPnPStartTime)=());((
%serviceUPnPTimeout)=());((%serviceUPnPExternalPort)=());((
%serviceUPnPExternalPortFile)=());((%serviceUPnPPort)=());($enabledUPnPMapping=
(0x07bd+ 6056-0x1f65));($UPnPMapStartTime=(0x0655+ 5534-0x1bf3));(
$UPnPMapTimeout=(0x0b96+ 101-0x0bfb));($GatewayIP=(""));($LocalIP=(""));(
$ExternalIP=(""));((%serviceUPnP)=());($UDPPortAdded=(0x16c2+ 264-0x17ca));(
$Handlerstimeout=(0x1254+ 1908-0x1950));((%SocketsToWriteNetworkInformation)=())
;($flagInformAllNodesAboutUPnPChanges=(0x09b8+ 1119-0x0e17));(
$networkThreadStarted=(0x06a9+ 1356-0x0bf5));($networkInfostarted=
(0x05b0+ 3873-0x14d1));($forceStartUPnPMap=(0x0d41+ 3252-0x19f5));(
$handleNetworkChange=(0x17e4+ 2708-0x2278));($NORMAL_MODE=(0x0328+ 7660-0x2114))
;($BACKGROUND_MODE=(0x00eb+ 8581-0x226f));($SKIP_WAITING=(0x0070+ 1510-0x0656));
($WAIT=(0x0228+ 8891-0x24e2));($FIELD_SEPARATOR="\x23");($sessionPort=(-
(0x0531+ 5760-0x1bb0)));(my $__nxTcpName="\x4e\x58\x54\x43\x50");(my $__nxUdpName
="\x4e\x58\x55\x44\x50");(my $__nxhtdName="\x4e\x58\x48\x54\x44");(my $__nxsshdName
="\x4e\x58\x53\x53\x48");(my $__cfgNXTCPKeyName=
"\x4e\x58\x54\x43\x50\x55\x50\x6e\x50\x50\x6f\x72\x74");(my $__cfgNXUDPKeyName=
"\x4e\x58\x55\x44\x50\x55\x50\x6e\x50\x50\x6f\x72\x74");(my $__cfgHTTPKeyName=
"\x48\x54\x54\x50\x55\x50\x6e\x50\x50\x6f\x72\x74");(my $__cfgSSHDKeyName=
"\x53\x53\x48\x55\x50\x6e\x50\x50\x6f\x72\x74");(my $__cfgEnableUPnPKeyName=
"\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50");(my $__cfgNXTCPKeyValue=
"\x4e\x58\x54\x43\x50");(my $__cfgNXUDPKeyValue="\x4e\x58\x55\x44\x50");(my $__cfgHTTPKeyValue
="\x48\x54\x54\x50");(my $__cfgSSHDKeyValue="\x53\x53\x48");(my $__serviceUpnpnxTcp
="\x75\x70\x6e\x70\x6e\x78\x74\x63\x70");(my $__serviceUpnpnxUdp=
"\x75\x70\x6e\x70\x6e\x78\x75\x64\x70");(my $__serviceUpnpssh=
"\x75\x70\x6e\x70\x73\x73\x68");(my $__serviceUpnphttps=
"\x75\x70\x6e\x70\x68\x74\x74\x70\x73");sub __createFileStructure{if ((not (-d (
$GLOBAL::ExternalTCPPortsDir)))){if (mkdir ($GLOBAL::ExternalTCPPortsDir)){
Logger::debug2 ((
"\x43\x72\x65\x61\x74\x65\x64\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20".
$GLOBAL::ExternalTCPPortsDir));Common::NXFile::setPermissionsFullForNX (
$GLOBAL::ExternalTCPPortsDir);}else{Logger::debug2 ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20"
.$GLOBAL::ExternalTCPPortsDir)."\x3a\x20").$!));}}else{
Common::NXFile::setPermissionsFullForNX ($GLOBAL::ExternalTCPPortsDir);}return;}
sub __setExternalUPnPPortsForAllServicesOnNetworkChange{Logger::debug (
"\x5f\x5f\x73\x65\x74\x45\x78\x74\x65\x72\x6e\x61\x6c\x55\x50\x6e\x50\x50\x6f\x72\x74\x73\x46\x6f\x72\x41\x6c\x6c\x53\x65\x72\x76\x69\x63\x65\x73\x4f\x6e\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"
);(my $ret=(0x1809+ 3052-0x23f5));(my $localIP=getLocalIPFromMemory ());
Logger::debug (((
"\x5f\x5f\x73\x65\x74\x45\x78\x74\x65\x72\x6e\x61\x6c\x55\x50\x6e\x50\x50\x6f\x72\x74\x73\x46\x6f\x72\x41\x6c\x6c\x53\x65\x72\x76\x69\x63\x65\x73\x4f\x6e\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65\x28\x29\x20\x67\x6f\x74\x20\x6c\x6f\x63\x61\x6c\x20\x49\x50\x3a\x20"
.$localIP)."\x2e"));foreach my $service (@UPnPServices){
getExternalUPnPPortFromMemoryORFile ($service);if (
isNotSetServiceUPnPExternalPort ($service)){if ((($localIP ne (""))and ($localIP
 ne "\x2d\x31"))){setExternalTCPPortFile ($service,$localIP);($ret=
(0x035c+ 8200-0x2363));}}else{($ret=(0x1cdc+ 2056-0x24e3));}}return ($ret);}sub 
__setExternalUPnPPortsForAllServices{(my $background=(shift (@_)||$NORMAL_MODE))
;Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x55\x50\x6e\x50\x20\x70\x6f\x72\x74\x73\x2e"
);if (isUPnPEnabled ()){if ((($background==$BACKGROUND_MODE)and (
getLocalIPFromMemory ()eq ("")))){getNetworkInfoBackground (
(0x051a+ 5584-0x1aea));return ((0x13bf+ 2498-0x1d81));}(my $localIP=getLocalIP 
());Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4c\x6f\x63\x61\x6c\x20\x49\x50\x3a\x20\x27".
$localIP)."\x27\x2e"));foreach my $service (@UPnPServices){
getExternalUPnPPortFromMemoryORFile ($service);if (
isNotSetServiceUPnPExternalPort ($service)){setExternalTCPPortFile ($service,
$localIP);}}}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x70\x6f\x72\x74\x73\x20\x6f\x6e\x6c\x79\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x73\x2e"
);foreach my $service (@UPnPServices){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x20\x27"
.$service)."\x27\x2e"));getExternalUPnPPortFromFile ($service);
setExternalTCPPortFile ($service,(-(0x00a0+ 7799-0x1f16)));}}return (
(0x044b+ 2962-0x0fdc));}sub __initUPnPService{(my $service=shift (@_));(
$serviceUPnPStartTime{$service}=(0x08bc+ 2920-0x1424));($serviceUPnPExternalPort
{$service}=(0x1740+ 3223-0x23d7));($serviceUPnPPort{$service}=(""));(
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x1385+ 3538-0x2157));
setServiceUPnPPort ($service);setServiceUPnPExternalPortFile ($service);
setServiceUPnPTimeout ($service);return;}sub __setUPnPMapEnabled{(my $enable=(
shift (@_)||(0x1a12+ 2010-0x21ec)));($enabledUPnPMapping=$enable);}sub 
__addTCPRule{(my $internalPorts=shift (@_));(my $externalPorts=shift (@_));(my $background
=shift (@_));(my $protocol="\x54\x43\x50");return (__addRule ($internalPorts,
$externalPorts,$background,$protocol));}sub __addUDPRule{(my $internalPorts=
shift (@_));(my $externalPorts=shift (@_));(my $background=shift (@_));(my $protocol
="\x55\x44\x50");return (__addRule ($internalPorts,$externalPorts,$background,
$protocol));}sub __addRule{(my $internalPorts=shift (@_));(my $externalPorts=
shift (@_));(my $background=shift (@_));(my $protocol=shift (@_));(my $ret=
(0x23f3+ 304-0x2523));if (($background==$BACKGROUND_MODE)){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4d\x61\x70\x70\x69\x6e\x67\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x2e"
);(my ($read,$write)=(""));if (main::nxPipeCreateBi ((\$read),(\$write))){
Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x20\x63\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x46\x44\x23"
.$read)."\x20\x46\x44\x23").$write)."\x2e"));}else{(my $error=libnxh::NXGetError
 ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return (
(0x0091+ 7730-0x1ec3));}Logger::debug (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x28"
.$write)."\x2c\x20").$internalPorts)."\x2c\x20").$externalPorts)."\x2c\x20").
$protocol)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exitValue=
libnxhs::NXCreatePortsAdd ($write,$internalPorts,$externalPorts,$protocol));
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$exitValue)."\x27\x2e"));if (($exitValue<(0x0f25+ 4433-0x2076))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::warning (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6e\x78\x75\x70\x6e\x70\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));
main::nxclose ($read);main::nxclose ($write);return ((0x0d72+ 2082-0x1594));}
NXSystemDaemons::addUPnPFD ("\x61\x64\x64\x70\x6f\x72\x74\x73",$read,$write,
(0x1867+ 969-0x1c30));setNetworkThreadFlag ((0x20d0+ 1308-0x25eb));($ret=$read);
}else{Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x41\x64\x64\x50\x6f\x72\x74\x73\x28"
.$internalPorts)."\x2c\x20").$externalPorts)."\x2c\x20").$protocol).
"\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $response=("\x20" x 
(0x242b+ 381-0x2544)));($exit_value=libnxhs::NXUpnpAddPorts ($internalPorts,
$externalPorts,$protocol,$response));Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x41\x64\x64\x50\x6f\x72\x74\x73\x28\x2e\x2e\x2e\x2c\x20"
.$response).
"\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x3a\x20").
$exit_value)."\x2e"));($response=~ s/\0// );($response=main::trimLine ($response
));parseNXUpNPMessage ($response,"\x61\x64\x64\x70\x6f\x72\x74\x73");($ret=
(0x1b1c+ 1420-0x20a7));}($UPnPStartTime=Common::NXTime::getSecondsSinceEpoch ())
;return ($ret);}sub getServiceNameByPort{(my $protocol=shift (@_));(my $servicePort
=shift (@_));if ((($servicePort eq (""))or ($protocol eq ("")))){Logger::warning
 (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$servicePort).
"\x27\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$protocol).
"\x27\x2e"));return ((""));}foreach my $service (@UPnPServices){(my $port=
getServiceUPnPPort ($service));if ((($port>(0x0120+ 9578-0x268a))and ($port==
$servicePort))){if ((($protocol eq "\x54\x43\x50")and isTCPService ($service))){
Logger::debug (((((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x46\x6f\x75\x6e\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27").$servicePort).
"\x27\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$protocol).
"\x27\x2e"));return ($service);}elsif ((($protocol eq "\x55\x44\x50")and 
isUDPService ($service))){Logger::debug (((((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x46\x6f\x75\x6e\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27").$servicePort).
"\x27\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$protocol).
"\x27\x2e"));return ($service);}}}return ((""));}sub setServiceState{(my $service
=shift (@_));(my $state=shift (@_));if (($service eq (""))){Logger::warning (
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x65\x2e"
);return;}if (($state eq "\x31")){Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x53\x65\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));($serviceUPnP{$service}{
"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x082d+ 6942-0x234a));}else{Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x53\x65\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x66\x6f\x72\x20\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));(
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x1dbb+ 1260-0x22a7));}
return;}sub addSocketToClientList{(my $clientSocket=shift (@_));(my $upnpFD=
shift (@_));(my $type=shift (@_));if (($clientSocket eq (""))){return;}
Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x41\x64\x64\x65\x64\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23"
.$clientSocket)."\x20\x6f\x66\x20\x74\x79\x70\x65\x20\x27").$type).
"\x27\x20\x75\x70\x6e\x70\x46\x44\x20\x46\x44\x23").$upnpFD).
"\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x20\x6c\x69\x73\x74\x2e"));(
$SocketsToWriteNetworkInformation{$clientSocket}{"\x74\x79\x70\x65"}=$type);(
$SocketsToWriteNetworkInformation{$clientSocket}{"\x73\x6f\x63\x6b\x65\x74"}=
$upnpFD);Common::NXCore::closeSocketAtFinish ($clientSocket);return;}sub 
isUPnPSocket{(my $fd=shift (@_));if ($SocketsToWriteNetworkInformation{$fd}){
Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23".$fd).
"\x2e"));return ((0x0e73+ 1967-0x1621));}return ((0x0588+ 3630-0x13b6));}sub 
handleUPnPSocketOnClose{(my $fd=shift (@_));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6c\x6f\x73\x65\x64\x20\x46\x44\x23"
.$fd)."\x2e"));if ($SocketsToWriteNetworkInformation{$fd}){delete (
$SocketsToWriteNetworkInformation{$fd});}}sub handleMessageOnDescriptor{(my $fd=
shift (@_));(my $type=NXSystemDaemons::getUpPnPFDType ($fd));Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6f\x6d\x65\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23"
.$fd)."\x20\x74\x79\x70\x65\x20\x27").$type)."\x27\x2e"));(my $read_buf=(""));(my $bytes_read
=main::nxread ($fd,(\$read_buf),4096));if ((not (defined ($bytes_read)))){(my $error
=libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());if ((($errorname eq "\x45\x41\x47\x41\x49\x4e")or 
($errorname eq "\x45\x49\x4e\x54\x52"))){Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23".
$fd)."\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20").$errorname).
"\x2c\x20").$errorstring)."\x2e"));return;}else{Logger::warning (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23".
$fd)."\x20\x66\x61\x69\x6c\x65\x64\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20")
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));
NXSystemDaemons::removeUPnPFD ($fd);}}elsif (($bytes_read==(0x0a3b+ 4788-0x1cef)
)){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$fd)."\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"));
NXSystemDaemons::removeUPnPFD ($fd);}else{parseNXUPnP ($type,$read_buf);
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$fd)."\x2e"));NXSystemDaemons::removeUPnPFD ($fd);}if (($type eq 
"\x61\x64\x64\x70\x6f\x72\x74\x73")){if (($__waitOnAddUPD==(0x249f+ 392-0x2626))
){next;}}if (((($type eq "\x6e\x65\x74\x69\x6e\x66\x6f")or ($type eq 
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73"))or ($type eq 
"\x61\x64\x64\x70\x6f\x72\x74\x73"))){if ((checkIfClientIsWaitingForReply ($fd)
==(0x1006+ 4407-0x213c))){sendNetworkInfoToAllSockets ($type);}elsif (($type eq 
"\x6e\x65\x74\x69\x6e\x66\x6f")){setNetworkInfoFlag ((0x07ec+ 1253-0x0cd1));}if 
(($type eq "\x61\x64\x64\x70\x6f\x72\x74\x73")){informAllNodesAboutUPnPChanges 
();($flagInformAllNodesAboutUPnPChanges=(0x0501+ 802-0x0823));}elsif ((($type eq
 "\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73")and (
$flagInformAllNodesAboutUPnPChanges==(0x02e2+ 6513-0x1c52)))){
informAllNodesAboutUPnPChanges ();($flagInformAllNodesAboutUPnPChanges=
(0x0621+  92-0x067d));}}}sub checkIfClientIsWaitingForReply{(my $fdToCheck=shift
 (@_));foreach my $sock (keys (%SocketsToWriteNetworkInformation)){if ((
$SocketsToWriteNetworkInformation{$sock}{"\x73\x6f\x63\x6b\x65\x74"}==$fdToCheck
)){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x46\x44\x23".
$fdToCheck)."\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x73\x74\x2e"));
return ((0x0820+ 4484-0x19a3));}}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x69\x65\x6e\x74\x20\x46\x44\x23".
$fdToCheck).
"\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x6f\x6e\x20\x6c\x69\x73\x74\x2e"))
;return ((0x0126+ 9091-0x24a9));}sub sendNetworkInfoToAllSockets{(my $type=shift
 (@_));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x6e\x74\x20\x74\x79\x70\x65\x20\x27".
$type).
"\x27\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x20\x74\x6f\x20\x61\x6c\x6c\x20\x73\x6f\x63\x6b\x65\x74\x73\x2e"
));setNetworkInfoFlag ((0x113a+ 5344-0x261a));(my $count=scalar (keys (
%SocketsToWriteNetworkInformation)));if (($count==(0x0b23+ 6974-0x2661))){
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4e\x6f\x20\x73\x6f\x63\x6b\x65\x74\x20\x63\x61\x6e\x64\x69\x64\x61\x74\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x2e"
);return;}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6f\x63\x6b\x65\x74\x73\x20\x63\x6f\x75\x6e\x74\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x27"
.$count)."\x27\x2e"));(my $body=buildMessageUPnPStatusFromMemory (
(0x1830+ 2995-0x23e2)));foreach my $sock (keys (
%SocketsToWriteNetworkInformation)){if (($SocketsToWriteNetworkInformation{$sock
}{"\x74\x79\x70\x65"}ne $type)){Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6b\x69\x70\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$sock).
"\x2c\x20\x64\x69\x66\x66\x65\x72\x65\x6e\x74\x20\x74\x79\x70\x65\x20\x27").
$type)."\x27\x20\x2d\x20").$SocketsToWriteNetworkInformation{$sock}{
"\x74\x79\x70\x65"})."\x2e"));next;}Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$sock)."\x20\x74\x79\x70\x65\x3a\x20").$SocketsToWriteNetworkInformation{$sock}
{"\x74\x79\x70\x65"})."\x2e"));if (sendNetworkInfoOnSocket ($sock,$body)){
NXServerDaemon::removeClientFDFromSelector ($sock);
NXServerDaemon::clearAcceptFDBuffer ($sock);main::nxclose ($sock);}delete (
$SocketsToWriteNetworkInformation{$sock});}}sub sendNetworkInfoOnSocket{(my $socket
=shift (@_));(my $body=shift (@_));if (($socket eq (""))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6f\x63\x6b\x65\x74\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);return ((0x0316+ 304-0x0446));}(my $bytes=main::nxwrite ($socket,$body));
Logger::debug ((((("\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x6e\x74\x20".$bytes
)."\x20\x62\x79\x74\x65\x73\x20\x6f\x6e\x20\x46\x44\x23").$socket)."\x2e"));
return ((0x0c21+ 5154-0x2042));}sub parseNXUPnP{(my $type=shift (@_));(my $buffer
=shift (@_));Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x50\x61\x72\x73\x65\x20\x74\x79\x70\x65\x20\x27"
.$type)."\x27\x20\x62\x75\x66\x66\x65\x72\x20\x27").$buffer)."\x27\x2e"));if ((
$type eq "\x6e\x65\x74\x69\x6e\x66\x6f")){parseNXUpNPNetInfoMessage ($buffer);if
 (($handleNetworkChange==(0x0826+ 4048-0x17f5))){($handleNetworkChange=
(0x10ac+ 1290-0x15b6));handleNetworkChangePortsAdd ();}else{
checkAndStartPortMaping ();}}else{parseNXUpNPMessage ($buffer,$type);}return (
(0x0aa4+ 617-0x0d0c));}sub parseNXUpNPNetInfoMessage{(my $buffer=shift (@_));
Logger::debug2 (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x70\x61\x72\x73\x65\x4e\x58\x55\x70\x4e\x50\x4e\x65\x74\x49\x6e\x66\x6f\x4d\x65\x73\x73\x61\x67\x65\x20\x72\x65\x61\x64\x3a\x20"
.$buffer)."\x2e"));($buffer=~ s/\0// );if (($buffer=~ /GATEWAY: (.*), LOCAL: (.*), EXTERNAL: (.*)/ )
){($GatewayIP=main::trimLine ($1));($LocalIP=main::trimLine ($2));($ExternalIP=
main::trimLine ($3));}Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x70\x61\x72\x73\x65\x4e\x58\x55\x70\x4e\x50\x4e\x65\x74\x49\x6e\x66\x6f\x4d\x65\x73\x73\x61\x67\x65\x20\x4c\x6f\x63\x61\x6c\x20\x49\x50\x3a\x20"
.$LocalIP)."\x2c\x20\x47\x61\x74\x65\x77\x61\x79\x20\x49\x50\x3a\x20").
$GatewayIP)."\x2c\x20\x45\x78\x74\x65\x72\x6e\x61\x6c\x20\x49\x50\x3a\x20").
$ExternalIP)."\x2e"));return;}sub checkAndStartPortMaping{if ((
$forceStartUPnPMap==(0x0deb+ 5780-0x247e))){setFlagForceStartUPnPMap (
(0x1452+ 1156-0x18d6));__setExternalUPnPPortsForAllServices ($NORMAL_MODE);
forceAddPortMapping ();}return;}sub parseNXUpNPMessage{(my $buffer=shift (@_));(my $type
=shift (@_));($buffer=lc ($buffer));($buffer=~ s/tcp=// );(my $protocol=
"\x54\x43\x50");if (($buffer=~ s/udp=// )){($protocol="\x55\x44\x50");}(my (
@List)=split ( /;/ ,$buffer,(0x0f89+ 2357-0x18be)));(my $enabledPortMApping=
(0x0347+ 1814-0x0a5d));foreach my $service (@List){(my ($port,$state)=split ( /:/ ,
$service,(0x1e76+ 126-0x1ef1)));(my $name=getServiceNameByPort ($protocol,$port)
);setServiceState ($name,$state);if (($state==(0x0e8b+ 5592-0x2462))){(
$enabledPortMApping=(0x0d92+ 4382-0x1eaf));}}if (($type eq 
"\x61\x64\x64\x70\x6f\x72\x74\x73")){__checkInitializeStatusAndAdjustTimeout (
$enabledPortMApping,$protocol);}return;}sub startUPnPMap{(my $time=shift (@_));
__setUPnPMapEnabled ((0x1feb+ 1044-0x23fe));if (($time>(0x1710+ 1445-0x1cb5))){(
$UPnPMapStartTime=Common::NXTime::getSecondsSinceEpoch ());($UPnPMapTimeout=
$time);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x74\x61\x72\x74\x65\x64\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x27"
.$UPnPMapTimeout)."\x27\x2e"));return;}($UPnPMapStartTime=(0x243f+ 142-0x24cd));
($UPnPMapTimeout=(0x00e7+ 9480-0x25ef));Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x74\x61\x72\x74\x65\x64\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x74\x69\x6d\x65\x72\x2e"
);return;}sub stopUPnPMap{unsetUPnPServices ();__setUPnPMapEnabled (
(0x0a28+ 4718-0x1c96));__disableRepeatMapping ((0x1636+ 1032-0x1a3e));(
$UPnPMapStartTime=(0x03a8+ 4316-0x1484));($UPnPMapTimeout=(0x00c0+ 7960-0x1fd8))
;Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x74\x6f\x70\x65\x64\x20\x6d\x61\x70\x70\x69\x6e\x67\x2e"
);return;}sub isUPnPMapEnabled{return ($enabledUPnPMapping);}sub isUPnPEnabled{
if (($GLOBAL::EnableUPnP=~ /(NXTCP|NXUDP|SSH|HTTP)/i )){return (
(0x08af+ 6647-0x22a5));}Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x64\x2e");return (
(0x16e3+ 3342-0x23f1));}sub isUPnPEnabledForSessions{if ((($GLOBAL::EnableUPnP=~ /NX/i )
and ($GLOBAL::EnableUPnPSession eq "\x31"))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x0522+ 2628-0x0f65));}Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return ((0x12c7+  74-0x1311));}sub addUdpRuleForSession{(my $udpPort=shift (@_
));(my $local=NXClientConnection::getLocalIp ());(my $remote=
NXClientConnection::getRemoteIp ());main::nxrequire (
"\x4e\x58\x4e\x65\x74\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73");(my $mask=
NXNetInterfaces::getMask ($local));if ((NXNetInterfaces::checkIsLocal ($local,
$remote,$mask)==(0x0392+ 8870-0x2638))){addRule ("\x55\x44\x50",$udpPort,
(0x1aff+ 1808-0x220e));__setSessionPort ($port);}}sub setServiceUPnPTimeout{(my $service
=shift (@_));(my $timeout=(shift (@_)||$timeout));($serviceUPnPTimeout{$service}
=$timeout);}sub getServiceUPnPTimeout{(my $service=shift (@_));return (
$serviceUPnPTimeout{$service});}sub setServiceUPnPExternalPortFile{(my $service=
shift (@_));($serviceUPnPExternalPortFile{$service}=((
$GLOBAL::ExternalTCPPortsDir.$GLOBAL::DIRECTORY_SLASH).$service));}sub 
getServiceUPnPExternalPortFile{(my $service=shift (@_));return (
$serviceUPnPExternalPortFile{$service});}sub setUPnPStartTime{(my $service=shift
 (@_));($serviceUPnPStartTime{$service}=Common::NXTime::getSecondsSinceEpoch ())
;return;}sub getUPnPStartTime{(my $service=shift (@_));return (
$serviceUPnPStartTime{$service});}sub setServiceUPnPPort{(my $service=shift (@_)
);if (((not (defined ($service)))or ($service eq ("")))){return (
(0x0907+ 792-0x0c1f));}(my $port=(0x030c+ 4629-0x1521));if (($service eq 
$__serviceUpnpnxTcp)){($port=NXNodeInfo::getNxdPort ());}if (($service eq 
$__serviceUpnpnxUdp)){($port=NXNodeInfo::getNxdUDPPort ());}elsif (($service eq 
$__serviceUpnphttps)){($port=NXNodeInfo::getHttpsPort ());}elsif (($service eq 
$__serviceUpnpssh)){($port=NXNodeInfo::getSshdPort ());}if ((((not (defined (
$serviceUPnPPort{$service})))or ($serviceUPnPPort{$service}eq ("")))or (
$serviceUPnPPort{$service}eq "\x30"))){($serviceUPnPPort{$service}=$port);}
Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x70\x6f\x72\x74\x20\x27").$serviceUPnPPort{$service}).
"\x27\x2e"));return;}sub getServiceUPnPPort{(my $service=shift (@_));if (((not (
defined ($service)))or ($service eq ("")))){return ((0x1f47+ 651-0x21d2));}if ((
defined ($serviceUPnPPort{$service})and ($serviceUPnPPort{$service}ne ("")))){
return ($serviceUPnPPort{$service});}else{setServiceUPnPPort ($service);if ((
defined ($serviceUPnPPort{$service})and ($serviceUPnPPort{$service}ne ("")))){
return ($serviceUPnPPort{$service});}}return ((0x07c0+ 141-0x084d));}sub init{
Logger::debug2 (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x69\x6e\x69\x74\x28\x29\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);(my $silence=shift (@_));__createFileStructure ();foreach my $service (
@UPnPServices){__initUPnPService ($service);}if (isUPnPEnabled ()){
__setRepeatMapping ($repeatMappingStarted);__calculateCountForRepeatMapping ();
__setUPnPMapEnabled ((0x087a+ 7525-0x25de));}if ((
__setExternalUPnPPortsForAllServices ($BACKGROUND_MODE)==(0x11d7+ 4342-0x22cd)))
{setFlagForceStartUPnPMap ((0x10c9+ 2995-0x1c7b));return ((0x03a5+ 6696-0x1dcc))
;}return ((0x01e4+ 1081-0x061d));}sub initServices{foreach my $service (
@UPnPServices){__initUPnPService ($service);}
__setExternalUPnPPortsForAllServices ($NORMAL_MODE);return;}sub 
destroyNetworkThread{if (($networkThreadStarted>(0x0beb+ 5499-0x2166))){
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x65\x73\x74\x72\x6f\x79\x4e\x65\x74\x77\x6f\x72\x6b\x54\x68\x72\x65\x61\x64\x28\x29\x20\x73\x74\x61\x72\x74\x2e"
);(my $exit_value=libnxhs::NXDestroyNetworkThread ());Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x44\x65\x73\x74\x72\x6f\x79\x4e\x65\x74\x77\x6f\x72\x6b\x54\x68\x72\x65\x61\x64\x28\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20"
.$exit_value)."\x2e"));setNetworkThreadFlag ((0x24f9+ 161-0x259a));
setNetworkInfoFlag ((0x2275+ 254-0x2373));}else{Logger::debug2 (
"\x4e\x65\x74\x77\x6f\x72\x6b\x54\x68\x72\x65\x61\x64\x20\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x65\x64\x2c\x20\x73\x6b\x69\x70\x70\x65\x64\x2e"
);}}sub destroy{destroyNetworkThread ();NXUdpControl::destroy ();return;}sub 
isUPnPServiceEnabled{(my $service=shift (@_));if (((not (defined ($service)))or 
($service eq ("")))){return ((0x200c+ 149-0x20a1));}if ((lc ($GLOBAL::EnableUPnP
)eq "\x6e\x6f\x6e\x65")){return ((0x06e1+ 3947-0x164c));}(my $return=
(0x00d5+ 3918-0x1023));if (((($service eq $__serviceUpnpnxTcp)and (
$GLOBAL::EnableUPnP=~ /NXTCP/ ))and NXSystemDaemons::isNxdEnabled ())){($return=
(0x07f2+ 4197-0x1856));}elsif (((($service eq $__serviceUpnpnxUdp)and (
$GLOBAL::EnableUPnP=~ /NXUDP/ ))and NXSystemDaemons::isNxdEnabled ())){($return=
(0x13b5+ 2125-0x1c01));}elsif (((($service eq $__serviceUpnphttps)and (
$GLOBAL::EnableUPnP=~ /HTTP/ ))and 
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ())){($return=
(0x0fa6+ 1382-0x150b));}elsif (((($service eq $__serviceUpnpssh)and (
$GLOBAL::EnableUPnP=~ /SSH/ ))and NXSystemDaemons::isSSHEnabled ())){($return=
(0x0ccd+ 2364-0x1608));}if (($return==(0x1201+ 1757-0x18dd))){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service)
."\x27\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"));return ((0x0760+ 7422-0x245d));}
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service)
."\x27\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"));return ((0x03e7+ 7015-0x1f4e))
;}sub getStatusMessage{(my $response=(""));if (
isNotAllUpnpGetNetworkInfoInMemory ()){getNetworkInfo ();}if (
isNotAllUpnpGetNetworkInfoInMemory ()){return ((""));}($response.=((
"\x4c\x6f\x63\x61\x6c\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$LocalIP)."\x0a"));($response.=((
"\x47\x61\x74\x65\x77\x61\x79\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$GatewayIP)."\x0a"));($response.=((
"\x45\x78\x74\x65\x72\x6e\x61\x6c\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$ExternalIP)."\x0a"));return ($response);}sub __sendMsgOnSocket{Logger::debug2 
((("\x5f\x5f\x73\x65\x6e\x64\x4d\x73\x67\x4f\x6e\x53\x6f\x63\x6b\x65\x74\x28".
join ($",@_))."\x29\x20\x73\x74\x61\x72\x74\x65\x64\x2e"));(my $clientSocket=
shift (@_));(my $response=shift (@_));if ((($clientSocket eq (""))or (
$clientSocket<(0x0b47+ 6504-0x24af)))){Logger::debug (((
"\x5f\x5f\x73\x65\x6e\x64\x4d\x73\x67\x4f\x6e\x53\x6f\x63\x6b\x65\x74\x3a\x20\x53\x6f\x63\x6b\x65\x74\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x6f\x73\x65\x64\x20\x46\x44\x23"
.$clientSocket)."\x2c\x20\x73\x6b\x69\x70\x70\x65\x64\x2e"));return (
(0x13bf+ 2727-0x1e66));}if ((defined ($response)and ($response ne ("")))){
Logger::debug (((((
"\x5f\x5f\x73\x65\x6e\x64\x4d\x73\x67\x4f\x6e\x53\x6f\x63\x6b\x65\x74\x3a\x20\x53\x65\x6e\x64\x20\x75\x70\x6e\x70\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$clientSocket)."\x3a\x20").$response)."\x2e"));main::nxwrite ($clientSocket,
$response);return ((0x1a8c+ 1107-0x1ede));}return ((0x0390+ 8877-0x263d));}sub 
handleCodeStartUPnPMap{(my $clientSocket=shift (@_));(my $body=shift (@_));if ((
$clientSocket eq (""))){return ((0x1822+ 2507-0x21ed));}(my $upnpFD=
handleUPnPMapMessage ($clientSocket,$body));if (($upnpFD>(0x00d1+ 986-0x04ab))){
return ((0x1159+ 4934-0x249e));}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x43\x6f\x64\x65\x53\x74\x61\x72\x74\x55\x50\x6e\x50\x4d\x61\x70\x28\x29\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6f\x6e\x6c\x79\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x73\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x2e"
);(my $msg=buildMessageUPnPStatus ());__sendMsgOnSocket ($clientSocket,$msg);
return ((0x0c6a+ 3547-0x1a45));}return ((0x1acd+ 206-0x1b9a));}sub 
handleUPnPMapMessage{(my $clientSocket=shift (@_));(my $message=shift (@_));(my $time
=(""));(my $upnpKey=(""));if (($message=~ /upnpmap time=(\d+):key=(.*)$/ )){(
$time=$1);($upnpKey=$2);}else{Logger::warning (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x6d\x61\x70\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);return ((0x060f+ 6822-0x20b5));}Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x6d\x61\x70\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x69\x6d\x65\x20\x27"
.$time)."\x27\x20\x6b\x65\x79\x20\x27").$upnpKey)."\x27\x2e"));(my $internalTCPPortsToAdd
=(""));(my $externalTCPPortsToAdd=(""));(my $internalUDPPortsToAdd=(""));(my $externalUDPPortsToAdd
=(""));(my $internalTCPPortsToDelete=(""));(my $externalTCPPortsToDelete=(""));(my $internalUDPPortsToDelete
=(""));(my $externalUDPPortsToDelete=(""));if ((((not (defined ($upnpKey)))or (
$upnpKey eq ("")))or ($upnpKey eq "\x6e\x6f\x6e\x65"))){($GLOBAL::EnableUPnP=
"\x6e\x6f\x6e\x65");}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x76\x61\x6c\x75\x65\x73\x2e"
);(my (@servicesList)=split ( /,/ ,$upnpKey,(0x0e5a+ 1795-0x155d)));(
$GLOBAL::EnableUPnP=(""));foreach my $serviceElement (@servicesList){(my (
@services)=split ( /:/ ,$serviceElement,(0x13fb+ 1835-0x1b26)));(my $service=
(""));if (($services[(0x0a40+ 1885-0x119d)]eq $__cfgNXTCPKeyValue)){(
$GLOBAL::EnableUPnP.=$__cfgNXTCPKeyValue);($service=$__serviceUpnpnxTcp);}elsif 
(($services[(0x0da6+ 3881-0x1ccf)]eq $__cfgNXUDPKeyValue)){($GLOBAL::EnableUPnP
.=("\x2c".$__cfgNXUDPKeyValue));($service=$__serviceUpnpnxUdp);}elsif ((
$services[(0x1efd+ 921-0x2296)]eq $__cfgSSHDKeyValue)){($GLOBAL::EnableUPnP.=(
"\x2c".$__cfgSSHDKeyValue));($service=$__serviceUpnpssh);}elsif (($services[
(0x1d6c+ 998-0x2152)]eq $__cfgHTTPKeyValue)){($GLOBAL::EnableUPnP.=("\x2c".
$__cfgHTTPKeyValue));($service=$__serviceUpnphttps);}else{next;}(my $iPort=
getServiceUPnPPort ($service));(my $newExtPort=$services[(0x14f7+ 374-0x166c)]);
(my $oldExtPort=getExternalUPnPPort ($service));if (isServiceActive ($service)){
if ((($newExtPort eq (""))or ($newExtPort!=$oldExtPort))){Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x6f\x6c\x64\x20\x70\x6f\x72\x74\x20\x27").$oldExtPort).
"\x27\x2e"));if (isTCPService ($service)){($internalTCPPortsToDelete.=($iPort.
"\x3a"));($externalTCPPortsToDelete.=($oldExtPort."\x3a"));}else{(
$internalUDPPortsToDelete.=($iPort."\x3a"));($externalUDPPortsToDelete.=(
$oldExtPort."\x3a"));}}}if ((($newExtPort ne (""))and ($newExtPort!=
(0x01a3+ 1744-0x0873)))){__setExternalUPnPPort ($service,$newExtPort);}}}
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x20\x27"
.$GLOBAL::EnableUPnP)."\x27\x2e"));if ((checkAllNetworkInformationsFromMemory ()
==(0x08a9+ 7264-0x2509))){getNetworkInfoBackground ((0x0e08+ 4079-0x1df7));}
startUPnPMap ($time);if ((lc ($GLOBAL::EnableUPnP)eq "\x6e\x6f\x6e\x65")){
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x70\x6f\x72\x74\x73\x2e"
);(my $ret=deleteServiceRules ((0x0196+ 629-0x040b),$BACKGROUND_MODE));if (($ret
>(0x03d8+ 7355-0x2093))){addSocketToClientList ($clientSocket,$ret,
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");(
$flagInformAllNodesAboutUPnPChanges=(0x1993+ 2178-0x2214));}unsetUPnPServices ()
;return ($ret);}foreach my $service (@UPnPServices){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x73\x2e"
);(my $iPort=getServiceUPnPPort ($service));(my $ePort=getExternalUPnPPort (
$service));Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x72\x76\x69\x63\x65\x20\x27".$service)
."\x27\x20\x69\x70\x6f\x72\x74\x20\x27").$iPort).
"\x27\x20\x65\x70\x6f\x72\x74\x20\x27").$ePort)."\x27\x2e"));if (
isUPnPServiceEnabled ($service)){if (isNotSetServiceUPnPExternalPort ($service))
{setExternalTCPPortFile ($service);}if (isTCPService ($service)){(
$internalTCPPortsToAdd.=($iPort."\x3a"));($externalTCPPortsToAdd.=($ePort."\x3a"
));}else{($internalUDPPortsToAdd.=($iPort."\x3a"));($externalUDPPortsToAdd.=(
$ePort."\x3a"));}}else{if (isServiceActive ($service)){if (isTCPService (
$service)){($internalTCPPortsToDelete.=($iPort."\x3a"));(
$externalTCPPortsToDelete.=($ePort."\x3a"));}else{($internalUDPPortsToDelete.=(
$iPort."\x3a"));($externalUDPPortsToDelete.=($ePort."\x3a"));}($serviceUPnP{
$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x0836+ 7269-0x249b));}}}(
$internalTCPPortsToDelete=~ s/:$// );($externalTCPPortsToDelete=~ s/:$// );
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x54\x6f\x44\x65\x6c\x65\x74\x65\x20\x27"
.$internalTCPPortsToDelete)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x54\x6f\x44\x65\x6c\x65\x74\x65\x20\x27"
.$externalTCPPortsToDelete)."\x27\x2e"));(my $upnpFD=(0x1636+ 2094-0x1e64));(my $type
=(""));if ((($internalTCPPortsToDelete ne (""))and ($externalTCPPortsToDelete ne
 ("")))){($upnpFD=deletePortMappingBackground ($internalTCPPortsToDelete,
$externalTCPPortsToDelete,"\x54\x43\x50"));($type=
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");}($internalUDPPortsToDelete=~ s/:$// )
;($externalUDPPortsToDelete=~ s/:$// );Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x54\x6f\x44\x65\x6c\x65\x74\x65\x20\x27"
.$internalUDPPortsToDelete)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x54\x6f\x44\x65\x6c\x65\x74\x65\x20\x27"
.$externalUDPPortsToDelete)."\x27\x2e"));if ((($internalUDPPortsToDelete ne ("")
)and ($externalUDPPortsToDelete ne ("")))){($upnpFD=deletePortMappingBackground 
($internalUDPPortsToDelete,$externalUDPPortsToDelete,"\x55\x44\x50"));($type=
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");}($internalTCPPortsToAdd=~ s/:$// )
;($externalTCPPortsToAdd=~ s/:$// );Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x54\x6f\x41\x64\x64\x20\x27"
.$internalTCPPortsToAdd)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x54\x6f\x41\x64\x64\x20\x27"
.$externalTCPPortsToAdd)."\x27\x2e"));if ((($internalTCPPortsToAdd ne (""))and (
$externalTCPPortsToAdd ne ("")))){($upnpFD=__addTCPRule ($internalTCPPortsToAdd,
$externalTCPPortsToAdd,$BACKGROUND_MODE));($type=
"\x61\x64\x64\x70\x6f\x72\x74\x73");}($internalUDPPortsToAdd=~ s/:$// );(
$externalUDPPortsToAdd=~ s/:$// );Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x54\x6f\x41\x64\x64\x20\x27"
.$internalUDPPortsToAdd)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x54\x6f\x41\x64\x64\x20\x27"
.$externalUDPPortsToAdd)."\x27\x2e"));if ((($internalUDPPortsToAdd ne (""))and (
$externalUDPPortsToAdd ne ("")))){($upnpFD=__addUDPRule ($internalUDPPortsToAdd,
$externalUDPPortsToAdd,$BACKGROUND_MODE));($type=
"\x61\x64\x64\x70\x6f\x72\x74\x73");}if (($upnpFD>(0x17b3+ 645-0x1a38))){
addSocketToClientList ($clientSocket,$upnpFD,$type);}return ($upnpFD);}sub 
handleCodeStopUPnPMap{(my $clientSocket=shift (@_));Logger::debug (
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x73\x74\x6f\x70\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);if (($clientSocket eq (""))){return ((0x00e0+ 4869-0x13e5));}stopUPnPMap ();if
 ((checkNetworkInformationsFromMemory ()==(0x0481+ 2485-0x0e36))){
getNetworkInfoBackground ((0x0fe1+ 3957-0x1f56));}(my $upnpFD=deleteServiceRules
 ((0x0a4c+ 1943-0x11e3),$BACKGROUND_MODE));if (($upnpFD>(0x1b78+ 103-0x1bdf))){
addSocketToClientList ($clientSocket,$upnpFD,
"\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");(
$flagInformAllNodesAboutUPnPChanges=(0x058f+ 6777-0x2007));return (
(0x046b+ 1147-0x08e5));}return ((0x0871+ 6659-0x2274));}sub 
handleCodeDeleteUPnPMap{(my $socket_fn=shift (@_));(my $message=(shift (@_)||
("")));($message=~ s/\0// );if (($message=~ /port=(\d+)/ )){(my $port=$1);
deletePortMappingBackground ($port,$port,"\x55\x44\x50",
"\x73\x65\x73\x73\x69\x6f\x6e");}else{Logger::warning (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));}return ((0x07ab+ 2619-0x11e6));}sub 
handleCodeStatusUPnPMap{(my $clientSocket=shift (@_));Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x73\x74\x61\x74\x75\x73\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$clientSocket)."\x2e"));if ((($clientSocket eq (""))or ($clientSocket<
(0x09f4+ 2766-0x14c2)))){return ((0x1655+ 891-0x19d0));}if ((
checkAllNetworkInformationsFromMemory ()==(0x13f4+ 1785-0x1aed))){(my $upnpFD=
getNetworkInfoBackground ((0x08f2+ 6348-0x21bd)));if (($upnpFD!=
(0x06e0+ 7700-0x24f4))){addSocketToClientList ($clientSocket,$upnpFD,
"\x6e\x65\x74\x69\x6e\x66\x6f");return ((0x09ad+ 6556-0x2348));}}(my $skipEmpty=
(0x03b9+ 5332-0x188c));(my $body=buildMessageUPnPStatusFromMemory ($skipEmpty));
Logger::debug2 (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x43\x6f\x64\x65\x53\x74\x61\x74\x75\x73\x55\x50\x6e\x50\x4d\x61\x70\x3a\x20\x53\x65\x6e\x64\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x20\x6f\x6e\x20\x46\x44\x23"
.$clientSocket)."\x2e"));main::nxwrite ($clientSocket,$body);return (
(0x0a70+ 1829-0x1195));}sub buildMessageUPnPStatusFromMemory{(my $skipEmpty=(
shift (@_)||(0x025b+ 2740-0x0d0f)));if ((($skipEmpty==(0x119d+ 3818-0x2087))and 
isNotAllUpnpGetNetworkInfoInMemory ())){Logger::debug (
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x53\x6b\x69\x70\x20\x62\x75\x69\x6c\x64\x20\x55\x50\x6e\x50\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);return ((""));}if ((not (NXMsg::isMessageRegistered (
"\x69\x43\x4d\x44\x55\x70\x6e\x70\x53\x74\x61\x74\x75\x73")))){
NXMsg::register_response ("\x4e\x58\x55\x70\x6e\x70",
"\x69\x43\x4d\x44\x55\x70\x6e\x70\x53\x74\x61\x74\x75\x73",
$GLOBAL::MSG_UPNP_STATUS);}(my ($regex,$response)=NXMsg::get_msg (
"\x69\x43\x4d\x44\x55\x70\x6e\x70\x53\x74\x61\x74\x75\x73",
"\x4e\x58\x55\x70\x6e\x70"));($response.="\x0a");($response.=((
"\x4c\x6f\x63\x61\x6c\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$LocalIP)."\x0a"));($response.=((
"\x47\x61\x74\x65\x77\x61\x79\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$GatewayIP)."\x0a"));($response.=((
"\x45\x78\x74\x65\x72\x6e\x61\x6c\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20"
.$ExternalIP)."\x0a"));foreach my $service (@UPnPServices){if (((not (defined (
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"})))or ($serviceUPnP{
$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}==(0x0285+ 1234-0x0757)))){next;}
getExternalUPnPPort ($service);(my $body=(""));if (($service eq 
$__serviceUpnpnxTcp)){($body.="\x4e\x58\x20\x54\x43\x50\x20\x70\x6f\x72\x74\x20"
);}elsif (($service eq $__serviceUpnpnxUdp)){($body.=
"\x4e\x58\x20\x55\x44\x50\x20\x70\x6f\x72\x74\x20");}elsif (($service eq 
$__serviceUpnpssh)){($body.="\x53\x53\x48\x20\x70\x6f\x72\x74\x20");}elsif ((
$service eq $__serviceUpnphttps)){($body.=
"\x48\x54\x54\x50\x20\x70\x6f\x72\x74\x20");}($body.=(getServiceUPnPPort (
$service)."\x20\x6d\x61\x70\x70\x65\x64\x20\x74\x6f\x3a\x20"));($response.=((((
sprintf ("\x25\x2d\x32\x37\x73",$body).$ExternalIP)."\x3a").
$serviceUPnPExternalPort{$service})."\x0a"));}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x42\x75\x69\x6c\x64\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$response)."\x27\x2e"));return ($response);}sub buildStatusMessageForClient{
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x42\x75\x69\x6c\x64\x20\x73\x74\x61\x74\x75\x73\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);(my $response=(""));($response.=(("\x6c\x6f\x63\x61\x6c\x2c".$LocalIP).
$FIELD_SEPARATOR));($response.=(("\x67\x61\x74\x65\x77\x61\x79\x2c".$GatewayIP).
$FIELD_SEPARATOR));($response.=("\x65\x78\x74\x65\x72\x6e\x61\x6c\x2c".
$ExternalIP));foreach my $service (@UPnPServices){if (((not (defined (
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"})))or ($serviceUPnP{
$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}==(0x14dd+ 2002-0x1caf)))){next;}
getExternalUPnPPort ($service);if ((($serviceUPnPExternalPort{$service}<=
(0x0b7a+ 5113-0x1f73))or ($ExternalIP eq ("")))){Logger::debug2 (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6b\x69\x70\x20\x27".$service).
"\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6d\x69\x73\x73\x69\x6e\x67\x3a\x20").
$ExternalIP)."\x3a").$serviceUPnPExternalPort{$service})."\x2e"));next;}(
$response.=$FIELD_SEPARATOR);if (($service eq $__serviceUpnpnxTcp)){($response.=
"\x6e\x78\x74\x63\x70\x2c");}elsif (($service eq $__serviceUpnpnxUdp)){(
$response.="\x6e\x78\x75\x64\x70\x2c");}elsif (($service eq $__serviceUpnpssh)){
($response.="\x73\x73\x68\x2c");}elsif (($service eq $__serviceUpnphttps)){(
$response.="\x68\x74\x74\x70\x2c");}($response.=(getServiceUPnPPort ($service).
"\x2c"));($response.=main::urlencode ((($ExternalIP.$FIELD_SEPARATOR).
$serviceUPnPExternalPort{$service})));}(my $response_enc=main::urlencode ((
"\x75\x70\x6e\x70\x73\x74\x61\x74\x75\x73\x20".$response)));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x42\x75\x69\x6c\x64\x20\x63\x6c\x69\x65\x6e\x74\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x27"
.$response)."\x27\x2e"));return ($response_enc);}sub buildMessageUPnPStatus{if (
isNotAllUpnpGetNetworkInfoInMemory ()){getNetworkInfo ();}return (
buildMessageUPnPStatusFromMemory ());}sub handleUPnPUnMapMessage{stopUPnPMap ();
deleteServiceRules ((0x12a1+ 3608-0x20b9),$NORMAL_MODE);return (
buildMessageUPnPStatus ());}sub commandUPnPMap{(my $time=(shift (@_)||
(0x0b3b+ 4469-0x1cb0)));Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x48\x61\x6e\x64\x6c\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x55\x50\x6e\x50\x20\x6d\x61\x70\x2e"
);if ((not (NXClientSystemDaemons::openConnection ()))){__sendMsgOnSocket (
main::nxgetSTDOUT (),getStatusMessage ());return ((0x02bc+ 2490-0x0c76));}(my $key
=(""));if (($GLOBAL::EnableUPnP=~ /none/ )){($key="\x6e\x6f\x6e\x65");}else{
main::nxrequire ("\x4e\x58\x54\x6f\x6f\x6c\x73");if (($GLOBAL::EnableUPnP=~ /NXTCP/ )
){($key.="\x4e\x58\x54\x43\x50\x3a");if ((NXTools::isCorrectPort (
$GLOBAL::NXTCPUPnPPort)and ($GLOBAL::NXTCPUPnPPort>=(0x100d+ 4961-0x236d)))){(
$key.=$GLOBAL::NXTCPUPnPPort);}else{(my $portFromFile=
getExternalUPnPPortFromFile ("\x75\x70\x6e\x70\x6e\x78\x74\x63\x70"));if (((
defined ($portFromFile)and ($portFromFile ne ("")))and ($portFromFile>
(0x0261+ 1930-0x09eb)))){($key.=$portFromFile);}}}if (($GLOBAL::EnableUPnP=~ /NXUDP/ )
){($key.="\x2c\x4e\x58\x55\x44\x50\x3a");if ((NXTools::isCorrectPort (
$GLOBAL::NXUDPUPnPPort)and ($GLOBAL::NXUDPUPnPPort>=(0x0a0f+ 604-0x0c6a)))){(
$key.=$GLOBAL::NXUDPUPnPPort);}else{(my $portFromFile=
getExternalUPnPPortFromFile ("\x75\x70\x6e\x70\x6e\x78\x75\x64\x70"));if (((
defined ($portFromFile)and ($portFromFile ne ("")))and ($portFromFile>
(0x0f29+ 3087-0x1b38)))){($key.=$portFromFile);}}}if (($GLOBAL::EnableUPnP=~ /SSH/ )
){($key.="\x2c\x53\x53\x48\x3a");if ((NXTools::isCorrectPort (
$GLOBAL::SSHUPnPPort)and ($GLOBAL::SSHUPnPPort>=(0x195d+ 2558-0x235a)))){($key.=
$GLOBAL::SSHUPnPPort);}else{(my $portFromFile=getExternalUPnPPortFromFile (
"\x75\x70\x6e\x70\x73\x73\x68"));if (((defined ($portFromFile)and ($portFromFile
 ne ("")))and ($portFromFile>(0x0e01+ 3264-0x1ac1)))){($key.=$portFromFile);}}}
if (($GLOBAL::EnableUPnP=~ /HTTP/ )){($key.="\x2c\x48\x54\x54\x50\x3a");if ((
NXTools::isCorrectPort ($GLOBAL::HTTPUPnPPort)and ($GLOBAL::HTTPUPnPPort>=
(0x1f38+ 1265-0x2428)))){($key.=$GLOBAL::HTTPUPnPPort);}else{(my $portFromFile=
getExternalUPnPPortFromFile ("\x75\x70\x6e\x70\x68\x74\x74\x70\x73"));if (((
defined ($portFromFile)and ($portFromFile ne ("")))and ($portFromFile>
(0x0ca6+ 4194-0x1d08)))){($key.=$portFromFile);}}}if (($key eq (""))){($key=
"\x6e\x6f\x6e\x65");}}NXClientSystemDaemons::cleanDaemonBuffer ();(my $testresult
=NXClientSystemDaemons::sendMessage ((((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPNP_START).
"\x20\x75\x70\x6e\x70\x6d\x61\x70\x20\x74\x69\x6d\x65\x3d").$time).
"\x3a\x6b\x65\x79\x3d").$key)."\x0a")));(my $reply=
NXClientSystemDaemons::parseMessageFromServer ($Handlerstimeout));
NXClientSystemDaemons::closeConnection ();if ((defined ($reply)and ($reply ne 
("")))){main::nxwrite (main::nxgetSTDOUT (),$reply);}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4e\x6f\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x66\x72\x6f\x6d\x20\x64\x61\x65\x6d\x6f\x6e\x2e"
);__sendMsgOnSocket (main::nxgetSTDOUT (),getStatusMessage ());}return (
(0x0276+ 163-0x0318));}sub commandUPnPUnMap{(my $time=(shift (@_)||
(0x0c36+  15-0x0c45)));if ((not (NXClientSystemDaemons::openConnection ()))){
__sendMsgOnSocket (main::nxgetSTDOUT (),getStatusMessage ());return (
(0x0102+ 6779-0x1b7d));}NXClientSystemDaemons::cleanDaemonBuffer ();(my $testresult
=NXClientSystemDaemons::sendMessage ((("\x4e\x58\x3e\x20".$GLOBAL::MSG_UPNP_STOP
)."\x20\x75\x70\x6e\x70\x75\x6e\x6d\x61\x70\x0a")));(my $reply=
NXClientSystemDaemons::parseMessageFromServer ($Handlerstimeout));
NXClientSystemDaemons::closeConnection ();if ((defined ($reply)and ($reply ne 
("")))){main::nxwrite (main::nxgetSTDOUT (),$reply);}else{__sendMsgOnSocket (
main::nxgetSTDOUT (),getStatusMessage ());}return ((0x00b6+ 9761-0x26d6));}sub 
getStatus{if ((not (NXClientSystemDaemons::openConnection ()))){
__sendMsgOnSocket (main::nxgetSTDOUT (),getStatusMessage ());return;}
NXClientSystemDaemons::cleanDaemonBuffer ();(my $testresult=
NXClientSystemDaemons::sendMessage ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPNP_STATUS_REQUEST).
"\x20\x75\x70\x6e\x70\x73\x74\x61\x74\x75\x73\x0a")));(my $reply=
NXClientSystemDaemons::parseMessageFromServer ($Handlerstimeout));if ((defined (
$reply)and ($reply ne ("")))){main::nxwrite (main::nxgetSTDOUT (),$reply);}
NXClientSystemDaemons::closeConnection ();return;}sub checkIfAddPortMapping{
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x68\x65\x63\x6b\x20\x70\x6f\x72\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x2e"
);if (($UPnPMapTimeout>(0x1566+ 2333-0x1e83))){(my $mappingLife=(
Common::NXTime::getSecondsSinceEpoch ()-$UPnPMapStartTime));if (($mappingLife>=
$UPnPMapTimeout)){stopUPnPMap ();deleteServiceRules ((0x07f2+ 7395-0x24d5),
$NORMAL_MODE);return;}}(my $nxupnpLife=(Common::NXTime::getSecondsSinceEpoch ()-
$UPnPStartTime));if (($nxupnpLife<$timeout)){return;}if (($networkInfostarted==
(0x132b+ 2838-0x1e40))){return;}($UPnPStartTime=
Common::NXTime::getSecondsSinceEpoch ());if ((getLocalIPFromMemory ()eq (""))){
getNetworkInfoBackground ((0x0c52+ 3215-0x18e1));return ((""));}addServiceRules 
((0x0a64+ 6203-0x229f));}sub forceAddPortMapping{(my $force=
(0x0323+ 7770-0x217c));return (addServiceRules ($force));}sub addServiceRules{(my $force
=(shift (@_)||(0x0390+ 6561-0x1d31)));if (($force==(0x13a4+ 4247-0x243b))){if ((
$UPnPMapTimeout>(0x1606+ 1985-0x1dc7))){(my $mappingLife=(
Common::NXTime::getSecondsSinceEpoch ()-$UPnPMapStartTime));if (($mappingLife>=
$UPnPMapTimeout)){stopUPnPMap ();deleteServiceRules ((0x037b+ 5829-0x1a40),
$NORMAL_MODE);return ((0x05b3+ 5866-0x1c9d));}}}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x46\x6f\x72\x63\x65\x20\x73\x74\x61\x72\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x70\x6f\x72\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x2e"
);}(my $internalTCPPorts=(""));(my $externalTCPPorts=(""));(my $internalUDPPorts
=(""));(my $externalUDPPorts=(""));foreach my $service (@UPnPServices){if (
isUPnPServiceEnabled ($service)){(my $iPort=getServiceUPnPPort ($service));
getExternalUPnPPortFromMemory ($service);if (isNotSetServiceUPnPExternalPort (
$service)){next;}(my $ePort=$serviceUPnPExternalPort{$service});if ((((($ePort==
(0x084d+ 1697-0x0eee))or ($iPort==(0x1122+ 3004-0x1cde)))or ($ePort eq ("")))or 
($iPort eq ("")))){next;}if (isTCPService ($service)){($internalTCPPorts.=(
$iPort."\x3a"));($externalTCPPorts.=($ePort."\x3a"));}else{($internalUDPPorts.=(
$iPort."\x3a"));($externalUDPPorts.=($ePort."\x3a"));}}}($internalTCPPorts=~ s/:$// )
;($externalTCPPorts=~ s/:$// );Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x20\x27"
.$internalTCPPorts)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x73\x20\x27"
.$externalTCPPorts)."\x27\x2e"));if ((($internalTCPPorts ne (""))and (
$externalTCPPorts ne ("")))){__addTCPRule ($internalTCPPorts,$externalTCPPorts,
$BACKGROUND_MODE);}($internalUDPPorts=~ s/:$// );($externalUDPPorts=~ s/:$// );
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x20\x27"
.$internalUDPPorts)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x55\x44\x50\x50\x6f\x72\x74\x73\x20\x27"
.$externalUDPPorts)."\x27\x2e"));if ((($internalUDPPorts ne (""))and (
$externalUDPPorts ne ("")))){__addUDPRule ($internalUDPPorts,$externalUDPPorts,
$BACKGROUND_MODE);}return ((0x0a54+ 439-0x0c0b));}sub isTCPService{(my $service=
shift (@_));if (($service ne "\x75\x70\x6e\x70\x6e\x78\x75\x64\x70")){return (
(0x197c+ 1499-0x1f56));}return ((0x0236+ 5558-0x17ec));}sub isUDPService{(my $service
=shift (@_));if (($service eq "\x75\x70\x6e\x70\x6e\x78\x75\x64\x70")){return (
(0x0a72+ 4018-0x1a23));}return ((0x0ed0+ 4116-0x1ee4));}sub addRule{(my $protocol
=shift (@_));(my $port=shift (@_));if (((($protocol eq (""))or ($port eq ("")))
or ($port==(0x14c7+ 2924-0x2033)))){Logger::warning (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x61\x64\x64\x52\x75\x6c\x65\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3a\x20\x27"
.$protocol)."\x27\x2c\x20\x70\x6f\x72\x74\x3a\x20\x27").$port)."\x27\x2e"));
return ((0x03d7+ 2766-0x0ea5));}my ($read,$write);if (main::nxPipeCreateBi ((
\$read),(\$write))){Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x20\x63\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x46\x44\x23"
.$read)."\x20\x46\x44\x23").$write)."\x2e"));}else{Logger::error (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x70\x61\x69\x72\x2e"
);return ((0x0c89+ 2118-0x14cf));}Logger::debug (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x28"
.$write)."\x2c\x20").$port)."\x2c\x20").$port)."\x2c\x20").$protocol).
"\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exitValue=libnxhs::NXCreatePortsAdd (
$write,$port,$port,$protocol));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x27"
.$exitValue)."\x27\x2e"));if (($exitValue<(0x172a+ 1536-0x1d2a))){
Logger::warning (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6e\x78\x75\x70\x6e\x70\x2e"
);main::nxclose ($read);main::nxclose ($write);return ((0x0ca0+  23-0x0cb7));}
NXSystemDaemons::addUPnPFD ("\x61\x64\x64\x70\x6f\x72\x74\x73",$read,$write,
(0x080a+ 6786-0x228c));if (($protocol eq "\x55\x44\x50")){setFlagUDPPortAdded ()
;}setNetworkThreadFlag ((0x02fa+ 6303-0x1b98));if (($protocol eq "\x55\x44\x50")
){main::addFhToMonitor ($read,
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x72\x41\x64\x64\x55\x44\x50\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);}return ((0x0704+ 7738-0x253d));}sub handlerAddUDPCallback{(my $f=shift (@_));
Logger::debug2 (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x72\x41\x64\x64\x55\x44\x50\x43\x61\x6c\x6c\x62\x61\x63\x6b\x28\x29\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);(my $read_buf=(""));(my $bytes_read=(0x0ba4+ 1989-0x1369));(($bytes_read,
$read_buf)=readOnCallbackFD ($f));destroyNetworkThread ();}sub 
handlerDeleteUDPCallback{(my $f=shift (@_));NXUdpControl::freePort (
NXSystemDaemons::getUpPnPFDPort ($f));}sub deleteServiceRules{(my $skipWaiting=(
shift (@_)||(0x00ff+ 7280-0x1d6f)));(my $mode=(shift (@_)||$NORMAL_MODE));
Logger::debug2 (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x44\x65\x6c\x65\x74\x65\x20\x73\x65\x72\x76\x69\x63\x65\x20\x72\x75\x6c\x65\x73\x20\x73\x6b\x69\x70\x57\x61\x69\x74\x69\x6e\x67\x20\x27"
.$skipWaiting)."\x27\x20\x6d\x6f\x64\x65\x20\x27").$mode)."\x27\x2e"));foreach my $service
 (@UPnPServices){getExternalUPnPPort ($service);}(my $internalTCPPortsToDelete=
(""));(my $externalTCPPortsToDelete=(""));(my $internalUDPPortsToDelete=(""));(my $externalUDPPortsToDelete
=(""));foreach my $service (@UPnPServices){(my $iPort=getServiceUPnPPort (
$service));if (((($iPort ne (""))and ($iPort!=(0x00b9+ 2726-0x0b5f)))and 
isServiceActive ($service))){if (isTCPService ($service)){(
$internalTCPPortsToDelete.=($iPort."\x3a"));($externalTCPPortsToDelete.=(
$serviceUPnPExternalPort{$service}."\x3a"));}else{($internalUDPPortsToDelete.=(
$iPort."\x3a"));($externalUDPPortsToDelete.=($serviceUPnPExternalPort{$service}.
"\x3a"));}($serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=
(0x0df0+ 3282-0x1ac2));}}($internalTCPPortsToDelete=~ s/:$// );(
$externalTCPPortsToDelete=~ s/:$// );($internalUDPPortsToDelete=~ s/:$// );(
$externalUDPPortsToDelete=~ s/:$// );(my $upnpFD=(0x091f+ 1520-0x0f0f));if (((
$internalTCPPortsToDelete ne (""))and ($externalTCPPortsToDelete ne ("")))){if (
($mode==$NORMAL_MODE)){deleteTCPRule ($internalTCPPortsToDelete,
$externalTCPPortsToDelete,$skipWaiting);}else{($upnpFD=
deletePortMappingBackground ($internalTCPPortsToDelete,$externalTCPPortsToDelete
,"\x54\x43\x50"));}}if ((($internalUDPPortsToDelete ne (""))and (
$externalUDPPortsToDelete ne ("")))){if (($mode==$NORMAL_MODE)){deleteTCPRule (
$internalUDPPortsToDelete,$externalUDPPortsToDelete,$skipWaiting);}else{($upnpFD
=deletePortMappingBackground ($internalUDPPortsToDelete,
$externalUDPPortsToDelete,"\x55\x44\x50"));}}return ($upnpFD);}sub deleteTCPRule
{(my $internalPorts=shift (@_));(my $externalPorts=shift (@_));(my $skipWaiting=
(shift (@_)||(0x0a80+ 3137-0x16c1)));(my $protocol="\x54\x43\x50");Logger::debug
 (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x52\x65\x6d\x6f\x76\x65\x50\x6f\x72\x74\x73\x28"
.$internalPorts)."\x2c\x20").$externalPorts)."\x2c\x20").$protocol)."\x2c\x20").
$skipWaiting)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=
libnxhs::NXUpnpRemovePorts ($internalPorts,$externalPorts,$protocol,$skipWaiting
));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x52\x65\x6d\x6f\x76\x65\x50\x6f\x72\x74\x73\x28\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x3a\x20"
.$exit_value)."\x2e"));($UPnPStartTime=(0x0f7f+ 2608-0x19af));return (
(0x0543+ 2683-0x0fbd));}sub deleteRule{(my $protocol=shift (@_));(my $port=shift
 (@_));if ((((((not (defined ($protocol)))or (not (defined ($port))))or (
$protocol eq ("")))or ($port eq ("")))or ($port==(0x1479+ 3113-0x20a2)))){
Logger::debug2 (((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x3a\x64\x65\x6c\x65\x74\x65\x52\x75\x6c\x65\x3a\x20\x77\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3a\x20"
.$protocol)."\x2c\x20\x70\x6f\x72\x74\x3a\x20").$port)."\x2e"));return (
(0x15d7+ 4340-0x26cb));}Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x52\x65\x6d\x6f\x76\x65\x50\x6f\x72\x74\x73\x28"
.$port)."\x2c\x20").$port)."\x2c\x20").$protocol).
"\x2c\x20\x30\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exit_value=
libnxhs::NXUpnpRemovePorts ($port,$port,$protocol,(0x065c+ 7604-0x2410)));
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x52\x65\x6d\x6f\x76\x65\x50\x6f\x72\x74\x73\x28\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x3a\x20"
.$exit_value)."\x2e"));return ((0x10cc+ 5565-0x2689));}sub 
deletePortMappingBackground{(my $internalPorts=shift (@_));(my $externalPorts=
shift (@_));(my $protocol=shift (@_));(my $type=shift (@_));if (((($protocol eq 
(""))or ($internalPorts eq ("")))or ($externalPorts eq ("")))){Logger::warning (
((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x64\x65\x6c\x65\x74\x65\x50\x6f\x72\x74\x4d\x61\x70\x70\x69\x6e\x67\x42\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x3a\x20\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27"
.$protocol)."\x27\x20\x70\x6f\x72\x74\x73\x20\x27").$internalPorts)."\x3a").
$externalPorts)."\x27\x2e"));return ((0x06f7+ 3352-0x140f));}(my ($read),$write)
;if (main::nxPipeCreateBi ((\$read),(\$write))){Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x46\x44\x23"
.$read)."\x20\x46\x44\x23").$write)."\x2e"));}else{Logger::error (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x70\x61\x69\x72\x2e"
);return ((0x093f+ 5020-0x1cdb));}Logger::debug (((((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x52\x65\x6d\x6f\x76\x65\x28\x46\x44\x23"
.$write)."\x2c\x20").$internalPorts)."\x2c\x20").$externalPorts)."\x2c\x20").
$protocol)."\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $exitValue=
libnxhs::NXCreatePortsRemove ($write,$internalPorts,$externalPorts,$protocol));
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x50\x6f\x72\x74\x73\x52\x65\x6d\x6f\x76\x65\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$exitValue)."\x27\x2e"));if (($exitValue<(0x16db+ 1494-0x1cb1))){
Logger::warning (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x64\x65\x6c\x65\x74\x65\x20\x4e\x58\x55\x50\x6e\x50\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20"
.$internalPorts)."\x2e"));main::nxclose ($read);main::nxclose ($write);return (
(0x1376+ 4301-0x2443));}setNetworkThreadFlag ((0x0c87+ 317-0x0dc3));
NXSystemDaemons::addUPnPFD ("\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73",$read
,$write,$internalPorts);if (($type eq "\x73\x65\x73\x73\x69\x6f\x6e")){
main::addFhToMonitor ($read,
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x72\x44\x65\x6c\x65\x74\x65\x55\x44\x50\x43\x61\x6c\x6c\x62\x61\x63\x6b"
);return ((0x0254+ 750-0x0541));}return ($read);}sub setExternalTCPPortFile{(my $service
=shift (@_));(my $localIP=(shift (@_)||("")));if ((((not (defined ($service)))or
 ($service eq ("")))or ($localIP eq "\x2d\x31"))){return ((0x0542+ 5039-0x18f1))
;}(my $port=generateExternalPort ($service,$localIP));if ((((not (defined ($port
)))or ($port eq ("")))or ($port==(0x02e8+ 8805-0x254d)))){__setExternalUPnPPort 
($service,(0x1ae5+ 2674-0x2557));return ((0x042f+ 436-0x05e3));}
__setExternalUPnPPort ($service,$port);(my $portFile=
getServiceUPnPExternalPortFile ($service));if (((not (defined ($portFile)))or (
$portFile eq ("")))){return ((0x1b44+ 1318-0x206a));}(my $TCP_PORT_FD=
main::nxopen ($portFile,($NXBits::O_WRONLY+$NXBits::O_CREAT),
$NXBits::UserReadWrite));if ((not (defined ($TCP_PORT_FD)))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::debug (((((((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x3a\x73\x65\x74\x45\x78\x74\x65\x72\x6e\x61\x6c\x54\x43\x50\x50\x6f\x72\x74\x46\x69\x6c\x65\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x27"
.$portFile)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error).
"\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return (
(0x1380+ 1011-0x1773));}main::nxwrite ($TCP_PORT_FD,$serviceUPnPExternalPort{
$service});main::nxclose ($TCP_PORT_FD);if (main::effectiveUserIsAdministrator 
()){Common::NXFile::setOwnershipForUserNX ($portFile);}return (
(0x0aa9+ 2340-0x13cc));}sub getExternalUPnPPortFromMemory{(my $service=shift (@_
));if (((not (defined ($service)))or ($service eq ("")))){return (
(0x1f9a+ 738-0x227c));}if (($serviceUPnPExternalPort{$service}!=
(0x043f+  38-0x0465))){return ($serviceUPnPExternalPort{$service});}(my $portFromCfg
=(0x12a6+ 1827-0x19c9));if (($service eq $__serviceUpnpnxTcp)){($portFromCfg=
$GLOBAL::NXTCPUPnPPort);}elsif (($service eq $__serviceUpnpnxUdp)){($portFromCfg
=$GLOBAL::NXUDPUPnPPort);}elsif (($service eq $__serviceUpnpssh)){($portFromCfg=
$GLOBAL::SSHUPnPPort);}elsif (($service eq $__serviceUpnphttps)){($portFromCfg=
$GLOBAL::HTTPUPnPPort);}main::nxrequire ("\x4e\x58\x54\x6f\x6f\x6c\x73");if ((
NXTools::isCorrectPort ($portFromCfg)and ($portFromCfg>=(0x25e9+   9-0x25f1)))){
__setExternalUPnPPort ($service,$portFromCfg);return ($serviceUPnPExternalPort{
$service});}return ((0x1517+ 952-0x18cf));}sub getExternalUPnPPort{(my $service=
shift (@_));if ((getExternalUPnPPortFromMemory ($service)==(0x200d+ 1017-0x2406)
)){return (getExternalUPnPPortFromFile ($service));}return (
$serviceUPnPExternalPort{$service});}sub __setExternalUPnPPort{(my $service=
shift (@_));(my $port=shift (@_));main::nxrequire (
"\x4e\x58\x54\x6f\x6f\x6c\x73");if ((($service ne (""))and 
NXTools::isCorrectPort ($port))){($serviceUPnPExternalPort{$service}=$port);
Logger::debug ((((("\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27".
$service).
"\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x70\x6f\x72\x74\x20\x27"
).$port)."\x27\x2e"));updateGlobalUPnPPortKey ($service,$port);}return;}sub 
getExternalUPnPPortFromMemoryORFile{(my $service=shift (@_));(my $port=
(0x105d+ 3786-0x1f27));($port=getExternalUPnPPortFromMemory ($service));if (((
$port ne (""))and ($port>(0x16e5+ 1417-0x1c6e)))){return ($port);}return (
getExternalUPnPPortFromFile ($service));}sub getExternalUPnPPortFromFile{(my $service
=shift (@_));(my $portFile=getServiceUPnPExternalPortFile ($service));if ((not (
Common::NXFile::isExists ($portFile)))){return ((0x0a03+ 3881-0x192c));}(my $TCP_PORT_FD
=main::nxopen ($portFile,$NXBits::O_RDONLY,(0x01c1+ 4249-0x125a)));if (defined (
$TCP_PORT_FD)){my ($line);main::nxrequire ("\x4e\x58\x54\x6f\x6f\x6c\x73");while
 (main::nxread ($TCP_PORT_FD,(\$line))){chomp ($line);if ((
NXTools::isCorrectPort ($line)and ($line>=(0x129c+ 1819-0x19b6)))){
__setExternalUPnPPort ($service,$line);Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x47\x65\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x70\x6f\x72\x74\x20\x27").$line).
"\x27\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x2e"));main::nxclose ($TCP_PORT_FD
);return ($serviceUPnPExternalPort{$service});}}main::nxclose ($TCP_PORT_FD);}
return ((0x0351+ 5445-0x1896));}sub isNotAllUpnpGetNetworkInfoInMemory{return ((
!isAllUpnpGetNetworkInfoInMemory ()));}sub isAllUpnpGetNetworkInfoInMemory{if ((
(($LocalIP eq (""))or ($GatewayIP eq ("")))or ($ExternalIP eq ("")))){return (
(0x0e91+ 1530-0x148b));}return ((0x08ed+ 5406-0x1e0a));}sub 
checkAllNetworkInformationsFromMemory{if ((((($LocalIP ne (""))and ($GatewayIP 
ne ("")))and ($ExternalIP ne ("")))and ($ExternalIP ne 
"\x30\x2e\x30\x2e\x30\x2e\x30"))){return ((0x196c+ 1021-0x1d68));}return (
(0x0354+ 4032-0x1314));}sub checkNetworkInformationsFromMemory{if (((($LocalIP 
ne (""))or ($GatewayIP ne ("")))or ($ExternalIP ne ("")))){return (
(0x01f1+ 4537-0x13a9));}return ((0x1913+ 2117-0x2158));}sub getNetworkInfo{(my $gatewayIP
=("\x20" x (0x04c5+ 4170-0x1127)));(my $localIP=("\x20" x (0x0904+ 246-0x0612)))
;(my $externalIP=("\x20" x (0x11cb+ 2460-0x177f)));Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28\x29\x20\x73\x74\x61\x72\x74\x2e"
);(my $return_code=libnxhs::NXUpnpGetNetworkInfo ($gatewayIP,$localIP,
$externalIP));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x55\x70\x6e\x70\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20\x27"
.$return_code)."\x27\x2e"));($gatewayIP=~ s/\0// );($localIP=~ s/\0// );(
$externalIP=~ s/\0// );($GatewayIP=main::trimLine ($gatewayIP));($LocalIP=
main::trimLine ($localIP));if (($externalIP ne "\x30\x2e\x30\x2e\x30\x2e\x30")){
($ExternalIP=main::trimLine ($externalIP));}}sub getNetworkInfoBackground{(my $returnFD
=(shift (@_)||(0x1401+ 2145-0x1c62)));(my $exit_value=(0x15d8+ 4138-0x2602));if 
(($networkInfostarted==(0x0a76+ 5905-0x2186))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x61\x72\x74\x65\x64\x2c\x20\x73\x6b\x69\x70\x70\x69\x6e\x67\x2e"
);return ((0x0776+ 3841-0x1676));}(my ($NXUPnP_ReadPipe,$NXUPnP_WritePipe)=(""))
;Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x47\x65\x74\x20\x4e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x20\x6d\x6f\x64\x65\x2e"
);if (main::nxPipeCreateBi ((\$NXUPnP_ReadPipe),(\$NXUPnP_WritePipe))){
Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x46\x44\x23"
.$NXUPnP_ReadPipe)."\x20\x46\x44\x23").$NXUPnP_WritePipe)."\x2e"));}else{(my $error
=libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));return (
(0x1db9+ 162-0x1e5b));}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28"
.$NXUPnP_WritePipe)."\x29\x20\x73\x74\x61\x72\x74\x2e"));($exit_value=
libnxhs::NXCreateNetworkInfo ($NXUPnP_WritePipe));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x43\x72\x65\x61\x74\x65\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x28\x29\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x27"
.$exit_value)."\x27\x2e"));if (($exit_value<(0x0d3f+ 2894-0x188d))){(my $error=
libnxh::NXGetError ());(my $errorname=libnxh::NXGetErrorName ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6e\x78\x75\x70\x6e\x70\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$error)."\x2c\x20").$errorname)."\x2c\x20").$errorstring)."\x2e"));
main::nxclose ($NXUPnP_ReadPipe);main::nxclose ($NXUPnP_WritePipe);return (
(0x24fa+ 234-0x25e4));}NXSystemDaemons::addUPnPFD (
"\x6e\x65\x74\x69\x6e\x66\x6f",$NXUPnP_ReadPipe,$NXUPnP_WritePipe,
(0x04e6+ 3273-0x11af));setNetworkInfoFlag ((0x0c89+ 2946-0x180a));
setNetworkThreadFlag ((0x0868+ 5519-0x1df6));if (($returnFD==
(0x1ec4+ 1668-0x2547))){return ($NXUPnP_ReadPipe);}return ((0x0877+ 5489-0x1de7)
);}sub getLocalIPFromMemory{if ((defined ($LocalIP)and ($LocalIP ne ("")))){
return ($LocalIP);}return ((""));}sub getLocalIP{if ((getLocalIPFromMemory ()ne 
(""))){return ($LocalIP);}getNetworkInfo ();if ((defined ($LocalIP)and ($LocalIP
 ne ("")))){return ($LocalIP);}return ((""));}sub generateExternalPort{(my $service
=shift (@_));(my $localIP=(shift (@_)||("")));(my $externalPort=
(0x1eef+ 1899-0x265a));if (((not (defined ($service)))or ($service eq ("")))){
return ((0x0907+ 2127-0x1156));}if (((not (defined ($localIP)))or ($localIP eq 
("")))){($localIP=getLocalIP ());}if (($localIP=~ /(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/ )
){(my $ip_3=$3);(my $ip_4=$4);(my $base=($ip_3 %(0x1be5+ 2458-0x2575)));($base=(
20000+((($ip_4-(0x2308+ 830-0x2645))*(0x19a4+ 529-0x1b8d))+($base *
(0x044b+ 6511-0x1db6)))));if (($service eq $__serviceUpnpnxTcp)){($externalPort=
$base);}elsif (($service eq $__serviceUpnpssh)){($externalPort=($base+
(0x093b+ 7377-0x260b)));}elsif (($service eq $__serviceUpnphttps)){(
$externalPort=($base+(0x0094+ 193-0x0153)));}elsif (($service eq 
$__serviceUpnpnxUdp)){($externalPort=($base+(0x0581+ 2718-0x101c)));}
Logger::debug (((((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x45\x78\x74\x65\x72\x6e\x61\x6c\x50\x6f\x72\x74\x3a\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x64\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x70\x6f\x72\x74\x3a\x20"
.$externalPort)."\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20").
$service)."\x2e"));return ($externalPort);}Logger::debug (((
"\x4e\x58\x55\x50\x6e\x50\x3a\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x45\x78\x74\x65\x72\x6e\x61\x6c\x50\x6f\x72\x74\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x70\x6f\x72\x74\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20"
.$service)."\x2e"));return ((0x1a3b+ 1572-0x205f));}sub 
isNotSetServiceUPnPExternalPort{(my $service=shift (@_));if (($service eq ("")))
{return ((0x16f9+ 3976-0x2680));}if ((((not (defined ($serviceUPnPExternalPort{
$service})))or ($serviceUPnPExternalPort{$service}eq ("")))or (
$serviceUPnPExternalPort{$service}==(0x1d49+ 2133-0x259e)))){return (
(0x0829+ 2068-0x103c));}return ((0x08c2+ 7661-0x26af));}sub 
isSetServiceUPnPExternalPort{(my $service=shift (@_));if ((defined (
$serviceUPnPExternalPort{$service})and ($serviceUPnPExternalPort{$service}>
(0x1a87+ 401-0x1c18)))){return ((0x0cc4+ 4260-0x1d67));}return (
(0x08d9+ 2602-0x1303));}sub isServiceActive{(my $service=shift (@_));
Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x27".
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}).
"\x27\x20\x70\x6f\x72\x74\x20\x27").$serviceUPnPExternalPort{$service}).
"\x27\x2e"));if ((($serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}==
(0x1952+ 911-0x1ce0))and ($serviceUPnPExternalPort{$service}>
(0x0f3c+ 176-0x0fec)))){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4d\x61\x70\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x69\x73\x20\x61\x63\x74\x69\x76\x65\x2e"));return (
(0x1cfd+ 2033-0x24ed));}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4d\x61\x70\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27"
.$service)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x63\x74\x69\x76\x65\x2e"));
return ((0x08bf+ 814-0x0bed));}sub isUDPPortAdded{return ($UDPPortAdded);}sub 
setFlagUDPPortAdded{($UDPPortAdded=(0x02dc+ 3103-0x0efa));Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x55\x44\x50\x50\x6f\x72\x74\x41\x64\x64\x65\x64\x27\x20\x66\x6c\x61\x67\x2e"
);return;}sub unSetFlagUDPPortAdded{($UDPPortAdded=(0x0464+ 6321-0x1d15));
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x73\x65\x74\x20\x27\x55\x44\x50\x50\x6f\x72\x74\x41\x64\x64\x65\x64\x27\x20\x66\x6c\x61\x67\x2e"
);return;}sub setFlagForceStartUPnPMap{(my $value=(shift (@_)||
(0x0d03+ 5614-0x22f1)));($forceStartUPnPMap=$value);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x66\x6f\x72\x63\x65\x53\x74\x61\x72\x74\x55\x50\x6e\x50\x4d\x61\x70\x27\x20\x66\x6c\x61\x67\x20\x27"
.$forceStartUPnPMap)."\x27\x2e"));return;}sub setNetworkInfoFlag{(my $value=(
shift (@_)||(0x1007+ 3978-0x1f91)));($networkInfostarted=$value);Logger::debug (
((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x6e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x66\x6f\x73\x74\x61\x72\x74\x65\x64\x27\x20\x66\x6c\x61\x67\x20\x27"
.$networkInfostarted)."\x27\x2e"));return;}sub setNetworkThreadFlag{(my $value=(
shift (@_)||(0x0ae8+ 2052-0x12ec)));($networkThreadStarted=$value);Logger::debug
 (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x6e\x65\x74\x77\x6f\x72\x6b\x54\x68\x72\x65\x61\x64\x53\x74\x61\x72\x74\x65\x64\x27\x20\x66\x6c\x61\x67\x20\x27"
.$networkThreadStarted)."\x27\x2e"));return;}sub clearNetworkInfoData{
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x65\x61\x72\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x73\x20\x64\x61\x74\x61\x2e"
);($GatewayIP=(""));($LocalIP=(""));($ExternalIP=(""));return;}sub 
unsetUPnPServices{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6c\x65\x61\x72\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x64\x61\x74\x61\x2e"
);foreach my $service (@UPnPServices){($serviceUPnPStartTime{$service}=
(0x0996+ 3727-0x1825));($serviceUPnPExternalPort{$service}=(0x1bad+ 1424-0x213d)
);($serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x0450+ 5779-0x1ae3))
;setServiceUPnPTimeout ($service);}return;}sub handleNetworkChange{
clearNetworkInfoData ();if (((isUPnPMapEnabled ()==(0x0f17+ 2598-0x193d))or (
isUPnPEnabled ()==(0x0a91+ 7204-0x26b5)))){Logger::debug2 (
"\x53\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x20\x55\x50\x6e\x50\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x69\x67\x6e\x6f\x72\x65\x20\x64\x65\x74\x65\x63\x74\x65\x64\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x63\x68\x61\x6e\x67\x65\x2e"
);return;}destroyNetworkThread ();unsetUPnPServices ();getNetworkInfoBackground 
((0x1cfd+ 663-0x1f94));($handleNetworkChange=(0x1f83+ 135-0x2009));return;}sub 
handleNetworkChangePortsAdd{Logger::debug2 (
"\x4e\x58\x55\x50\x6e\x50\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"
);if (((isUPnPMapEnabled ()==(0x1063+ 959-0x1422))or (isUPnPEnabled ()==
(0x089c+ 1332-0x0dd0)))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x75\x70\x70\x6f\x72\x74\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x69\x67\x6e\x6f\x72\x65\x20\x64\x65\x74\x65\x63\x74\x65\x64\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x63\x68\x61\x6e\x67\x65\x2e"
);return;}if ((__setExternalUPnPPortsForAllServicesOnNetworkChange ()==
(0x0843+ 1126-0x0ca9))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65\x50\x6f\x72\x74\x73\x41\x64\x64\x20\x4d\x69\x73\x73\x69\x6e\x67\x20\x65\x78\x74\x65\x72\x6e\x61\x6c\x20\x70\x6f\x72\x74\x65\x73\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x70\x6f\x72\x74\x73\x20\x61\x66\x74\x65\x72\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x63\x68\x61\x6e\x67\x65\x2e"
);informAllNodesAboutUPnPChanges ();return;}deleteServiceRules (
(0x00d1+ 3394-0x0e13),$BACKGROUND_MODE);if ((forceAddPortMapping ()==
(0x1858+  25-0x1871))){informAllNodesAboutUPnPChanges ();}return;}sub 
readOnCallbackFD{(my $f=shift (@_));(my $read_buf=(""));(my $bytes_read=
main::nxread ($f,(\$read_buf),(0x1afd+ 1895-0x1264)));if ((not (defined (
$bytes_read)))){(my $error=libnxh::NXGetError ());(my $errorname=
libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());if (((
$errorname eq "\x45\x41\x47\x41\x49\x4e")or ($errorname eq 
"\x45\x49\x4e\x54\x52"))){Logger::debug (((((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x64\x20\x6f\x6e\x20\x46\x44\x23".
$f)."\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20").$errorname).
"\x2c\x20").$errorstring)."\x2e"));}}elsif (($bytes_read==(0x0297+ 296-0x03bf)))
{Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x46\x44\x23"
.$f)."\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"));}else{Logger::debug ((
((("\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x64\x20\x27".$read_buf).
"\x27\x20\x6f\x6e\x20\x46\x44\x23").$f)."\x2e"));}return ($bytes_read,$read_buf)
;}sub checkIfInformNodeAboutUPnPChanges{(my $sessionID=shift (@_));(my $upnpStatusMessage
=buildStatusMessageForClient ());(my $message=((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPNP_STATUS_TO_NXCLIENT)."\x20").$upnpStatusMessage));
NXLocalSession::informNodeAboutUPnPChanges ($sessionID,$message);return;}sub 
delSessionUdpPort{(my $udpPort=__getSessionPort ());if ((((not (defined (
$udpPort)))or ($udpPort eq ("")))or ($udpPort<(0x11d8+ 1451-0x1783)))){
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x55\x44\x50\x20\x70\x6f\x72\x74\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"
);return;}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x27\x73\x20\x55\x44\x50\x20\x70\x6f\x72\x74\x20\x27"
.$udpPort)."\x27\x20\x74\x6f\x20\x63\x6c\x6f\x73\x65\x2e"));if (isUDPPortAdded 
()){if ((not (NXClientSystemDaemons::openConnection ()))){deleteRule (
"\x55\x44\x50",$udpPort);main::nxrequire (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");NXUdpControl::freePort (
$udpPort);}else{NXClientSystemDaemons::sendMessage ((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_UPNP_DELETE)."\x20\x70\x6f\x72\x74\x3d").$udpPort)."\x0a"));
NXClientSystemDaemons::closeConnection ();}unSetFlagUDPPortAdded ();}return;}sub
 informAllNodesAboutUPnPChanges{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x6e\x66\x6f\x72\x6d\x20\x6e\x6f\x64\x65\x73\x20\x61\x62\x6f\x75\x74\x20\x63\x68\x61\x6e\x67\x65\x73\x2e"
);main::nxrequire ("\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x32");(my (@sessions)=
NXSession2::getListOfSessionsForServerStatusNotify ());Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x46\x6f\x75\x6e\x64\x20\x27".scalar (@sessions
)).(("\x27\x20\x73\x65\x73\x73\x69\x6f\x6e\x5b\x73\x5d\x3a\x20".join ($",
@sessions))."\x2e")));if ((scalar (@sessions)!=(0x0687+ 7887-0x2556))){(my $upnpStatusMessage
=buildStatusMessageForClient ());(my $message=((
$GLOBAL::MSG_UPNP_STATUS_TO_NXCLIENT."\x20").$upnpStatusMessage));while (scalar 
(@sessions)){(my $sessionId=shift (@sessions));Logger::debug (((
"\x53\x65\x6e\x64\x69\x6e\x67\x20\x74\x68\x65\x20\x75\x70\x6e\x70\x20\x73\x74\x61\x74\x75\x73\x20\x74\x6f\x20\x74\x68\x65\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x20\x69\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x3a\x20"
.$sessionId)."\x2e"));main::send_command_to_server ($sessionId,$message);}}}sub 
handleUPnPSingleServiceMessage{(my $clientSocket=shift (@_));(my $message=shift 
(@_));(my $service=(""));(my $port=(""));if (($message=~ /service=(.*) port=(\d+)$/ )
){($service=$1);($port=$2);}else{Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x3a\x20\x49\x67\x6e\x6f\x72\x65\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message)."\x27\x2e"));return ((0x1760+ 1765-0x1e45));}Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x69\x6e\x67\x6c\x65\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e"
);if ((not (isServiceEnabled ($service)))){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x20\x53\x65\x72\x76\x69\x63\x65\x20\x27"
.$service).
"\x27\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x2c\x20\x66\x69\x6e\x69\x73\x68\x69\x6e\x67\x2e"
));(my $msg=buildMessageUPnPStatus ());__sendMsgOnSocket ($clientSocket,$msg);
return ((0x0689+ 7599-0x2438));}updateCFGKeys ($service,$port);if ((
checkAllNetworkInformationsFromMemory ()==(0x1a63+ 2307-0x2366))){
getNetworkInfoBackground ((0x00e9+ 6042-0x1883));}getExternalUPnPPort ($service)
;if (isNotSetServiceUPnPExternalPort ($service)){setExternalTCPPortFile (
$service);if (isNotSetServiceUPnPExternalPort ($service)){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x20\x69\x73\x4e\x6f\x74\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x55\x50\x6e\x50\x45\x78\x74\x65\x72\x6e\x61\x6c\x50\x6f\x72\x74\x20\x66\x6f\x72\x20\x27"
.$service)."\x27\x2c\x20\x66\x69\x6e\x69\x73\x68\x69\x6e\x67\x2e"));(my $msg=
buildMessageUPnPStatus ());__sendMsgOnSocket ($clientSocket,$msg);return (
(0x1767+ 2589-0x2184));}}(my $iPort=getServiceUPnPPort ($service));(my $ePort=
$serviceUPnPExternalPort{$service});Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x20\x47\x6f\x74\x20\x69\x50\x6f\x72\x74\x3a\x20\x27"
.$iPort)."\x27\x2c\x20\x65\x50\x6f\x72\x74\x3a\x20\x27").$ePort)."\x27\x2e"));(my $upnpFD
=(0x0b70+ 4390-0x1c96));(my $type=(""));if ((($ePort ne (""))and ($ePort ne ("")
))){if (isTCPService ($service)){($upnpFD=deletePortMappingBackground ($iPort,
$ePort,"\x54\x43\x50"));}else{($upnpFD=deletePortMappingBackground ($iPort,
$ePort,"\x55\x44\x50"));}($type="\x64\x65\x6c\x65\x74\x65\x70\x6f\x72\x74\x73");
}if (($port>(0x1b8c+ 1206-0x2042))){if ((defined ($iPort)and ($iPort ne ("")))){
if (isTCPService ($service)){($upnpFD=__addTCPRule ($iPort,$port,
$BACKGROUND_MODE));}else{($upnpFD=__addUDPRule ($iPort,$port,$BACKGROUND_MODE));
}($type="\x61\x64\x64\x70\x6f\x72\x74\x73");__setExternalUPnPPort ($service,
$port);}}else{($flagInformAllNodesAboutUPnPChanges=(0x09cd+ 3386-0x1706));(
$serviceUPnP{$service}{"\x72\x75\x6e\x6e\x69\x6e\x67"}=(0x0710+ 1803-0x0e1b));}
if (($upnpFD>(0x171a+ 1359-0x1c69))){addSocketToClientList ($clientSocket,
$upnpFD,$type);return ((0x1026+ 4111-0x2034));}else{Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x55\x50\x6e\x50\x53\x69\x6e\x67\x6c\x65\x53\x65\x72\x76\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x28\x29\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x6f\x6e\x6c\x79\x20\x6e\x65\x74\x77\x6f\x72\x6b\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x73\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x2e"
);(my $msg=buildMessageUPnPStatus ());__sendMsgOnSocket ($clientSocket,$msg);
return ((0x1009+ 718-0x12d7));}}sub updateCFGKeys{(my $service=shift (@_));(my $port
=shift (@_));(my $cfgKeyName=getCFGKeyGatewayPortBasedOnService ($service));(my $cfgEnableUPnPKeyValue
=getEnableUPnPKeyValueBasedOnService ($service));updateGlobalUPnPPortKey (
$service,$port);if (($port>(0x03ec+ 6421-0x1d01))){(my $error=(""));if (((
$cfgKeyName ne (""))and main::changeServerCfgKeySetError ($cfgKeyName,$port,(
\$error)))){Logger::debug2 (
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x75\x70\x64\x61\x74\x65\x43\x46\x47\x4b\x65\x79\x73\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x63\x66\x67\x2e"
);}else{Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x75\x70\x64\x61\x74\x65\x43\x46\x47\x4b\x65\x79\x73\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x75\x70\x64\x61\x74\x65\x20\x27"
.$cfgKeyName).
"\x27\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x6b\x65\x79\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x3a\x20"
).$error)."\x2e"));}addServiceToKeyEnableUPnP ($cfgEnableUPnPKeyValue);}else{
removeServiceFromKeyEnableUPnP ($cfgEnableUPnPKeyValue);}if ((not (
main::changeServerCfgKeySetError ($__cfgEnableUPnPKeyName,$GLOBAL::EnableUPnP,(
\$error))))){Logger::debug (((((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x75\x70\x64\x61\x74\x65\x43\x46\x47\x4b\x65\x79\x73\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x75\x70\x64\x61\x74\x65\x20\x27"
.$__cfgEnableUPnPKeyName).
"\x27\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x6b\x65\x79\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x3a\x20"
).$error)."\x2e"));}return ((0x07e6+ 1379-0x0d48));}sub 
addServiceToKeyEnableUPnP{(my $service=shift (@_));Logger::debug (((((
"\x41\x64\x64\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27".$service).
"\x27\x20\x74\x6f\x20\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x20\x6b\x65\x79\x3a\x20\x27"
).$GLOBAL::EnableUPnP)."\x27\x2e"));if (isUPnPEnabled ()){if ((not ((
$GLOBAL::EnableUPnP=~ /$service/ )))){($GLOBAL::EnableUPnP.=("\x2c".$service));}
}else{($GLOBAL::EnableUPnP=$service);}Logger::debug (((
"\x55\x70\x64\x61\x74\x65\x64\x20\x27\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x27\x20\x6b\x65\x79\x20\x74\x6f\x3a\x20\x27"
.$GLOBAL::EnableUPnP)."\x27\x2e"));return;}sub removeServiceFromKeyEnableUPnP{(my $service
=shift (@_));Logger::debug ((((("\x52\x65\x6d\x6f\x76\x65\x20\x27".$service).
"\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x66\x72\x6f\x6d\x20\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x20\x6b\x65\x79\x3a\x20\x27"
).$GLOBAL::EnableUPnP)."\x27\x2e"));if (isUPnPEnabled ()){if ((
$GLOBAL::EnableUPnP=~ /,$service/ )){($GLOBAL::EnableUPnP=~ s/,$service// );}
elsif (($GLOBAL::EnableUPnP=~ /$service,/ )){($GLOBAL::EnableUPnP=~ s/$service,// )
;}elsif (($GLOBAL::EnableUPnP=~ /$service/ )){($GLOBAL::EnableUPnP=~ s/$service// )
;}if (($GLOBAL::EnableUPnP eq (""))){($GLOBAL::EnableUPnP="\x6e\x6f\x6e\x65");}}
else{($GLOBAL::EnableUPnP="\x6e\x6f\x6e\x65");}Logger::debug (((
"\x55\x70\x64\x61\x74\x65\x64\x20\x27\x45\x6e\x61\x62\x6c\x65\x55\x50\x6e\x50\x27\x20\x6b\x65\x79\x20\x74\x6f\x3a\x20\x27"
.$GLOBAL::EnableUPnP)."\x27\x2e"));return;}sub isServiceEnabled{(my $service=
shift (@_));if (((not (defined ($service)))or ($service eq ("")))){return (
(0x11e7+ 3105-0x1e08));}if ((($service eq $__serviceUpnpnxTcp)and 
NXSystemDaemons::isNxdEnabled ())){return ((0x04a0+ 629-0x0714));}elsif (((
$service eq $__serviceUpnpnxUdp)and NXSystemDaemons::isNxdEnabled ())){return (
(0x0652+ 8241-0x2682));}elsif ((($service eq $__serviceUpnphttps)and 
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ())){return (
(0x0e05+ 2836-0x1918));}elsif ((($service eq $__serviceUpnpssh)and 
NXSystemDaemons::isSSHEnabled ())){return ((0x07cc+ 761-0x0ac4));}return (
(0x10c6+ 1566-0x16e4));}sub getCFGKeyGatewayPortBasedOnService{(my $service=
shift (@_));if (($service eq $__serviceUpnpnxTcp)){return ($__cfgNXTCPKeyValue);
}elsif (($service eq $__serviceUpnpnxUdp)){return ($__cfgNXUDPKeyValue);}elsif (
($service eq $__serviceUpnphttps)){return ($__cfgHTTPKeyName);}elsif (($service 
eq $__serviceUpnpssh)){return ($__cfgSSHDKeyName);}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x27".$service)
."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e"));return ((""));
}sub getEnableUPnPKeyValueBasedOnService{(my $service=shift (@_));if (($service 
eq $__serviceUpnpnxTcp)){return ($__cfgNXTCPKeyValue);}elsif (($service eq 
$__serviceUpnpnxUdp)){return ($__cfgNXUDPKeyValue);}elsif (($service eq 
$__serviceUpnphttps)){return ($__cfgHTTPKeyValue);}elsif (($service eq 
$__serviceUpnpssh)){return ($__cfgSSHDKeyValue);}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x3a\x20\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x27".
$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e"));
return ((""));}sub updateGlobalUPnPPortKey{(my $service=shift (@_));(my $port=
shift (@_));if (($service eq $__serviceUpnpnxTcp)){($GLOBAL::NXTCPUPnPPort=$port
);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x27\x4e\x58\x54\x43\x50\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x20\x74\x6f\x20\x27"
.$GLOBAL::NXTCPUPnPPort)."\x27\x2e"));}elsif (($service eq $__serviceUpnpnxUdp))
{($GLOBAL::NXUDPUPnPPort=$port);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x27\x4e\x58\x55\x44\x50\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x20\x74\x6f\x20\x27"
.$GLOBAL::NXUDPUPnPPort)."\x27\x2e"));}elsif (($service eq $__serviceUpnphttps))
{($GLOBAL::HTTPUPnPPort=$port);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x27\x48\x54\x54\x50\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x20\x74\x6f\x20\x27"
.$GLOBAL::HTTPUPnPPort)."\x27\x2e"));}elsif (($service eq $__serviceUpnpssh)){(
$GLOBAL::SSHUPnPPort=$port);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x64\x20\x27\x53\x53\x48\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x20\x74\x6f\x20\x27"
.$GLOBAL::SSHUPnPPort)."\x27\x2e"));}else{Logger::warning (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6b\x69\x70\x20\x75\x70\x64\x61\x74\x65\x20\x55\x50\x6e\x50\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x6d\x65\x6d\x6f\x72\x79\x2e\x20\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x27"
.$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e"));
return ((0x0275+ 7852-0x2121));}}sub updateCFGandPortMapping{(my $service=shift 
(@_));(my $port=shift (@_));if ((not (NXClientSystemDaemons::openConnection ()))
){updateCFGKeys ($service,$port);__sendMsgOnSocket (main::nxgetSTDOUT (),
getStatusMessage ());return ((0x1774+ 432-0x1924));}
NXClientSystemDaemons::cleanDaemonBuffer ();(my $message=((((((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_UPNP_MAPPING_SERVICE).
"\x20\x73\x65\x72\x76\x69\x63\x65\x3d").$service)."\x20\x70\x6f\x72\x74\x3d").
$port)."\x0a"));if ((NXClientSystemDaemons::sendMessage ($message)!=
(0x0d47+ 1528-0x133e))){Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x27"
.$message).
"\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
));__sendMsgOnSocket (main::nxgetSTDOUT (),getStatusMessage ());}(my $reply=
NXClientSystemDaemons::parseMessageFromServer ($Handlerstimeout));
NXClientSystemDaemons::closeConnection ();if ((defined ($reply)and ($reply ne 
("")))){main::nxwrite (main::nxgetSTDOUT (),$reply);}else{__sendMsgOnSocket (
main::nxgetSTDOUT (),getStatusMessage ());}return ((0x0544+ 3861-0x1458));}sub 
convertNXplayerServiceNameIntoUPnPServiceName{(my $service=shift (@_));if ((
$service=~ /^$__nxTcpName$/ )){return ($__serviceUpnpnxTcp);}elsif (($service=~ /^$__nxUdpName$/ )
){return ($__serviceUpnpnxUdp);}elsif (($service=~ /^$__nxhtdName$/ )){return (
$__serviceUpnphttps);}elsif (($service=~ /^$__nxsshdName$/ )){return (
$__serviceUpnpssh);}Logger::debug2 (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x63\x6f\x6e\x76\x65\x72\x74\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e\x20\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x27"
.$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x20\x6e\x61\x6d\x65\x2e"));
return ((""));}sub __setSessionPort{($sessionPort=shift (@_));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x55\x50\x6e\x50\x20\x70\x6f\x72\x74\x20\x27"
.$sessionPort)."\x27\x2e"));}sub __getSessionPort{return ($sessionPort);}sub 
__checkInitializeStatusAndAdjustTimeout{(my $portMappingAdded=(shift (@_)||
(0x0631+ 1071-0x0a60)));(my $protocol=shift (@_));if ((__isRepeatMappingStarted 
()==(0x18d7+ 2289-0x21c7))){if (($portMappingAdded==(0x01e9+ 7171-0x1dec))){
__setTimeoutForRepeatMapping ();}else{__disableRepeatMapping (
(0x14c6+ 3314-0x21b8));}}}sub __setTimeoutForRepeatMapping{if ((
$protocolsCountForRepeatMapping>=(0x1d50+ 816-0x207e))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x6b\x69\x70\x20\x72\x65\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
);($protocolsCountForRepeatMapping=(0x0988+ 3521-0x1748));return;}(my $timeout=
shift (@timeoutForRepeatMapping));if (((not (defined ($timeout)))or ($timeout eq
 ("")))){Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x61\x63\x68\x65\x64\x20\x72\x65\x70\x65\x61\x74\x20\x6c\x69\x6d\x69\x74\x2e"
);__disableRepeatMapping ((0x0628+ 2536-0x100f));return;}foreach my $lookup_value
 (@allPossibleTimeoutForRepeat){if (($timeout==$lookup_value)){($NXUpnp::timeout
=$timeout);__calculateCountForRepeatMapping ();Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x55\x70\x64\x61\x74\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x72\x65\x70\x65\x61\x74\x20\x70\x6f\x72\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x3a\x20\x27"
.$NXUpnp::timeout)."\x27\x2e"));return;}}Logger::warning (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x49\x6e\x63\x6f\x72\x65\x63\x74\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x76\x61\x6c\x75\x65\x2e"
);__disableRepeatMapping ((0x14b4+ 3057-0x20a4));return;}sub 
__disableRepeatMapping{(my $force=(shift (@_)||(0x0ac1+ 7153-0x26b2)));
Logger::debug (
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x20\x72\x65\x70\x65\x61\x74\x20\x6d\x61\x70\x70\x69\x6e\x67\x20\x6f\x6e\x20\x73\x74\x61\x72\x74\x75\x70\x2e"
);if (((__isRepeatMappingStarted ()==(0x02f8+ 2149-0x0b5c))or ($force==
(0x038a+ 1886-0x0ae7)))){__setRepeatMapping ($repeatMappingDisabled);}if (((
$timeout!=$defaultTimeout)or ($force==(0x1416+ 728-0x16ed)))){
__setDefaultTimeout ();}($protocolsCountForRepeatMapping=(0x0bf3+ 1314-0x1115));
return;}sub __setDefaultTimeout{($timeout=$defaultTimeout);Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x52\x65\x73\x74\x6f\x72\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x74\x6f\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x76\x61\x6c\x75\x65\x3a\x20\x27"
.$timeout)."\x27\x2e"));return;}sub __setRepeatMapping{($repeatMapping=shift (@_
));Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x72\x65\x70\x65\x61\x74\x4d\x61\x70\x70\x69\x6e\x67\x27\x20\x66\x6c\x61\x67\x20\x27"
.$repeatMapping)."\x27\x2e"));return;}sub __isRepeatMappingStarted{if ((
$repeatMapping==$repeatMappingStarted)){return ((0x1a0a+ 1329-0x1f3a));}return (
(0x078b+ 5499-0x1d06));}sub __calculateCountForRepeatMapping{(my $oldValue=
$protocolsCountForRepeatMapping);($protocolsCountForRepeatMapping=
(0x0b43+ 2512-0x1513));if (($GLOBAL::EnableUPnP=~ /(NXTCP|SSH|HTTP)/i )){(++
$protocolsCountForRepeatMapping);}if (($GLOBAL::EnableUPnP=~ /(NXUDP)/i )){(++
$protocolsCountForRepeatMapping);}Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x53\x65\x74\x20\x27\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x73\x43\x6f\x75\x6e\x74\x46\x6f\x72\x52\x65\x70\x65\x61\x74\x4d\x61\x70\x70\x69\x6e\x67\x27\x20\x66\x6c\x61\x67\x20\x27"
.$protocolsCountForRepeatMapping)."\x27\x2e"));return;}sub 
isRepeatMappingInProgress{if ((isUPnPMapEnabled ()and isUPnPEnabled ())){if ((
__isRepeatMappingStarted ()==(0x192b+  11-0x1935))){foreach my $lookup_value (
@allPossibleTimeoutForRepeat){if (($timeout==$lookup_value)){return (
(0x1366+ 3903-0x22a4));}}}}return ((0x01c0+ 8944-0x24b0));}sub 
getTimeoutForRepeatMapping{(my $newTime=($timeout *(0x168d+ 1113-0x16fe)));
Logger::debug (((
"\x4e\x58\x55\x70\x6e\x70\x3a\x20\x4e\x65\x77\x20\x74\x69\x6d\x65\x6f\x75\x74\x3a\x20\x27"
.$newTime)."\x27\x2e"));return ($newTime);}"\x3f\x3f\x3f";
