############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXProcess;no warnings;($NXProcess::children={});(
$NXProcess::childrenData={});($NXProcess::finishedChildren={});(
$NXProcess::childFinishedWithSignal={});($NXProcess::childrenExitCallback={});(
$NXProcess::childrenErrorCallback={});($NXProcess::childrenToLeave={});(
$NXProcess::watchDogList={});($NXProcess::finishedWatchDogList={});(
$NXProcess::watchDogToLeaveList={});($NXProcess::watchDogAsSuperuser={});(
$NXProcess::errorNoProcessToWait=(-(0x13fb+ 3171-0x205d)));(
$NXProcess::statusRunning=(0x0d57+ 340-0x0eab));($NXProcess::statusExited=
(0x1100+ 1529-0x16f8));($NXProcess::signalKill=(0x0981+ 4727-0x1bef));(
$NXProcess::signalTerm=(0x12ed+ 4452-0x2442));($NXProcess::signalSegv=
(0x1e56+ 805-0x2170));($NXProcess::processTree=(0x0bd2+ 6372-0x24b5));(
$NXProcess::noProcessTree=(0x026d+ 1579-0x0898));sub nxProcessCreate{(my $filename
=shift (@_));(my $command=shift (@_));(my $environment=shift (@_));(my $stdin=
shift (@_));(my $stdout=shift (@_));(my $stderr=shift (@_));(my $priority=shift 
(@_));my ($pid);my ($pidOrHandle);Logger::debug (((((((((((((((
"\x6e\x78\x50\x72\x6f\x63\x65\x73\x73\x43\x72\x65\x61\x74\x65\x3a\x20\x27".
$filename)."\x27\x20\x27").join ($",@$command))."\x27\x20\x27").join ($",
@$environment))."\x27\x20\x27\x46\x44\x23").$stdin)."\x27\x20\x27\x46\x44\x23").
$stdout)."\x27\x20\x27\x46\x44\x23").$stderr)."\x27\x20\x27").$priority)."\x27")
);($pidOrHandle=libnxh::NXProcessCreate ($filename,$command,$environment,$stdin,
$stdout,$stderr,$priority));if (($pidOrHandle==(-(0x1f34+ 1192-0x23db)))){
Common::NXCore::reportErrorFromNXPL (((((((((((((((((
"\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x43\x72\x65\x61\x74\x65\x28".$filename).
"\x2c\x20").$command)."\x2c\x20").$environment)."\x2c\x20").$stdin)."\x2c\x20").
$stdout)."\x2c\x20").$stderr)."\x2c\x20").$priority).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$pidOrHandle)."\x2e"));return ((-(0x1500+ 1515-0x1aea)));}($pid=
handleProcessHandle ($pidOrHandle));addChild ($pid);(my $commandLine=$filename);
foreach my $parameter (@$command){if (($parameter eq $filename)){next;}else{(
$commandLine.=("\x20".$parameter));}}registerChildName ($commandLine,$pid);
return ($pid);}sub nxProcessExec{(my $filename=shift (@_));(my $command=shift (
@_));(my $environment=shift (@_));(my $ref_error=shift (@_));Logger::debug (((((
(("\x6e\x78\x50\x72\x6f\x63\x65\x73\x73\x45\x78\x65\x63\x3a\x20\x27".$filename).
"\x27\x20\x27").join ($",@$command))."\x27\x20\x27").join ($",@$environment)).
"\x27"));(my $result=libnxh::NXProcessExec ($filename,$command,$environment));if
 (($result==(-(0x1561+ 413-0x16fd)))){Common::NXCore::reportErrorFromNXPL ((((((
((("\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x45\x78\x65\x63\x28".$filename).
"\x2c\x20").$command)."\x2c\x20").$environment).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$result)."\x2e"));($$ref_error=libnxh::NXGetErrorString ());return (
(0x0602+ 4190-0x1660));}return ((0x00f8+ 7844-0x1f9b));}sub handleProcessHandle{
(my $pidOrHandle=shift (@_));return ($pidOrHandle);(my $pid=getPidFromHandle (
$pidOrHandle));($NXProcess::processPidsArrayByHandle{$pidOrHandle}=$pid);(
$NXProcess::processHandlesArrayByPid{$pid}=$pidOrHandle);return ($pid);}sub 
getPidFromHandle{(my $handle=shift (@_));(my $pid=libnxh::NXConvertHandlerToPid 
($handle));Logger::debug (((((
"\x67\x65\x74\x50\x69\x64\x46\x72\x6f\x6d\x48\x61\x6e\x64\x6c\x65\x3a\x20\x68\x61\x6e\x64\x6c\x65\x20\x5b"
.$handle).
"\x5d\x20\x63\x6f\x6e\x76\x65\x72\x74\x65\x64\x20\x74\x6f\x20\x70\x69\x64\x20\x5b"
).$pid)."\x5d\x2e"));return ($pid);}sub convertToHandleIfNeeded{(my $pid=shift (
@_));return ($pid);if (defined ($NXProcess::processHandlesArrayByPid{$pid})){(my $handle
=$NXProcess::processHandlesArrayByPid{$pid});if (($pid==
$NXProcess::processPidsArrayByHandle{$handle})){return ($handle);}}return ($pid)
;}sub checkIsProcessFinished{(my $pid=shift (@_));if (($pid>
(0x0215+ 6648-0x1c0d))){if ((not (isChildProcess ($pid)))){if (isChildFinished (
$pid)){return ((0x0898+ 5652-0x1eab));}if ((not (isOnWatchdogProcess ($pid)))){
if (isFinishedWatchDog ($pid)){return ((0x16eb+ 2301-0x1fe7));}return ((-
(0x0ebc+ 4731-0x2136)));}}}if (($pid==(0x196c+ 772-0x1c70))){return ((-
(0x087c+ 1206-0x0d31)));}return ((0x095c+ 3757-0x1809));}sub 
checkForWaitingEventForPid{(my $pid=shift (@_));(my $childrenList=
$NXProcess::children);if (($pid==(-(0x1704+ 1632-0x1d63)))){foreach my $listpid 
(keys (%$childrenList)){if (isChildFinished ($listpid)){return ($listpid);}else{
next;}}return ((0x031c+ 5754-0x1996));}elsif (($pid>(0x1432+ 4587-0x261d))){if (
isChildProcess ($pid)){if (isChildFinished ($pid)){return ($pid);}else{return (
(0x1c31+ 2745-0x26ea));}}else{if (isChildFinished ($pid)){return ($pid);}if (
isFinishedWatchDog ($pid)){return ($pid);}if (isOnWatchdogProcess ($pid)){return
 ((0x0f07+ 2122-0x1751));}return ((-(0x15a5+ 3624-0x23cc)));}}return ((-
(0x066a+ 7157-0x225e)));}sub nxwaitpid{(my $pid=shift (@_));(my $options=(shift 
(@_)||$NXBits::WAIT_NOHANG));(my $timeout=(shift (@_)||"\x69\x6e\x66"));(my $startwaitpid
=Common::NXTime::getSecondsSinceEpoch ());(my $sigpid=(-(0x10c9+ 3357-0x1de5)));my (
$status);my ($nxplreturn);(my $finished=checkIsProcessFinished ($pid));if ((
$finished!=(0x0799+ 7782-0x25ff))){if (($finished==(-(0x1bd8+ 309-0x1d0c)))){
return ((-(0x0c21+ 1950-0x13be)));}return ($pid);}(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);if (($options==$NXBits::WAIT_UNTRACED)){while ((0x0b22+ 242-0x0c13)){
if (($timeout eq "\x69\x6e\x66")){Common::NXCore::exitFromSelectOnFirstSignal ()
;(my (@ready)=$selector->can_read);
Common::NXCore::disableExitFromSelectOnFirstSignal ();}else{if (($timeout<=
(0x1e1f+ 1311-0x233e))){return ((0x15ab+ 2208-0x1e4b));}
Common::NXCore::exitFromSelectOnFirstSignal ();(my (@ready)=$selector->can_read 
(($timeout *(0x168c+ 2825-0x1dad))));
Common::NXCore::disableExitFromSelectOnFirstSignal ();($timeout=($timeout-(
Common::NXTime::getSecondsSinceEpoch ()-$startwaitpid)));}(my $check=
checkForWaitingEventForPid ($pid));if (((!$check)==(0x12e2+ 2255-0x1bb1))){
return ($check);}}}else{(my (@ready)=$selector->can_read ((0x03a5+ 7177-0x1fae),
"\x73\x69\x6c\x65\x6e\x74"));(my $waitingEvent=checkForWaitingEventForPid ($pid)
);return ($waitingEvent);}}sub nxChildProcessCheck{(my $pid=shift (@_));(my $status
=(0x0a85+ 819-0x0db8));(my $exit=(0x0c41+ 504-0x0e39));my ($nxplreturn);(my $pidToNxpl
=convertToHandleIfNeeded ($pid));($nxplreturn=libnxh::NXProcessCheck ($pidToNxpl
,$status));if (($nxplreturn==(-(0x0053+ 4652-0x127e)))){(my $errname=
libnxh::NXGetErrorName ());Logger::warning (((((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x28".$pid)
."\x2f").$pidToNxpl).
"\x29\x20\x77\x69\x74\x68\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x43\x68\x65\x63\x6b\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x27"
).$errname)."\x27\x2e"));}sub BEGIN{require POSIX;do{"\x50\x4f\x53\x49\x58"->
import ("\x3a\x73\x79\x73\x5f\x77\x61\x69\x74\x5f\x68")};}if (($nxplreturn==
(0x01d4+ 3611-0x0fef))){if (WIFEXITED ($status)){($exit=WEXITSTATUS ($status));
setChildExitCode ($pid,$exit);}if (WIFSIGNALED ($status)){($exit=WTERMSIG (
$status));setChildExitSignal ($pid,$exit);}}return ($nxplreturn);}sub sigterm{(my $process_pid
=shift (@_));if (libnxh::NXProcessRunning ($process_pid)){my ($result);if (
isChildProcess ($process_pid)){Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x54\x45\x52\x4d\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($result=libnxh::NXProcessKill ($process_pid,$NXBITS::SIGTERM));}else{
Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x54\x45\x52\x4d\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x6f\x74\x20\x61\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($result=libnxh::NXKillProcess ($process_pid,$NXBITS::SIGTERM));}if (($result
==(-(0x0354+ 678-0x05f9)))){Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid)."\x2e"));return ((0x2401+ 127-0x2480));}else{Logger::debug (((((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
).$result)."\x2e"));return ((0x0b6f+ 3913-0x1ab7));}}Logger::debug (((
"\x54\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x54\x45\x52\x4d\x2c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));return ((0x1720+   2-0x1721));}sub winKillTreeProcess{return (
(0x01dc+ 3109-0x0e00));}sub sigkill{(my $process_pid=shift (@_));(my $process_tree
=(shift (@_)||(0x179b+ 1590-0x1dd1)));if ((not (defined ($process_pid)))){
Logger::warning (
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x62\x75\x74\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x70\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"
);return ((0x09b7+ 6702-0x23e5));}if ((($process_pid==(0x12db+ 4496-0x246b))or (
$process_pid==$ $))) {
 main::nxexit (getSignalKill ());}(my $pidToNxpl=
convertToHandleIfNeeded ($process_pid));(my $status=isProcessRunning (
$process_pid));if ($status){my ($return);if (isChildProcess ($process_pid)){
Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($return=libnxh::NXProcessKill ($pidToNxpl,getSignalKill ()));}else{if ((
$process_tree==(0x054f+ 2101-0x0d84))){Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x6f\x74\x20\x61\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($return=libnxh::NXKillProcess ($process_pid,getSignalKill ()));}else{
Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x74\x72\x65\x65\x2e"
));($return=libnxh::NXKillTree ($process_pid,getSignalKill ()));}}if (($return==
(-(0x1df7+ 823-0x212d)))){Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid)."\x2e"));return ((0x05ad+ 8247-0x25e4));}else{Logger::debug (((((
(("\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".
$process_pid)."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
).$return)."\x2e"));return ((0x0ab8+ 2949-0x163c));}}else{Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x4b\x49\x4c\x4c\x2c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));}return ((0x0179+ 3461-0x0efd));}sub sigSegv{(my $process_pid=shift (@_));if 
((not (defined ($process_pid)))){Logger::warning (
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x53\x45\x47\x56\x20\x62\x75\x74\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x70\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"
);return ((0x0e56+ 1912-0x15ce));}(my $pidToNxpl=convertToHandleIfNeeded (
$process_pid));(my $status=isProcessRunning ($process_pid));if ($status){my (
$return);if (isChildProcess ($process_pid)){Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x53\x45\x47\x56\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($return=libnxh::NXProcessKill ($pidToNxpl,getSignalSegv ()));}else{
Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x53\x45\x47\x56\x2c\x20\x73\x69\x67\x6e\x61\x6c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x6e\x6f\x74\x20\x61\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));($return=libnxh::NXKillProcess ($process_pid,getSignalSegv ()));}if (($return
==(-(0x142b+ 3864-0x2342)))){Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x53\x45\x47\x56\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$process_pid)."\x2e"));return ((0x0468+ 2874-0x0fa2));}else{Logger::debug (((((
(("\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".
$process_pid)."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x53\x45\x47\x56\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
).$return)."\x2e"));return ((0x1229+ 1571-0x184b));}}else{Logger::debug (((((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$process_pid)
."\x2f").$pidToNxpl).
"\x20\x75\x73\x69\x6e\x67\x20\x53\x49\x47\x53\x45\x47\x56\x2c\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));}return ((0x07ca+ 2703-0x1258));}sub signalProcessByRestrictedScript{(my $pid
=shift (@_));(my $signal=shift (@_));(my $tree=shift (@_));(my $nxkillScript=
"\x6e\x78\x6b\x69\x6c\x6c\x2e\x73\x68");(my (@command)=(
Common::NXCore::getNXExecCommand (),$nxkillScript,$pid,$signal,$tree));(my (
@parameters)=());main::run_command ((\@command),(\@parameters));}sub 
sendTerminateWaitAndKill{(my $processPid=shift (@_));(my $sleepTime=(shift (@_)
||(0x0cf3+ 4006-0x1c98)));if ((($processPid==(0x0974+ 5314-0x1e36))or (not (
defined ($processPid))))){Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x70\x69\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x27"
.$processPid)."\x27\x2e"));return ((0x013c+ 769-0x043d));}if (isProcessRunning (
$processPid)){Logger::debug (((
"\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x63\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$processPid).
"\x27\x20\x77\x69\x74\x68\x20\x73\x69\x67\x6e\x61\x6c\x20\x27\x31\x35\x27"));if 
(sigterm ($processPid)){Logger::debug (((
"\x53\x49\x47\x54\x45\x52\x4d\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x63\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid)."\x2e"));nxwaitpid ($processPid,$NXBits::WAIT_UNTRACED,$sleepTime)
;if (isProcessRunning ($processPid)){if (sigkill ($processPid)){Logger::debug ((
(
"\x53\x49\x47\x4b\x49\x4c\x4c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid)."\x2e"));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid)."\x2e"));}}else{Logger::debug (((
"\x43\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$processPid).
"\x27\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
));}}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x54\x45\x52\x4d\x20\x74\x6f\x20\x63\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid)."\x2e"));}}else{Logger::debug (((
"\x43\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$processPid).
"\x27\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
));}}sub leaveOrphans{foreach my $pid (keys (%$NXProcess::childrenToLeave)){(my $pidToNxpl
=convertToHandleIfNeeded ($pid));(my $result=libnxh::NXForceRemove ($pidToNxpl))
;if (($result==(-(0x0d6c+ 2214-0x1611)))){Common::NXCore::reportErrorFromNXPL ((
(((
"\x43\x61\x6e\x6e\x6f\x74\x20\x66\x6f\x72\x63\x65\x20\x72\x65\x6d\x6f\x76\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid)."\x2f").$pidToNxpl)."\x2e"));}else{Logger::debug (((((
"\x4c\x65\x66\x74\x20\x70\x72\x6f\x63\x65\x73\x73\x20".$pid)."\x2f").$pidToNxpl)
."\x20\x61\x73\x20\x6f\x72\x70\x68\x61\x6e\x2e"));}}foreach my $pid (keys (
%$NXProcess::watchDogList)){(my $result=libnxh::NXRemoveWatchdog ($pid));if ((
$result==(-(0x0e22+ 5616-0x2411)))){Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x20\x6f\x6e\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid)."\x2e"));}else{Logger::debug (((((
"\x52\x65\x6d\x6f\x76\x65\x64\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x20\x6f\x6e\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid)."\x20\x77\x69\x74\x68\x20\x72\x65\x73\x75\x6c\x74\x20\x27").$result).
"\x27\x2e"));}}}sub leaveChildAtFinish{(my $pid=shift (@_));if (isChildProcess (
$pid)){Logger::debug (((
"\x53\x65\x74\x74\x69\x6e\x67\x20\x63\x68\x69\x6c\x64\x20".$pid).
"\x20\x74\x6f\x20\x62\x65\x20\x6c\x65\x66\x74\x20\x61\x66\x74\x65\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x65\x6e\x64\x73\x2e"
));($$NXProcess::childrenToLeave{$pid}=(0x16d5+ 2035-0x1ec7));}}sub 
leaveWatchdogAtFinish{(my $pid=shift (@_));($$NXProcess::watchDogToLeaveList{
$pid}=(0x198b+ 202-0x1a54));}sub removeFromLeaveWatchdogAtFinishList{(my $pid=
shift (@_));delete ($$NXProcess::watchDogToLeaveList{$pid});}sub 
addToWatchDogList{(my $pid=shift (@_));($$NXProcess::watchDogList{$pid}=
(0x0c6c+ 984-0x1043));delete ($$NXProcess::finishedWatchDogList{$pid});}sub 
handleWatchDogSIG{foreach my $pid (keys (%$NXProcess::watchDogList)){
Logger::debug3 (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27\x2e"));if ((not (libnxh::NXProcessRunning ($pid)))){Logger::debug (
(("\x4e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));
(my $callback=$$NXProcess::childrenExitCallback{$pid});Logger::debug (((((
"\x45\x78\x65\x63\x75\x74\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27").$pid
)."\x2e\x27"));delete ($$NXProcess::watchDogList{$pid});libnxh::NXRemoveWatchdog
 ($pid);($$NXProcess::finishedWatchDogList{$pid}=(0x0fb0+ 3322-0x1ca9));if ((
$callback ne (""))){&{$callback;}($pid,(0x0411+ 8627-0x25c4));}}}}sub 
setCallbackSIGCHLD{(my $pid=shift (@_));(my $callback=shift (@_));(
$$NXProcess::childrenExitCallback{$pid}=$callback);(
$$NXProcess::childrenErrorCallback{$pid}=$callback);if (((not (isChildProcess (
$pid)))and (not (isOnWatchdogProcess ($pid))))){addToWatchDogList ($pid);}
Logger::debug2 ((((("\x4e\x65\x77\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x5b".
$$NXProcess::childrenExitCallback{$pid}).
"\x5d\x20\x66\x6f\x72\x20\x53\x49\x47\x43\x48\x49\x4c\x44\x20\x66\x6f\x72\x20\x70\x69\x64\x20\x5b"
).$pid)."\x5d"));}sub setExitCallback{(my $pid=shift (@_));(my $callback=shift (
@_));($$NXProcess::childrenExitCallback{$pid}=$callback);}sub setErrorCallback{(my $pid
=shift (@_));(my $callback=shift (@_));($$NXProcess::childrenErrorCallback{$pid}
=$callback);}sub addWatchdog{(my $pid=shift (@_));if (((not (defined ($pid)))or 
($pid==(0x0c95+ 1661-0x1312)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x50\x49\x44\x20\x27"
.$pid)."\x27\x2e"));return ((-(0x11c3+ 1287-0x16c9)));}if (isOnWatchdogProcess (
$pid)){Logger::warning ((("\x50\x72\x6f\x63\x65\x73\x73\x20\x50\x49\x44\x20\x27"
.$pid).
"\x27\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x6f\x6e\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x20\x6c\x69\x73\x74\x2e"
));return ((0x0b72+ 6706-0x25a4));}Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x64\x64\x57\x61\x74\x63\x68\x64\x6f\x67\x28"
.$pid)."\x2c\x20").$NXBITS::SIGCHLD)."\x29\x2e"));(my $result=
libnxh::NXAddWatchdog ($pid,$NXBITS::SIGCHLD));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x64\x64\x57\x61\x74\x63\x68\x64\x6f\x67\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$result)."\x27\x2e"));addToWatchDogList ($pid);setCallbackSIGCHLD ($pid,(
\&nxDefaultWatchdogExitHandler));return ((0x0a91+ 4480-0x1c11));}sub addChild{(my $pid
=(shift (@_)||(0x0d01+ 3070-0x18ff)));if (($pid<=(0x0252+ 2427-0x0bcd))){
Logger::warning (((
"\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x77\x72\x6f\x6e\x67\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x2e"));return;}if ((not (isChildProcess ($pid)))){(my $pidToNxpl=
convertToHandleIfNeeded ($pid));(my $nxplreturn=libnxh::NXProcessAdd ($pidToNxpl
));($$NXProcess::children{$pid}=(0x02b6+ 2378-0x0bff));Logger::debug (((((
"\x41\x64\x64\x65\x64\x20\x27".$pid)."\x2f").$pidToNxpl).
"\x27\x20\x74\x6f\x20\x63\x68\x69\x6c\x64\x72\x65\x6e\x20\x6c\x69\x73\x74\x2e"))
;($$NXProcess::childrenExitCallback{$pid}=(\&nxDefaultExitCodeHandler));(
$$NXProcess::childrenErrorCallback{$pid}=(\&nxDefaultExitCodeHandler));(
$$NXProcess::childFinishedWithSignal{$pid}=(0x04cf+ 6432-0x1def));if (
isChildFinished ($pid)){delete ($$NXProcess::finishedChildren{$pid});}if (
isFinishedWatchDog ($pid)){delete ($$NXProcess::finishedWatchDogList{$pid});}}
else{Logger::debug (((
"\x54\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x61\x64\x64\x20\x73\x61\x6d\x65\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x20\x61\x73\x20\x63\x68\x69\x6c\x64\x2e"));}}sub 
nxDefaultExitCodeHandler{(my $pid=shift (@_));(my $code=shift (@_));
Logger::debug (((
"\x6e\x78\x44\x65\x66\x61\x75\x6c\x74\x45\x78\x69\x74\x43\x6f\x64\x65\x48\x61\x6e\x64\x6c\x65\x72\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x2e"));}sub 
nxDefaultWatchdogExitHandler{(my $pid=shift (@_));Logger::debug (((
"\x6e\x78\x44\x65\x66\x61\x75\x6c\x74\x57\x61\x74\x63\x68\x64\x6f\x67\x45\x78\x69\x74\x48\x61\x6e\x64\x6c\x65\x72\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x5b"
.$pid)."\x5d\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x2e"));}sub removechild{(my $pid
=shift (@_));if (isChildProcess ($pid)){Logger::debug (((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x52\x65\x6d\x6f\x76\x65\x28"
.$pid)."\x29"));(my $pidToNxpl=convertToHandleIfNeeded ($pid));(my $nxplreturn=
libnxh::NXProcessRemove ($pidToNxpl));if (($nxplreturn==(-(0x1c31+ 775-0x1f37)))
){Common::NXCore::reportErrorFromNXPL (((
"\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x52\x65\x6d\x6f\x76\x65\x28".$pidToNxpl).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));}(my ($name,$lifetime)=
getChildNameAndLifetime ($pid));if (processTerminatedBySignal ($pid)){(my $exitSignal
=getChildExitSignal ($pid));if (($exitSignal!=$NXBITS::SIGTERM)){Logger::warning
 ((((((((((("\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$name).
"\x27\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27").$pid)."\x2f").$pidToNxpl).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x73\x69\x67\x6e\x61\x6c\x20"
).$exitSignal)."\x20\x61\x66\x74\x65\x72\x20").$lifetime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));}else{Logger::debug (((((((((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$name).
"\x27\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27").$pid)."\x2f").$pidToNxpl).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x73\x69\x67\x6e\x61\x6c\x20"
).$exitSignal)."\x20\x61\x66\x74\x65\x72\x20").$lifetime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));}}else{(my $exitCode=getChildExitCode (
$pid));if (($exitCode==(0x15c4+ 2957-0x2151))){Logger::debug (((((((((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$name).
"\x27\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27").$pid)."\x2f").$pidToNxpl).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$exitCode)."\x20\x61\x66\x74\x65\x72\x20").$lifetime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));}else{Logger::warning (((((((((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$name).
"\x27\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27").$pid)."\x2f").$pidToNxpl).
"\x27\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$exitCode)."\x20\x61\x66\x74\x65\x72\x20").$lifetime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e"));}}delete ($$NXProcess::children{$pid});
}if (exists ($$NXProcess::childrenToLeave{$pid})){delete (
$$NXProcess::childrenToLeave{$pid});}}sub isProcessRunning{(my $pid=shift (@_));
if (((not (defined ($pid)))or ($pid<=(0x1935+ 302-0x1a63)))){return (
(0x0209+ 4155-0x1244));}if (($pid==$ $)) {
 return ((0x0e97+ 1949-0x1633));}if (
isChildProcess ($pid)){return ((0x03a4+ 7848-0x224b));}(my $pidToNxpl=
convertToHandleIfNeeded ($pid));(my $ret=libnxh::NXProcessRunning ($pidToNxpl));
if (($ret==(-(0x15ca+ 2357-0x1efe)))){(my $errname=libnxh::NXGetErrorName ());if
 ((($errname eq "\x45\x41\x43\x43\x45\x53")or ($errname eq 
"\x45\x50\x45\x52\x4d"))){return ((0x09b2+ 5024-0x1d51));}Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x52\x75\x6e\x6e\x69\x6e\x67\x28"
.$pid)."\x2f").$pidToNxpl)."\x29\x20\x3a\x20").$errname));return (
(0x0f8b+ 2029-0x1778));}return ($ret);}sub handleSIGUSR1{Logger::debug (
"\x68\x61\x6e\x64\x6c\x65\x53\x49\x47\x55\x53\x52\x31",(0x037f+ 482-0x0561));if 
(defined ($NXBegin::handlerSIGUSR1)){if (($NXBegin::handlerSIGUSR1 ne (""))){
Logger::debug (("\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x63\x61\x6c\x6c\x3a\x20".
$NXBegin::handlerSIGUSR1),(0x04b8+ 6112-0x1c98));&$NXBegin::handlerSIGUSR1 ();}}
else{Logger::debug ("\x49\x67\x6e\x6f\x72\x69\x6e\x67\x20\x55\x53\x52\x31",
(0x1b68+ 2774-0x263e));}}sub handleSIGCHLD{(my $children=$NXProcess::children);my (
$status);my ($nxplreturn);foreach my $listpid (keys (%$children)){Logger::debug3
 ((
"\x68\x61\x6e\x64\x6c\x65\x53\x49\x47\x43\x48\x4c\x44\x20\x63\x68\x65\x63\x6b\x69\x6e\x67\x20\x63\x68\x69\x6c\x64\x3a\x20"
.$listpid),(0x1f0a+ 384-0x208a));($nxplreturn=nxChildProcessCheck ($listpid));
unless ($nxplreturn){removechild ($listpid);my ($callback);if ((
$$NXProcess::finishedChildren{$listpid}==(0x0d17+ 2027-0x1502))){($callback=
$$NXProcess::childrenExitCallback{$listpid});}else{($callback=
$$NXProcess::childrenErrorCallback{$listpid});}&{$callback;}($listpid,
$$NXProcess::finishedChildren{$listpid});}}handleWatchDogSIG ();
handleWatchdogAsSuperuserSIGCHLD ();}sub getExitValue{(my $pid=shift (@_));(my $exitValue
=$$NXProcess::finishedChildren{$pid});if ((not (defined ($exitValue)))){if ((not
 (isChildProcess ($pid)))){Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20\x66\x72\x6f\x6d\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid).
"\x2e\x20\x54\x68\x69\x73\x20\x69\x73\x20\x6e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
));return ((0x02aa+ 6751-0x1d09));}else{Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20\x66\x72\x6f\x6d\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$pid).
"\x2e\x20\x50\x72\x6f\x63\x65\x73\x73\x20\x73\x74\x69\x6c\x6c\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));return ((0x2470+ 425-0x2619));}}return ($exitValue);}sub isChildProcess{(my $pid
=shift (@_));if (exists ($$NXProcess::children{$pid})){return (
(0x1150+ 4125-0x216c));}else{return ((0x0b83+ 2825-0x168c));}}sub 
isOnWatchdogProcess{(my $pid=shift (@_));if (exists ($$NXProcess::watchDogList{
$pid})){return ((0x11e5+ 1470-0x17a2));}else{return ((0x10c1+ 2460-0x1a5d));}}
sub isChildFinished{(my $pid=shift (@_));if (exists (
$$NXProcess::finishedChildren{$pid})){return ((0x2035+ 1508-0x2618));}else{
return ((0x22cc+ 548-0x24f0));}}sub isFinishedWatchDog{(my $pid=shift (@_));if (
exists ($$NXProcess::finishedWatchDogList{$pid})){return ((0x195c+ 769-0x1c5c));
}else{return ((0x133c+ 4971-0x26a7));}}sub processTerminatedBySignal{(my $pid=
shift (@_));if (($$NXProcess::childFinishedWithSignal{$pid}==
(0x0647+ 5027-0x19e9))){return ((0x1eb9+ 930-0x225a));}else{return (
(0x0fb8+ 4769-0x2259));}}sub waitProcess{(my $pid=shift (@_));(my $timeout=shift
 (@_));my ($exitValue);my ($waitpidOption);my ($waitpidResult);my ($return);if (
($timeout gt (0x0b80+ 2569-0x1589))){($waitpidOption=$NXBits::WAIT_UNTRACED);
Logger::debug (((((
"\x77\x61\x69\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x3a\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x20\x75\x73\x69\x6e\x67\x20").$timeout).
"\x73\x20\x61\x73\x20\x74\x69\x6d\x65\x6f\x75\x74"));}else{($waitpidOption=
$NXBits::WAIT_NOHANG);Logger::debug (((
"\x77\x61\x69\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x3a\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pid)."\x27"));}unless ((isChildProcess ($pid)or isOnWatchdogProcess ($pid))){
Logger::debug (((
"\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$pid).
"\x20\x6e\x6f\x74\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x65\x64\x2c\x20\x61\x64\x64\x69\x6e\x67\x20\x77\x61\x74\x63\x68\x64\x6f\x67\x2e"
));addWatchdog ($pid);}($waitpidResult=nxwaitpid ($pid,$waitpidOption,$timeout))
;if (($waitpidResult==$pid)){($exitValue=getStatusExited ());}elsif ((
$waitpidResult==(0x1138+ 3028-0x1d0c))){Logger::debug (((
"\x72\x65\x61\x63\x68\x65\x64\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x6f\x66\x20".
$timeout).((
"\x73\x20\x77\x68\x69\x6c\x65\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27")));($exitValue=getStatusRunning ());}elsif (($waitpidResult==(-
(0x074b+ 6475-0x2095)))){Logger::debug (((
"\x6e\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20\x27"
.$pid)."\x27\x20\x74\x6f\x20\x77\x61\x69\x74"));($exitValue=
getErrorNoProcessToWait ());}return ($exitValue);}sub getErrorNoProcessToWait{
return ($NXProcess::errorNoProcessToWait);}sub getStatusRunning{return (
$NXProcess::statusRunning);}sub getStatusExited{return ($NXProcess::statusExited
);}sub getSignalKill{return ($NXProcess::signalKill);}sub getSignalTerm{return (
$NXProcess::signalTerm);}sub getSignalSegv{return ($NXProcess::signalSegv);}sub 
getProcessTree{return ($NXProcess::processTree);}sub getNoProcessTree{return (
$NXProcess::noProcessTree);}sub registerChildName{(my $processName=shift (@_));(my $processPid
=shift (@_));(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));($milisec=substr ($milisec,(0x0e5c+ 5542-0x2402),
(0x0276+ 4643-0x1496)));Logger::debug2 (((((((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x27".$processName).
"\x27\x20\x73\x74\x61\x72\x74\x65\x64\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20\x27"
).$processPid).
"\x27\x20\x61\x74\x20\x74\x69\x6d\x65\x73\x74\x61\x6d\x70\x20\x27").$sec)."\x2c"
).$milisec)."\x27"));($$NXProcess::childrenData{$processPid}={});(
$$NXProcess::childrenData{$processPid}{"\x6e\x61\x6d\x65"}=$processName);(
$$NXProcess::childrenData{$processPid}{
"\x73\x74\x61\x72\x74\x53\x65\x63\x6f\x6e\x64\x73"}=$sec);(
$$NXProcess::childrenData{$processPid}{
"\x73\x74\x61\x72\x74\x4d\x69\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73"}=$milisec);}
sub getChildNameAndLifetime{(my $pid=shift (@_));(my $childData=
$$NXProcess::childrenData{$pid});if (defined ($childData)){(my $name=$$childData
{"\x6e\x61\x6d\x65"});(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));($milisec=substr ($milisec,(0x035f+ 6176-0x1b7f),
(0x0cbd+ 6314-0x2564)));(my $startSeconds=$$NXProcess::childrenData{$pid}{
"\x73\x74\x61\x72\x74\x53\x65\x63\x6f\x6e\x64\x73"});(my $startMiliseconds=
$$NXProcess::childrenData{$pid}{
"\x73\x74\x61\x72\x74\x4d\x69\x6c\x69\x73\x65\x63\x6f\x6e\x64\x73"});(my $liveTimeSeconds
=($sec-$startSeconds));(my $liveTimeMiliseconds=($milisec-$startMiliseconds));if
 (($liveTimeMiliseconds<(0x0cbb+ 4844-0x1fa7))){($liveTimeMiliseconds=(
$liveTimeMiliseconds+(0x0779+ 2976-0x0f31)));($liveTimeSeconds=($liveTimeSeconds
-(0x05e3+ 4310-0x16b8)));}(my $liveTime=(($liveTimeSeconds."\x2c").sprintf (
"\x25\x30\x33\x64",$liveTimeMiliseconds)));return ($name,$liveTime);}return (
(""),(0x00f6+ 2905-0x0c4f));}sub waitToTerminateOrKillIfStayAlive{(my $processPid
=shift (@_));(my $sleepTime=shift (@_));if (((not (defined ($processPid)))or (
$processPid<(0x0562+ 2597-0x0f87)))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x61\x69\x74\x20\x74\x6f\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x6f\x72\x20\x6b\x69\x6c\x6c\x20\x69\x66\x20\x73\x74\x61\x79\x20\x61\x6c\x69\x76\x65\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x50\x49\x44\x2e"
);return;}if (((not (defined ($sleepTime)))or ($sleepTime<(0x0547+ 5101-0x1933))
)){($sleepTime=(0x0705+ 1085-0x0b41));}if (isProcessRunning ($processPid)){
nxwaitpid ($processPid,$NXBits::WAIT_UNTRACED,$sleepTime);if (isProcessRunning (
$processPid)){if (sigkill ($processPid)){Logger::debug (((
"\x53\x49\x47\x4b\x49\x4c\x4c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid)."\x2e"));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid)."\x2e"));}}}else{Logger::debug (((
"\x43\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$processPid).
"\x27\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
));}}sub waitToTerminateOrKillByScriptIfStayAlive{(my $processPid=shift (@_));(my $sleepTime
=shift (@_));if (((not (defined ($processPid)))or ($processPid<
(0x0989+ 1575-0x0fb0)))){Logger::warning (
"\x77\x61\x69\x74\x54\x6f\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x4f\x72\x4b\x69\x6c\x6c\x42\x79\x53\x63\x72\x69\x70\x74\x49\x66\x53\x74\x61\x79\x41\x6c\x69\x76\x65\x3a\x20\x70\x69\x64\x20\x6e\x6f\x74\x20\x70\x72\x6f\x76\x69\x64\x65\x64\x2e"
);return;}if (((not (defined ($sleepTime)))or ($sleepTime<(0x00c7+ 8476-0x21e2))
)){($sleepTime=(0x050f+ 7213-0x213b));}if (isProcessRunning ($processPid)){(my $waitpid
=nxwaitpid ($processPid,$NXBits::WAIT_UNTRACED,$sleepTime));if (($waitpid!=
$processPid)){Logger::warning (((((
"\x77\x61\x69\x74\x54\x6f\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x4f\x72\x4b\x69\x6c\x6c\x42\x79\x53\x63\x72\x69\x70\x74\x49\x66\x53\x74\x61\x79\x41\x6c\x69\x76\x65\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid).
"\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x66\x69\x6e\x69\x73\x68\x20\x77\x69\x74\x68\x69\x6e\x20"
).$sleepTime).
"\x20\x73\x65\x63\x6f\x6e\x64\x73\x2e\x20\x4b\x69\x6c\x6c\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x62\x79\x20\x72\x65\x73\x74\x72\x69\x63\x74\x65\x64\x20\x73\x63\x72\x69\x70\x74\x2e"
));signalProcessByRestrictedScript ($processPid,getSignalKill ());}}else{
Logger::debug (((
"\x77\x61\x69\x74\x54\x6f\x54\x65\x72\x6d\x69\x6e\x61\x74\x65\x4f\x72\x4b\x69\x6c\x6c\x42\x79\x53\x63\x72\x69\x70\x74\x49\x66\x53\x74\x61\x79\x41\x6c\x69\x76\x65\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$processPid).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x6f\x70\x70\x65\x64\x2e"
));}}sub addWatchdogAsSuperuserOnWindows{Logger::warning (
"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x61\x64\x64\x57\x61\x74\x63\x68\x64\x6f\x67\x41\x73\x53\x75\x70\x65\x72\x75\x73\x65\x72\x4f\x6e\x57\x69\x6e\x64\x6f\x77\x73\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x72\x75\x6e\x20\x6f\x6e\x20\x57\x69\x6e\x64\x6f\x77\x73\x20\x73\x79\x73\x74\x65\x6d\x2e"
);return ((-(0x1849+ 3431-0x25af)));}sub addProcessToWatchdogAsSuperuserList{(my $pid
=shift (@_));(my $handle=shift (@_));($$NXProcess::watchDogAsSuperuser{$pid}=
$handle);delete ($$NXProcess::finishedWatchDogList{$pid});}sub 
handleWatchdogAsSuperuserSIGCHLD{foreach my $pid (keys (
%$NXProcess::watchDogAsSuperuser)){(my $handle=$$NXProcess::watchDogAsSuperuser{
$pid});Logger::debug3 (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$pid)."\x27\x20\x77\x69\x74\x68\x20\x68\x61\x6e\x64\x6c\x65\x20\x27").$handle).
"\x27\x2e"));if ((not (libnxh::NXProcessRunning ($pid)))){Logger::debug (((
"\x4e\x6f\x74\x20\x63\x68\x69\x6c\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27".
$pid)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));(my $callback
=$$NXProcess::childrenExitCallback{$pid});Logger::debug (((((
"\x45\x78\x65\x63\x75\x74\x69\x6e\x67\x20\x63\x61\x6c\x6c\x62\x61\x63\x6b\x20\x27"
.$callback)."\x27\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27").$pid
)."\x27\x2e"));delete ($$NXProcess::watchDogAsSuperuser{$pid});Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x68\x61\x6e\x64\x6c\x65\x20\x27".$handle).
"\x27\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6c\x69\x73\x74\x2e"));(my $return
=libnxh::NXRemoveProcess ($handle));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x52\x65\x6d\x6f\x76\x65\x50\x72\x6f\x63\x65\x73\x73\x28"
.$handle)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$return).
"\x27\x2e"));if (($return==(-(0x21bf+ 467-0x2391)))){
Common::NXCore::reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x68\x61\x6e\x64\x6c\x65\x20\x27"
.$handle).
"\x27\x20\x66\x72\x6f\x6d\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x6c\x69\x73\x74\x2e"
));}($$NXProcess::finishedWatchDogList{$pid}=(0x2211+ 986-0x25ea));if ((
$callback ne (""))){&{$callback;}($pid,(0x0887+ 4084-0x187b));}}}}sub 
setChildExitCode{(my $pid=shift (@_));(my $code=shift (@_));(
$$NXProcess::finishedChildren{$pid}=$code);}sub getChildExitCode{(my $pid=shift 
(@_));if ((not (processTerminatedBySignal ($pid)))){return (
$$NXProcess::finishedChildren{$pid});}return (undef);}sub setChildExitSignal{(my $pid
=shift (@_));(my $sig=shift (@_));($$NXProcess::finishedChildren{$pid}=$sig);(
$$NXProcess::childFinishedWithSignal{$pid}=(0x040f+ 4059-0x13e9));}sub 
getChildExitSignal{(my $pid=shift (@_));if (processTerminatedBySignal ($pid)){
return ($$NXProcess::finishedChildren{$pid});}return (undef);}sub 
getChildrenOfProcess{(my $pid=shift (@_));(my $commandPath=
Common::NXShellCommands::getPath ("\x70\x73"));if (($commandPath eq 
$Common::NXShellCommands::pathNotFound)){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x69\x73\x74\x20\x63\x68\x69\x6c\x64\x72\x65\x6e\x20\x6f\x66\x20\x27"
.$pid).
"\x27\x2e\x20\x50\x72\x6f\x67\x72\x61\x6d\x20\x27\x70\x73\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x70\x72\x65\x73\x65\x6e\x74\x20\x69\x6e\x20\x61\x20\x6b\x6e\x6f\x77\x6e\x20\x70\x61\x74\x68\x2e"
));return (());}(my (@command)=());(my (@options)=());push (@command,
$commandPath);push (@command,"\x2d\x2d\x70\x70\x69\x64",$pid);push (@command,
"\x2d\x6f");push (@command,"\x70\x69\x64\x3d");(my ($stderr,$stdout,$exitValue)=
main::nxRunCommand ((\@command),(\@options)));if (($exitValue!=
(0x150a+ 344-0x1662))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x69\x73\x74\x20\x63\x68\x69\x6c\x64\x72\x65\x6e\x20\x6f\x66\x20\x27"
.$pid)."\x27\x2e"));return (());}($stdout=~ s/^\s+|\s+$//g );(my (@pids)=split ( /\s+/ ,
$stdout,(0x1e2a+ 827-0x2165)));return (@pids);}"\x3f\x3f\x3f";
