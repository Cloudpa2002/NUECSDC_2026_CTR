############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXScripts::BEGIN{package NXScripts;no warnings;require NXSessionParameters;
do{
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"->
import};}package NXScripts;no warnings;($nxReportSysLoadScriptPid=(-
(0x04b2+ 309-0x05e6)));($nxReportSysLoadScriptMaxRerun=(0x075d+ 417-0x08f4));(
$nxReportSysLoadScriptRerunTries=(0x0591+ 1464-0x0b49));(
$nxReportSysLoadScriptRerunCheckDelay=(0x0956+ 6803-0x2065));(
$nxReportSysLoadScriptLastRun=(0x13b5+ 4032-0x2375));(
$nxReportSysLoadScriptFinishedAbnormally=(0x02d2+ 1700-0x0976));(
$nxReportSysLoadScriptProcessName=(""));sub runScript{(my $functionName=shift (
@_));(my (%functions)=(
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x6c\x6f\x67\x69\x6e",
$GLOBAL::UserScriptBeforeLogin,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x69\x6e",
$GLOBAL::UserScriptAfterLogin,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x6f\x75\x74",
$GLOBAL::UserScriptAfterLogout,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$GLOBAL::UserScriptBeforeSessionStart,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$GLOBAL::UserScriptAfterSessionStart,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x75\x73\x70\x65\x6e\x64"
,$GLOBAL::UserScriptBeforeSessionDisconnect,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x75\x73\x70\x65\x6e\x64"
,$GLOBAL::UserScriptAfterSessionDisconnect,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,$GLOBAL::UserScriptBeforeSessionReconnect,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,$GLOBAL::UserScriptAfterSessionReconnect,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$GLOBAL::UserScriptBeforeSessionClose,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,$GLOBAL::UserScriptAfterSessionClose,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,$GLOBAL::UserScriptBeforeSessionFailure,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,$GLOBAL::UserScriptAfterSessionFailure,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x72\x65\x61\x74\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptBeforeCreateUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x72\x65\x61\x74\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptAfterCreateUser,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x65\x6c\x65\x74\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptBeforeDeleteUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x65\x6c\x65\x74\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptAfterDeleteUser,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x69\x73\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptBeforeDisableUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x69\x73\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptAfterDisableUser,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x65\x6e\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptBeforeEnableUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x65\x6e\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$GLOBAL::UserScriptAfterEnableUser,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x69\x6d\x69\x74\x5f\x61\x6c\x61\x72\x6d"
,$GLOBAL::UserScriptAfterLimitAlarm,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x61\x72\x74"
,$GLOBAL::ScriptBeforeServerDaemonStart,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x61\x72\x74"
,$GLOBAL::ScriptAfterServerDaemonStart,
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x6f\x70"
,$GLOBAL::ScriptBeforeServerDaemonStop,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x6f\x70"
,$GLOBAL::ScriptAfterServerDaemonStop,
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x73\x79\x6e\x63"
,$GLOBAL::ScriptAfterClusterSync,
"\x73\x63\x72\x69\x70\x74\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x73\x65\x74\x5f\x73\x68\x61\x72\x65\x64\x5f\x69\x70"
,$GLOBAL::ScriptClusterSetSharedIP,
"\x73\x63\x72\x69\x70\x74\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x63\x6c\x65\x61\x72\x5f\x73\x68\x61\x72\x65\x64\x5f\x69\x70"
,$GLOBAL::ScriptClusterClearSharedIP));(my $name=$functions{$functionName});(my $timeout
=undef);if (($name=~ /^(.*?) --timeout (\d+)$/ )){($name=$1);($timeout=$2);}if (
$GLOBAL::SCRIPT_DEBUG){Logger::debug ((
"\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$functionName),(0x198b+ 146-0x1a1d));
}if ($name){if ($GLOBAL::SCRIPT_DEBUG){Logger::debug ((((
"\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$functionName)."\x20").$name),
(0x1365+ 1402-0x18df));}if (-x ($name)){(my (@command)=($name,@_));my (
@parameters);__setEnvironmentVariablesForScript ((\@parameters),$functionName);
if (($timeout ne (""))){push (@parameters,"\x74\x69\x6d\x65\x6f\x75\x74",
$timeout);}(my ($cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(
\@parameters)));if ($GLOBAL::SCRIPT_DEBUG){Logger::debug ((((((((
"\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$functionName).
"\x20\x72\x65\x74\x75\x72\x6e\x3a\x5b").$cmd_err)."\x2c").$cmd_out)."\x2c").(
$exit_value."\x5d")));}if ((not ($exit_value))){__checkAndReloadDatabaseIfNeeded
 ($cmd_out);return ((0x17f4+ 1408-0x1d74));}else{Logger::error (((
"\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x20\x6f\x66\x20\x73\x63\x72\x69\x70\x74\x20"
.$functionName)."\x20\x66\x61\x69\x6c\x65\x64\x2e"),(0x0766+ 3627-0x1591));
return ($cmd_err,$cmd_out,$exit_value);}}else{if ($GLOBAL::SCRIPT_DEBUG){
Logger::debug ((("\x53\x43\x52\x49\x50\x54\x53\x3a\x3a\x20".$functionName).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74"),
(0x00cf+ 3440-0x0e3f));}}}else{return ((0x0969+ 4105-0x1972));}}sub 
handleScriptBeforeLogin{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x6c\x6f\x67\x69\x6e",
NXClientConnection::getRemoteIp ()));if (($exit_value!=(0x00f8+ 4314-0x11d2))){
Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterLogin{(my $user
=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x69\x6e",$user
,NXClientConnection::getRemoteIp ()));if (($exit_value!=(0x1090+ 3933-0x1fed))){
Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterLogout{(my $user
=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x6f\x75\x74",
$user,NXClientConnection::getRemoteIp ()));if (($exit_value!=
(0x1f38+ 1392-0x24a8))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptBeforeStart{my (
$cmd_err,$cmd_out,$exit_value);if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(
($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}if ((
$exit_value!=(0x08e3+ 847-0x0c32))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterStart{my (
$cmd_err,$cmd_out,$exit_value);if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(
($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x74\x61\x72\x74\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}if ((
$exit_value!=(0x01e6+ 8378-0x22a0))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptBeforeDisconnect{(my (
$cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x75\x73\x70\x65\x6e\x64"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));if ((
$exit_value!=(0x0466+ 2485-0x0e1b))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptAfterDisconnect{(my ($cmd_err
,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x75\x73\x70\x65\x6e\x64"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));if ((
$exit_value!=(0x06c2+ 3868-0x15de))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptBeforeReconnect{(my ($cmd_err
,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));if ((
$exit_value!=(0x12c5+ 596-0x1519))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterReconnect{
(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x72\x65\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6e\x67"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));if ((
$exit_value!=(0x160c+ 111-0x167b))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptBeforeClose{my ($cmd_err,
$cmd_out,$exit_value);if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(
($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}if ((
$exit_value!=(0x096d+ 1219-0x0e30))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptAfterClose{my ($cmd_err,
$cmd_out,$exit_value);if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(
($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x6c\x6f\x73\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}if ((
$exit_value!=(0x056d+ 7462-0x2293))){main::terminateSession (
Server::getMySessionID ());NXSession2::handleError (
"\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64",$message);
Server::setSessionFileRemoved ();}}sub handleScriptBeforeFailure{if (
Common::NXSessionType::isAttach (NXSessionParameters::getSessionType ())){(my (
$cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(my (
$cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}}sub 
handleScriptAfterFailure{if (Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ())){(my ($cmd_err,$cmd_out,$exit_value)=
runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort (),
Server::getMainSessionID (),NXSessionParameters::getMainSessionType ()));}else{(my (
$cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x73\x65\x73\x73\x69\x6f\x6e\x5f\x66\x61\x69\x6c\x75\x72\x65"
,Server::getMySessionID (),NXSessionParameters::getUsername (),
NXSessionParameters::getNodeHost (),NXSessionParameters::getNodePort ()));}}sub 
handleScriptBeforeCreateUser{(my $user=shift (@_));(my ($cmd_err,$cmd_out,
$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x63\x72\x65\x61\x74\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x069b+ 5369-0x1b94))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterCreateUser{
(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x63\x72\x65\x61\x74\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x2386+ 161-0x2427))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptBeforeDeleteUser
{(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x65\x6c\x65\x74\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x0bc8+ 4689-0x1e19))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterDeleteUser{
(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x65\x6c\x65\x74\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x1377+ 818-0x16a9))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
handleScriptBeforeDisableUser{(my $user=shift (@_));(my ($cmd_err,$cmd_out,
$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x69\x73\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x0388+ 3343-0x1097))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterDisableUser
{(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x69\x73\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x0f13+ 1791-0x1612))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptBeforeEnableUser
{(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x65\x6e\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x0529+ 1906-0x0c9b))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterEnableUser{
(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x65\x6e\x61\x62\x6c\x65\x5f\x75\x73\x65\x72"
,$user));if (($exit_value!=(0x05df+ 8094-0x257d))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);if ($cmd_err){chomp ($cmd_err);NXMsg::send_response (
"\x65\x43\x6d\x64\x45\x72\x72","\x4e\x58\x53\x63\x72\x69\x70\x74\x73",$cmd_err);
}NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterLimitAlarm{
(my $user=shift (@_));(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x69\x6d\x69\x74\x5f\x61\x6c\x61\x72\x6d"
,$user,NXClientConnection::getRemoteIp ()));if (($exit_value!=
(0x0ea2+ 6084-0x2666))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
handleScriptBeforeDaemonStart{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x61\x72\x74"
));if (($exit_value!=(0x07c2+ 6429-0x20df))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
handleScriptAfterDaemonStart{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x61\x72\x74"
));if (($exit_value!=(0x07e7+ 1236-0x0cbb))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
handleScriptBeforeDaemonStop{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x6f\x70"
));if (($exit_value!=(0x0a90+ 2078-0x12ae))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub handleScriptAfterDaemonStop
{(my ($cmd_err,$cmd_out,$exit_value)=runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x64\x61\x65\x6d\x6f\x6e\x5f\x73\x74\x6f\x70"
));if (($exit_value!=(0x0865+ 5974-0x1fbb))){Common::NXMsg::error (
"\x65\x45\x78\x65\x63\x75\x74\x69\x6f\x6e\x53\x63\x72\x69\x70\x74\x46\x61\x69\x6c\x65\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
__setEnvironmentVariablesForScript{(my $ref_parameters=shift (@_));(my $name=
shift (@_));Server::addCONNECTIONvariableToEnvArrayPassed ($ref_parameters);if (
($name eq 
"\x73\x63\x72\x69\x70\x74\x5f\x62\x65\x66\x6f\x72\x65\x5f\x6c\x6f\x67\x69\x6e"))
{push (@$ref_parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
Server::getClientVersion ()));}elsif (($name eq 
"\x73\x63\x72\x69\x70\x74\x5f\x61\x66\x74\x65\x72\x5f\x6c\x6f\x67\x69\x6e")){
push (@$ref_parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
Server::getClientVersion ()));push (@$ref_parameters,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x52\x55\x4e\x4e\x45\x52\x5f\x41\x55\x54\x48\x3d".
NXLogin::getAuthMethod ()));}}sub __checkAndReloadDatabaseIfNeeded{(my $cmd_out=
shift (@_));if (($cmd_out=~ /(reload servers|reload nodes)/i )){
NXNodes::reloadNodesDB ();}if (($cmd_out=~ /(reload profiles|reload rules)/i )){
main::nxrequire ("\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42");
NXProfilesDB::reloadProfilesDB ();}if (($cmd_out=~ /reload users/i )){
main::nxrequire ("\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");
NXUsersManager::reloadUsersDB ();}if (($cmd_out=~ /reload groups/i )){
main::nxrequire ("\x4e\x58\x47\x72\x6f\x75\x70\x73");NXGroups::reloadGroupsDB ()
;}if (($cmd_out=~ /reload administrators/i )){main::nxrequire (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXAdministratorsManager::reloadAdministratorsDB ();}if (($cmd_out=~ /reload clusters/i )
){main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");NXCluster::reload ();
}}sub handleScriptBeforeKillingHangedProcess{(my $sessionId=shift (@_));(my $pid
=shift (@_));if (($GLOBAL::scriptBeforeKillingHangedProcess ne (""))){(my $script
=$GLOBAL::scriptBeforeKillingHangedProcess);if (-x ($script)){(my (@command)=(
$script,$pid,$sessionId));(my (@parameters)=());(my ($cmd_err,$cmd_out,
$exit_value)=main::run_command ((\@command),(\@parameters)));}else{if (
Common::NXFile::fileExists ($script)){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x27".$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x69\x73\x20\x6e\x6f\x74\x20\x65\x78\x65\x63\x75\x74\x61\x62\x6c\x65\x2e"
));}else{Logger::warning ((("\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x27".
$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"
));}}}}sub runNXReportSystemLoadScript{(my $script=
NXPaths::getNXReportLoadScript ());if (NXSystemDaemons::isRunning (
getSystemLoadScriptProcessName ())){Logger::debug (((
"\x53\x6b\x69\x70\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x27".$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));return ((0x0745+ 1588-0x0d78));}if (-x ($script)){(my $systemLoadFile=
NXPaths::getSystemLoadFile ());if ((not (__prepareSystemLoadFile (
$systemLoadFile)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$script)."\x27\x2e"));return ((0x09a1+ 6618-0x237b));}(my (@command)=());push (
@command,$script);push (@command,$systemLoadFile);(my (@parameters)=());(my $pid
=(-(0x0faf+  25-0x0fc7)));push (@parameters,"\x67\x65\x74\x20\x70\x69\x64",(
\$pid));main::nxRunCommandBg ((\@command),(\@parameters));if (($pid>
(0x08b1+ 2987-0x145c))){($nxReportSysLoadScriptFinishedAbnormally=
(0x1511+ 1041-0x1922));($nxReportSysLoadScriptLastRun=
Common::NXTime::getSecondsSinceEpoch ());($nxReportSysLoadScriptPid=$pid);
Common::NXProcess::setCallbackSIGCHLD ($pid,(\&nxReportLoadScriptSIGCHLDHandler)
);NXSystemDaemons::savePid (getSystemLoadScriptProcessName (),$pid);return (
(0x05a8+ 985-0x0980));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$script)."\x27\x2e"));return ((0x09b8+ 7124-0x258c));}}else{if (
Common::NXFile::fileExists ($script)){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x69\x73\x20\x6e\x6f\x74\x20\x65\x78\x65\x63\x75\x74\x61\x62\x6c\x65\x2e"
));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x75\x6e\x20\x73\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$script).
"\x27\x2e\x20\x53\x63\x72\x69\x70\x74\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"
));}}return ((0x0772+ 7096-0x232a));}sub __prepareSystemLoadFile{(my $systemLoadFile
=shift (@_));if ((not (Common::NXFile::fileExists ($systemLoadFile)))){return (
Common::NXFile::createFileReadWriteByUserReadByGroupOthers ($systemLoadFile));}
else{if ((Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll (
$systemLoadFile)==(-(0x11a3+ 463-0x1371)))){return ((0x1065+ 2587-0x1a80));}
return ((0x1e50+ 667-0x20ea));}}sub rerunNXReportSystemLoadScript{(++
$nxReportSysLoadScriptRerunTries);runNXReportSystemLoadScript ();}sub 
shouldRerunNXReportSystemLoadScript{if ((not (
isRunNXReportSystemLoadScriptEnabled ()))){return ((0x1c68+ 1823-0x2387));}if ((
$nxReportSysLoadScriptFinishedAbnormally==(0x039c+ 7639-0x2173))){return (
(0x022d+ 4387-0x1350));}if (($nxReportSysLoadScriptRerunTries>
$nxReportSysLoadScriptMaxRerun)){return ((0x0521+ 157-0x05be));}(my $currentTime
=Common::NXTime::getSecondsSinceEpoch ());(my $delay=
$nxReportSysLoadScriptRerunCheckDelay);if ((($nxReportSysLoadScriptLastRun+
$delay)<$currentTime)){return ((0x19a5+ 193-0x1a65));}return (
(0x077d+ 2707-0x1210));}sub isRunNXReportSystemLoadScriptEnabled{if ((
NXLicense::isMultiNodeFeature ()and ($GLOBAL::LoadBalancingAlgorithm eq 
"\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64"))){return ((0x0225+ 4241-0x12b5))
;}elsif (NXServerDaemon::isReportSystemLoadRequestReceived ()){return (
(0x012a+ 5930-0x1853));}return ((0x06c1+ 7670-0x24b7));}sub 
nxReportLoadScriptSIGCHLDHandler{(my $pid=shift (@_));(my $code=shift (@_));if (
((not (NXSystemDaemons::isShutdownFlag ()))and ($code!=(0x0bda+ 2194-0x146c)))){
($nxReportSysLoadScriptFinishedAbnormally=(0x13e2+ 1378-0x1943));}(my $file=
NXPaths::getSystemLoadFile ());if (-f ($file)){Common::NXFile::truncateFile (
$file);}}sub handleNXReportSystemLoadScriptAfterDaemonStart{if (
NXLicense::isMultiNodeFeature ()){handleLeftoverSystemLoadScriptCleanup ();}if (
isRunNXReportSystemLoadScriptEnabled ()){runNXReportSystemLoadScript ();}}sub 
handleLeftoverSystemLoadScriptCleanup{if (isReportSystemLoadSupported ()){
terminateNXReportSystemLoadScriptIfRunning ();}}sub isReportSystemLoadSupported{
if ((NXLicense::isServerAvailableAsRemoteNode ()or NXLicense::isMultiNodeFeature
 ())){return ((0x09a4+ 1014-0x0d99));}return ((0x037c+ 1802-0x0a86));}sub 
terminateNXReportSystemLoadScriptIfRunning{(my $pid=NXSystemDaemons::readPid (
getSystemLoadScriptProcessName ()));if ((not (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($pid,
getSystemLoadScriptProcessName ())))){return;}if ((Common::NXProcess::sigterm (
$pid)==(0x0df1+ 4897-0x2111))){NXSystemDaemons::waitForServiceClosure ($pid,
getSystemLoadScriptProcessName ());}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($pid,
getSystemLoadScriptProcessName ())){NXSystemDaemons::killServiceIfRunning ($pid,
getSystemLoadScriptProcessName (),(0x0de4+ 3862-0x1cfa));}else{
NXSystemDaemons::removePidFile (getSystemLoadScriptProcessName ());}(my $file=
NXPaths::getSystemLoadFile ());if (Common::NXFile::fileExists ($file)){
Common::NXFile::truncateFile ($file);}}sub getSystemLoadScriptProcessName{if ((
$nxReportSysLoadScriptProcessName eq (""))){($nxReportSysLoadScriptProcessName=
substr (NXPaths::getNXReportLoadScriptName (),(0x0355+ 6600-0x1d1d),
(0x13da+ 269-0x14d8)));}return ($nxReportSysLoadScriptProcessName);}sub 
getCustomErrorMessage{(my $messageId=shift (@_));(my (@parameters)=());(my (
@command)=($GLOBAL::CustomErrorMessages,$messageId));(my ($cmdErr,$customMessage
,$exitValue)=main::run_command ((\@command),(\@parameters)));if ((($exitValue!=
(0x0f06+ 4351-0x2005))or ($customMessage eq ("")))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x75\x73\x74\x6f\x6d\x20\x65\x72\x72\x6f\x72\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x77\x69\x74\x68\x20\x73\x63\x72\x69\x70\x74\x20\x27"
.$GLOBAL::CustomErrorMessages)."\x27\x2e"));return;}($customMessage=~ s/^\n//gm )
;($customMessage=~ s/\n$//gm );return ($customMessage);}"\x3f\x3f\x3f";
