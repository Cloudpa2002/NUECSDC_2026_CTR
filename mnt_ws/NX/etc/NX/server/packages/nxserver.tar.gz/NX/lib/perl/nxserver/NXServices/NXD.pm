############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXServices::NXD;no warnings;(my $__pid=(0x0337+ 6790-0x1dbd));(my $__disabled
=(0x1d8b+ 245-0x1e80));(my $__startTime=(0x0541+ 675-0x07e4));(my $__silenceMode
=(0x1391+ 1793-0x1a92));(my $__restartCouter=(0x01f1+ 866-0x0553));(my $__stdin=
(-(0x079d+ 5748-0x1e10)));(my $__handlingManualStart=(0x164d+ 1516-0x1c39));(my $__status
=$NXSystemDaemons::statusUninitialized);sub isEnabled{if (($__disabled==
(0x12b9+ 2877-0x1df5))){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);return ((0x0e59+ 3952-0x1dc9));}if (NXSystemDaemons::isServiceDisabled (
"\x6e\x78\x64")){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x6f\x72\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x2e"
);return ((0x02f9+  52-0x032d));}if (NXSystemDaemons::isNxdStartupKeyDisabled ()
){if (__isHandlingManualStart ()){return ((0x0030+ 8911-0x22fe));}Logger::debug 
(
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x72\x75\x6e\x20\x6d\x61\x6e\x75\x61\x6c\x6c\x79\x2e"
);return ((0x1447+ 4380-0x2563));}Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x69\x73\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"
);return ((0x0477+ 2638-0x0ec4));}sub isDisabled{return ((!isEnabled ()));}sub 
setEnabled{($__disabled=(0x06b4+ 1557-0x0cc9));}sub setDisabled{($__disabled=
(0x04b0+ 2136-0x0d07));}sub start{if (($__status eq 
$NXSystemDaemons::statusStarting)){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x2e"
);return ((0x059b+ 2576-0x0faa));}if (isEnabled ()){
NXSystemDaemons::removeStopFlag ("\x6e\x78\x64");($__status=
$NXSystemDaemons::statusStarting);if ((NXSystemDaemons::isNxdStartupKeyDisabled 
()and __isHandlingManualStart ())){main::nxrequire (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c");NXFirewall::addFirewallNXDPort ();}(my $nxdPid
=__runNXD ());if (Common::NXProcess::isProcessRunning ($nxdPid)){($__status=
$NXSystemDaemons::statusRunning);__handleNXDStartedWithPid ($nxdPid);return (
(0x1ce1+ 2545-0x26d1));}return ((0x1839+ 3580-0x2635));}return (
(0x092f+ 6374-0x2214));}sub stop{NXSystemDaemons::setStopFlag ("\x6e\x78\x64");
setDisabled ();(my $ret=__closeNXD ());main::nxrequire (
"\x4e\x58\x53\x68\x75\x74\x64\x6f\x77\x6e");if ((($ret==(0x0e86+ 2414-0x17f4))
and NXShutdown::serviceWasDisabled ("\x6e\x78\x64"))){setPid (
(0x06a6+ 3770-0x1560));__handleNXDAlreadyClosed ();return ((0x1e29+ 221-0x1f06))
;}elsif (($ret==(0x014f+ 8711-0x2356))){setPid ((0x04a5+ 5652-0x1ab9));
__handleNXDClosed ();return ((0x0193+ 8399-0x2262));}__handleNXDNotClosed ();
return ((0x19e1+ 2627-0x2423));}sub isSilenceMode{if (($__silenceMode==
(0x0aca+ 1673-0x1152))){return ((0x1cb3+ 1714-0x2364));}if (
Server::isClientConnectionClosed ()){($__silenceMode=(0x0588+ 3360-0x12a7));}
return ($__silenceMode);}sub setSilentMode{($__silenceMode=(0x0342+ 6462-0x1c7f)
);}sub __closeNXD{(my $nxdPid=getPid ());if ((($nxdPid==(0x150b+ 249-0x1604))or 
(not (Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxdPid,
"\x6e\x78\x64"))))){return ((0x159b+ 254-0x1699));}if (($__status eq 
$NXSystemDaemons::statusTerminating)){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6e\x67\x2e"
);return ((0x0c55+ 706-0x0f17));}($__status=$NXSystemDaemons::statusTerminating)
;if ((Common::NXProcess::sigterm ($nxdPid)==(0x0579+ 852-0x08cc))){
NXSystemDaemons::waitForServiceClosure ($nxdPid,"\x6e\x78\x64");}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxdPid,
"\x6e\x78\x64")){NXSystemDaemons::killServiceIfRunning ($nxdPid,"\x6e\x78\x64",
(0x08d5+ 1229-0x0da2));}else{return ((0x0358+ 9023-0x2697));}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxdPid,
"\x6e\x78\x64")){($__status=$NXSystemDaemons::statusTerminated);return (
(0x0ba6+ 3632-0x19d5));}return ((0x1010+ 249-0x1109));}sub __handleNXDClosed{if 
((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73","\x6e\x78\x64");}
NXSystemDaemons::removePidFile ("\x6e\x78\x64");main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ("\x6e\x78\x64");}
sub __handleNXDAlreadyClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73","\x6e\x78\x64");
}NXSystemDaemons::removePidFile ("\x6e\x78\x64");main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ("\x6e\x78\x64");}
sub __handleNXDNotClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73","\x6e\x78\x64");}
}sub getPid{if (($__pid!=(0x1096+ 4653-0x22c3))){Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x20"
.$__pid)."\x2e"));return ($__pid);}($__pid=NXSystemDaemons::readPid (
"\x6e\x78\x64"));return ($__pid);}sub setPid{($__pid=shift (@_));if (($__pid>
(0x0afc+ 5596-0x20d8))){NXSystemDaemons::savePid ("\x6e\x78\x64",$__pid);}}sub 
__setStartTime{($__startTime=Common::NXTime::getSecondsSinceEpoch ());}sub 
__handleNXDStartedWithPid{(my $nxdPid=shift (@_));
Common::NXProcess::setExitCallback ($nxdPid,(\&nxdSIGCHLDHandler));
Common::NXProcess::setErrorCallback ($nxdPid,(\&nxdSIGCHLDHandler));
Logger::debug (((
"\x4e\x58\x44\x20\x69\x73\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$nxdPid)."\x2e"));__setStartTime ();setPid ($nxdPid);__resetHandlingManualStart
 ();main::nxrequire ("\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToAdd 
("\x6e\x78\x64");}sub __getStdoutFile{return ((((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x64\x2e\x6c\x6f\x67"));}sub __getStderrFile{return (((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x64\x2e\x6c\x6f\x67"));}sub __runNXD{(my $servicePid
=getPid ());if ((($servicePid>(0x1378+ 1474-0x193a))and 
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($servicePid,
"\x6e\x78\x64"))){if (((not (Common::NXProcess::isChildProcess ($servicePid)))
and (not (Common::NXProcess::isOnWatchdogProcess ($servicePid))))){
Common::NXProcess::addWatchdog ($servicePid,$NXBITS::SIGCHLD);
Common::NXProcess::setCallbackSIGCHLD ($servicePid,(\&nxdSIGCHLDHandler));}
Logger::debug (
"\x4e\x58\x44\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);return ($servicePid);}if (($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31"))
{__createCertIfNeeded ();}(my (@command)=__getCommandStart ());(my (@options)=
__getCommandOptions ());my ($nxdPid);push (@options,
"\x67\x65\x74\x20\x70\x69\x64",(\$nxdPid));Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6e\x78\x64\x2e");main::nxRunCommand ((
\@command),(\@options));return ($nxdPid);}sub __createCertIfNeeded{if (
Common::NXFile::isExists (NXPaths::getHostPrivateCert ())){return;}(my (@command
)=());push (@command,$GLOBAL::COMMAND_NXKEYGEN);push (@command,"\x2d\x6b\x20");
push (@command,NXPaths::getHostPrivateCert ());push (@command,"\x2d\x63\x20");
push (@command,NXPaths::getHostPublicCert ());(my (@options)=());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(((
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",((("\x4e\x58\x5f\x45\x54\x43\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e"));
main::nxRunCommand ((\@command),(\@options));}sub __getCommandStart{(my (
@command)=());push (@command,(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x62\x69\x6e").$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x64"));if ((
NXNodeInfo::getNxdPort ()!=(0x2533+ 1614-0x1be1))){push (@command,(
"\x2d\x70\x20".NXNodeInfo::getNxdPort ()));}if ((NXNodeInfo::getNxdUDPPort ()!=
(0x22b9+ 433-0x14ca))){push (@command,("\x2d\x75\x20".NXNodeInfo::getNxdUDPPort 
()));}if (($GLOBAL::NXdConnectionsLimit!=(""))){push (@command,("\x2d\x4c\x20".
$GLOBAL::NXdConnectionsLimit));}if (($GLOBAL::NXdConnectionsInterval!=(""))){
push (@command,("\x2d\x52\x20".($GLOBAL::NXdConnectionsInterval *
(0x0aad+ 7281-0x2336))));}if (($GLOBAL::NXdConnectionsIntervalLimit!=(""))){push
 (@command,("\x2d\x43\x20".$GLOBAL::NXdConnectionsIntervalLimit));}if ((
$GLOBAL::NXdListenAddress ne (""))){push (@command,"\x2d\x6c",
$GLOBAL::NXdListenAddress);}return (@command);}sub __getCommandOptions{(my (
@options)=());push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".(
$GLOBAL::NODE_ROOT."\x2f\x6c\x69\x62")));(my $homeDir=NXPaths::getUserNXHomeDir 
());push (@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".
$homeDir));main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if (
NXCluster::isEnabled ()){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4c\x55\x53\x54\x45\x52\x3d".$GLOBAL::ClusterHost));}if (($ENV
{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",((("\x4e\x58\x5f\x45\x54\x43\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e"));}my ($nxdStdin);
Common::NXCore::nxPipeCreateBi ((\$__stdin),(\$nxdStdin));push (@options,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",$nxdStdin);push (@options,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");
Logger::debug ((("\x4e\x58\x44\x3a\x20\x53\x74\x64\x69\x6e\x20\x46\x44\x23".
$__stdin)."\x2e"));push (@options,"\x73\x74\x64\x65\x72\x72",__getStderrFile ())
;push (@options,"\x73\x74\x64\x6f\x75\x74",__getStdoutFile ());push (@options,
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x3d".libnxh::NXTransGetEnvironment
 ("\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e")));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".$GLOBAL::NODE_ROOT));return (@options
);}sub getStdin{return ($__stdin);}sub nxdSIGCHLDHandler{(my $pid=shift (@_));(my $code
=shift (@_));Logger::debug (((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$pid).
"\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$code)."\x2e"));NXSystemDaemons::removePidFile ("\x6e\x78\x64");setPid (
(0x177f+ 2463-0x211e));if ((($GLOBAL::REQUEST_TERMINATE==(0x1405+ 3577-0x21fd))
or NXSystemDaemons::isShutdownFlag ())){Logger::debug (
"\x4e\x6f\x74\x20\x72\x65\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x4e\x58\x44\x20\x64\x75\x72\x69\x6e\x67\x20\x73\x68\x75\x74\x64\x6f\x77\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x2e"
);return ((0x187c+ 3341-0x2589));}main::nxrequire (
"\x4e\x58\x52\x65\x64\x69\x73\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e");
NXRedisSubscription::sendNxdClosedEvent ();if (isDisabled ()){return;}if (
NXSystemDaemons::isStopFlag ("\x6e\x78\x64")){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x44\x20\x68\x61\x73\x20\x73\x74\x6f\x70\x20\x66\x6c\x61\x67\x2e"
);return;}if (__isMaximumRestartCounterReached ()){setDisabled ();return;}start 
();}sub __isMaximumRestartCounterReached{(my $lifeTime=(
Common::NXTime::getSecondsSinceEpoch ()-$__startTime));if (($lifeTime<
$GLOBAL::TooShortServiceLifeTime)){($__restartCouter+=(0x10e9+ 2901-0x1c3d));}
else{($__restartCouter=(0x0272+ 1136-0x06e2));}if (($__restartCouter>
$GLOBAL::MaximumServiceRestartCounter)){Logger::warning (
"\x52\x65\x61\x63\x68\x65\x64\x20\x6d\x61\x78\x69\x6d\x75\x6d\x20\x4e\x58\x44\x20\x72\x65\x73\x74\x61\x72\x74\x20\x63\x6f\x75\x6e\x74\x65\x72\x2e"
);return ((0x109b+ 972-0x1466));}return ((0x1d87+ 241-0x1e78));}sub 
setHandlingManualStart{($__handlingManualStart=(0x02c7+ 357-0x042b));}sub 
__isHandlingManualStart{if (($__handlingManualStart==(0x0055+ 7084-0x1c00))){
return ((0x0471+ 2716-0x0f0c));}return ((0x1dc8+ 1894-0x252e));}sub 
__resetHandlingManualStart{($__handlingManualStart=(0x0966+  44-0x0992));}return
 ((0x0446+ 4228-0x14c9));
