############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXWebStorage::addWebData{package NXWebStorage;no warnings;(my $ref_parameters
=shift (@_));Logger::debug (((((
"\x4e\x58\x57\x65\x62\x53\x74\x6f\x72\x61\x67\x65\x3a\x20\x41\x64\x64\x20\x64\x61\x74\x61\x20\x66\x6f\x72\x20\x53\x49\x44\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27\x3a\x20\x27").$$ref_parameters{
"\x64\x61\x74\x61"})."\x27\x2e"));(my $ret=__addKey ($$ref_parameters{
"\x73\x69\x64"},main::urlencode ($$ref_parameters{"\x64\x61\x74\x61"})));
Logger::debug (((
"\x4e\x58\x57\x65\x62\x53\x74\x6f\x72\x61\x67\x65\x3a\x20\x5f\x5f\x61\x64\x64\x4b\x65\x79\x28\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x3a\x20"
.$ret)."\x2e"));if (($ret!=(0x01e4+ 8284-0x2240))){(my $message=((
"\x53\x61\x76\x65\x64\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x69\x6e\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x66\x6f\x72\x20\x73\x69\x64\x3a\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27"));Logger::debug (($message."\x2e"));if
 ((main::nxwrite (main::nxgetSTDOUT (),(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_WEBSTORAGE_ADD)."\x20").$message)."\x0a"))==(-(0x07c6+ 2914-0x1327)
))){return ((0x0315+ 7104-0x1ed5));}return ((0x0563+ 4062-0x1540));}(my $message
=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x61\x76\x65\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x69\x6e\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x66\x6f\x72\x20\x73\x69\x64\x3a\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27"));Logger::debug (($message."\x2e"));
main::nxwrite (main::nxgetSTDOUT (),(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ERROR).
"\x20").$message)."\x0a"));return ((0x094f+ 2658-0x13b1));}sub 
NXWebStorage::getWebData{package NXWebStorage;no warnings;(my $ref_parameters=
shift (@_));Logger::debug (
"\x53\x74\x61\x72\x74\x20\x67\x65\x74\x20\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x2e"
);(my $data=__getKey ($$ref_parameters{"\x73\x69\x64"}));if (((not (defined (
$data)))or ($data eq ("")))){(my $message=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x66\x72\x6f\x6d\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x66\x6f\x72\x20\x73\x69\x64\x3a\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27"));Logger::debug (($message."\x2e"));
main::nxwrite (main::nxgetSTDOUT (),(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ERROR).
"\x20").$message)."\x0a"));return ((0x10d6+ 1284-0x15da));}(my $message=((
"\x47\x65\x74\x20\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72\x20\x64\x61\x74\x61\x20\x66\x72\x6f\x6d\x20\x64\x61\x74\x61\x62\x61\x73\x65\x20\x66\x6f\x72\x20\x73\x69\x64\x3a\x20\x27"
.$$ref_parameters{"\x73\x69\x64"})."\x27"));Logger::debug (($message."\x2e"));(my $buffer
=(((((("\x4e\x58\x3e\x20".$GLOBAL::MSG_WEBSTORAGE_GET)."\x20\x73\x69\x64\x3d").
$$ref_parameters{"\x73\x69\x64"})."\x20\x64\x61\x74\x61\x3d").$data)."\x0a"));if
 ((main::nxwrite (main::nxgetSTDOUT (),$buffer)==(-(0x08f0+ 7481-0x2628)))){
return ((0x01f5+ 6779-0x1c70));}return ((0x2075+ 530-0x2286));}sub 
NXWebStorage::__getKey{package NXWebStorage;no warnings;(my $key=shift (@_));(my $ret
=NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x57\x45\x42\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x0a")));if (($ret==(0x0775+ 4460-0x18e1))){return ((""));}return (
main::urldecode (NXRedis::get ()));}sub NXWebStorage::__addKey{package 
NXWebStorage;no warnings;(my $key=shift (@_));(my $value=shift (@_));return (
NXRedis::sendToDb (((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x57\x45\x42\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x2c\x76\x61\x6c\x75\x65\x3d").$value)."\x0a")));}sub 
NXWebStorage::__delKey{package NXWebStorage;no warnings;(my $key=shift (@_));
return (NXRedis::sendToDb (((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x57\x45\x42\x44\x61\x74\x61\x2c\x66\x69\x65\x6c\x64\x3d"
.$key)."\x2c\x66\x69\x65\x6c\x64\x3d").$key)."\x0a")));}package NXWebStorage;no 
warnings;"\x3f\x3f\x3f";
