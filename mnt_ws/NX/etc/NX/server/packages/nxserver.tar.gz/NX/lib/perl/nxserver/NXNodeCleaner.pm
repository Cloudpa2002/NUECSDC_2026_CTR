############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXNodeCleaner;no warnings;($node={});($nodeFD={});sub start{(my $session
=shift (@_));(my $display=shift (@_));(my $type=shift (@_));(my $owner=shift (@_
));(my $pid=shift (@_));(my $shMemId=NXNodeExec::handleSharedMemoryGet ($session
));if ((not (defined ($pid)))){if ((not (defined ($session)))){Logger::warning (
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x69\x64\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2c\x20\x64\x72\x6f\x70\x20\x73\x74\x61\x72\x74\x20\x6e\x6f\x64\x65\x20\x63\x6c\x65\x61\x6e\x65\x72\x2e"
);return;}if ((not (defined ($display)))){Logger::warning (
"\x44\x69\x73\x70\x6c\x61\x79\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2c\x20\x64\x72\x6f\x70\x20\x73\x74\x61\x72\x74\x20\x6e\x6f\x64\x65\x20\x63\x6c\x65\x61\x6e\x65\x72\x2e"
);return;}($pid=(0x02df+ 655-0x056e));}if (((not (defined ($type)))and defined (
$session))){($type=NXSession2::getTypeBySessionId ($session));}if ((defined (
$session)and defined ($node{$session}))){Logger::warning (((
"\x4e\x6f\x64\x65\x20\x43\x6c\x65\x61\x6e\x65\x72\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$session)."\x2e"));return;}Logger::debug (((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x63\x6c\x65\x61\x6e\x69\x6e\x67\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20"
.$session)."\x2e"));(my $inherit=Server::getInheritConnectionDescriptor ());
Server::setInheritConnectionDescriptor ("\x6e\x6f");main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x50\x72\x6f\x63\x65\x73\x73");(my ($nodeIn,$nodeOut,
$nxexecPid,$pidFD)=NXNodeProcess::start ($owner,
"\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72\x3a\x3a\x6e\x78\x65\x78\x65\x63\x50\x69\x64\x43\x61\x6c\x6c\x62\x61\x63\x6b"
));Server::setInheritConnectionDescriptor ($inherit);(my (%node)=(
"\x73\x65\x73\x73\x69\x6f\x6e",$session,"\x64\x69\x73\x70\x6c\x61\x79",$display,
"\x74\x79\x70\x65",$type,"\x6f\x77\x6e\x65\x72",$owner,"\x70\x69\x64",$pid,
"\x46\x44\x69\x6e",$nodeIn,"\x46\x44\x6f\x75\x74",$nodeOut,
"\x6e\x78\x65\x78\x65\x63\x50\x69\x64",$nxexecPid,"\x73\x68\x4d\x65\x6d\x49\x64"
,$shMemId,"\x63\x6c\x65\x61\x6e\x65\x72\x50\x69\x64",(-(0x1651+ 1181-0x1aed))));
($NXNodeCleaner::node{$session}=(\%node));($nodeFD{$nodeOut}=$session);($nodePid
{$pidFD}=$session);(my $description=($session."\x20\x63\x6c\x65\x61\x6e\x65\x72"
));(my $handler=
"\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72\x3a\x3a\x63\x61\x6c\x6c\x62\x61\x63\x6b"
);__registerMessages ();Common::NXSelector::addToGlobalSelector ($nodeOut,
$description,$handler);if (($owner ne "\x6e\x78")){main::nxrequire (
"\x4e\x58\x44\x65\x62\x75\x67\x4d\x61\x6e\x61\x67\x65\x72");
NXDebugManager::addUserForLogCollection ($owner);}__setState ($session,
"\x77\x61\x69\x74\x46\x6f\x72\x50\x72\x6f\x6d\x74");}sub callback{(my $fd=shift 
(@_));(my $session=$nodeFD{$fd});my ($buffer);(my $bytes=main::nxread ($fd,(
\$buffer),65536));if (($bytes>(0x137b+ 2555-0x1d76))){Logger::debug ((((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20".$session).
"\x20\x63\x6c\x65\x61\x6e\x65\x72\x3a\x20").$buffer));__checkStatus ($session);
__parseMessage ($session,$buffer);}else{Logger::debug (($session.
"\x20\x63\x6c\x65\x61\x6e\x65\x72\x20\x63\x6c\x6f\x73\x65\x64\x2e"));
Common::NXSelector::removeFromGlobalSelector ($fd);main::nxclose ($fd);if ((
$node{$session}{"\x63\x6c\x65\x61\x6e\x65\x72\x50\x69\x64"}==(-
(0x111c+ 4894-0x2439)))){(my $pidFD=getPidFDBySession ($session));if (($pidFD>(-
(0x1305+ 1513-0x18ed)))){($nodePid{$pidFD}=undef);delete ($nodePid{$pidFD});
main::nxclose ($pidFD);Common::NXSelector::removeFromGlobalSelector ($pidFD);}}(
$node{$session}=undef);($nodeFD{$fd}=undef);delete ($node{$session});delete (
$nodeFD{$fd});}}sub getPidFDBySession{(my $session=shift (@_));foreach my $fd (
keys (%nodePid)){if (($nodePid{$fd}eq $session)){return ($fd);}}return ((-
(0x1cf4+ 1738-0x23bd)));}sub nxexecPidCallback{(my $fd=shift (@_));my ($buffer);
(my $bytes=main::nxread ($fd,(\$buffer),(0x1e0c+ 951-0x11c3)));Logger::debug (((
(
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x6e\x78\x65\x78\x65\x63\x20\x50\x49\x44\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$fd)."\x3a\x20").$buffer));if (($buffer=~ /(\d+)/ )){(my $pid=$1);(my $session=
$nodePid{$fd});Logger::debug (((($session.
"\x20\x63\x6c\x65\x61\x6e\x65\x72\x20\x69\x73\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
).$pid)."\x2e"));($node{$session}{"\x63\x6c\x65\x61\x6e\x65\x72\x50\x69\x64"}=
$pid);}elsif (($bytes==(0x1902+ 2031-0x20f1))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x6e\x78\x6e\x6f\x64\x65\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x46\x44\x23"
.$fd).
"\x2e\x20\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x63\x6c\x6f\x73\x65\x64\x2e"
));}else{Logger::warning (((((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x75\x6e\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20"
.$buffer).
"\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x70\x69\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
).$fd)."\x2e"));return;}($nodePid{$fd}=undef);delete ($nodePid{$fd});
main::nxclose ($fd);Common::NXSelector::removeFromGlobalSelector ($fd);}sub 
__getCleanersCount{return (scalar (keys (%node)));}sub __setState{(my $session=
shift (@_));(my $newState=shift (@_));($node{$session}{"\x73\x74\x61\x74\x65"}=
$newState);}sub __waitForMessages{(my $timeout=$GLOBAL::DefaultSelectorTimeout);my (
$startTime);(my $workingNodes=__getCleanersCount ());while ((($workingNodes>
(0x0766+ 1484-0x0d32))and ($timeout>(0x03cc+ 3134-0x100a)))){Logger::debug (((((
"\x57\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20".$workingNodes).
"\x20\x63\x6c\x65\x61\x6e\x65\x72\x28\x73\x29\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20"
).$timeout)."\x20\x6d\x73\x2e"));(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);($startTime=Common::NXTime::getSecondsSinceEpoch ());(my (@ready)=
$selector->can_read ($timeout));(my $timewait=(
Common::NXTime::getSecondsSinceEpoch ()-$startTime));if (($timewait>
(0x0893+ 3371-0x15bd))){($timeout-=($timewait *(0x07b4+ 4293-0x1491)));}(
$workingNodes=__getCleanersCount ());}}sub __parseMessage{(my $session=shift (@_
));(my $buffer=shift (@_));while (($buffer ne (""))){my ($message);(($buffer,
$message)=__getLineToParse ($buffer));if (($message=~ /NX> (\d+).*/ )){(my $code
=$1);if (Common::NXMsg::isPackedMessageNumber ($code)){(my ($indexString,
$message,@parameters)=Common::NXMsg::unpackResponse ($message));($code=
Common::NXMsg::getNumber ($indexString));if (((not ($code))and ($message=~ /NX> (\d+).*/ )
)){($code=$1);}}if (($handleMessage{$code}ne (""))){(my $function=$handleMessage
{$code});Logger::debug (((((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x20".$code).
"\x20\x77\x69\x74\x68\x20").$function)."\x2e"));&$function ($session,$message);}
else{if (Common::NXMsg::isErrorMessageNumber ($code)){Logger::warning (((((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x65\x72\x72\x6f\x72\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20"
.$session)."\x20\x63\x6c\x65\x61\x6e\x65\x72\x20\x27").$message)."\x27\x2e"));}
else{Logger::warning (((((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x20".$code).
"\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20").$session).
"\x20\x63\x6c\x65\x61\x6e\x65\x72\x20\x6e\x6f\x74\x20\x69\x6d\x70\x6c\x65\x6d\x65\x6e\x74\x65\x64\x2e"
));}}}elsif (($message=~ /Parent application/ )){Logger::debug ((
"\x49\x67\x6e\x6f\x72\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20".$message));}
else{Logger::warning ((((
"\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20"
.$session)."\x20\x63\x6c\x65\x61\x6e\x65\x72\x3a\x20").$message));}}}sub 
__getLineToParse{(my $buffer=shift (@_));(my $line=(""));if (($buffer=~ /^(.*?)\n(.*)$/s )
){($line=$1);($buffer=$2);}else{($buffer=(""));}return ($buffer,$line);}sub 
__registerMessages{($handleMessage{$GLOBAL::MSG_NODE_CONNECTED}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x4e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64"
);($handleMessage{$GLOBAL::MSG_NODE_SHELL_PROMPT}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x4e\x6f\x64\x65\x53\x68\x65\x6c\x6c\x50\x72\x6f\x6d\x70\x74"
);($handleMessage{$GLOBAL::MSG_NODE_END_OK}=
"\x5f\x5f\x68\x61\x6e\x64\x6c\x65\x4e\x6f\x64\x65\x45\x6e\x64\x4f\x4b");}sub 
__handleNodeConnected{(my $session=shift (@_));(my $message=shift (@_));
Logger::debug (((
"\x48\x61\x6e\x64\x6c\x65\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20"
.$session)."\x20\x63\x6c\x65\x61\x6e\x65\x72\x2e"));(my $request=
"\x73\x68\x65\x6c\x6c\x0a\x0a");__sendRequestToNode ($session,$request);
__setState ($session,
"\x77\x61\x69\x74\x69\x6e\x67\x4f\x6e\x53\x68\x65\x6c\x6c\x50\x72\x6f\x6d\x70\x74"
);}sub __handleNodeShellPrompt{(my $session=shift (@_));(my $message=shift (@_))
;Logger::debug (((
"\x48\x61\x6e\x64\x6c\x65\x20\x73\x68\x65\x6c\x6c\x20\x70\x72\x6f\x6d\x70\x74\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20"
.$session)."\x20\x63\x6c\x65\x61\x6e\x65\x72\x2e"));(my $parameters=($session.
"\x20"));($parameters.=($node{$session}{"\x64\x69\x73\x70\x6c\x61\x79"}."\x20"))
;($parameters.=($node{$session}{"\x74\x79\x70\x65"}."\x20"));($parameters.=(
$node{$session}{"\x70\x69\x64"}."\x20"));if (($node{$session}{
"\x73\x68\x4d\x65\x6d\x49\x64"}ne (""))){($parameters.=$node{$session}{
"\x73\x68\x4d\x65\x6d\x49\x64"});}($parameters=main::urlencode ($parameters));(my $request
=(("\x63\x6c\x65\x61\x6e\x41\x66\x74\x65\x72\x44\x69\x65\x0a".$parameters).
"\x0a"));__sendRequestToNode ($session,$request);__setState ($session,
"\x77\x61\x69\x74\x69\x6e\x67\x4f\x6e\x4e\x6f\x64\x65\x45\x6e\x64");}sub 
__handleNodeEndOK{(my $session=shift (@_));(my $message=shift (@_));
Logger::debug (((
"\x48\x61\x6e\x64\x6c\x65\x20\x6e\x6f\x64\x65\x20\x65\x6e\x64\x20\x4f\x4b\x20\x66\x72\x6f\x6d\x20\x74\x68\x65\x20"
.$session)."\x20\x63\x6c\x65\x61\x6e\x65\x72\x2e"));__setState ($session,
"\x77\x61\x69\x74\x69\x6e\x67\x4f\x6e\x4e\x6f\x64\x65\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x43\x6c\x6f\x73\x65"
);}sub __sendRequestToNode{(my $session=shift (@_));(my $request=shift (@_));(my $nodeIn
=$node{$session}{"\x46\x44\x69\x6e"});Logger::debug ((((((
"\x52\x65\x71\x75\x65\x73\x74\x20\x74\x6f\x20\x74\x68\x65\x20".$session).
"\x20\x63\x6c\x65\x61\x6e\x65\x72\x20\x6f\x6e\x20\x46\x44\x23").$nodeIn).
"\x3a\x20").$request));(my $bytes=main::nxwrite ($nodeIn,$request));if (($bytes
<=(0x0c1b+ 4956-0x1f77))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x6f\x20\x74\x68\x65\x20"
.$session)."\x20\x63\x6c\x65\x61\x6e\x65\x72\x2e"));}}sub collect{Logger::debug 
(
"\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72\x3a\x20\x43\x6f\x6c\x6c\x65\x63\x74\x20\x74\x68\x65\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x63\x6c\x65\x61\x6e\x65\x72\x73\x2e"
);if ((__getCleanersCount ()>(0x1232+ 3576-0x202a))){__waitForMessages ();}
foreach my $session (keys (%node)){__checkStatus ($session);__killCleaner (
$session);}Logger::debug (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72\x3a\x20\x4e\x6f\x20\x6d\x6f\x72\x65\x20\x63\x6c\x65\x61\x6e\x65\x72\x73\x20\x74\x6f\x20\x77\x61\x69\x74\x20\x66\x6f\x72\x2e"
);}sub __checkStatus{(my $session=shift (@_));Logger::debug (((((
"\x54\x68\x65\x20".$session).
"\x20\x63\x6c\x65\x61\x6e\x65\x72\x20\x73\x74\x61\x74\x75\x73\x3a\x20").$node{
$session}{"\x73\x74\x61\x74\x65"})."\x2e"));}sub __killCleaner{(my $session=
shift (@_));(my $cleanerPid=$node{$session}{
"\x63\x6c\x65\x61\x6e\x65\x72\x50\x69\x64"});if ((defined ($cleanerPid)and (
$cleanerPid>(0x066b+ 6599-0x2032)))){if (
Common::NXCore::isProcessRunnningAndExpectedNameMatch ($cleanerPid,
"\x6e\x78\x6e\x6f\x64\x65\x7c\x6e\x78\x65\x78\x65\x63")){
Common::NXProcess::signalProcessByRestrictedScript ($cleanerPid,
Common::NXProcess::getSignalKill ());}}(my $nxexecPid=$node{$session}{
"\x6e\x78\x65\x78\x65\x63\x50\x69\x64"});if ((defined ($nxexecPid)and (
$nxexecPid>(0x1894+ 2418-0x2206)))){if (
Common::NXCore::isProcessRunnningAndExpectedNameMatch ($nxexecPid,
"\x6e\x78\x65\x78\x65\x63")){Common::NXProcess::signalProcessByRestrictedScript 
($nxexecPid,Common::NXProcess::getSignalKill ());}}(my $fd=$node{$session}{
"\x46\x44\x6f\x75\x74"});($node{$session}=undef);($nodeFD{$fd}=undef);delete (
$node{$session});delete ($nodeFD{$fd});}"\x3f\x3f\x3f";
