############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXDbusMonitor;no warnings;require Common::NXShellCommands;require NXDbus
;($monitoringMode_noDbus="\x5f\x5f\x6e\x6f\x44\x42\x75\x73\x5f\x5f");(
$monitoringMode_CK=
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x43\x6f\x6e\x73\x6f\x6c\x65\x4b\x69\x74"
);($monitoringMode_GDM=
"\x6f\x72\x67\x2e\x67\x6e\x6f\x6d\x65\x2e\x44\x69\x73\x70\x6c\x61\x79\x4d\x61\x6e\x61\x67\x65\x72"
);($monitoringMode_FDM=
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x69\x73\x70\x6c\x61\x79\x4d\x61\x6e\x61\x67\x65\x72"
);($monitoringMode_LOG=
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x6c\x6f\x67\x69\x6e\x31"
);($event_sessionAdded="\x53\x65\x73\x73\x69\x6f\x6e\x41\x64\x64\x65\x64");(
$event_sessionRemoved="\x53\x65\x73\x73\x69\x6f\x6e\x52\x65\x6d\x6f\x76\x65\x64"
);($event_activeSessionChanged=
"\x41\x63\x74\x69\x76\x65\x53\x65\x73\x73\x69\x6f\x6e\x43\x68\x61\x6e\x67\x65\x64"
);($monitoringMode=(""));($stdout=(-(0x0665+ 7774-0x24c2)));($stdin=(-
(0x19cb+ 1328-0x1efa)));($started=(0x1451+ 2106-0x1c8b));($pid=
(0x129a+ 4005-0x223f));($currentEvent=(""));sub startMonitor{if ((not (
isDbusEnabledByConfig ()))){Logger::debug (
"\x44\x42\x75\x73\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x0a7a+ 4191-0x1ad9));}if ($started){return ((0x0c4f+ 5723-0x22aa));}
if (($monitoringMode eq (""))){if ((not (selectMonitoringMode ()))){
Logger::debug (
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x3a\x20\x6e\x6f\x20\x62\x75\x73\x20\x73\x75\x69\x74\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x69\x6e\x67\x20\x66\x6f\x75\x6e\x64\x2e"
);return ((0x1ca1+ 1543-0x22a8));}}Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);my ($dbusIn);my ($dbusOut);Common::NXCore::nxPipeCreateBi ((\$stdin),(\$dbusIn
));Common::NXCore::nxPipeCreateBi ((\$stdout),(\$dbusOut));if (($monitoringMode 
eq $monitoringMode_CK)){($pid=NXDbus::dbusMonitor ($dbusIn,$dbusOut,
"\x73\x79\x73\x74\x65\x6d","\x73\x69\x67\x6e\x61\x6c",(""),
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x43\x6f\x6e\x73\x6f\x6c\x65\x4b\x69\x74\x2e\x53\x65\x61\x74"
,("")));}elsif (($monitoringMode eq $monitoringMode_GDM)){($pid=
NXDbus::dbusMonitor ($dbusIn,$dbusOut,"\x73\x79\x73\x74\x65\x6d",
"\x6d\x65\x74\x68\x6f\x64\x5f\x63\x61\x6c\x6c",(""),
"\x6f\x72\x67\x2e\x67\x6e\x6f\x6d\x65\x2e\x44\x69\x73\x70\x6c\x61\x79\x4d\x61\x6e\x61\x67\x65\x72\x2e\x4d\x61\x6e\x61\x67\x65\x72"
,"\x52\x65\x67\x69\x73\x74\x65\x72\x53\x65\x73\x73\x69\x6f\x6e"));}elsif ((
$monitoringMode eq $monitoringMode_FDM)){($pid=NXDbus::dbusMonitor ($dbusIn,
$dbusOut,"\x73\x79\x73\x74\x65\x6d","\x73\x69\x67\x6e\x61\x6c",(""),
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x44\x69\x73\x70\x6c\x61\x79\x4d\x61\x6e\x61\x67\x65\x72"
,("")));}elsif (($monitoringMode eq $monitoringMode_LOG)){($pid=
NXDbus::dbusMonitor ($dbusIn,$dbusOut,"\x73\x79\x73\x74\x65\x6d",
"\x73\x69\x67\x6e\x61\x6c",(""),
"\x6f\x72\x67\x2e\x66\x72\x65\x65\x64\x65\x73\x6b\x74\x6f\x70\x2e\x6c\x6f\x67\x69\x6e\x31\x2e\x4d\x61\x6e\x61\x67\x65\x72"
,("")));}if (($pid>(0x0c09+ 5156-0x202d))){($started=(0x0c67+ 1858-0x13a8));
Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$pid)."\x2e"));return ((0x080d+ 1146-0x0c86));}else{Logger::debug (
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);return ((0x04bd+ 7398-0x21a3));}}sub getStdout{return ($stdout);}sub isRunning
{return ($started);}sub stopMonitor{Logger::debug (
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x73\x74\x6f\x70\x4d\x6f\x6e\x69\x74\x6f\x72\x2e"
);if (isRunning ()){Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x73\x69\x67\x74\x65\x72\x6d\x20\x74\x6f\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20\x27"
.$pid)."\x27\x2e"));Common::NXProcess::signalProcessByRestrictedScript ($pid,
Common::NXProcess::getSignalTerm ());if ((Common::NXProcess::nxwaitpid ($pid,
$NXBits::WAIT_UNTRACED,(0x022c+ 6280-0x1aaf))==$pid)){($pid=(-
(0x0c79+ 1162-0x1102)));($started=(0x1dbc+ 446-0x1f7a));}else{
Common::NXProcess::signalProcessByRestrictedScript ($pid,
Common::NXProcess::getSignalKill ());if ((Common::NXProcess::nxwaitpid ($pid,
$NXBits::WAIT_UNTRACED,(0x1b36+ 2975-0x26d0))==$pid)){($pid=(-
(0x16aa+ 1085-0x1ae6)));($started=(0x1fd7+ 1500-0x25b3));}}}}sub 
parseDbusMonitorBuffer{(my $buffer=shift (@_));(my (@lines)=split ( /\n/ ,
$buffer,(0x0968+ 1426-0x0efa)));foreach my $line (@lines){parseDbusMonitorLine (
$line);}}sub parseDbusMonitorLine{(my $line=shift (@_));Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x70\x61\x72\x73\x65\x20\x6c\x69\x6e\x65\x20\x27"
.$line)."\x27\x2e"));if (($monitoringMode eq $monitoringMode_CK)){
parseDbusMonitorLine_CK ($line);}elsif (($monitoringMode eq $monitoringMode_LOG)
){parseDbusMonitorLine_LOG ($line);}else{if (($line=~ /member=SessionRemoved/ ))
{PhysicSessions::forceCheck ();}elsif (($line=~ /member=SessionAdded/ )){
PhysicSessions::forceCheck ();}elsif (($line=~ /RegisterSession/ )){
PhysicSessions::forceCheck ();}elsif (($line=~ /object path "(.*)"/ )){(my $objectPath
=$1);Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x74\x68\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20\x27"
.$objectPath)."\x27\x2e"));}}}sub parseDbusMonitorLine_CK{(my $line=shift (@_));
if (($line=~ /member=SessionAdded/ )){PhysicSessions::forceCheck ();}elsif ((
$line=~ /member=SessionRemoved/ )){PhysicSessions::forceCheck ();}elsif (($line
=~ /member=ActiveSessionChanged/ )){PhysicSessions::forceCheck ();}elsif (($line
=~ /object path "(.*)"/ )){(my $objectPath=$1);Logger::debug (((((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x74\x68\x20\x27"
.$objectPath)."\x27\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$currentEvent)
."\x2e"));if (($currentEvent eq $event_sessionAdded)){PhysicSessions::forceCheck
 ();}if (($currentEvent eq $event_sessionRemoved)){PhysicSessions::forceCheck ()
;}setEvent ((""));}elsif (($line=~ /string "(.*)"/ )){(my $objectPath=$1);
Logger::debug (((((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x74\x68\x20\x27"
.$objectPath)."\x27\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$currentEvent)
."\x2e"));if (($objectPath eq (""))){setEvent ((""));return (
(0x0a19+ 4208-0x1a89));}if (($currentEvent eq $event_activeSessionChanged)){
PhysicSessions::forceCheck ();}setEvent ((""));}}sub parseDbusMonitorLine_LOG{(my $line
=shift (@_));if (($line=~ /member=SessionNew/ )){PhysicSessions::forceCheck ();}
elsif (($line=~ /member=SessionRemoved/ )){PhysicSessions::forceCheck ();}elsif 
(($line=~ /object path "(.*)"/ )){(my $objectPath=$1);Logger::debug (((((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x62\x6a\x65\x63\x74\x20\x70\x61\x74\x68\x20\x27"
.$objectPath)."\x27\x20\x66\x6f\x72\x20\x65\x76\x65\x6e\x74\x20").$currentEvent)
."\x2e"));if (($currentEvent eq $event_sessionAdded)){PhysicSessions::forceCheck
 ();}if (($currentEvent eq $event_sessionRemoved)){PhysicSessions::forceCheck ()
;}setEvent ((""));}}sub selectMonitoringMode{if (($monitoringMode ne (""))){
Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6d\x6f\x64\x65\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$monitoringMode)."\x27\x2e"));if (($monitoringMode eq $monitoringMode_noDbus)){
return ((0x0a6b+ 288-0x0b8b));}return ((0x1096+  97-0x10f6));}(my (@busNames)=
NXDbus::getSystemBusNames ());foreach my $busName (@busNames){if (
canNameBeUsedToMonitor ($busName)){if (($busName eq $monitoringMode_GDM)){(
$monitoringMode=$busName);Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6d\x6f\x64\x65\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$monitoringMode)."\x27\x2e"));return ((0x13c1+ 2373-0x1d05));}elsif (($busName 
eq $monitoringMode_FDM)){($monitoringMode=$busName);Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6d\x6f\x64\x65\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$monitoringMode)."\x27\x2e"));return ((0x0a24+ 1391-0x0f92));}elsif (($busName 
eq $monitoringMode_CK)){($monitoringMode=$busName);}elsif ((($busName eq 
$monitoringMode_LOG)and ($monitoringMode ne $monitoringMode_CK))){(
$monitoringMode=$busName);}elsif ((($monitoringMode ne $monitoringMode_CK)and (
$monitoringMode ne $monitoringMode_LOG))){($monitoringMode=$busName);}}}if ((
$monitoringMode ne (""))){Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6d\x6f\x64\x65\x20\x73\x65\x74\x20\x74\x6f\x20\x27"
.$monitoringMode)."\x27\x2e"));return ((0x12cb+ 1232-0x179a));}($monitoringMode=
$monitoringMode_noDbus);return ((0x08b4+ 6219-0x20ff));}sub monitoringMode_byLOG
{if (($monitoringMode eq $monitoringMode_LOG)){return ((0x008c+ 3328-0x0d8b));}
return ((0x1d2d+ 1700-0x23d1));}sub monitoringMode_byCK{if (($monitoringMode eq 
$monitoringMode_CK)){return ((0x05f9+ 7355-0x22b3));}return (
(0x12d2+ 1093-0x1717));}sub monitoringMode_byGDM{if (($monitoringMode eq 
$monitoringMode_GDM)){return ((0x02d4+ 4239-0x1362));}return (
(0x0199+ 3984-0x1129));}sub monitoringMode_byFDM{if (($monitoringMode eq 
$monitoringMode_FDM)){return ((0x008b+ 4199-0x10f1));}return (
(0x11e3+ 2549-0x1bd8));}sub checkByDbusDisabled{if (($monitoringMode eq (""))){
return ((0x1219+ 556-0x1444));}if (($monitoringMode eq $monitoringMode_noDbus)){
return ((0x1928+ 3038-0x2505));}return ((0x09b7+ 6258-0x2229));}sub 
canNameBeUsedToMonitor{(my $name=shift (@_));if ((((($name eq $monitoringMode_CK
)or ($name eq $monitoringMode_FDM))or ($name eq $monitoringMode_LOG))or ($name 
eq $monitoringMode_GDM))){return ((0x1c14+ 1393-0x2184));}return (
(0x0971+ 2301-0x126e));}sub setEvent{(my $event=shift (@_));($currentEvent=
$event);}sub isDbusEnabledByConfig{return ($GLOBAL::UseDbusToHandleSystemEvents)
;}"\x3f\x3f\x3f";
