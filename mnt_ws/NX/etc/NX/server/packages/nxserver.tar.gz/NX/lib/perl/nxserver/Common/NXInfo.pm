############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXInfo;no warnings;($NXFeatures=(""));(
$checkLocalBySystemdSessions=(0x0020+ 4666-0x125a));($osPreferSsOverNetstat=
(0x0a7d+ 2008-0x1255));sub getHostInfo{__checkNxFeatures ();(my $retval=
libnxh::NXGetHostnameInfo ());Logger::debug2 (((
"\x48\x6f\x73\x74\x6e\x61\x6d\x65\x49\x6e\x66\x6f\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$retval)."\x2e"));return ($retval);}sub getHwInfo{__checkNxFeatures ();(my $retval
=libnxh::NXGetHwInfo ());Logger::debug2 (((
"\x48\x77\x49\x6e\x66\x6f\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20".$retval).
"\x2e"));return ($retval);}sub getOsInfo{__checkNxFeatures ();(my $retval=
libnxh::NXGetOsInfo ());Logger::debug2 (((
"\x4f\x73\x49\x6e\x66\x6f\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20".$retval).
"\x2e"));return ($retval);}sub getDistroInfo{__checkNxFeatures ();(my $retval=
libnxh::NXGetDistroInfo ());Logger::debug2 (((
"\x44\x69\x73\x74\x72\x6f\x49\x6e\x66\x6f\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$retval)."\x2e"));return ($retval);}sub getKernelInfo{__checkNxFeatures ();(my $retval
=libnxh::NXGetKernelInfo ());Logger::debug2 (((
"\x4b\x65\x72\x6e\x65\x6c\x49\x6e\x66\x6f\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$retval)."\x2e"));return ($retval);}sub getArchInfo{__checkNxFeatures ();(my $retval
=libnxh::NXGetArchInfo ());Logger::debug2 (((
"\x41\x72\x63\x68\x49\x6e\x66\x6f\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20".
$retval)."\x2e"));return ($retval);}sub getCpuInfo{__checkNxFeatures ();(my $retval
=libnxh::NXGetCpuInfo ());Logger::debug2 (((
"\x43\x70\x75\x49\x6e\x66\x6f\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20".$retval).
"\x2e"));return ($retval);}sub getProcessor{__checkNxFeatures ();(my $retval=
libnxh::NXGetProcessor ());($retval=~ s/^\s+// );Logger::debug2 (((
"\x50\x72\x6f\x63\x65\x73\x73\x6f\x72\x20\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$retval)."\x2e"));return ($retval);}sub getMemInfo{__checkNxFeatures ();(my $buffer
=("\x20" x (0x060c+ 544-0x080c)));(my $ret=libnxh::NXGetMemInfo ($buffer));if ((
$ret!=(-(0x0ee3+ 1315-0x1405)))){($buffer=~ s/\D//g );Logger::debug2 (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4d\x65\x6d\x49\x6e\x66\x6f\x3a\x20\x42\x75\x66\x66\x65\x72\x20\x63\x6f\x6e\x74\x61\x69\x6e\x73\x20\x5b"
.$buffer)."\x5d"));}else{(my $errNum=libnxh::NXGetError ());(my $errString=
libnxh::NXGetErrorString ());Logger::error (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4d\x65\x6d\x49\x6e\x66\x6f\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20"
.$errNum)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errString)."\x2e"));
main::nxexit ();}return ($buffer);}sub getSupportInfo{__checkNxFeatures ();(my $retval
=libnxh::NXGetSupportInfo ());Logger::debug2 (((
"\x53\x75\x70\x70\x6f\x72\x74\x49\x6e\x66\x6f\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$retval)."\x2e"));return ($retval);}sub __checkNxFeatures{if (($NXFeatures eq 
(""))){($NXFeatures=(0x17bf+ 229-0x18a3));if (((libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53")eq (""))or (
libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e")eq 
("")))){Logger::debug (
"\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x20\x61\x6e\x64\x20\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e\x20\x62\x65\x63\x61\x75\x73\x65\x20\x69\x74\x20\x77\x61\x73\x6e\x27\x74\x20\x67\x69\x76\x65\x6e\x20\x62\x79\x20\x70\x61\x72\x65\x6e\x74\x2e"
);setNxFeatures ();setNxVersion ();}}return ((0x0b24+ 1475-0x10e6));}sub 
getNxFeatures{(my $feat=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53"));Logger::debug (((
"\x46\x65\x61\x74\x75\x72\x65\x73\x20\x6f\x66\x20\x4e\x58\x20".$feat)."\x2e"));
return ($feat);}sub setNxFeatures{libnxh::NXTransSetEnvironment (
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53",(""));(my $hostname=getHostInfo 
());(my $model=Common::NXCore::processPurgeArg (getHwInfo ()));(my $platform=
getOsInfo ());(my $flavor=getDistroInfo ());(my $kernel=getKernelInfo ());(my $architecture
=getArchInfo ());(my $processor=getProcessor ());(my $processors=getCpuInfo ());
(my $memory=getMemInfo ());(my $support=getSupportInfo ());(my $feat=(((((((((((
((((((($hostname."\x2c").$model)."\x2c").$platform)."\x2c").$flavor)."\x2c").
$kernel)."\x2c").$architecture)."\x2c").$processor)."\x2c").$processors)."\x2c")
.$memory)."\x2c").$support));Logger::debug (
"\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x75\x70\x20\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x2e"
);Logger::debug (("\x4e\x65\x77\x20\x76\x61\x6c\x75\x65\x3a\x20".$feat));
libnxh::NXTransSetEnvironment ("\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53",
$feat);($NXFeatures=(0x0f81+ 5445-0x24c5));return ($feat);}sub getNxVersion{(my $version
=libnxh::NXGetVersionInfo ());Logger::debug2 (((
"\x56\x65\x72\x73\x69\x6f\x6e\x20\x6f\x66\x20\x4e\x58\x20".$version)."\x2e"));
return ($version);}sub setNxVersion{libnxh::NXTransSetEnvironment (
"\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e",(""));(my $version=
libnxh::NXGetVersionInfo ());Logger::debug (
"\x55\x70\x64\x61\x74\x69\x6e\x67\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x75\x70\x20\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e"
);Logger::debug (("\x4e\x65\x77\x20\x76\x61\x6c\x75\x65\x3a\x20".$version));
libnxh::NXTransSetEnvironment ("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e",
$version);}sub isArchitecture64Bit{if (defined ($architectureIs64Bit)){return (
$architectureIs64Bit);}(my $architecture=getArchInfo ());if (($architecture=~ /x86_64/ )
){($architectureIs64Bit=(0x1243+ 1390-0x17b0));return ((0x0e56+ 1627-0x14b0));}
else{($architectureIs64Bit=(0x186b+ 1933-0x1ff8));return ((0x14a6+ 685-0x1753));
}}sub setVariablesBasedOnDistributionAndKernel{(my $distro=lc (getDistroInfo ())
);(my $kernel=getKernelInfo ());if (($distro=~ /fedora/ )){if (($kernel=~ /^4/ )
){setVariablesForFedora22 ();}}if (($distro=~ /opensuse/ )){
setVariablesForOpenSUSE ();}}sub setVariablesForFedora22{Logger::debug (
"\x46\x65\x64\x6f\x72\x61\x20\x32\x32\x20\x64\x65\x74\x65\x63\x74\x65\x64\x2e");
($checkLocalBySystemdSessions=(0x2605+ 106-0x266e));}sub setVariablesForOpenSUSE
{Logger::debug (
"\x4f\x70\x65\x6e\x53\x55\x53\x45\x20\x64\x65\x74\x65\x63\x74\x65\x64\x2e");
setOsPreferSsOverNetstat ();}sub shouldCheckLocalBySystemdSessions{if ((
$checkLocalBySystemdSessions==(0x0805+ 483-0x09e7))){return (
(0x0a90+ 1010-0x0e81));}return ((0x16cf+ 3747-0x2572));}sub 
setOsPreferSsOverNetstat{($osPreferSsOverNetstat=(0x0472+ 2919-0x0fd8));}sub 
doesOsPreferSsOverNetstat{if (($osPreferSsOverNetstat==(0x0f38+ 465-0x1108))){
return ((0x1a03+ 1972-0x21b6));}return ((0x03a8+ 6407-0x1caf));}return (
(0x0a77+ 2434-0x13f8));
