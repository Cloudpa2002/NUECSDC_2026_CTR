############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXRemoteMachinesGroups::BEGIN{package NXRemoteMachinesGroups;no warnings;
require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub 
NXRemoteMachinesGroups::BEGIN{package NXRemoteMachinesGroups;no warnings;require
 Exception::Log;do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->
import};}sub NXRemoteMachinesGroups::BEGIN{package NXRemoteMachinesGroups;no 
warnings;require NXMsg;do{"\x4e\x58\x4d\x73\x67"->import};}package 
NXRemoteMachinesGroups;no warnings;((%__loadedGroups)=());sub addGroupToDBHash{(my $ref_hash
=shift (@_));(my $groupname=shift (@_));(my $priority=shift (@_));(my (%group)=
());($group{"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}=$groupname);($group{
"\x70\x72\x69\x6f\x72\x69\x74\x79"}=$priority);($group{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=(""));($$ref_hash{$groupname}=(\%group));}
sub editGroupPriorityInDBHash{(my $ref_hash=shift (@_));(my $groupname=shift (@_
));(my $priority=shift (@_));($$ref_hash{$groupname}{
"\x70\x72\x69\x6f\x72\x69\x74\x79"}=$priority);}sub addMachineToGroupInDBHash{(my $ref_hash
=shift (@_));(my $groupname=shift (@_));(my $machine=shift (@_));if ($$ref_hash{
$groupname}{"\x6d\x61\x63\x68\x69\x6e\x65\x73"}){($$ref_hash{$groupname}{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"}.=("\x2c".$machine));}else{($$ref_hash{
$groupname}{"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=$machine);}}sub 
delMachineFromGroupInDBHash{(my $ref_hash=shift (@_));(my $groupname=shift (@_))
;(my $machine=shift (@_));($$ref_hash{$groupname}{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=~ s/^$machine,// );($$ref_hash{$groupname}{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=~ s/,*$machine// );}sub save{(my $name=shift
 (@_));(my $ref_hash=shift (@_));if ((not (%$ref_hash))){
NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d"
.$name)."\x0a"));}else{my ($command);foreach my $group (values (%$ref_hash)){(my $groupname
=main::urlencode ($$group{"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}));(my $record=
main::urlencode (__createRecord ($group)));if (($record ne $__loadedGroups{
$groupname})){($command.=((("\x2c\x66\x69\x65\x6c\x64\x3d".$groupname).
"\x2c\x76\x61\x6c\x75\x65\x3d").$record));}delete ($__loadedGroups{$groupname});
}if (($command ne (""))){NXRedis::sendToDbAndSave ((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d"
.$name).$command)."\x0a"));}if (%__loadedGroups){my ($commandDel);foreach my $key
 (keys (%__loadedGroups)){($commandDel.=("\x2c\x66\x69\x65\x6c\x64\x3d".$key));}
if (($commandDel ne (""))){NXRedis::sendToDbAndSave ((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d"
.$name).$commandDel)."\x0a"));}}}return ((0x0254+ 7056-0x1de3));}sub getGroupsDB
{(my $name=shift (@_));(my (%groupsDB)=());if (($ENV{
"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31")){return (%groupsDB);}
NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x61\x6c\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d"
.$name)."\x0a"));((%__loadedGroups)=split ( / / ,NXRedis::get (),
(0x11b5+ 2391-0x1b0c)));foreach my $key (keys (%__loadedGroups)){(my $ref_group=
__parseDBLine (main::urldecode ($__loadedGroups{$key})));($groupsDB{$$ref_group{
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}}=$ref_group);}return (%groupsDB);}sub 
cleanLoadedGroups{((%__loadedGroups)=());}sub printOneMachineGroupList{(my $ref_group
=shift (@_));(my $ref_parameters=shift (@_));if ((main::nxwrite (
main::nxgetSTDOUT (),(("\x4e\x6f\x64\x65\x20\x6e\x61\x6d\x65\x3a\x20".
$$ref_group{"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"})."\x0a"))==(-
(0x048d+ 5783-0x1b23)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT);
return ((0x0b3d+ 7043-0x26c0));}if ((main::nxwrite (main::nxgetSTDOUT (),((
"\x50\x72\x69\x6f\x72\x69\x74\x79\x3a\x20".$$ref_group{
"\x70\x72\x69\x6f\x72\x69\x74\x79"})."\x0a"))==(-(0x1e73+ 178-0x1f24)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x184a+ 551-0x1a71));}if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){if ((main::nxwrite (main::nxgetSTDOUT (),(
("\x4e\x6f\x64\x65\x20\x55\x55\x49\x44\x3a\x20".$$ref_group{
"\x6d\x61\x63\x68\x69\x6e\x65\x73"})."\x0a"))==(-(0x06a4+ 1619-0x0cf6)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x0380+ 1676-0x0a0c));}if ((main::nxwrite (main::nxgetSTDOUT (),((
"\x4e\x6f\x64\x65\x3a\x20".$$ref_group{"\x68\x6f\x73\x74\x70\x6f\x72\x74"}).
"\x0a"))==(-(0x0468+ 5887-0x1b66)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((0x0b99+ 2216-0x1441));}}if ((main::nxwrite
 (main::nxgetSTDOUT (),"\x0a")==(-(0x00c1+ 3485-0x0e5d)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x11e4+ 3179-0x1e4f));}return ((0x1d13+  45-0x1d3f));}sub printMachinesGroups{(my $ref_hash
=shift (@_));(my $ref_parameters=shift (@_));(my (%table)=());__setMaxWidths ((
\%table),$ref_hash,$ref_parameters);if ((__printHeader ((\%table),
$ref_parameters)==(0x0841+ 2900-0x1395))){return ((0x1c0f+ 1370-0x2169));}if ((
__printBody ((\%table),$ref_hash,$ref_parameters)==(0x0e36+ 3542-0x1c0c))){
return ((0x024b+ 1961-0x09f4));}return ((0x0287+ 3165-0x0ee3));}sub 
__setMaxWidths{(my $ref_table=shift (@_));(my $ref_hash=shift (@_));(my $ref_parameters
=shift (@_));NXTools::setWidth ($ref_table,
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65",
"\x47\x72\x6f\x75\x70\x20\x6e\x61\x6d\x65");NXTools::setWidth ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73","\x4e\x6f\x64\x65\x20\x6e\x61\x6d\x65");
NXTools::setWidth ($ref_table,"\x70\x72\x69\x6f\x72\x69\x74\x79",
"\x50\x72\x69\x6f\x72\x69\x74\x79");if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){NXTools::setWidth ($ref_table,
"\x6d\x61\x63\x68\x69\x6e\x65\x73","\x4e\x6f\x64\x65\x20\x55\x55\x49\x44");
NXTools::setWidth ($ref_table,"\x68\x6f\x73\x74\x70\x6f\x72\x74",
"\x4e\x6f\x64\x65");}foreach my $group (values (%$ref_hash)){NXTools::setWidth (
$ref_table,"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65",$$group{
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"});(my (@nodenameLines)=split ( /,/ ,
$$group{"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"},(0x13af+ 4455-0x2516)));foreach my $line
 (@nodenameLines){NXTools::setWidth ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73",$line);}NXTools::setWidth ($ref_table,
"\x70\x72\x69\x6f\x72\x69\x74\x79",$$group{"\x70\x72\x69\x6f\x72\x69\x74\x79"});
if (defined ($$ref_parameters{"\x65\x78\x74\x65\x6e\x64\x65\x64"})){(my (
@nodeLines)=split ( /,/ ,$$group{"\x6d\x61\x63\x68\x69\x6e\x65\x73"},
(0x0425+ 3303-0x110c)));foreach my $line (@nodeLines){NXTools::setWidth (
$ref_table,"\x6d\x61\x63\x68\x69\x6e\x65\x73",$line);}(my (@hostportLines)=split
 ( /,/ ,$$group{"\x68\x6f\x73\x74\x70\x6f\x72\x74"},(0x0389+ 1856-0x0ac9)));
foreach my $line (@hostportLines){NXTools::setWidth ($ref_table,
"\x68\x6f\x73\x74\x70\x6f\x72\x74",$line);}}}}sub __printHeader{(my $ref_table=
shift (@_));(my $ref_parameters=shift (@_));if ((NXTools::printWidth ($ref_table
,"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65",
"\x47\x72\x6f\x75\x70\x20\x6e\x61\x6d\x65")==(-(0x0b33+ 4720-0x1da2)))){return (
(0x0521+ 3306-0x120b));}if ((NXTools::printWidth ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73","\x4e\x6f\x64\x65\x20\x6e\x61\x6d\x65")==
(-(0x0401+ 1439-0x099f)))){return ((0x1e02+ 1332-0x2336));}if ((
NXTools::printWidth ($ref_table,"\x70\x72\x69\x6f\x72\x69\x74\x79",
"\x50\x72\x69\x6f\x72\x69\x74\x79")==(-(0x044f+ 5350-0x1934)))){return (
(0x005c+ 1539-0x065f));}if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){if ((NXTools::printWidth ($ref_table,
"\x6d\x61\x63\x68\x69\x6e\x65\x73","\x4e\x6f\x64\x65\x20\x55\x55\x49\x44")==(-
(0x21b5+ 1213-0x2671)))){return ((0x02f0+ 4301-0x13bd));}if ((
NXTools::printWidth ($ref_table,"\x68\x6f\x73\x74\x70\x6f\x72\x74",
"\x4e\x6f\x64\x65")==(-(0x16af+ 2275-0x1f91)))){return ((0x14d4+ 3449-0x224d));}
}if ((main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x006a+ 5811-0x171c)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x087f+ 4667-0x1aba));}if ((NXTools::printMark ($ref_table,
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65")==(-(0x05b2+ 6264-0x1e29)))){return (
(0x1aa2+ 2087-0x22c9));}if ((NXTools::printMark ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73")==(-(0x0484+ 895-0x0802)))){return (
(0x05b9+ 246-0x06af));}if ((NXTools::printMark ($ref_table,
"\x70\x72\x69\x6f\x72\x69\x74\x79")==(-(0x002a+ 6532-0x19ad)))){return (
(0x072d+ 1768-0x0e15));}if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){if ((NXTools::printMark ($ref_table,
"\x6d\x61\x63\x68\x69\x6e\x65\x73")==(-(0x135b+ 1543-0x1961)))){return (
(0x003b+ 8497-0x216c));}if ((NXTools::printMark ($ref_table,
"\x68\x6f\x73\x74\x70\x6f\x72\x74")==(-(0x1720+ 3195-0x239a)))){return (
(0x06fa+ 7720-0x2522));}}if ((main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-
(0x22a1+ 610-0x2502)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT);
return ((0x0803+ 2858-0x132d));}return ((0x078d+ 5593-0x1d65));}sub __printBody{
(my $ref_table=shift (@_));(my $ref_hash=shift (@_));(my $ref_parameters=shift (
@_));foreach my $group (values (%$ref_hash)){(my (@nodenameLines)=split ( /,/ ,
$$group{"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"},(0x1641+ 2574-0x204f)));(my (
@nodesLines)=split ( /,/ ,$$group{"\x6d\x61\x63\x68\x69\x6e\x65\x73"},
(0x1302+ 3595-0x210d)));(my (@hostportLines)=split ( /,/ ,$$group{
"\x68\x6f\x73\x74\x70\x6f\x72\x74"},(0x1412+ 2908-0x1f6e)));(my $maxLines=scalar
 (@nodesLines));if (($maxLines==(0x1794+ 423-0x193b))){($maxLines=
(0x05e8+ 3793-0x14b8));}for ((my $i=(0x09c0+ 2402-0x1322));($i<$maxLines);(++$i)
){(my $groupname=(""));(my $nodename=(""));(my $priority=(""));(my $nodesLine=
(""));(my $hostportLine=(""));if (($i==(0x10a9+ 2645-0x1afe))){($groupname=
$$group{"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"});($priority=$$group{
"\x70\x72\x69\x6f\x72\x69\x74\x79"});}if (defined ($nodenameLines[$i])){(
$nodename=$nodenameLines[$i]);}if (defined ($nodesLines[$i])){($nodesLine=
$nodesLines[$i]);}if (defined ($hostportLines[$i])){($hostportLine=
$hostportLines[$i]);}if ((NXTools::printWidth ($ref_table,
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65",$groupname)==(-(0x068a+ 2801-0x117a)))){
return ((0x1c99+ 1241-0x2172));}if ((NXTools::printWidth ($ref_table,
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73",$nodename)==(-(0x02e6+  99-0x0348)))){
return ((0x0608+ 8169-0x25f1));}if ((NXTools::printWidth ($ref_table,
"\x70\x72\x69\x6f\x72\x69\x74\x79",$priority)==(-(0x1aea+ 1678-0x2177)))){return
 ((0x071f+ 906-0x0aa9));}if (defined ($$ref_parameters{
"\x65\x78\x74\x65\x6e\x64\x65\x64"})){if ((NXTools::printWidth ($ref_table,
"\x6d\x61\x63\x68\x69\x6e\x65\x73",$nodesLine)==(-(0x001a+ 8516-0x215d)))){
return ((0x1588+ 2844-0x20a4));}if ((NXTools::printWidth ($ref_table,
"\x68\x6f\x73\x74\x70\x6f\x72\x74",$hostportLine)==(-(0x0256+ 3914-0x119f)))){
return ((0x00ad+ 5564-0x1669));}}if ((main::nxwrite (main::nxgetSTDOUT (),"\x0a"
)==(-(0x2521+ 369-0x2691)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((0x1ecc+ 1444-0x2470));}}}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x04f1+  64-0x0530)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return (
(0x122b+ 3860-0x213f));}}sub __createRecord{(my $ref_group=shift (@_));(my $record
=(""));($record.=($$ref_group{"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}."\x3a"));(
$record.=(main::urlencode ($$ref_group{"\x6d\x61\x63\x68\x69\x6e\x65\x73"}).
"\x3a"));($record.=$$ref_group{"\x70\x72\x69\x6f\x72\x69\x74\x79"});
Logger::debug3 (((
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x4d\x61\x63\x68\x69\x6e\x65\x73\x47\x72\x6f\x75\x70\x73\x3a\x20\x43\x72\x65\x61\x74\x65\x64\x20\x72\x65\x63\x6f\x72\x64\x20\x27"
.$record)."\x27\x2e"));return ($record);}sub __parseDBLine{(my $lineToParse=
shift (@_));chomp ($lineToParse);(my (@segments)=split ( /:/ ,$lineToParse,
(0x02a8+ 5825-0x1969)));(my (%remoteGroup)=());($remoteGroup{
"\x67\x72\x6f\x75\x70\x6e\x61\x6d\x65"}=$segments[(0x090d+ 2250-0x11d7)]);(
$remoteGroup{"\x6d\x61\x63\x68\x69\x6e\x65\x73"}=main::urldecode ($segments[
(0x094f+ 6973-0x248b)]));($remoteGroup{"\x70\x72\x69\x6f\x72\x69\x74\x79"}=
$segments[(0x0d45+ 1745-0x1414)]);($remoteGroup{
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"}=(""));($remoteGroup{
"\x68\x6f\x73\x74\x70\x6f\x72\x74"}=(""));(my (@machines)=split ( /,/ ,
$remoteGroup{"\x6d\x61\x63\x68\x69\x6e\x65\x73"},(0x0038+ 3381-0x0d6d)));(my $nodeParams
=(""));foreach my $machine (@machines){($nodeParams=NXNodes::get ($machine));(
$remoteGroup{"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"}.=(main::urldecode (
$$nodeParams{"\x6e\x6f\x64\x65\x2d\x6e\x61\x6d\x65"})."\x2c"));($remoteGroup{
"\x68\x6f\x73\x74\x70\x6f\x72\x74"}.=((($$nodeParams{"\x68\x6f\x73\x74"}."\x3a")
.$$nodeParams{"\x70\x6f\x72\x74"})."\x2c"));}($remoteGroup{
"\x6e\x6f\x64\x65\x6e\x61\x6d\x65\x73"}=~ s/,$// );($remoteGroup{
"\x68\x6f\x73\x74\x70\x6f\x72\x74"}=~ s/,$// );return ((\%remoteGroup));}
"\x3f\x3f\x3f";
