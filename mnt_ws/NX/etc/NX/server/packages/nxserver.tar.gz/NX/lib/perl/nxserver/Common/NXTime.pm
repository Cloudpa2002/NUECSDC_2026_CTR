############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXTime::getSecondsSinceEpoch{package Common::NXTime;no warnings;(my $seconds
=libnxh::NXGetTime ());return ($seconds);}sub 
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch{package Common::NXTime;no 
warnings;(my $buffer=("\x3a" x (0x09d2+ 2362-0x12e4)));my (@arr);my (@result);(my $retval
=libnxh::NXSecondsAndMicrosecondsSinceEpoch ($buffer));if (($retval!=(-
(0x08c7+ 6609-0x2297)))){(@arr=split ( /:/ ,$buffer,(0x19f0+ 1386-0x1f5a)));(
@result=splice (@arr,(0x11cd+ 981-0x15a2),(0x07cb+ 1771-0x0eb4)));return (
@result);}else{(my $errorNumber=libnxh::NXGetError ());(my $errorString=
libnxh::NXGetErrorString ());syswrite (STDERR,
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x74\x69\x6d\x65\x20\x77\x69\x74\x68\x20\x6d\x69\x63\x72\x6f\x73\x65\x63\x6f\x6e\x64\x20\x70\x72\x65\x63\x69\x73\x69\x6f\x6e\x2e\x0a"
);syswrite (STDERR,((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20\x27").$errorString)."\x27\x2e\x0a"));main::nxexit ();}}
sub Common::NXTime::getMillisecondsSinceEpoch{package Common::NXTime;no warnings
;(my ($seconds,$microseconds)=getSecondsAndMicrosecondsSinceEpoch ());(my $milliseconds
=int ((($seconds *(0x0819+ 6124-0x1c1d))+($microseconds/(0x0d9b+ 1180-0x0e4f))))
);return ($milliseconds);}sub Common::NXTime::getLocalTime{package 
Common::NXTime;no warnings;my (@arr);my (@result);(my $buffer=("\x3a" x 
(0x0657+ 294-0x0755)));(my $retval=libnxh::NXLocalTime ($buffer));if (($retval!=
(-(0x07a9+ 5210-0x1c02)))){(@arr=split ( /:/ ,$buffer,(0x1068+ 4567-0x223f)));(
@result=splice (@arr,(0x0853+ 6026-0x1fdd),(0x0f51+ 2061-0x1755)));return (
@result);}else{(my $errorNumber=libnxh::NXGetError ());(my $errorString=
libnxh::NXGetErrorString ());syswrite (STDERR,
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x74\x69\x6d\x65\x2e\x0a"
);syswrite (STDERR,((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20\x27").$errorString)."\x27\x2e\x0a"));main::nxexit ();}}
sub Common::NXTime::getLocalTimeFromTimestamp{package Common::NXTime;no warnings
;(my $stamp=shift (@_));my (@arr);my (@result);(my $buffer=("\x3a" x 
(0x0188+ 1485-0x072d)));(my $retval=libnxh::NXLocalTimeFromTimestamp ($stamp,
$buffer));if (($retval!=(-(0x1742+ 1571-0x1d64)))){(@arr=split ( /:/ ,$buffer,
(0x1acb+ 2912-0x262b)));(@result=splice (@arr,(0x0336+ 738-0x0618),
(0x13d1+ 1012-0x17bc)));return (@result);}else{(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());syswrite (
STDERR,((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x74\x69\x6d\x65\x2e\x20\x41\x72\x67\x75\x6d\x65\x6e\x74\x20\x69\x73\x20"
.$stamp)."\x2e\x0a"));syswrite (STDERR,((((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20\x27").$errorString)."\x27\x2e\x0a"));main::nxexit ();}}
sub Common::NXTime::getDateString{package Common::NXTime;no warnings;(my $string
=libnxh::NXLocalTimeAsString ());return ($string);}sub 
Common::NXTime::getTimestamp{package Common::NXTime;no warnings;(my ($sec,
$microsec)=getSecondsAndMicrosecondsSinceEpoch ());(my (@time)=
getLocalTimeFromTimestamp ($sec));(my $milisec=sprintf ("\x25\x30\x36\x64",
$microsec));($milisec=((substr ($milisec,(0x0ce8+ 647-0x0f6f),
(0x0ada+ 6309-0x237c))."\x2e").substr ($milisec,(0x0109+ 8524-0x2252))));(my $Timestamp
=((((((sprintf ("\x25\x30\x32\x64",$time[(0x047f+ 6196-0x1cb1)])."\x3a").sprintf
 ("\x25\x30\x32\x64",$time[(0x1781+ 1214-0x1c3e)]))."\x3a").sprintf (
"\x25\x30\x32\x64",$time[(0x1da0+ 1227-0x226b)]))."\x3a").sprintf ($milisec)));
return ($Timestamp);}sub Common::NXTime::getTimestampOnlyMicroseconds{package 
Common::NXTime;no warnings;(my ($sec,$microsec)=
getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf ("\x25\x30\x36\x64"
,$microsec));($milisec=((substr ($milisec,(0x16e0+ 4111-0x26ef),
(0x07e4+ 966-0x0ba7))."\x2e").substr ($milisec,(0x22b2+ 239-0x239e))));(my $Timestamp
=sprintf ($milisec));return ($Timestamp);}sub Common::NXTime::__getTimeMs{
package Common::NXTime;no warnings;(my ($sec,$microsec)=
getSecondsAndMicrosecondsSinceEpoch ());(my (@time)=getLocalTimeFromTimestamp (
$sec));(my $milisec=sprintf ("\x25\x30\x36\x64",$microsec));($milisec=(substr (
$milisec,(0x03e2+ 3484-0x117e),(0x01f9+ 1717-0x08ab)).substr ($milisec,
(0x0f3b+ 1415-0x14bf))));return ($milisec,@time);}sub Common::NXTime::getTimeMs{
package Common::NXTime;no warnings;(my ($milisec,@time)=__getTimeMs ());(my $TimeMs
=((((sprintf ("\x25\x30\x32\x64",$time[(0x18e1+  27-0x18fa)]).sprintf (
"\x25\x30\x32\x64",$time[(0x00d1+ 3973-0x1055)])).sprintf ("\x25\x30\x32\x64",
$time[(0x0e29+ 1323-0x1354)]))."\x2e").sprintf ($milisec)));return ($TimeMs);}
sub Common::NXTime::getLoggerTimeline{package Common::NXTime;no warnings;(my (
$milisec,@time)=__getTimeMs ());($milisec=((substr ($milisec,
(0x0c48+ 6425-0x2561),(0x139b+ 2483-0x1d4b))."\x2e").substr ($milisec,
(0x06f9+ 7592-0x249e))));(my $Timeline=(sprintf (
"\x25\x30\x34\x64\x2d\x25\x30\x32\x64\x2d\x25\x30\x32\x64\x20\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x20"
,((0x09fb+ 5200-0x16df)+$time[(0x1438+ 3288-0x210b)]),((0x02d8+ 8622-0x2485)+
$time[(0x1297+ 1755-0x196e)]),$time[(0x0ee5+ 4474-0x205c)],$time[
(0x0cd9+ 5074-0x20a9)],$time[(0x1f9a+ 884-0x230d)],$time[(0x0fff+ 2118-0x1845)])
.$milisec));return ($Timeline);}sub 
Common::NXTime::getLoggerTimelineOnlyMicroseconds{package Common::NXTime;no 
warnings;(my ($milisec,@time)=__getTimeMs ());($milisec=((substr ($milisec,
(0x107b+ 1370-0x15d5),(0x0422+ 7276-0x208b))."\x2e").substr ($milisec,
(0x1296+ 2130-0x1ae5))));(my $Timeline=sprintf ($milisec));return ($Timeline);}
sub Common::NXTime::convertLocalTimeFromTimestampToHumanReadableString{package 
Common::NXTime;no warnings;(my $timestamp=shift (@_));(my (@time)=
getLocalTimeFromTimestamp ($timestamp));(my $timeString=sprintf (
"\x25\x30\x34\x64\x2d\x25\x30\x32\x64\x2d\x25\x30\x32\x64\x20\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x3a\x25\x30\x32\x64"
,((0x1a29+ 3885-0x21ea)+$time[(0x0d45+ 3928-0x1c98)]),($time[
(0x0cd4+ 1174-0x1166)]+(0x0f55+ 3699-0x1dc7)),$time[(0x0de5+ 3300-0x1ac6)],$time
[(0x09fb+ 6657-0x23fa)],$time[(0x0d3d+ 1544-0x1344)],$time[(0x1a6b+ 201-0x1b34)]
));return ($timeString);}sub Common::NXTime::getDateTimeForFileName{package 
Common::NXTime;no warnings;(my $dateTime=getLoggerTimeline ());($dateTime=~ s/ [^ ]*$// )
;($dateTime=~ s/-/./gm );($dateTime=~ s/:/./gm );($dateTime=~ s/ /-/gm );return 
($dateTime);}sub Common::NXTime::getSecondsInWeek{package Common::NXTime;no 
warnings;return (604800);}sub Common::NXTime::convertSecondsToDaysRounded{
package Common::NXTime;no warnings;(my $seconds=shift (@_));(my $days=($seconds/
86400));($days=(int ($days)+(0x0321+ 1466-0x08da)));return ($days);}package 
Common::NXTime;no warnings;"\x3f\x3f\x3f";
