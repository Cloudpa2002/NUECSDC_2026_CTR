############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXFile::BEGIN{package Common::NXFile;no warnings;require 
Common::Logger;do{"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4c\x6f\x67\x67\x65\x72"->
import};}sub Common::NXFile::dirname{package Common::NXFile;no warnings;(my (
$path)=@_);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x44\x69\x72\x6e\x61\x6d\x65\x20"
.$path)."\x20\x73\x74\x61\x72\x74\x2e"));(my $ret=libnxh::NXGetDirname ($path));
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x44\x69\x72\x6e\x61\x6d\x65\x20\x73\x74\x6f\x70\x2e"
);($ret=~ s/\\$// );return ($ret);}sub Common::NXFile::basename{package 
Common::NXFile;no warnings;(my ($path)=@_);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x42\x61\x73\x65\x6e\x61\x6d\x65\x20"
.$path)."\x20\x73\x74\x61\x72\x74\x2e"));(my $ret=libnxh::NXGetBasename ($path))
;Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x42\x61\x73\x65\x6e\x61\x6d\x65\x20\x73\x74\x6f\x70\x2e"
);return ($ret);}sub Common::NXFile::setPermissions_windows{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $sid=shift (@_));(my $mode=
shift (@_));(my $inherit=(shift (@_)||(0x0990+ 695-0x0c47)));(my $ref_errorName=
shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x0d11+ 886-0x1087)));(my $returnVal=(-(0x0f09+ 1798-0x160e)));if ((not (
defined ($path)))){if (($silent==(0x1490+ 2613-0x1ec5))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x2e"
);}return ($returnVal);}if ((($mode=~ /^$GLOBAL::InheritPermission/ )or (($sid 
ne (""))and ($sid!=(-(0x07e0+ 3525-0x15a4)))))){Logger::debug (((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x74\x53\x65\x63\x75\x72\x69\x74\x79\x49\x6e\x66\x6f\x28"
.$path)."\x2c\x20").$sid)."\x2c\x20").$mode)."\x2c\x20").$inherit).
"\x29\x20\x73\x74\x61\x72\x74\x2e"));(my $result=libnxh::NXSetSecurityInfo (
$path,$sid,$mode,$inherit));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x74\x53\x65\x63\x75\x72\x69\x74\x79\x49\x6e\x66\x6f\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$result)."\x27\x2e"));if ((($result==(0x10e2+   9-0x10eb))or ($result==
(0x0aca+ 6849-0x258a)))){($returnVal=(0x074f+ 7409-0x2440));}else{(
$$ref_errorName=libnxh::NXGetErrorString ());($$ref_errorCode=libnxh::NXGetError
 ());if (($silent==(0x0b16+ 5898-0x2220))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20"
.$path)."\x2e\x20").$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e"));}}}
else{if (($silent==(0x13e4+ 3627-0x220f))){Logger::error (((
"\x53\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20"
.$path)."\x2e"));}}return ($returnVal);}sub Common::NXFile::setPermissions_unix{
package Common::NXFile;no warnings;(my $path=shift (@_));(my $mode=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x1481+ 3081-0x208a)));(my $returnVal=(-(0x19c5+ 3198-0x2642)));if ((not (
defined ($path)))){if (($silent==(0x134f+ 4157-0x238c))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x2e"
);}return ($returnVal);}Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x4d\x6f\x64\x65\x28".
$path)."\x2c\x20").$mode)."\x29"));($returnVal=libnxh::NXFileMode ($path,$mode))
;if (($returnVal==(-(0x0328+ 7551-0x20a6)))){($$ref_errorName=
libnxh::NXGetErrorString ());($$ref_errorCode=libnxh::NXGetError ());if ((
$silent==(0x028a+ 2592-0x0caa))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20"
.$path)."\x2e\x20").$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e"));}}
Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x4d\x6f\x64\x65\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnVal)."\x27\x2e"));return ($returnVal);}sub 
Common::NXFile::setOwnershipForUser_windows{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $sid=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0855+ 7004-0x23b1)));(my $returnVal=
setPermissions_windows ($path,$sid,$GLOBAL::OwnerPermission,
(0x0386+ 7241-0x1fcf),$ref_errorName,$ref_errorCode,(0x0b3b+ 1848-0x1272)));if (
($returnVal==(-(0x1680+ 2955-0x220a)))){if (($silent==(0x0600+ 3611-0x141b))){
Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x6f\x72\x20"
.$path)."\x2e\x20").$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e"));}}
return ($returnVal);}sub Common::NXFile::setOwnershipForUser_unix{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $uid=shift (@_));(my $gid=
shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x19ac+ 1215-0x1e6b)));(my $returnVal=(-(0x1987+ 3119-0x25b5)));
Logger::debug (((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x74\x46\x69\x6c\x65\x4f\x77\x6e\x65\x72\x28"
.$path)."\x2c\x20").$uid)."\x2c\x20").$gid)."\x29"));(my $return=
libnxh::NXSetFileOwner ($path,$uid,$gid));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x74\x46\x69\x6c\x65\x4f\x77\x6e\x65\x72\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));if (($return==(-(0x14a7+ 518-0x16ac)))){($$ref_errorName=
libnxh::NXGetErrorString ());($$ref_errorCode=libnxh::NXGetError ());if ((
$silent==(0x02fc+ 8579-0x247f))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x74\x6f\x20\x27"
.$path)."\x27\x3a\x20").$$ref_errorCode)."\x2c\x20").$$ref_errorName)."\x2e"));}
}else{($returnVal=(0x00a1+ 9534-0x25df));}return ($returnVal);}sub 
Common::NXFile::__setOwnershipForUserNX{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $setNXGroup=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x1bc6+ 2793-0x26af)));(my $returnVal=(-
(0x1497+ 3110-0x20bc)));(my $uid=Common::NXCore::userInfoGetUidByUsername (
"\x6e\x78"));(my $gid=(-(0x0b49+ 3897-0x1a81)));if ($setNXGroup){($gid=
Common::NXCore::userInfoGetGidByUsername ("\x6e\x78"));}($returnVal=
setOwnershipForUser_unix ($path,$uid,$gid,$ref_errorName,$ref_errorCode,$silent)
);return ($returnVal);}sub Common::NXFile::__setOwnershipForUserNXGroupRoot{
package Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=
shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x0138+ 6664-0x1b40)));(my $returnVal=(-(0x16dd+ 323-0x181f)));(my $uid=
Common::NXCore::userInfoGetUidByUsername ("\x6e\x78"));(my $gid=
Common::NXCore::userInfoGetGidByUsername ("\x72\x6f\x6f\x74"));($returnVal=
setOwnershipForUser_unix ($path,$uid,$gid,$ref_errorName,$ref_errorCode,$silent)
);return ($returnVal);}sub Common::NXFile::setOwnershipForUserNX{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x09f7+ 2266-0x12d1)));
(my $setNXGroup=(0x05e0+ 1395-0x0b53));return (__setOwnershipForUserNX ($path,
$setNXGroup,$ref_errorName,$ref_errorCode,$silent));}sub 
Common::NXFile::setOwnershipForUserAndGroupNX{package Common::NXFile;no warnings
;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (
@_));(my $silent=(shift (@_)||(0x16bb+ 1898-0x1e25)));(my $setNXGroup=
(0x0b2a+ 4815-0x1df8));return (__setOwnershipForUserNX ($path,$setNXGroup,
$ref_errorName,$ref_errorCode,$silent));}sub 
Common::NXFile::setOwnershipForUserNXGroupRoot{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x1eb4+ 1101-0x2301)));return (
__setOwnershipForUserNXGroupRoot ($path,$ref_errorName,$ref_errorCode,$silent));
}sub Common::NXFile::setOwnershipForUserNXSilent{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));return (setOwnershipForUserNX ($path,$ref_errorName,$ref_errorCode,
(0x0797+ 6143-0x1f95)));}sub Common::NXFile::setOwnershipForUser{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $userName=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x1b4b+  54-0x1b81)));(my $returnVal=(-(0x0261+ 1385-0x07c9)));if (($silent==
(0x0460+ 4626-0x1672))){if (($path eq (""))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x2e"
);return ($returnVal);}if (($userName eq (""))){Logger::warning (((
"\x55\x73\x65\x72\x6e\x61\x6d\x65\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x74\x6f\x20"
.$path)."\x2e"));return ($returnVal);}}(my $uid=
Common::NXCore::userInfoGetUidByUsername ($userName));(my $gid=
Common::NXCore::userInfoGetGidByUsername ($userName));($returnVal=
setOwnershipForUser_unix ($path,$uid,$gid,$ref_errorName,$ref_errorCode,$silent)
);return ($returnVal);}sub Common::NXFile::setOwnershipForUserSilent{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $userName=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));return (setOwnershipForUser ($path,
$userName,$ref_errorName,$ref_errorCode,(0x0ac9+ 6313-0x2371)));}sub 
Common::NXFile::setOwnershipForOwnerFile{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $fileToGetOwner=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x124b+ 3947-0x21b6)));(my ($dev,$ino,
$mode,$nlink,$uid,$gid)=Common::NXCore::NXStat ($fileToGetOwner));(my $returnVal
=(-(0x024d+ 8086-0x21e2)));if (($silent==(0x1016+ 4110-0x2024))){if (($path eq 
(""))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x2e"
);return ($returnVal);}if (($uid eq (""))){Logger::warning (((
"\x55\x69\x64\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x74\x6f\x20"
.$path)."\x2e"));return ($returnVal);}}($returnVal=setOwnershipForUser_unix (
$path,$uid,$gid,$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub
 Common::NXFile::setPermissionsReadWriteForNX{package Common::NXFile;no warnings
;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (
@_));(my $silent=(shift (@_)||(0x1b92+ 2436-0x2516)));(my $returnVal=(-
(0x1c73+ 1295-0x2181)));($returnVal=setPermissions_unix ($path,
$NXBits::UserReadWrite,$ref_errorName,$ref_errorCode,$silent));return (
$returnVal);}sub Common::NXFile::setPermissionsReadWriteForNXSilent{package 
Common::NXFile;no warnings;(my $dbFilePath=shift (@_));(my $ref_errorName=shift 
(@_));(my $ref_errorCode=shift (@_));return (setPermissionsReadWriteForNX (
$dbFilePath,$ref_errorName,$ref_errorCode,(0x02b4+ 2944-0x0e33)));}sub 
Common::NXFile::setPermissionReadOnlyForNX{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x1079+ 1943-0x1810)));(my $returnVal=(-(0x0776+  17-0x0786)));(
$returnVal=setPermissions_unix ($path,$NXBits::UserRead,$ref_errorName,
$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionReadOnlyForNXSilent{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));return (setPermissionReadOnlyForNX ($path,$ref_errorName,
$ref_errorCode,(0x0141+ 513-0x0341)));}sub 
Common::NXFile::setPermissionsReadOnlyForUser{package Common::NXFile;no warnings
;(my $path=shift (@_));(my $sid=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0129+ 1111-0x0580)));(my $returnVal=(-
(0x00f3+ 6410-0x19fc)));($returnVal=setPermissions_unix ($path,$NXBits::UserRead
,$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionsFullForNX{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x14fc+ 2143-0x1d5b)));(my $returnVal=(-(0x0444+ 6882-0x1f25)));(
$returnVal=setPermissions_unix ($path,($NXBits::UserReadWrite+
$NXBits::UserExecute),$ref_errorName,$ref_errorCode,$silent));return ($returnVal
);}sub Common::NXFile::setPermissionsFullForNXDirectory{package Common::NXFile;
no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x02e1+ 675-0x0584)));(my $returnVal=(-
(0x051f+ 3838-0x141c)));($returnVal=setPermissions_unix ($path,(
$NXBits::UserReadWrite+$NXBits::UserExecute),$ref_errorName,$ref_errorCode,
$silent));return ($returnVal);}sub 
Common::NXFile::setOwnerShipNXAndFullPermissions{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x095f+ 3790-0x182d)));(my $returnVal=
setOwnershipForUserNX ($path,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissionsFullForNX ($path,$ref_errorName,$ref_errorCode,$silent)==(-
(0x1235+ 510-0x1432)))){($returnVal=(-(0x0556+ 2312-0x0e5d)));}return (
$returnVal);}sub Common::NXFile::setPermissionsReadWriteForAllReportToStderr{
package Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=
shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x0f70+ 2293-0x1865)));(my $returnVal=(-(0x04f0+ 2791-0x0fd6)));(my $permissions
=(($NXBits::UserReadWrite+$NXBits::GroupReadWrite)+$NXBits::OthersReadWrite));(
$returnVal=setPermissions_unix ($path,$permissions,$ref_errorName,$ref_errorCode
,$silent));if (($returnVal==(-(0x0c81+ 2510-0x164e)))){main::nxwrite (
main::nxgetSTDERR (),((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$path)."\x20\x74\x6f\x20").$permissions).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$$ref_errorCode)."\x2c\x20").
$$ref_errorName)."\x2e\x0a"));}return ($returnVal);}sub 
Common::NXFile::setPermissionsReadWriteForOwnerAndGroupWriteForAllReportToStderr
{package Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=
shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x050c+ 1736-0x0bd4)));(my $returnVal=(-(0x0e50+ 2811-0x194a)));(my $permissions
=(($NXBits::UserReadWrite+$NXBits::GroupReadWrite)+$NXBits::OthersWrite));(
$returnVal=setPermissions_unix ($path,$permissions,$ref_errorName,$ref_errorCode
,$silent));if (($returnVal==(-(0x01a3+ 1696-0x0842)))){main::nxwrite (
main::nxgetSTDERR (),((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$path)."\x20\x74\x6f\x20").$permissions).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$$ref_errorCode)."\x2c\x20").
$$ref_errorName)."\x2e\x0a"));}return ($returnVal);}sub 
Common::NXFile::setPermissionsFullForAllDirectory{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0643+ 6555-0x1fde)));(my $returnVal=(-
(0x0152+ 7864-0x2009)));(my $permissions=($NXBits::UserReadWrite+
$NXBits::UserExecute));($permissions+=($NXBits::GroupReadWrite+
$NXBits::GroupExecute));($permissions+=($NXBits::OthersReadWrite+
$NXBits::OthersExecute));($permissions+=$NXBits::TemporaryAll);($returnVal=
setPermissions_unix ($path,$permissions,$ref_errorName,$ref_errorCode,$silent));
return ($returnVal);}sub 
Common::NXFile::setPermissionsInheritAndAllowTakeOwnershipIfNeeded{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0231+ 3956-0x11a5)));
(my $returnVal=(-(0x162c+ 1757-0x1d08)));Logger::error (
"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x73\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x49\x6e\x68\x65\x72\x69\x74\x41\x6e\x64\x41\x6c\x6c\x6f\x77\x54\x61\x6b\x65\x4f\x77\x6e\x65\x72\x73\x68\x69\x70\x49\x66\x4e\x65\x65\x64\x65\x64\x20\x69\x73\x20\x6e\x6f\x74\x20\x69\x6d\x70\x6c\x65\x6d\x65\x6e\x74\x65\x64\x20\x6f\x6e\x20\x55\x6e\x69\x78\x2e"
);return ($returnVal);}sub Common::NXFile::setPermissionsInherit{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0670+ 4101-0x1675)));
(my $returnVal=(-(0x17cf+ 935-0x1b75)));Logger::error (
"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x73\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x49\x6e\x68\x65\x72\x69\x74\x20\x69\x73\x20\x6e\x6f\x74\x20\x69\x6d\x70\x6c\x65\x6d\x65\x6e\x74\x65\x64\x20\x6f\x6e\x20\x55\x6e\x69\x78\x2e"
);return ($returnVal);}sub Common::NXFile::setPermissionsFullForUserDirectory{
package Common::NXFile;no warnings;(my $path=shift (@_));(my $user=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x0029+ 2006-0x07ff)));(my $returnVal=(-(0x05a5+ 1333-0x0ad9)));(my $permissions
=($NXBits::UserReadWrite+$NXBits::UserExecute));($returnVal=setPermissions_unix 
($path,$permissions,$ref_errorName,$ref_errorCode,$silent));return ($returnVal);
}sub Common::NXFile::setPermissionsUserNodeRootDirectory{package Common::NXFile;
no warnings;(my $path=shift (@_));(my $user=shift (@_));(my $ref_errorName=shift
 (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x004b+ 5609-0x1634)));(my $returnVal=(-(0x0263+ 5384-0x176a)));(my $permissions
=($NXBits::UserReadWrite+$NXBits::UserExecute));($returnVal=setPermissions_unix 
($path,$permissions,$ref_errorName,$ref_errorCode,$silent));return ($returnVal);
}sub Common::NXFile::setPermissionsFullForUser{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $user=shift (@_));(my $ref_errorName=shift (
@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x1742+ 546-0x1964)));(my $returnVal=(-(0x10cc+ 3378-0x1dfd)));(my $permissions
=($NXBits::UserReadWrite+$NXBits::UserExecute));($returnVal=setPermissions_unix 
($path,$permissions,$ref_errorName,$ref_errorCode,$silent));return ($returnVal);
}sub Common::NXFile::setPermissionsReadWriteForUserAndAdmin{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $user=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x134c+ 4957-0x26a9)));(my $returnVal=(-(0x0207+ 794-0x0520)));(my $permissions
=$NXBits::UserReadWrite);($returnVal=setPermissions_unix ($path,$permissions,
$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionsFullForAll{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (@_));(my $silent
=(shift (@_)||(0x1085+ 5035-0x2430)));(my $returnVal=(-(0x00cf+ 2885-0x0c13)));(my $permissions
=($NXBits::UserReadWrite+$NXBits::UserExecute));($permissions+=(
$NXBits::GroupReadWrite+$NXBits::GroupExecute));($permissions+=(
$NXBits::OthersReadWrite+$NXBits::OthersExecute));($permissions+=
$NXBits::TemporaryAll);($returnVal=setPermissions_unix ($path,$permissions,
$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionReadExecutableForAll{package Common::NXFile;no 
warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0b28+ 3817-0x1a11)));(my $returnVal=
(0x0dca+ 4085-0x1dbf));(my $permissions=($NXBits::UserReadWrite+
$NXBits::UserExecute));($permissions+=($NXBits::GroupRead+$NXBits::GroupExecute)
);($permissions+=($NXBits::OthersRead+$NXBits::OthersExecute));($returnVal=
setPermissions_unix ($path,$permissions,$ref_errorName,$ref_errorCode,$silent));
return ($returnVal);}sub 
Common::NXFile::setPermissionFullForOwnerReadExecuteForAll{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0d8f+ 3536-0x1b5f)));
(my $returnVal=(-(0x0294+ 8706-0x2495)));(my $permissions=(
$NXBits::UserReadWrite+$NXBits::UserExecute));($permissions+=($NXBits::GroupRead
+$NXBits::GroupExecute));($permissions+=($NXBits::OthersRead+
$NXBits::OthersExecute));($returnVal=setPermissions_unix ($path,$permissions,
$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionReadWriteForAll{package Common::NXFile;no warnings;
(my $path=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode=shift (
@_));(my $silent=(shift (@_)||(0x084b+ 1762-0x0f2d)));(my $returnVal=(-
(0x01c4+ 3534-0x0f91)));(my $permissions=(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersReadWrite));($returnVal=
setPermissions_unix ($path,$permissions,$ref_errorName,$ref_errorCode,$silent));
return ($returnVal);}sub 
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x17cf+ 512-0x19cf)));(my $returnVal
=(-(0x059a+ 680-0x0841)));(my $permissions=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));($returnVal=setPermissions_unix ($path
,$permissions,$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAllForce{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0377+ 282-0x0491)));(my $returnVal
=(-(0x0696+ 7340-0x2341)));(my $permissions=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));($returnVal=setPermissions_unix ($path
,$permissions,$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermission{package Common::NXFile;no warnings;(my $path=shift
 (@_));(my $permissions=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x187d+ 1761-0x1f5e)));(my $returnVal=
(0x145b+ 3026-0x202d));($returnVal=setPermissions_unix ($path,$permissions,
$ref_errorName,$ref_errorCode,$silent));return ($returnVal);}sub 
Common::NXFile::setPermissionSilent{package Common::NXFile;no warnings;(my $path
=shift (@_));(my $permissions=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(0x076b+ 1600-0x0daa));return (setPermission ($path,
$permissions,$ref_errorName,$ref_errorCode,$silent));}sub 
Common::NXFile::setOwnerShipAndPermissionsForNX{package Common::NXFile;no 
warnings;(my $dbFilePath=shift (@_));(my $ref_errorName=shift (@_));(my $ref_errorCode
=shift (@_));(my $silent=(shift (@_)||(0x0323+ 5949-0x1a60)));(my $returnVal=
setOwnershipForUserNX ($dbFilePath,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissionsReadWriteForNX ($dbFilePath,$ref_errorName,$ref_errorCode,$silent)
==(-(0x1770+ 1968-0x1f1f)))){($returnVal=(-(0x0931+ 6121-0x2119)));}return (
$returnVal);}sub Common::NXFile::setOwnerShipAndPermissionsForUserAndGroupNX{
package Common::NXFile;no warnings;(my $dbFilePath=shift (@_));(my $ref_errorName
=shift (@_));(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||
(0x09a3+ 3537-0x1774)));(my $returnVal=setOwnershipForUserAndGroupNX (
$dbFilePath,$ref_errorName,$ref_errorCode,$silent));if ((
setPermissionsReadWriteForNX ($dbFilePath,$ref_errorName,$ref_errorCode,$silent)
==(-(0x09bf+ 3315-0x16b1)))){($returnVal=(-(0x0efc+ 393-0x1084)));}return (
$returnVal);}sub Common::NXFile::setOwnerShipAndPermissionsReadOnlyForNX{package
 Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_))
;(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0528+ 3155-0x117b)))
;(my $returnVal=setOwnershipForUserNX ($path,$ref_errorName,$ref_errorCode,
$silent));if ((setPermissionReadOnlyForNX ($path,$ref_errorName,$ref_errorCode,
$silent)==(-(0x0ea4+ 1927-0x162a)))){($returnVal=(-(0x0213+ 3138-0x0e54)));}
return ($returnVal);}sub 
Common::NXFile::setPermissionReadWriteForOwnerAndGroupWriteForAll{package 
Common::NXFile;no warnings;(my $path=shift (@_));(my $ref_errorName=shift (@_));
(my $ref_errorCode=shift (@_));(my $silent=(shift (@_)||(0x0f88+ 905-0x1311)));(my $returnVal
=(-(0x0b91+ 3728-0x1a20)));(my $permissions=$NXBits::UserReadWrite);(
$permissions+=$NXBits::GroupReadWrite);($permissions+=$NXBits::OthersWrite);(
$returnVal=setPermissions_unix ($path,$permissions,$ref_errorName,$ref_errorCode
,$silent));return ($returnVal);}sub Common::NXFile::directoryExists{package 
Common::NXFile;no warnings;(my $path=shift (@_));($path=~ s/\\$// );if ((
libnxh::NXDirectoryExists ($path)==(0x0611+ 4121-0x1629))){return (
(0x0456+ 5838-0x1b23));}return ((0x06e2+ 1229-0x0baf));}sub 
Common::NXFile::fileExists{package Common::NXFile;no warnings;(my $path=shift (
@_));if ((libnxh::NXFileExists ($path)==(0x00dd+ 3556-0x0ec0))){Logger::debug ((
("\x4e\x58\x46\x69\x6c\x65\x3a\x20\x46\x69\x6c\x65\x20\x27".$path).
"\x27\x20\x65\x78\x69\x73\x74\x73\x2e"));return ((0x0b0d+ 1505-0x10ed));}
Logger::debug ((("\x4e\x58\x46\x69\x6c\x65\x3a\x20\x46\x69\x6c\x65\x20\x27".
$path)."\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));
return ((0x0da6+ 5444-0x22ea));}sub Common::NXFile::isExists{package 
Common::NXFile;no warnings;(my $path=shift (@_));if ((libnxh::NXExists ($path)==
(0x0603+ 6849-0x20c3))){return ((0x02e8+ 7888-0x21b7));}return (
(0x1af2+ 2238-0x23b0));}sub Common::NXFile::removeFile{package Common::NXFile;no
 warnings;(my $path=shift (@_));(my $silent=shift (@_));(my $ref_error=shift (@_
));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x52\x65\x6d\x6f\x76\x65\x28"
.$path)."\x29"));if ((libnxh::NXFileRemove ($path)!=(0x0365+ 4758-0x15fb))){(my $errorString
=libnxh::NXGetErrorString ());(my $errorCode=libnxh::NXGetError ());if (($silent
!=(0x08c9+ 966-0x0c8e))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20\x27"
.$path)."\x27"));Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x20".
$errorCode)."\x2c\x20\x27").$errorString)."\x27"));}($$ref_error=$errorString);
return ((0x0c22+ 4560-0x1df2));}return ((0x0554+ 2064-0x0d63));}sub 
Common::NXFile::renameFile{package Common::NXFile;no warnings;(my $oldName=shift
 (@_));(my $newName=shift (@_));(my $silent=shift (@_));(my $ref_error=shift (@_
));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x52\x65\x6e\x61\x6d\x65\x28"
.$oldName)."\x2c\x20").$newName)."\x29"));if ((libnxh::NXFileRename ($oldName,
$newName)!=(0x0b10+ 5631-0x210f))){(my $errorString=libnxh::NXGetErrorString ())
;(my $errorCode=libnxh::NXGetError ());if (($silent!=(0x0ae7+ 4757-0x1d7b))){
Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$oldName)."\x27\x20\x74\x6f\x20\x27").$newName)."\x27"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorCode)."\x2c\x20\x27").$errorString)
."\x27"));}($$ref_error=$errorString);return ((0x0d74+ 1997-0x1541));}return (
(0x1963+ 2381-0x22af));}sub Common::NXFile::createFileReadWriteByAll{package 
Common::NXFile;no warnings;(my $file=shift (@_));(my $ref_error=shift (@_));(my $createHandle
=main::nxopen ($file,$NXBits::O_CREAT,(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersReadWrite)));if ((not (defined (
$createHandle)))){($$ref_error=libnxh::NXGetErrorString ());return (
(0x1159+ 1980-0x1915));}main::nxclose ($createHandle);return (
(0x170f+ 2517-0x20e3));}sub 
Common::NXFile::createFileReadWriteByUserReadByGroupOthers{package 
Common::NXFile;no warnings;(my $file=shift (@_));(my $ref_error=shift (@_));(my $createHandle
=main::nxopen ($file,$NXBits::O_CREAT,(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead)));if ((not (defined ($createHandle)))){
($$ref_error=libnxh::NXGetErrorString ());return ((0x046b+ 8201-0x2474));}
main::nxclose ($createHandle);return ((0x04e6+ 4320-0x15c5));}sub 
Common::NXFile::isSameFile{package Common::NXFile;no warnings;(my $fd1=shift (@_
));(my $fd2=shift (@_));if ((libnxh::NXIsSameFile ($fd1,$fd2)==
(0x1e54+ 107-0x1ebe))){return ((0x0982+ 4960-0x1ce1));}return (
(0x07fb+ 5703-0x1e42));}sub Common::NXFile::compressFile{package Common::NXFile;
no warnings;(my $source=shift (@_));(my $destination=shift (@_));(my $silent=
shift (@_));if ((libnxh::NXCompressFile ($source,$destination)!=
(0x08a3+ 6610-0x2274))){(my $errorString=libnxh::NXGetErrorString ());(my $errorCode
=libnxh::NXGetError ());if (($silent!=(0x1f59+ 1880-0x26b0))){Logger::warning ((
(((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6d\x70\x72\x65\x73\x73\x20\x66\x69\x6c\x65\x20\x27"
.$source)."\x27\x20\x74\x6f\x20\x27").$destination)."\x27\x2e"));Logger::warning
 ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorCode)."\x2c\x20\x27").
$errorString)."\x27"));}return ((0x0225+ 1190-0x06cb));}return (
(0x12d6+ 3427-0x2038));}sub Common::NXFile::getFileContent{package 
Common::NXFile;no warnings;(my $file=shift (@_));Logger::debug (((
"\x4e\x58\x46\x69\x6c\x65\x3a\x20\x47\x65\x74\x20\x66\x69\x6c\x65\x20\x27".$file
)."\x27\x20\x63\x6f\x6e\x74\x65\x6e\x74\x2e"));(my $fileBody=undef);unless (
fileExists ($file)){return ($fileBody);}(my $fileHandle=main::nxopen ($file,
$NXBits::O_RDONLY));unless (defined ($fileHandle)){return ($fileBody);}while (
main::nxreadLine ($fileHandle,(\$_))){($fileBody.=$_);}main::nxclose (
$fileHandle);return ($fileBody);}sub 
Common::NXFile::setFileContentCreateIfNeeded{package Common::NXFile;no warnings;
(my $file=shift (@_));(my $content=shift (@_));(my $rights=shift (@_));(my $fileHandle
=main::nxopen ($file,(($NXBits::O_WRONLY+$NXBits::O_TRUNC)+$NXBits::O_CREAT),
$rights));unless (defined ($fileHandle)){return ((0x0b6f+ 6506-0x24d9));}if ((
main::nxwrite ($fileHandle,$content)==(-(0x1959+ 717-0x1c25)))){main::nxclose (
$fileHandle);return ((0x0d8b+ 4127-0x1daa));}main::nxclose ($fileHandle);return 
((0x01ef+ 3310-0x0edc));}sub Common::NXFile::truncateFile{package Common::NXFile
;no warnings;(my $filePath=shift (@_));(my $handle=main::nxopen ($filePath,(
$NXBits::O_WRONLY+$NXBits::O_TRUNC)));if (defined ($handle)){main::nxclose (
$handle);return ((0x0e17+ 337-0x0f67));}return ((0x0747+ 7911-0x262e));}sub 
Common::NXFile::setServerLogFilePermissions{package Common::NXFile;no warnings;(my $path
=Common::NXPaths::getNXServerLogPath ());return (
setServerOrErrorLogFilePermissions ($path));}sub 
Common::NXFile::setServerOrErrorLogFilePermissions{package Common::NXFile;no 
warnings;(my $path=shift (@_));if (($GLOBAL::CommonLogDirectory eq (""))){if (
Common::NXCore::isEffectiveUserNXRootOrSystem ()){setPermissionsReadWriteForNX (
$path);if (Common::NXCore::isEffectiveUsernameRoot ()){setOwnershipForUserNX (
$path);}}else{(my $user=Common::NXCore::getEffectiveUsername ());
setPermissionsReadWriteForUserAndAdmin ($path,$user);}}else{
setCommonServerOrErrorLogFilePermissionsAndOwner ($path);}}sub 
Common::NXFile::setCommonServerOrErrorLogFilePermissionsAndOwner{package 
Common::NXFile;no warnings;(my $path=shift (@_));if (
Common::NXCore::isEffectiveUsernameRoot ()){
setPermissionReadWriteForOwnerAndGroupWriteForAll ($path);}}sub 
Common::NXFile::getServerLogFilePermissions{package Common::NXFile;no warnings;
if (($GLOBAL::CommonLogDirectory ne (""))){(my $permissions=
$NXBits::UserReadWrite);($permissions+=$NXBits::GroupReadWrite);($permissions+=
$NXBits::OthersWrite);return ($permissions);}else{return ($NXBits::UserReadWrite
);}}package Common::NXFile;no warnings;"\x3f\x3f\x3f";
