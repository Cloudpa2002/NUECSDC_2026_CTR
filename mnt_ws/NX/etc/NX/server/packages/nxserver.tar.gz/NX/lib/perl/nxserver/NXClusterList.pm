############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXClusterList::print{package NXClusterList;no warnings;(my $ref_params=shift
 (@_));main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");NXCluster::init 
();Common::NXMsg::send_response (
"\x72\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74");__setWidth ((
\%table),"\x68\x6f\x73\x74","\x48\x6f\x73\x74");__setWidth ((\%table),
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65","\x49\x6e\x74\x65\x72\x66\x61\x63\x65");
__setWidth ((\%table),"\x6e\x65\x74\x6d\x61\x73\x6b",
"\x4e\x65\x74\x6d\x61\x73\x6b");foreach my $node (values (
%NXCluster::myClusterDB)){__setWidth ((\%table),"\x68\x6f\x73\x74",$$node{
"\x68\x6f\x73\x74"});__setWidth ((\%table),
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65",$$node{
"\x69\x6e\x74\x65\x72\x66\x61\x63\x65"});__setWidth ((\%table),
"\x6e\x65\x74\x6d\x61\x73\x6b",$$node{"\x6e\x65\x74\x6d\x61\x73\x6b"});}
__printWidth ((\%table),"\x68\x6f\x73\x74","\x48\x6f\x73\x74");__printWidth ((
\%table),"\x69\x6e\x74\x65\x72\x66\x61\x63\x65",
"\x49\x6e\x74\x65\x72\x66\x61\x63\x65");__printWidth ((\%table),
"\x6e\x65\x74\x6d\x61\x73\x6b","\x4e\x65\x74\x6d\x61\x73\x6b");main::nxwrite (
main::nxgetSTDOUT (),"\x0a");__printMark ((\%table),"\x68\x6f\x73\x74");
__printMark ((\%table),"\x69\x6e\x74\x65\x72\x66\x61\x63\x65");__printMark ((
\%table),"\x6e\x65\x74\x6d\x61\x73\x6b");main::nxwrite (main::nxgetSTDOUT (),
"\x0a");foreach my $node (values (%NXCluster::myClusterDB)){__printWidth ((
\%table),"\x68\x6f\x73\x74",main::urldecode ($$node{"\x68\x6f\x73\x74"}));
__printWidth ((\%table),"\x69\x6e\x74\x65\x72\x66\x61\x63\x65",main::urldecode (
$$node{"\x69\x6e\x74\x65\x72\x66\x61\x63\x65"}));__printWidth ((\%table),
"\x6e\x65\x74\x6d\x61\x73\x6b",main::urldecode ($$node{
"\x6e\x65\x74\x6d\x61\x73\x6b"}));main::nxwrite (main::nxgetSTDOUT (),"\x0a");}
main::nxwrite (main::nxgetSTDOUT (),"\x0a");if ($$ref_params{
"\x63\x6f\x6e\x66\x69\x67\x75\x72\x65"}){main::nxwrite (main::nxgetSTDOUT (),((
"\x53\x68\x61\x72\x65\x64\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x20".
$GLOBAL::ClusterHost)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x4d\x61\x73\x74\x65\x72\x20\x73\x65\x72\x76\x65\x72\x3a\x20\x20".
$GLOBAL::ClusterMaster)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x50\x72\x6f\x74\x6f\x63\x6f\x6c\x73\x3a\x20\x20\x20\x20\x20\x20".
$GLOBAL::ClusterProto)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x47\x72\x61\x63\x65\x20\x70\x65\x72\x69\x6f\x64\x3a\x20\x20\x20".
$GLOBAL::ClusterGracePeriod)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x52\x65\x74\x72\x79\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x3a\x20".
$GLOBAL::ClusterRetryInterval)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x50\x72\x6f\x62\x65\x20\x74\x69\x6d\x65\x6f\x75\x74\x3a\x20\x20".
$GLOBAL::ClusterProbeTimeout)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x49\x6e\x74\x65\x72\x76\x61\x6c\x3a\x20\x20\x20\x20\x20\x20\x20".
$GLOBAL::ClusterInterval)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x54\x69\x6d\x65\x6f\x75\x74\x3a\x20\x20\x20\x20\x20\x20\x20\x20".
$GLOBAL::ClusterTimeout)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x4c\x6f\x61\x64\x2d\x62\x61\x6c\x61\x6e\x63\x69\x6e\x67\x3a\x20".
$GLOBAL::ClusterLoadBalancing)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x47\x55\x49\x44\x3a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20".
$GLOBAL::ClusterGUID)."\x0a"));main::nxwrite (main::nxgetSTDOUT (),((
"\x53\x69\x6e\x67\x6c\x65\x20\x63\x65\x72\x74\x3a\x20\x20\x20\x20".
$GLOBAL::ClusterSingleCert)."\x0a"));}}sub NXClusterList::__setWidth{package 
NXClusterList;no warnings;(my $refTable=shift (@_));(my $name=shift (@_));(my $value
=shift (@_));if (($$refTable{$name}<libnxh::NXStringLength ($value))){(
$$refTable{$name}=libnxh::NXStringLength ($value));}}sub 
NXClusterList::__printWidth{package NXClusterList;no warnings;(my $refTable=
shift (@_));(my $name=shift (@_));(my $value=shift (@_));(my $width=($$refTable{
$name}+(0x09a0+ 5149-0x1dbc)));(my $message=
Common::NXCore::leftJustifyOrTrimString ($value,$width));main::nxwrite (
main::nxgetSTDOUT (),$message);}sub NXClusterList::__printMark{package 
NXClusterList;no warnings;(my $refTable=shift (@_));(my $name=shift (@_));(my $value
=shift (@_));(my $width=($$refTable{$name}+(0x0117+ 7699-0x1f29)));(my $message=
Common::NXCore::leftJustifyOrTrimString (("\x2d" x $$refTable{$name}),$width));
main::nxwrite (main::nxgetSTDOUT (),$message);}sub NXClusterList::status{package
 NXClusterList;no warnings;main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);(my $reply=NXClientSystemDaemons::requestClusterStatus ());if (($reply=~ ('NX> ' . $GLOBAL::MSG_CLUSTER_RUNNING) )
){if ((not (NXMsg::isMessageRegistered (
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x52\x75\x6e\x6e\x69\x6e\x67")))){
NXMsg::register_response ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74"
,"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x52\x75\x6e\x6e\x69\x6e\x67",
$GLOBAL::MSG_CLUSTER_RUNNING);}NXMsg::send_response (
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x52\x75\x6e\x6e\x69\x6e\x67",
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74");return (
(0x0845+ 5324-0x1d11));}if ((not (NXMsg::isMessageRegistered (
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x44\x69\x73\x61\x62\x6c\x65\x64"))
)){NXMsg::register_response (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74",
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x44\x69\x73\x61\x62\x6c\x65\x64",
$GLOBAL::MSG_CLUSTER_DISABLED);}NXMsg::send_response (
"\x69\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74");}package NXClusterList;
no warnings;Common::NXMsg::register_response (
"\x72\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x4c\x69\x73\x74",
$GLOBAL::MSG_CLUSTER_LIST);return ((0x0bd6+ 4714-0x1e3f));
