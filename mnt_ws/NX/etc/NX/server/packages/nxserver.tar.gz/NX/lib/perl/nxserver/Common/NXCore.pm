############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require Common::NXPaths;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x74\x68\x73"->import};}sub 
Common::NXCore::BEGIN{package Common::NXCore;no warnings;require strict;do{
"\x73\x74\x72\x69\x63\x74"->unimport ("\x72\x65\x66\x73")};}sub 
Common::NXCore::BEGIN{package Common::NXCore;no warnings;require strict;do{
"\x73\x74\x72\x69\x63\x74"->unimport ("\x73\x75\x62\x73")};}sub 
Common::NXCore::BEGIN{package Common::NXCore;no warnings;eval (
"\x73\x75\x62\x20\x53\x4e\x53\x7b\x40\x5f\x3b\x7d\x73\x75\x62\x20\x53\x4e\x7b\x24\x5f\x5b\x30\x5d\x3b\x7d"
);}package Common::NXCore;no warnings;require Common::NXFile;(our (@ISA)=
"\x45\x78\x70\x6f\x72\x74\x65\x72");sub BEGIN{require Exporter;do{
"\x45\x78\x70\x6f\x72\x74\x65\x72"->import};}sub BEGIN{require Errno;do{
"\x45\x72\x72\x6e\x6f"->import ("\x3a\x50\x4f\x53\x49\x58")};}(our (@EXPORT)=SNS
 ("\x6e\x78\x72\x65\x61\x64","\x6e\x78\x77\x72\x69\x74\x65",
"\x6e\x78\x6f\x70\x65\x6e","\x6e\x78\x63\x6c\x6f\x73\x65",
"\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x52\x65\x64\x69\x72\x65\x63\x74\x65\x64"
,
"\x72\x65\x64\x69\x72\x65\x63\x74\x53\x74\x61\x6e\x64\x61\x72\x64\x53\x65\x72\x76\x65\x72\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73"
,"\x6e\x78\x72\x65\x61\x64\x4c\x69\x6e\x65",
"\x61\x64\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x54\x6f\x4e\x58\x50\x4c\x41\x72\x72\x61\x79"
,
"\x72\x65\x6d\x6f\x76\x65\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x46\x72\x6f\x6d\x4e\x58\x50\x4c\x41\x72\x72\x61\x79"
,"\x70\x61\x72\x73\x65\x5f\x63\x6f\x6e\x66\x69\x67\x5f\x66\x69\x6c\x65",
"\x69\x6e\x69\x74\x5f\x62\x79\x5f\x63\x6f\x6e\x66\x69\x67\x5f\x66\x69\x6c\x65",
"\x6e\x78\x73\x6c\x65\x65\x70",
"\x6e\x78\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x4d\x6f\x6e\x6f",
"\x6e\x78\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x42\x69",
"\x6e\x78\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64",
"\x6e\x78\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x42\x67",
"\x6e\x78\x45\x78\x65\x63\x43\x6f\x6d\x6d\x61\x6e\x64",
"\x6e\x78\x65\x78\x69\x74",
"\x6e\x78\x4c\x69\x73\x74\x65\x6e\x4f\x6e\x53\x6f\x63\x6b\x65\x74",
"\x6e\x78\x73\x65\x6c\x65\x63\x74",
"\x6e\x78\x41\x63\x63\x65\x70\x74\x53\x6f\x63\x6b\x65\x74",
"\x6e\x78\x66\x6c\x6f\x63\x6b","\x6e\x78\x63\x6f\x6e\x6e\x65\x63\x74",
"\x6e\x78\x67\x65\x74\x53\x54\x44\x49\x4e",
"\x6e\x78\x67\x65\x74\x53\x54\x44\x4f\x55\x54",
"\x6e\x78\x67\x65\x74\x53\x54\x44\x45\x52\x52",
"\x6e\x78\x63\x68\x65\x63\x6b\x50\x69\x70\x65",
"\x6e\x78\x72\x65\x73\x74\x6f\x72\x65\x53\x54\x44\x45\x52\x52",
"\x6e\x78\x72\x65\x64\x69\x72\x65\x63\x74\x53\x54\x44\x45\x52\x52",
"\x64\x65\x66\x69\x6e\x65",
"\x72\x65\x64\x69\x72\x65\x63\x74\x53\x74\x64\x65\x72\x72\x4e\x58\x50\x4c",
"\x68\x69\x64\x65\x4f\x75\x74\x70\x75\x74",
"\x6e\x78\x43\x68\x65\x63\x6b\x44\x65\x73\x6b\x74\x6f\x70\x4f\x77\x6e\x65\x72",
"\x72\x65\x73\x74\x6f\x72\x65\x53\x74\x61\x6e\x64\x61\x72\x64\x53\x65\x72\x76\x65\x72\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73"
,"\x63\x6c\x6f\x73\x65\x53\x6f\x63\x6b\x65\x74\x41\x74\x46\x69\x6e\x69\x73\x68",
"\x64\x6f\x4e\x6f\x74\x43\x6c\x6f\x73\x65\x53\x6f\x63\x6b\x65\x74\x41\x74\x46\x69\x6e\x69\x73\x68"
,"\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65","\x75\x72\x6c\x64\x65\x63\x6f\x64\x65",
"\x6e\x78\x54\x69\x6d\x65",
"\x61\x64\x64\x46\x68\x54\x6f\x4d\x6f\x6e\x69\x74\x6f\x72",
"\x6e\x78\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c",
"\x6c\x6f\x61\x64\x41\x67\x65\x6e\x74\x4c\x69\x62\x72\x61\x72\x69\x65\x73",
"\x6c\x6f\x61\x64\x41\x6c\x6c\x4d\x6f\x64\x75\x6c\x65\x73\x4c\x69\x62\x72\x61\x72\x69\x65\x73"
,"\x6c\x6f\x61\x64\x4e\x58\x4c\x69\x62\x72\x61\x72\x79",
"\x69\x73\x4e\x58\x4c\x69\x62\x72\x61\x72\x79\x4c\x6f\x61\x64\x65\x64\x46\x6f\x72\x4d\x6f\x64\x75\x6c\x65"
));($NXCore::currentNXSelectDescriptors={});($NXCore::descriptorsRedirected=
"\x6e\x6f");%NXCore::NXPLDescriptorsArray;(@NXCore::runCommandEnvironment=());(
$NXCore::runCommandPriority=(""));($NXCore::nodePriority=
"\x6e\x6f\x74\x53\x65\x74");$NXCore::readBuffer;%NXCore::UserInfo;
%NXCore::systemExitCodes;($NXCore::WMRunningTimeout_default=
(0x0ee6+ 3411-0x1a45));($NXCore::WMRunningTimeout_max=10000);(
$NXCore::WMRunningTimeout=$NXCore::WMRunningTimeout_default);(
@NXCore::NXServerLibraryList=("\x6c\x69\x62\x6e\x78\x68",
"\x6c\x69\x62\x6e\x78\x68\x73"));(@NXCore::NXNodeLibraryList=(
"\x6c\x69\x62\x6e\x78\x68","\x6c\x69\x62\x6e\x78\x68\x6e"));(
@NXCore::NXAgentLibraryList="\x6c\x69\x62\x6e\x78\x64\x69\x61\x67");(
@NXCore::NXWebPlayerLibraryList=("\x6c\x69\x62\x6e\x78\x68",
"\x6c\x69\x62\x6e\x78\x68\x73"));($$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}={
"\x6c\x69\x62\x6e\x78\x64\x69\x61\x67",(0x01bd+ 1137-0x062e),
"\x6c\x69\x62\x6e\x78\x68",(0x02cc+ 4234-0x1356),"\x6c\x69\x62\x6e\x78\x68\x6e",
(0x1166+ 780-0x1472),"\x6c\x69\x62\x6e\x78\x68\x73",(0x0505+ 579-0x0748)});(
$NXCore::nxselectIteration=(0x00b2+ 8051-0x2025));($NXCore::nxstdinClosed=
(0x1557+ 3503-0x2306));($NXCore::windowsConsoleCPGet=(0x10a0+  75-0x10eb));sub 
shouldExitFromSelectOnFirstSignal{if (($GLOBAL::finishSelect==
(0x079b+ 6286-0x2028))){return ((0x1ebd+ 1167-0x234b));}return (
(0x0344+ 7946-0x224e));}sub exitFromSelectOnFirstSignal{($GLOBAL::finishSelect=
(0x0892+ 3184-0x1501));}sub disableExitFromSelectOnFirstSignal{(
$GLOBAL::finishSelect=(0x0353+ 2236-0x0c0f));}sub 
getExitFromSelectOnFirstSignalFlag{return ($GLOBAL::finishSelect);}sub 
setExitFromSelectOnFirstSignalFlagValue{(my $finishSelect=shift (@_));(
$GLOBAL::finishSelect=$finishSelect);}sub shouldExitFromSelectWithSignalFD{if ((
$GLOBAL::finishSelectWithSignalFD==(0x0bff+ 2333-0x151b))){return (
(0x1597+ 2568-0x1f9e));}return ((0x0467+ 4153-0x14a0));}sub 
exitFromSelectWithSignalFD{($GLOBAL::finishSelectWithSignalFD=
(0x183c+ 1420-0x1dc7));}sub disableExitFromSelectWithSignalFD{(
$GLOBAL::finishSelectWithSignalFD=(0x06fa+ 7479-0x2431));}sub isNxstdinClosed{
return ($NXCore::nxstdinClosed);}sub setNxstdinClosed{($NXCore::nxstdinClosed=
(0x1054+ 3118-0x1c81));}sub nxselect{(my $ref_descriptors=shift (@_));(my $timeout
=shift (@_));(my $ref_result=shift (@_));(my $silence=shift (@_));($silence=
undef);(my $starttime=int ((main::nxTime ()*(0x1720+ 1005-0x1725))));if (((not (
defined ($timeout)))or ($timeout<(-(0x16d4+ 218-0x17ad))))){($timeout=(-
(0x1984+ 274-0x1a95)));}__setCurrentNXSelectDescriptos ($ref_descriptors);(my $usingFirstCallbackAsTimeout
=(0x00f2+ 7840-0x1f92));my ($nxselectTimeoutTimestamp);my (
$firstCallbackTimestamp);if (Common::NXSelector::isAnyTimestampCallbackWaiting 
()){($nxselectTimeoutTimestamp=($starttime+$timeout));($firstCallbackTimestamp=(
Common::NXSelector::getFirstTimestampCallback ()*(0x10cd+ 138-0x0d6f)));if (
isCallbackTimestampBeforeSelectTimeout ($nxselectTimeoutTimestamp,
$firstCallbackTimestamp)){if (isTimeToRunTimestampCallback (
$firstCallbackTimestamp,$starttime)){
Common::NXSelector::runFirstTimestampCallback ();return (
runNextIterationAfterRunCallback (__getCurrentNXSelectDescriptorsAndClean (),
$ref_result,$nxselectTimeoutTimestamp,$starttime));}else{($timeout=
setNewSelectTimeout ($firstCallbackTimestamp,$starttime));}(
$usingFirstCallbackAsTimeout=(0x10ac+ 141-0x1138));}}(my $length=
Common::NXSelector::countNonGlobalHandlers ($ref_descriptors));(my $descriptors=
(""));(my $log_descriptors=(""));foreach my $a (@$ref_descriptors){if ((
$descriptors eq (""))){($descriptors=($descriptors.$a));($log_descriptors=((
$log_descriptors."\x46\x44\x23").$a));}else{($descriptors=(($descriptors."\x2c")
.$a));($log_descriptors=(($log_descriptors."\x2c\x20\x46\x44\x23").$a));}}if ((
not (defined ($silence)))){Logger::debug2 (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x28".
$log_descriptors)."\x2c\x20").$timeout)."\x29"));}if (defined (
$NXBegin::MonitoredHandler)){($descriptors.=("\x2c".$NXBegin::MonitoredHandler))
;}(my $return=libnxh::NXSelect ($descriptors,$timeout));if (($timeout!=(-
(0x0092+ 2751-0x0b50)))){(my $actualTime=int ((main::nxTime ()*
(0x0718+ 8686-0x251e))));($timeout=($timeout-($actualTime-$starttime)));if ((
$timeout<(0x0898+ 7398-0x257d))){($timeout=(0x05c7+ 6931-0x20da));}}(my (@result
)=());if (($return==(0x0f62+ 1466-0x151c))){if ($usingFirstCallbackAsTimeout){
Common::NXSelector::runFirstTimestampCallback ();return (
runNextIterationAfterRunCallback (__getCurrentNXSelectDescriptorsAndClean (),
$ref_result,$nxselectTimeoutTimestamp,$firstCallbackTimestamp));}else{(
@$ref_result=@result);__cleanCurrentNXSelectIteration ();return;}}($return=~ /(-?\d+):(.*)/ )
;(my $exitcode=$1);(my $ready=$2);if (($exitcode==(-(0x10a2+ 5550-0x264f)))){(my $error
=libnxh::NXGetErrorName ());(my $errorstring=libnxh::NXGetErrorString ());if ((
$error ne "\x45\x49\x4e\x54\x52")){Logger::error (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x28".
$descriptors).
"\x29\x20\x65\x78\x69\x74\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x27"
).$errorstring)."\x27\x2e"));}else{Logger::debug2 (
"\x53\x65\x6c\x65\x63\x74\x20\x65\x78\x69\x74\x20\x62\x65\x63\x61\x75\x73\x65\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x45\x49\x4e\x54\x52"
);}(@$ref_result=@result);if (($error eq "\x45\x42\x41\x44\x46")){nxexit ();}
__cleanCurrentNXSelectIteration ();return;}my ($spacepos);my ($fh);(my $signalFd
=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});if ((not (($ready=~ /\d+/ )))){(
@$ref_result=@result);__cleanCurrentNXSelectIteration ();return;}while ((length 
($ready)>(0x0d65+ 6151-0x256c))){($spacepos=index ($ready,"\x2c"));if ((
$spacepos>(0x1a05+ 1923-0x2188))){($fh=substr ($ready,(0x0f3b+ 4920-0x2273),
$spacepos));if (($fh==$signalFd)){$NXBegin::parser->checkSignal;if ((($length==
(0x0419+ 4689-0x1669))or shouldExitFromSelectOnFirstSignal ())){
disableExitFromSelectOnFirstSignal ();if (shouldExitFromSelectWithSignalFD ()){
disableExitFromSelectWithSignalFD ();push (@$ref_result,$signalFd);}
__cleanCurrentNXSelectIteration ();return (());}if (($exitcode==
(0x0e62+ 4958-0x21bf))){return (nxselect (
__getCurrentNXSelectDescriptorsAndClean (),$timeout,$ref_result));}}elsif (
Common::NXSelector::handleGlobalSelectorDescriptor ($fh)){Logger::debug (((
"\x46\x44\x23".$fh).
"\x20\x68\x61\x6e\x64\x6c\x65\x64\x20\x62\x79\x20\x67\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72"
));push (@result,$fh);last;}else{push (@result,$fh);}($ready=substr ($ready,(
$spacepos+(0x08fa+ 814-0x0c27)),length ($ready)));}else{if (($ready==$signalFd))
{$NXBegin::parser->checkSignal;if ((($length==(0x0866+ 1406-0x0de3))or 
shouldExitFromSelectOnFirstSignal ())){disableExitFromSelectOnFirstSignal ();if 
(shouldExitFromSelectWithSignalFD ()){disableExitFromSelectWithSignalFD ();push 
(@$ref_result,$signalFd);}__cleanCurrentNXSelectIteration ();return (());}if ((
$exitcode==(0x0e51+ 984-0x1228))){return (nxselect (
__getCurrentNXSelectDescriptorsAndClean (),$timeout,$ref_result));}}elsif ((
defined ($NXBegin::MonitoredHandler)and ($ready==$NXBegin::MonitoredHandler))){(my $callback
=$NXBegin::MonitoredHandlerCallback);if (defined ($callback)){&{$callback;}(
$ready);}($NXBegin::MonitoredHandler=undef);($NXBegin::MonitoredHandlerCallback=
undef);if (($exitcode==(0x0354+ 2600-0x0d7b))){return (nxselect (
__getCurrentNXSelectDescriptorsAndClean (),$timeout,$ref_result));}}elsif (
Common::NXSelector::handleGlobalSelectorDescriptor ($ready)){Logger::debug2 (((
"\x46\x44\x23".$ready).
"\x20\x68\x61\x6e\x64\x6c\x65\x64\x20\x62\x79\x20\x67\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72"
));push (@result,$ready);last;}else{push (@result,$ready);}last;}}if ((not (
defined ($silence)))){foreach my $a (@result){Logger::debug2 ((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x20\x72\x65\x74\x75\x72\x6e\x3a\x20\x46\x44\x23"
.$a));}}(@$ref_result=@result);__cleanCurrentNXSelectIteration ();return;}sub 
restoreStandardServerDescriptors{($GLOBAL::DefaultSTDINDescriptor=
(0x0aa5+ 5721-0x20fe));($GLOBAL::DefaultSTDOUTDescriptor=(0x0534+ 2744-0x0feb));
($NXCore::descriptorsRedirected="\x6e\x6f");}sub 
redirectStandardServerDescriptors{($NXCore::descriptorsRedirected="\x79\x65\x73"
);Logger::debug2 ((
"\x52\x65\x64\x69\x72\x65\x63\x74\x20\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x62\x61\x73\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$GLOBAL::SOCKET_PASSED));($GLOBAL::DefaultSTDINDescriptor=
$GLOBAL::SOCKET_PASSED);if ((not (($GLOBAL::SOCKET_PASSED>=(0x0a13+ 1747-0x10e6)
)))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x65\x72\x76\x65\x72\x20\x73\x74\x64\x69\x6e\x2c\x20\x62\x61\x64\x20\x46\x44\x23"
.$GLOBAL::SOCKET_PASSED));}else{Logger::debug ((
"\x53\x45\x52\x56\x45\x52\x5f\x53\x54\x44\x49\x4e\x3a\x20".nxgetSTDIN ()));}(
$GLOBAL::DefaultSTDOUTDescriptor=$GLOBAL::SOCKET_PASSED);if ((not ((
$GLOBAL::SOCKET_PASSED>=(0x2099+ 1210-0x2553))))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x65\x72\x76\x65\x72\x20\x73\x64\x74\x6f\x75\x74\x2c\x20\x62\x61\x64\x20\x46\x44\x23"
.$GLOBAL::SOCKET_PASSED));}else{Logger::debug ((
"\x53\x45\x52\x56\x45\x52\x5f\x53\x54\x44\x4f\x55\x54\x3a\x20".nxgetSTDOUT ()));
}}sub descriptorsRedirected{if (($NXCore::descriptorsRedirected eq 
"\x79\x65\x73")){return ((0x0e3a+ 570-0x1073));}return ((0x013b+ 2059-0x0946));}
sub nxopen{(my $filepath=shift (@_));(my $mode=shift (@_));(my $permissions=(
shift (@_)||(0x01e0+ 8217-0x21f9)));(my $silent=(shift (@_)||{}));(my $modret=(-
(0x03e5+ 1974-0x0b9a)));(my $setRights=(0x15d6+ 3009-0x2197));(my ($package,
$filename,$line,$sub)=caller ((0x0097+ 4545-0x1257)));if (($sub eq (""))){($sub=
$package);}unless (Common::NXFile::isExists ($filepath)){($setRights=
(0x0383+ 6132-0x1b76));}(my $filepathToNXOpen=$filepath);(my $ret=libnxh::NXOpen
 ($filepathToNXOpen,$mode,$permissions));if (($ret==(-(0x08a1+ 4960-0x1c00)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());if (
__warningShouldBeLogged ($sub,$errorNumber,$silent)){__reportWarningNXOpenFail (
$filepath,$mode,$silent,$errorNumber,$errorstring);}return (undef);}if (((($sub 
ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x5f\x5f\x6f\x70\x65\x6e\x4c\x6f\x67\x46\x69\x6c\x65"
)and isNXLibraryLoadedForModule ())and ($sub ne 
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x57\x6f\x72\x6b\x69\x6e\x67\x44\x69\x72\x3a\x3a\x69\x6e\x69\x74\x42\x61\x63\x6b\x75\x70"
))){Logger::debug ((((((((((("\x4e\x58\x4f\x70\x65\x6e\x20\x46\x44\x23".$ret).
"\x20\x2d\x20\x66\x69\x6c\x65\x20").$filepath).
"\x20\x77\x69\x74\x68\x20\x6d\x6f\x64\x65\x20").$mode).
"\x20\x61\x6e\x64\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20").
$permissions)."\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));}if ($setRights){my (
$errorName);my ($errorNumber);if (($permissions==(0x1707+ 3333-0x240c))){(
$permissions=$NXBits::UserReadWrite);}($modret=
Common::NXFile::setPermissionSilent ($filepath,$permissions,(\$errorName),(
\$errorNumber)));if (($modret==(-(0x0b84+ 6117-0x2368)))){if (
__warningShouldBeLogged ($sub,$errorNumber,$silent)){Logger::warning (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$filepath)."\x20\x74\x6f\x20").$permissions)."\x2e\x20").$errorNumber).
"\x2c\x20").$errorName)."\x2e"));}return (undef);}}closeSocketAtFinish ($ret);
return ($ret);}sub __warningShouldBeLogged{(my $sub=shift (@_));(my $error=shift
 (@_));(my $silent=shift (@_));if (($sub eq 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x5f\x5f\x6f\x70\x65\x6e\x4c\x6f\x67\x46\x69\x6c\x65"
)){return ((0x07e2+ 1503-0x0dc1));}if ((not (isNXLibraryLoadedForModule ()))){
return ((0x0bab+ 524-0x0db7));}if (($sub eq 
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x57\x6f\x72\x6b\x69\x6e\x67\x44\x69\x72\x3a\x3a\x69\x6e\x69\x74\x42\x61\x63\x6b\x75\x70"
)){return ((0x0b36+ 5905-0x2247));}if (defined ($$silent{"\x41\x4c\x4c"})){
return ((0x02ef+ 8076-0x227b));}if (((ErrnoENOENT ()==$error)and defined (
$$silent{"\x45\x4e\x4f\x45\x4e\x54"}))){return ((0x0619+ 2482-0x0fcb));}if (((
ErrnoEACCES ()==$error)and defined ($$silent{"\x45\x41\x43\x43\x45\x53"}))){
return ((0x04fb+ 4809-0x17c4));}return ((0x0660+ 3500-0x140b));}sub 
__reportWarningNXOpenFail{(my $filepath=shift (@_));(my $mode=shift (@_));(my $silent
=shift (@_));(my $errorNumber=shift (@_));(my $errorstring=shift (@_));(my $accessLog
=(""));(my $modeLog=(""));if (((ErrnoEACCES ()==$errorNumber)and defined (
$$silent{"\x45\x41\x43\x43\x45\x53"}))){($accessLog=(("\x55\x73\x65\x72\x20".
getEffectiveUsername ())."\x20"));if ((($mode %(0x0293+ 6252-0x1afd))==
(0x0493+ 6799-0x1f21))){($modeLog="\x20\x74\x6f\x20\x77\x72\x69\x74\x65");}else{
($modeLog="\x20\x74\x6f\x20\x72\x65\x61\x64");}Logger::warning (((($accessLog.
"\x63\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e").$modeLog).(("\x3a\x20".$filepath
)."\x2e")));Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));}else{Logger::warning (
(("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x3a\x20".$filepath)."\x2e"));
Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20\x27").$errorstring)."\x27\x2e"));}}sub nxclose{(my $file=shift (@_));(my $firstCaller
=(caller ((0x0b06+ 4692-0x1d57)))[(0x05d3+ 6618-0x1faa)]);($firstCaller=~ s/:.*//s )
;(my ($package,$filename,$line,$sub)=caller ((0x0653+ 4462-0x17c0)));if (($sub 
eq (""))){($sub=$package);}(my $silence=(shift (@_)||"\x6e\x6f"));if ((not (
defined ($file)))){if (((!$silence)=="\x6e\x6f")){Logger::error (((
"\x4e\x58\x43\x6c\x6f\x73\x65\x20\x63\x61\x6c\x6c\x65\x64\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x61\x6e\x79\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x20\x66\x72\x6f\x6d\x20"
.$sub)."\x2e"));}return ((0x03b3+ 5884-0x1aaf));}if ((($firstCaller ne 
"\x4c\x6f\x67\x67\x65\x72")and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x63\x6c\x6f\x73\x65\x4c\x6f\x67\x46\x69\x6c\x65"
))){Logger::debug ((((("\x4e\x58\x43\x6c\x6f\x73\x65\x20\x46\x44\x23".$file).
"\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));}if (exists ($$NXCore::readBuffer{
$file})){delete ($$NXCore::readBuffer{$file});}
__removeDescriptorFromNXSelectCurrentList ($file);if (exists (
$$NXBegin::SocketsToClose{$file})){delete ($$NXBegin::SocketsToClose{$file});}
else{if ((($sub ne "\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x6c\x6f\x67")and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x63\x6c\x6f\x73\x65\x4c\x6f\x67\x46\x69\x6c\x65"
))){Logger::warning (((((
"\x4e\x58\x43\x6c\x6f\x73\x65\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x6c\x6f\x73\x65\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23"
.$file)."\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));}return;}(my $ret=
libnxh::NXDescriptorClose ($file));return ((!$ret));}sub nxreadLine{(my $filehandle
=shift (@_));(my $readBuffer=shift (@_));(my $line=(""));(my $eolpos=(-
(0x15a1+ 1574-0x1bc6)));(my $block=($GLOBAL::lengthOfReadLineBlock||
(0x0620+ 4326-0x1686)));(my $blockread=(0x0ded+ 5418-0x2317));($$readBuffer=("")
);if ((not (exists ($$NXCore::readBuffer{$filehandle})))){($$NXCore::readBuffer{
$filehandle}=(""));my ($buffer);while (main::nxread ($filehandle,(\$buffer),
16384)){($$NXCore::readBuffer{$filehandle}=($$NXCore::readBuffer{$filehandle}.
$buffer));}}($eolpos=index ($$NXCore::readBuffer{$filehandle},"\x0a"));if ((
$eolpos==(-(0x0e0f+ 1455-0x13bd)))){($line=$$NXCore::readBuffer{$filehandle});(
$$NXCore::readBuffer{$filehandle}=(""));}else{($line=substr (
$$NXCore::readBuffer{$filehandle},(0x124b+ 3245-0x1ef8),($eolpos+
(0x0d9a+ 5571-0x235c))));($$NXCore::readBuffer{$filehandle}=substr (
$$NXCore::readBuffer{$filehandle},($eolpos+(0x0754+ 1088-0x0b93)),length (
$$NXCore::readBuffer{$filehandle})));}($$readBuffer=$line);return (length ($line
));}sub nxread{(my $FD_passed=shift (@_));(my $readBuffer=shift (@_));(my $length
=(shift (@_)||(0x2336+ 1468-0x20f2)));(my $tmpRead=("\x20" x ($length+
(0x1ca2+ 1812-0x23b5))));(my $readLength=(0x198f+  11-0x199a));(my $FD_correct=
$FD_passed);if ((ref ($FD_passed)and isNXLibraryLoadedForModule ())){if ((
$$FD_passed=~ /\*main::(\d+)/ )){($FD_correct=$1);}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20".
$$FD_passed)."\x20\x74\x6f\x20\x69\x6e\x74"));nxexit ();}}($readLength=
libnxh::NXRead ($FD_correct,$tmpRead,$length));if ((not (defined ($readLength)))
){return (undef);}elsif (($readLength>(0x0326+ 7363-0x1fe9))){($$readBuffer=
substr ($tmpRead,(0x1426+ 4424-0x256e),$readLength));return ($readLength);}elsif
 (($readLength==(-(0x0799+ 6190-0x1fc6)))){return (undef);}else{return (
$readLength);}}sub nxwrite{(my $FD_passed=shift (@_));(my $message=shift (@_));
if ((not (defined ($message)))){($message=(""));}(my $length=(shift (@_)||length
 ($message)));(my $offset=shift (@_));(my $silent=(shift (@_)||
(0x0444+ 407-0x05db)));if (($length==(0x0633+ 8134-0x25f9))){return;}(my (
$package,$filename,$line,$sub)=caller ((0x0808+ 1048-0x0c1f)));(my $FD_correct=
$FD_passed);if ((ref ($FD_passed)and isNXLibraryLoadedForModule ())){if ((
$$FD_passed=~ /\*main::(\d+)/ )){($FD_correct=$1);}else{nxwrite (
(0x02ff+ 786-0x060f),((
"\x6e\x78\x77\x72\x69\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20"
.$$FD_passed).
"\x20\x74\x6f\x20\x69\x6e\x74\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x65\x2e\x0a"))
;nxexit ();}}if ((defined ($offset)and ($offset ne ("")))){if (
isNXLibraryLoadedForModule ()){(my $nxwriteReturn=libnxh::NXWrite ($FD_correct,
$message,$length));if ((($nxwriteReturn==(-(0x1731+ 2873-0x2269)))and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x54\x6f\x4c\x6f\x67\x66\x69\x6c\x65"
))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x46\x44\x23".
$FD_correct)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));}return ($nxwriteReturn);}return (syswrite (
$FD_correct,$message,$length,$offset));}if (isNXLibraryLoadedForModule ()){(my $nxwriteReturn
=libnxh::NXWrite ($FD_correct,$message,$length));if ((($nxwriteReturn==(-
(0x0f69+ 4058-0x1f42)))and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x54\x6f\x4c\x6f\x67\x66\x69\x6c\x65"
))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x46\x44\x23".
$FD_correct)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));}return ($nxwriteReturn);}return (syswrite (
$$FD_correct,$message,$length));}sub setRunCommandEnv{(
@NXCore::runCommandEnvironment=@_);}sub getRunCommandEnv{return (
@NXCore::runCommandEnvironment);}sub cleanRunCommandEnv{(
@NXCore::runCommandEnvironment=());}sub setRunCommandPriority{(
$NXCore::runCommandPriority=shift (@_));}sub getRunCommandPriority{return (
$NXCore::runCommandPriority);}sub setCommandEnvironment{(my (@envToSet)=
getRunCommandEnv ());while ((my $key=shift (@envToSet))){(my $value=shift (
@envToSet));($ENV{$key}=$value);Logger::debug ((((
"\x73\x65\x74\x43\x6f\x6d\x6d\x61\x6e\x64\x45\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74\x20\x27"
.$key)."\x27\x3d").$ENV{$key}),(0x0a18+ 2208-0x12b7));}}sub isNodeNormalPriority
{if ((getNodePriority ()eq "\x6e\x6f\x72\x6d\x61\x6c")){return (
(0x12c9+ 4809-0x2591));}return ((0x0247+ 6864-0x1d17));}sub isNodeLowPriority{if
 ((getNodePriority ()eq "\x6c\x6f\x77")){return ((0x1615+ 4259-0x26b7));}return 
((0x06b5+ 4956-0x1a11));}sub setNodePriority{($NXCore::nodePriority=shift (@_));
}sub getNodePriority{if (($NXCore::nodePriority eq "\x6e\x6f\x74\x53\x65\x74")){
($NXCore::nodePriority=$GLOBAL::DisplayAgentPriority);}return (
$NXCore::nodePriority);}sub addDescriptorToNXPLArray{(my $descriptor=shift (@_))
;if (exists ($NXCore::NXPLDescriptorsArray{$descriptor})){Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$descriptor).
"\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x69\x6e\x20\x4e\x58\x50\x4c\x20\x61\x72\x72\x61\x79\x2e"
));}else{($NXCore::NXPLDescriptorsArray{$descriptor}=(0x14b7+ 723-0x1789));
Logger::debug ((("\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".
$descriptor).
"\x20\x61\x64\x64\x65\x64\x20\x74\x6f\x20\x4e\x58\x50\x4c\x20\x61\x72\x72\x61\x79\x2e"
));}}sub removeDescriptorFromNXPLArray{(my $descriptor=shift (@_));if (exists (
$NXCore::NXPLDescriptorsArray{$descriptor})){delete (
$NXCore::NXPLDescriptorsArray{$descriptor});Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$descriptor).
"\x20\x64\x65\x6c\x65\x74\x65\x64\x20\x66\x72\x6f\x6d\x20\x4e\x58\x50\x4c\x20\x61\x72\x72\x61\x79\x2e"
));}else{Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$descriptor).
"\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x4e\x58\x50\x4c\x20\x61\x72\x72\x61\x79\x2e"
));}}sub ioShouldBeDoneThroughNXPL{(my $descriptor=shift (@_));if (exists (
$NXCore::NXPLDescriptorsArray{$descriptor})){return ((0x042a+ 8226-0x244b));}
else{return ((0x04db+ 6138-0x1cd5));}}sub parse_config_line{(my $line=shift (@_)
);(my $acceptable_keys=shift (@_));chomp ($line);($line=main::trimLine ($line));
if (($line=~ /^[ \t]*#/ )){return;}elsif (($line=~ /^([ \t]*([^=;#]+)\s[ \s=]*"([^"]*))"$/ )
){(my ($key,$value)=($2,$3));($key=main::trimLine ($key));($value=main::trimLine
 ($value));if ((not (defined ($value)))){($value=(""));}if ((($key=~ /(^$acceptable_keys$)/ )
or ($GLOBAL::REFRESH_CFG==(0x03c0+ 4402-0x14f1)))){main::redefine ($key,$value);
}}else{(my ($key,$value)=split ( / / ,$line,(0x131b+ 4511-0x24b8)));($key=
main::trimLine ($key));($value=~ s/(=|")//g );($value=main::trimLine ($value));
if (($value=~ /\s/ )){return;}if (((not (defined ($value)))or ($value eq (""))))
{if (($key eq 
"\x44\x69\x73\x61\x62\x6c\x65\x50\x65\x72\x73\x69\x73\x74\x65\x6e\x74\x53\x65\x73\x73\x69\x6f\x6e"
)){($value=(""));}else{return;}}if ((($key=~ /(^$acceptable_keys$)/ )or (
$GLOBAL::REFRESH_CFG==(0x1a12+ 191-0x1ad0)))){main::redefine ($key,$value);}}}
sub parse_config_line_init{(my $line=shift (@_));(my $config_file=shift (@_));
chomp ($line);($line=main::trimLine ($line));if ((($line eq (""))or ($line=~ /^#/ )
)){return;}elsif (($line=~ /^([ \t]*([^=;#]+)\s[ \s=]*"([^"]*))"$/ )){(my ($key,
$value)=($2,$3));($key=main::trimLine ($key));($value=main::trimLine ($value));
if ((not (defined ($value)))){($value=(""));}if ((($key=~ /(^$GLOBAL::OVERRIDABLE_USER_CONFIG_KEYS$)/ )
or ($GLOBAL::REFRESH_CFG==(0x08a8+ 1880-0x0fff)))){main::redefine ($key,$value);
}else{(my $kkey=("\x47\x4c\x4f\x42\x41\x4c\x3a\x3a".$key));if (defined ($$kkey))
{Logger::debug (((((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x6b\x65\x79\x20\x27"
.$key).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x72\x65\x64\x65\x66\x69\x6e\x65\x64\x20\x69\x6e\x20\x27"
).$config_file)."\x27"),(0x1362+ 1762-0x1a44));}else{main::define ($key,$value);
}}}else{(my ($key,$value)=split ( /\s/ ,$line,(0x1659+ 3866-0x2571)));($key=
main::trimLine ($key));if (($value=~ /^=(.*)/ )){($value=$1);}($value=~ s/"//g )
;($value=main::trimLine ($value));if (($value=~ /\s/ )){return;}if (((not (
defined ($value)))or ($value eq ("")))){if (((($key eq 
"\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x4c\x69\x62\x72\x61\x72\x79\x50\x72\x65\x6c\x6f\x61\x64"
)or ($key eq 
"\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x4c\x69\x62\x72\x61\x72\x79\x50\x61\x74\x68"
))or ($key eq 
"\x43\x6c\x69\x65\x6e\x74\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x65\x74\x68\x6f\x64\x73"
))){($value=(""));}else{return;}}if ((($key=~ /(^$GLOBAL::OVERRIDABLE_USER_CONFIG_KEYS$)/ )
or ($GLOBAL::REFRESH_CFG==(0x0618+ 3280-0x12e7)))){if ((
$GLOBAL::KEYS_WITH_YES_NO_NONE_ACCEPT_VALUE=~ /\($key\)/ )){if ((($value eq 
"\x79\x65\x73")or ($value eq "\x65\x6e\x61\x62\x6c\x65\x64"))){($value=
(0x0df8+ 2846-0x1915));}elsif (((($value eq "\x6e\x6f")or ($value eq 
"\x6e\x6f\x6e\x65"))or ($value eq "\x64\x69\x73\x61\x62\x6c\x65\x64"))){($value=
(0x0723+ 6156-0x1f2f));}}main::redefine ($key,$value);}else{(my $kkey=(
"\x47\x4c\x4f\x42\x41\x4c\x3a\x3a".$key));if (defined ($$kkey)){Logger::debug ((
(((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x6b\x65\x79\x20\x27"
.$key).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x72\x65\x64\x65\x66\x69\x6e\x65\x64\x20\x69\x6e\x20\x27"
).$config_file)."\x27"),(0x0d54+ 1627-0x13af));}else{main::define ($key,$value);
}}}}sub define{(my ($key,$value)=@_);(my $kkey=(
"\x47\x4c\x4f\x42\x41\x4c\x3a\x3a".$key));if (((not (defined ($$kkey)))or (
$GLOBAL::REFRESH_CFG==(0x0418+ 8503-0x254e)))){($$kkey=$value);}}sub 
parse_buffer{(my $buffer=shift (@_));(my $config_file=shift (@_));(my $acceptable_keys
=(shift (@_)||(-(0x020b+ 4220-0x1286))));(my $finish=(0x0179+ 7747-0x1fbc));(my $firstchar
=(""));(my $line=(""));(my $oldline=(""));(my $oldpos=(-(0x149f+ 1934-0x1c2c)));my (
$newpos);while ((not ($finish))){if (($buffer=~ /\G(.*)([\n])/cg )){($firstchar=
substr ($1,(0x0339+ 7019-0x1ea4),(0x0b60+ 3411-0x18b2)));if (($2 eq (""))){(
$buffer=~ /\G(.*)$/g );($oldline=$1);($finish=(0x05f0+ 6734-0x203d));}else{(
$line=($1."\x0a"));if (($acceptable_keys==(-(0x02c3+ 6108-0x1a9e)))){
parse_config_line_init ($line,$config_file);}else{parse_config_line ($line,
$acceptable_keys);}}}else{($finish=(0x04ac+ 237-0x0598));}}return ($oldline);}
sub init_by_config_file{(my ($config_file,$errorString_ref)=@_);my ($fd);my (
$errorNumber);if ((not (defined ($config_file)))){Logger::error (
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65"
,(0x17c4+ 1391-0x1d32));error ("\x69\x6e\x69\x74",
"\x69\x6e\x69\x74\x20\x62\x79\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65",
"\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65"
);}if (Common::NXFile::isExists ($config_file)){($fd=main::nxopen ($config_file,
$NXBits::FileOpenRead,(0x0ee8+ 2243-0x17ab)));($errorNumber=libnxh::NXGetError 
());($$errorString_ref=libnxh::NXGetErrorString ());}else{return (
(0x08cf+ 5346-0x1db0));}if ((not (defined ($fd)))){Logger::error (((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x3a\x20\x27"
.$config_file)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$$errorString_ref)."\x2e"));return ((0x0a0b+ 3228-0x16a6));}Logger::debug (((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x70\x61\x72\x73\x65\x20\x6f\x66\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65\x20\x27"
.$config_file)."\x27"),(0x0981+ 2944-0x1501));(my $processName=
NXBegin::getProcessName ());Logger::debug ((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x65\x64\x3a\x20"
.$processName),(0x1ae4+ 763-0x1ddf));my ($buffer);while (main::nxreadLine ($fd,(
\$buffer))){parse_config_line_init ($buffer,$config_file);}main::nxclose ($fd);
return ((0x18d9+ 2257-0x21aa));}sub parse_config_file{(my ($config_file,
$acceptable_keys)=@_);my ($FILEH);if ((not (defined ($config_file)))){
Logger::error (
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65"
,(0x0deb+ 2396-0x1746));error ("\x69\x6e\x69\x74",
"\x69\x6e\x69\x74\x20\x62\x79\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65",
"\x69\x6e\x63\x6f\x72\x72\x65\x63\x74\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x61\x6c\x6c\x2c\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x72\x61\x6d\x65\x74\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65"
);}if (Common::NXFile::isExists ($config_file)){($FILEH=main::nxopen (
$config_file,$NXBits::FileOpenRead,(0x0982+ 6083-0x2145)));}else{return (
(0x208d+ 339-0x21df));}if ((not (defined ($FILEH)))){return (
(0x09f3+ 6522-0x236c));}Logger::debug (((
"\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x61\x74\x69\x6f\x6e\x3a\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x70\x61\x72\x73\x65\x20\x6f\x66\x20\x63\x6f\x6e\x66\x69\x67\x20\x66\x69\x6c\x65\x20\x27"
.$config_file)."\x27"),(0x11bf+ 1665-0x1840));my ($buffer);while (
main::nxreadLine ($FILEH,(\$buffer))){parse_config_line ($buffer,
$acceptable_keys);}main::nxclose ($FILEH);return ((0x0988+ 4151-0x19bf));}sub 
reportErrorFromNXPL{(my $errorText=shift (@_));if (($errorText ne (""))){
Logger::error ($errorText);}else{(my ($package,$filename,$line,$sub)=caller (
(0x0f5a+ 3141-0x1b9e)));Logger::error (((
"\x54\x68\x65\x72\x65\x20\x69\x73\x20\x65\x72\x72\x6f\x72\x20\x77\x69\x74\x68\x20\x4e\x58\x50\x4c\x20\x69\x6e\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20"
.$sub)."\x2e"));}(my $errorString=logErrorFromNXPL ());return ($errorString);}
sub logErrorFromNXPL{(my $errorNumber=libnxh::NXGetError ());(my $errorName=
libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());my (
$reportedError);if ((($errorName ne (""))and ($errorName ne 
"\x53\x75\x63\x63\x65\x73\x73"))){if ((($errorNumber ne (""))and ($errorNumber 
ne "\x30"))){($reportedError=(($errorNumber."\x2c\x20").$errorName));}elsif (((
$errorString ne (""))and ($errorString ne "\x4e\x6f\x20\x65\x72\x72\x6f\x72"))){
($reportedError=(($errorName."\x2c\x20").$errorString));}else{($reportedError=
$errorName);}}elsif ((($errorNumber ne (""))and ($errorNumber ne "\x30"))){(
$reportedError=(($errorNumber."\x2c\x20").$errorName));}else{($reportedError=
"\x4e\x58\x50\x4c\x20\x64\x69\x64\x6e\x27\x74\x20\x72\x65\x70\x6f\x72\x74\x20\x74\x68\x65\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65\x72\x72\x6f\x72"
);Logger::debug2 (($reportedError."\x2e"));return ($reportedError);}
Logger::error ((("\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$reportedError)."\x2e"))
;return ($reportedError);}sub nxPipeCreateMono{(my $socket1=shift (@_));(my $socket2
=shift (@_));(my $ret=libnxh::NXPipeCreate ($$socket1,$$socket2,
(0x1145+ 1808-0x1855)));if (($ret==(-(0x0803+ 3874-0x1724)))){(my $errorName=
libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning ((((
"\x43\x6f\x75\x6c\x64\x6e\x27\x74\x20\x63\x72\x65\x61\x74\x65\x20\x70\x69\x70\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorName)."\x2c\x20").$errorString));return ((0x0326+ 6285-0x1bb3));}
closeSocketAtFinish ($$socket1);closeSocketAtFinish ($$socket2);Logger::debug ((
((((("\x4e\x58\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x28\x46\x44\x23".
$$socket1)."\x2c\x20\x46\x44\x23").$$socket2).
"\x2c\x20\x30\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$ret)."\x27"));
return (($ret+(0x04d0+ 4893-0x17ec)));}sub nxPipeCreateBiWithError{(my $ref_socket1
=shift (@_));(my $ref_socket2=shift (@_));(my $ref_error=shift (@_));(my $ret=
libnxh::NXPipeCreate ($$ref_socket1,$$ref_socket2,(0x17f9+ 1937-0x1f89)));if ((
$ret==(-(0x058f+ 5628-0x1b8a)))){(my $errorName=libnxh::NXGetErrorName ());(my $errorString
=libnxh::NXGetErrorString ());Logger::warning (((((
"\x43\x6f\x75\x6c\x64\x6e\x27\x74\x20\x63\x72\x65\x61\x74\x65\x20\x70\x69\x70\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorName)."\x2c\x20").$errorString)."\x2e"));($$ref_error=$errorString);
return ((0x0c72+ 5194-0x20bc));}closeSocketAtFinish ($$ref_socket1);
closeSocketAtFinish ($$ref_socket2);Logger::debug (((((((
"\x4e\x58\x50\x69\x70\x65\x43\x72\x65\x61\x74\x65\x28\x46\x44\x23".$$ref_socket1
)."\x2c\x20\x46\x44\x23").$$ref_socket2).
"\x2c\x20\x31\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20").$ret)."\x2e"));
return (($ret+(0x01ef+ 1929-0x0977)));}sub nxPipeCreateBi{(my $ref_socket1=shift
 (@_));(my $ref_socket2=shift (@_));my ($error);return (nxPipeCreateBiWithError 
($ref_socket1,$ref_socket2,(\$error)));}sub nxRunCommand{(my ($command,$options)
=@_);(my $silent=(shift (@_)||(0x00a4+ 2992-0x0c54)));(my $runcommand=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64"
->new);$runcommand->setCommand (@$command);$runcommand->setOptions (@$options);(my (
$cmd_err,$cmd_out,$exit_value)=$runcommand->run);if ((((!$cmd_err)==
(0x1699+ 1909-0x1e0e))and ($silent==(0x0737+ 8108-0x26e3)))){Logger::warning ((
"\x45\x72\x72\x6f\x72\x20\x64\x75\x72\x69\x6e\x67\x20\x74\x68\x65\x20\x65\x78\x65\x63\x75\x74\x69\x6f\x6e\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e\x20"
.$cmd_out));}return ($cmd_err,$cmd_out,$exit_value);}sub nxRunCommandBg{(my (
$command,$options,$stdin,$stdout,$stderr)=@_);my ($rcOut,$rcErr,$rcExit);(my $runcommand
=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64"
->new);$runcommand->setRunCommandInBG;$runcommand->setSaveStdinTo ($stdin);
$runcommand->setSaveStdoutTo ($stdout);$runcommand->setSaveStderrTo ($stderr);
$runcommand->setCommand (@$command);$runcommand->setOptions (@$options);(($rcOut
,$rcErr,$rcExit)=$runcommand->run);return ($rcOut,$rcErr,$rcExit);}sub 
nxExecCommand{(my ($command,$options)=@_);(my $silent=(shift (@_)||
(0x1627+ 2694-0x20ad)));(my $runcommand=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64"
->new);$runcommand->setCommandForExec (@$command);$runcommand->setOptions (
@$options);$runcommand->setExecCommand;(my $error=$runcommand->run);if (($error 
ne (""))){Logger::warning ((((
"\x45\x72\x72\x6f\x72\x20\x64\x75\x72\x69\x6e\x67\x20\x74\x68\x65\x20\x65\x78\x65\x63\x75\x74\x69\x6f\x6e\x20\x6f\x66\x20\x74\x68\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e\x20"
.$cmd_out)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").$error));return (
$error);}return ((""));}sub run_setup{(my $name=shift (@_));(my $name2=(shift (
@_)||("")));(my $run_in_bg=(0x2511+ 429-0x26bd));($name=("\x2d\x2d".$name));if (
($name2 ne (""))){if (($name2 eq "\x6e\x6f\x62\x67")){($run_in_bg=
(0x00b7+ 6223-0x1906));($name2=(""));}else{($name2=("\x2d\x2d".$name2));}}my (
$CommandSetup);if (($GLOBAL::SOFTWARE_NAME eq "\x4e\x58\x53\x45\x52\x56\x45\x52"
)){($CommandSetup=(((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x63\x72\x69\x70\x74\x73").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x74\x75\x70"
).$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72"));}else{(
$CommandSetup=(((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x63\x72\x69\x70\x74\x73").$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x74\x75\x70"
).$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x6e\x6f\x64\x65"));}Logger::debug (
"\x52\x75\x6e\x6e\x69\x6e\x67\x20\x72\x75\x6e\x5f\x73\x65\x74\x75\x70",
(0x0d05+ 3961-0x1c7e));(my (@command)=());if (($name2 eq (""))){(@command=(
$GLOBAL::CommandBash,"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote
 ($CommandSetup,$name)));}else{(@command=($GLOBAL::CommandBash,
"\x2d\x2d\x6c\x6f\x67\x69\x6e","\x2d\x63",main::shell_quote ($CommandSetup,$name
,$name2)));}(my (@options)=());my ($childPid);push (@options,
"\x67\x65\x74\x20\x70\x69\x64",(\$childPid));if (($run_in_bg==
(0x0c63+ 685-0x0f0f))){push (@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");}(my (
$cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@options)));
Common::NXProcess::leaveChildAtFinish ($childPid);return ($cmd_err,$cmd_out,
$exit_value);}sub encodeBase64{(my $message=shift (@_));(my $size=length (
$message));(my $max=($size *(0x05d1+ 1585-0x0c00)));(my $buffer=("\x20" x $max))
;(my $sizeEncoded=libnxh::NXB64Encode ($message,$size,$buffer,$max));(my $encodedMessage
=substr ($buffer,(0x236c+  23-0x2383),$sizeEncoded));return ($encodedMessage);}
sub decodeBase64{(my $encodedMessage=shift (@_));(my $size=length (
$encodedMessage));(my $max=($size *(0x0197+ 8865-0x2436)));(my $buffer=("\x20" x
 $max));(my $sizeDecoded=libnxh::NXB64Decode ($encodedMessage,$size,$buffer,$max
));(my $decodedMessage=substr ($buffer,(0x0b15+ 6469-0x245a),$sizeDecoded));
return ($decodedMessage);}sub nxexit{(my $return=shift (@_));
NXBegin::finalizeProcess ();exit ($return);}sub assertExit{(my $return=shift (@_
));(my ($package,$filename,$line,$sub)=caller ((0x14c9+ 3142-0x210e)));if (($sub
 eq (""))){($sub=$package);}if ((($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x73\x65\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x54\x6f\x4c\x6f\x67\x66\x69\x6c\x65"
)and ($sub ne 
"\x4c\x6f\x67\x67\x65\x72\x3a\x3a\x63\x6c\x6f\x73\x65\x4c\x6f\x67\x46\x69\x6c\x65"
))){Logger::warning (((
"\x41\x73\x73\x65\x72\x74\x20\x66\x61\x69\x6c\x65\x64\x20\x66\x72\x6f\x6d\x20".
$sub)."\x2e"));}return ((0x12d9+ 1969-0x1a8a));}sub nxAcceptSocket{(my $socket=
shift (@_));(my $silent=(shift (@_)||(0x1858+ 339-0x19ab)));(my $fd=
libnxh::NXAccept ($socket));(my $error=libnxh::NXGetError ());(my $errorName=
libnxh::NXGetErrorName ());(my $errorString=libnxh::NXGetErrorString ());if ((
not (defined ($fd)))){if (($silent==(0x0ca2+ 1048-0x10ba))){Logger::warning ((((
(((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x70\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$socket)."\x3a\x20").$error)."\x2c\x20").$errorString)."\x2e"));}return (undef)
;}elsif (($fd==(-(0x0769+ 4943-0x1ab7)))){if (($silent==(0x0bef+ 710-0x0eb5))){
Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x70\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$socket)."\x3a\x20").$error)."\x2c\x20").$errorString)."\x2e"));}return (undef)
;}else{Logger::debug (((((
"\x41\x63\x63\x65\x70\x74\x65\x64\x20\x6f\x6e\x20\x46\x44\x23".$socket).
"\x3a\x20\x46\x44\x23").$fd)."\x2e"));libnxh::NXDescriptorInheritable ($fd,
(0x1211+ 2071-0x1a28));closeSocketAtFinish ($fd);return ($fd);}}sub checkSocket{
(my $port=shift (@_));(my $nxplReturn=libnxh::NXTryBindLocal (
(0x0b0a+ 2800-0x15f9),$port));Logger::debug ((((
"\x4e\x58\x54\x72\x79\x42\x69\x6e\x64\x4c\x6f\x63\x61\x6c\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x3a\x20"
.$port)."\x20\x72\x65\x74\x75\x72\x6e\x3a\x20").$nxplReturn));if (($nxplReturn 
eq (0x1957+ 1742-0x2024))){return ((0x0b01+ 3237-0x17a6));}elsif (($nxplReturn 
eq (-(0x091f+ 2315-0x1229)))){return ((0x0e75+ 1510-0x145a));}else{(my $error=
libnxh::NXGetErrorName ());Logger::warning (((((((
"\x4e\x58\x54\x72\x79\x42\x69\x6e\x64\x4c\x6f\x63\x61\x6c\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27"
.$port).
"\x27\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x76\x61\x6c\x75\x65\x20\x27"
).$nxplReturn)."\x27\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x3a\x20\x27").
$error)."\x27\x2e"));return ((0x1079+ 2473-0x1a21));}}sub checkUnixSocket{(my $socketName
=shift (@_));(my $isAbstract=shift (@_));(my $str=($isAbstract?
"\x61\x62\x73\x74\x72\x61\x63\x74\x20":("")));(my $nxplReturn=
libnxh::NXTryConnectUnixSocket ($socketName,$isAbstract));Logger::debug ((((((
"\x4e\x58\x54\x72\x79\x43\x6f\x6e\x6e\x65\x63\x74\x55\x6e\x69\x78\x53\x6f\x63\x6b\x65\x74\x20\x66\x6f\x72\x20"
.$str)."\x73\x6f\x63\x6b\x65\x74\x3a\x20").$socketName).
"\x20\x72\x65\x74\x75\x72\x6e\x3a\x20").$nxplReturn));if (($nxplReturn eq 
(0x04e8+ 6603-0x1eb2))){return ((0x1602+ 3021-0x21ce));}elsif (($nxplReturn eq (
-(0x0781+ 345-0x08d9)))){return ((0x009b+ 9516-0x25c7));}else{(my $error=
libnxh::NXGetErrorName ());Logger::warning (((((((((
"\x4e\x58\x54\x72\x79\x43\x6f\x6e\x6e\x65\x63\x74\x55\x6e\x69\x78\x53\x6f\x63\x6b\x65\x74\x20\x66\x6f\x72\x20"
.$str)."\x73\x6f\x63\x6b\x65\x74\x20\x27").$socketName).
"\x27\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x76\x61\x6c\x75\x65\x20\x27"
).$nxplReturn)."\x27\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x3a\x20\x27").
$error)."\x27\x2e"));return ((0x0524+ 6018-0x1ca5));}}sub nxListenOnSocket{(my $port
=shift (@_));(my $silent=(shift (@_)||(0x0972+ 6941-0x248f)));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4f\x70\x65\x6e\x53\x6f\x63\x6b\x65\x74\x54\x6f\x4c\x69\x73\x74\x65\x6e\x45\x78\x28"
.$port)."\x2c\x20\x31\x30\x30\x2c\x20\x31\x2c\x20\x31\x29"));(my $FD=
libnxh::NXOpenSocketToListenEx ($port,(0x01b9+ 3132-0x0d91),
(0x14f4+ 3299-0x21d6),(0x0b9c+ 2502-0x1561)));if (($FD==(-(0x0043+ 4529-0x11f3))
)){(my $error=libnxh::NXGetError ());(my $errorName=libnxh::NXGetErrorName ());(my $errorString
=libnxh::NXGetErrorString ());if ((($silent==(0x15ba+ 2545-0x1fab))and (
$errorName ne "\x45\x41\x44\x44\x52\x49\x4e\x55\x53\x45"))){Logger::warning ((((
((("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x70\x6f\x72\x74\x20\x27".
$port)."\x27\x20\x74\x6f\x20\x6c\x69\x73\x74\x65\x6e\x3a\x20").$error).
"\x2c\x20").$errorString)."\x2e"));return ((-(0x037d+ 7786-0x21e5)));}return ((-
(0x0c83+ 156-0x0d1e)));}Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4f\x70\x65\x6e\x53\x6f\x63\x6b\x65\x74\x54\x6f\x4c\x69\x73\x74\x65\x6e\x45\x78\x28"
.$port).
"\x2c\x20\x31\x30\x30\x2c\x20\x31\x2c\x20\x31\x29\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x46\x44\x23"
).$FD)."\x2e"));(my $ret=libnxh::NXDescriptorInheritable ($FD,
(0x1064+ 3258-0x1d1e)));unless ($ret){Logger::warning (((
"\x6e\x78\x4c\x69\x73\x74\x65\x6e\x4f\x6e\x53\x6f\x63\x6b\x65\x74\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x69\x6e\x68\x65\x72\x69\x74\x65\x64\x20\x66\x6c\x61\x67\x20\x6f\x6e\x20\x46\x44\x23"
.$FD)."\x2e"));}closeSocketAtFinish ($FD);return ($FD);}sub nxconnect{(my $addr=
shift (@_));(my $port=shift (@_));(my $silence=(shift (@_)||"\x6e\x6f"));(my (
$package,$filename,$line,$sub)=caller ((0x0694+ 6391-0x1f8a)));if (($sub eq ("")
)){($sub=$package);}if ((not (defined ($port)))){Logger::error (((((
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x3a\x20".$addr).
"\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x63\x61\x6c\x6c\x20\x66\x72\x6f\x6d\x20"
).$sub)."\x2e"));nxexit ();}Logger::debug (((((((
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20".$addr)."\x20").$port).
"\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));(my $ret=libnxh::NXConnect ($addr,
$port));(my $error=libnxh::NXGetErrorName ());(my $errorstring=
libnxh::NXGetErrorString ());if (($ret==(-(0x1314+ 3894-0x2249)))){if (($silence
 eq "\x6e\x6f")){Logger::warning (((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20"
.$addr)."\x2c\x20").$port)."\x3a\x20").$errorstring)."\x20\x66\x72\x6f\x6d\x20")
.$sub)."\x2e"));}return ($ret);}Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x20\x72\x65\x74\x75\x72\x6e\x3a\x20\x46\x44\x23"
.$ret)."\x2e"));libnxh::NXDescriptorInheritable ($ret,(0x0029+ 8244-0x205d));
closeSocketAtFinish ($ret);return ($ret);}sub nxTryLock{(my $filepath=shift (@_)
);(my $mode=shift (@_));(my $tryLock=libnxh::NXFileTryLock ($filepath,$mode));(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());if ((
$tryLock==(-(0x0710+ 4458-0x1879)))){Logger::warning (((((
"\x4e\x58\x46\x69\x6c\x65\x54\x72\x79\x4c\x6f\x63\x6b\x28".$filepath)."\x2c\x20"
).$mode)."\x29\x20\x66\x61\x69\x6c\x65\x64\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));return ((0x0660+ 1670-0x0ce6));}Logger::debug2 ((((((
("\x4e\x58\x46\x69\x6c\x65\x54\x72\x79\x4c\x6f\x63\x6b\x28".$filepath).
"\x2c\x20").$mode)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$tryLock)
."\x27\x2e"));return ($tryLock);}sub nxflock{(my $filepath=shift (@_));(my $mode
=shift (@_));(my $flock=libnxh::NXFileLock ($filepath,$mode));Logger::debug ((((
(((
"\x6e\x78\x66\x6c\x6f\x63\x6b\x3a\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x46\x69\x6c\x65\x4c\x6f\x63\x6b\x28"
.$filepath)."\x2c\x20").$mode).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27").$flock)."\x27\x2e"));if ((
$flock==(-(0x169f+ 2752-0x215e)))){($flock=(0x14fd+ 3232-0x219d));}return (
$flock);}sub redirectStderrNXPL{(my $path=shift (@_));if (((not (defined ($path)
))or ($path ne ("")))){Logger::debug (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x65\x72\x72\x20\x77\x69\x74\x68\x6f\x75\x74\x20\x70\x61\x74\x68"
);}if (defined ($NXBegin::oldSTDERR)){(my $fd_copy=libnxh::NXFileClone (
$NXBegin::oldSTDERR,(0x1a38+ 2304-0x2336)));main::nxclose ($NXBegin::oldSTDERR);
($NXBegin::oldSTDERR=undef);}else{($NXBegin::oldSTDERR=libnxh::NXFileDuplicate (
(0x0c4d+ 5504-0x21cb)));Logger::debug (((
"\x44\x75\x70\x6c\x69\x63\x61\x74\x65\x20\x6f\x66\x20\x53\x54\x44\x45\x52\x52\x20\x66\x64\x20\x69\x73\x3a\x20\x5b"
.$NXBegin::oldSTDERR)."\x5d"));(my $TMPFILE=main::nxopen ($path,(
$NXBits::O_CREAT+$NXBits::O_WRONLY),(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersWrite)));(my $fd_copy=
libnxh::NXFileClone ($TMPFILE,(0x0d59+ 2716-0x17f3)));}}sub nxsetSTDIN{(my $int=
shift (@_));($GLOBAL::DefaultSTDINDescriptor=$int);}sub nxsetSTDOUT{(my $int=
shift (@_));($GLOBAL::DefaultSTDOUTDescriptor=$int);}sub nxsetSTDERR{(my $int=
shift (@_));($NXBegin::STDERRint=$int);}sub nxgetSTDIN{if (
isNXLibraryLoadedForModule ()){return ($GLOBAL::DefaultSTDINDescriptor);}else{
return ((\*STDIN));}}sub nxgetSTDOUT{if (isNXLibraryLoadedForModule ()){return (
$GLOBAL::DefaultSTDOUTDescriptor);}else{return ((\*STDOUT));}}sub nxgetSTDERR{if
 (isNXLibraryLoadedForModule ()){return ($STDERR);}else{return ((\*STDERR));}}
sub nxsleep{(my $sleep=shift (@_));(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add (
$signalFd);$selector->can_read (($sleep *(0x0c9a+ 4284-0x196e)),
"\x73\x69\x6c\x65\x6e\x74");return;}sub nxcheckPipe{(my $fh=shift (@_));(my $return
=libnxh::NXSelect ($fh,(0x1847+ 3042-0x2428)));if (($return==
(0x0fb7+ 932-0x135b))){return ((0x0bad+ 3402-0x18f7));}($return=~ /(\d):(.*)/ );
(my $exitcode=$1);return ($exitcode);}sub closeSocketAtFinish{(my $fh=shift (@_)
);($$NXBegin::SocketsToClose{$fh}=(0x13e9+ 2565-0x1ded));}sub 
doNotCloseSocketAtFinish{(my $fh=shift (@_));Logger::debug (((
"\x4e\x58\x43\x6f\x72\x65\x3a\x20\x44\x6f\x20\x6e\x6f\x74\x20\x63\x6c\x6f\x73\x65\x20\x61\x74\x20\x66\x69\x6e\x69\x73\x68\x20\x46\x44\x23"
.$fh)."\x2e"));delete ($$NXBegin::SocketsToClose{$fh});}sub hideOutput{(my $log=
shift (@_));if ((not (defined ($log)))){return ((""));}($log=~ s/\w{32}/*****/gm )
;return ($log);}sub urlencode{(my ($string)=@_);if ((length ($string)==
(0x1416+ 355-0x1579))){Logger::debug3 (
"\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x3a\x20\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x65\x6e\x63\x6f\x64\x65\x2e"
);return ($string);}(my $buffer=("\x20" x ((length ($string)*
(0x0ff4+ 5724-0x264d))+(0x2292+ 466-0x2462))));(my $length=libnxh::NXUrlEncode (
$string,$buffer,length ($buffer)));if (($length==(-(0x0232+ 1525-0x0826)))){
Logger::warning (
"\x75\x72\x6c\x65\x6e\x63\x6f\x64\x65\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x65\x6e\x63\x6f\x64\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e\x0a"
);return ((-(0x0d2f+ 1815-0x1445)));}(my $result=substr ($buffer,
(0x0b10+ 7073-0x26b1),$length));return ($result);}sub urldecode{(my ($string)=@_
);if ((length ($string)==(0x0e33+ 6187-0x265e))){Logger::debug3 (
"\x75\x72\x6c\x64\x65\x63\x6f\x64\x65\x3a\x20\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x64\x65\x63\x6f\x64\x65\x2e"
);return ($string);}(my $buffer=("\x20" x ((length ($string)*
(0x15cb+ 1225-0x1a91))+(0x12f1+ 3793-0x21c0))));(my $length=libnxh::NXUrlDecode 
($string,$buffer,length ($buffer)));if (($length==(-(0x09a2+ 3248-0x1651)))){
Logger::warning (
"\x75\x72\x6c\x64\x65\x63\x6f\x64\x65\x3a\x20\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x64\x65\x63\x6f\x64\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2e\x0a"
);return ((-(0x1a6f+ 2207-0x230d)));}(my $result=substr ($buffer,
(0x04e9+ 4503-0x1680),$length));return ($result);}sub isCorrectIP{(my $ipToCheck
=shift (@_));(my (@ip)=split ( /%/ ,$ipToCheck,(0x07e3+ 2348-0x110f)));if (($ip[
(0x02bd+ 5024-0x165d)]=~ /^(?:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9](?::|$)){8,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,6})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,6})?))|(?:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){6,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,4})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,4}:)?))?(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}))$/i )
){return ((0x16f9+ 517-0x18fd));}return ((0x0206+ 915-0x0599));}sub 
nxGetDesktopOwner{(my $buffer=("\x20" x (0x0af0+ 3722-0x187a)));(my $bufferLength
=(0x0d87+ 6174-0x24a5));(my $ret=libnxh::NXAppleDesktopOwner ($buffer,
$bufferLength));if (($ret==(-(0x014b+ 5073-0x151b)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());(my $file=
"\x2f\x64\x65\x76\x2f\x63\x6f\x6e\x73\x6f\x6c\x65");(my $desktopOwnerID=(stat (
$file))[(0x1769+  71-0x17ac)]);if (($desktopOwnerID==(0x0767+ 5151-0x1b86))){
return ("\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77");}Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x2e"
);Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20\x27").$errorstring)."\x27\x2e"));return ((-(0x02aa+ 2889-0x0df2)));}(
$buffer=substr ($buffer,(0x1e98+ 1414-0x241e),index ($buffer,"\x00")));return (
$buffer);}sub nxCheckDesktopOwner{(my $user=nxGetDesktopOwner ());if (($user==(-
(0x1a0a+ 386-0x1b8b)))){return ((-(0x1699+  28-0x16b4)));}if (($user eq 
"\x6c\x6f\x67\x69\x6e\x77\x69\x6e\x64\x6f\x77")){Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x70\x70\x6c\x65\x44\x65\x73\x6b\x74\x6f\x70\x4f\x77\x6e\x65\x72\x3a\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x69\x73\x20\x4c\x6f\x67\x69\x6e\x20\x57\x69\x6e\x64\x6f\x77\x2e"
);return ((0x056c+ 1820-0x0c88));}(my $uid=userInfoGetUidByUsername ($user));
Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x70\x70\x6c\x65\x44\x65\x73\x6b\x74\x6f\x70\x4f\x77\x6e\x65\x72\x3a\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x69\x73\x20\x27"
.$user)."\x27\x20\x69\x64\x3a\x20\x27").$uid)."\x27\x2e"));return ($uid);}sub 
digestMd5Hex{(my $data=join ((""),@_));(my $buffer=("\x20" x 
(0x0486+ 5752-0x1ada)));my ($output);(my $errcode=libnxh::NXMd5Hex ($buffer,
$data));if (($errcode!=(-(0x081c+ 1824-0x0f3b)))){($output=substr ($buffer,
(0x1427+ 856-0x177f),(0x0605+ 1701-0x0c8a)));Logger::debug2 ((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x64\x35\x48\x65\x78\x20\x72\x65\x74\x75\x72\x6e\x73\x20"
.$output));return ($output);}else{reportErrorFromNXPL (
"\x64\x69\x67\x65\x73\x74\x4d\x64\x35\x48\x65\x78\x20\x66\x61\x69\x6c\x65\x64\x2e"
);main::nxexit ((0x1e21+ 2024-0x2608));}}sub digestMd5Base64{(my $data=join (
(""),@_));(my $buffer=("\x20" x (0x1f08+ 331-0x202f)));my ($output);(my $errcode
=libnxh::NXMd5B64 ($buffer,$data));if (($errcode!=(-(0x0f64+ 4875-0x226e)))){(
$output=$buffer);($output=~ s/\0// );($output=~ s/=*\s+// );Logger::debug2 ((
"\x64\x69\x67\x65\x73\x74\x4d\x64\x35\x42\x61\x73\x65\x36\x34\x3a\x20\x72\x65\x74\x75\x72\x6e\x69\x6e\x67\x20"
.$output));return ($output);}else{reportErrorFromNXPL (
"\x64\x69\x67\x65\x73\x74\x4d\x64\x35\x42\x36\x34\x20\x66\x61\x69\x6c\x65\x64\x2e"
);main::nxexit ((0x0be8+ 2502-0x15ad));}}sub nxTime{(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));(my $timems=(($sec."\x2e").substr ($milisec,
(0x05e2+ 6801-0x2073),(0x0b35+ 6514-0x24a4))));return ($timems);}sub 
isWMRunningByDisplay{(my $display=shift (@_));my ($errname);Logger::debug ((
"\x69\x73\x57\x4d\x52\x75\x6e\x6e\x69\x6e\x67\x42\x79\x44\x69\x73\x70\x6c\x61\x79\x20\x63\x61\x6c\x6c\x20\x6f\x6e\x20"
.$display));(my $ret=libnxh::NXWmRunning ($display));if (($ret==(-
(0x01b5+ 3467-0x0f3f)))){($errname=libnxh::NXGetErrorName ());if (($errname eq 
"\x45\x54\x49\x4d\x45\x44\x4f\x55\x54")){if ((not (increaseWmrunningTimeout ()))
){Logger::warning (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67\x20\x2d\x20\x6d\x61\x78\x69\x6d\x75\x6d\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x6f\x66\x20"
.$NXCore::WMRunningTimeout_max)."\x20\x72\x65\x61\x63\x68\x65\x64\x2e"));}else{(
$ret=libnxh::NXWmRunning ($display));if (($ret==(-(0x1652+ 133-0x16d6)))){(
$errname=libnxh::NXGetErrorName ());}}}Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x57\x4d\x20\x6f\x6e\x20\x64\x69\x73\x70\x6c\x61\x79\x20"
.$display)."\x20").$errname));}Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67\x28"
.$display)."\x29\x20\x5b").$ret)."\x5d"));return ($ret);}sub 
increaseWmrunningTimeout{if (($NXCore::WMRunningTimeout==
$NXCore::WMRunningTimeout_max)){return ((0x0da5+ 4899-0x20c8));}if (defined (
$GLOBAL::NXWmRunningTimeout)){($NXCore::WMRunningTimeout_max=
$GLOBAL::NXWmRunningTimeout);}($NXCore::WMRunningTimeout=
$NXCore::WMRunningTimeout_max);__setWMRunningTimeout ($NXCore::WMRunningTimeout)
;return ((0x031c+ 4996-0x169f));}sub setDefaultWmrunningTimeout{if ((
$NXCore::WMRunningTimeout==$NXCore::WMRunningTimeout_default)){return (
(0x061d+ 5975-0x1d74));}($NXCore::WMRunningTimeout=
$NXCore::WMRunningTimeout_default);__setWMRunningTimeout (
$NXCore::WMRunningTimeout);return ((0x1f94+ 192-0x2053));}sub 
__setWMRunningTimeout{(my $timeout=shift (@_));Logger::debug (((
"\x53\x65\x74\x74\x69\x6e\x67\x20\x57\x4d\x52\x75\x6e\x6e\x69\x6e\x67\x20\x74\x69\x6d\x65\x6f\x75\x74\x20\x74\x6f\x20\x27"
.$timeout)."\x27\x20\x6d\x73\x2e"));libnxh::NXWmSetTimeout ($timeout);}sub 
initVariable{(my $var=shift (@_));(my $value=shift (@_));($$var=$value);}sub 
initNXPLVariables{(my $variables=libnxh::NXInitConstants ());Logger::debug (((
"\x57\x41\x4e\x20\x69\x6e\x69\x74\x4e\x58\x50\x4c\x56\x61\x72\x69\x61\x62\x6c\x65\x73\x20\x5b"
.$variables)."\x5d\x2e"));initVariable ((\$NXBits::LOCK_SH),@$variables[
(0x12dd+ 2416-0x1c23)]);initVariable ((\$NXBits::LOCK_EX),@$variables[
(0x1855+ 2756-0x22ee)]);initVariable ((\$NXBits::LOCK_NB),(0x11e6+ 168-0x128e));
initVariable ((\$NXBits::UserRead),@$variables[(0x0261+ 4159-0x1291)]);
initVariable ((\$NXBits::UserWrite),@$variables[(0x1952+ 1513-0x1f2b)]);
initVariable ((\$NXBits::UserReadWrite),@$variables[(0x0918+ 7686-0x270d)]);
initVariable ((\$NXBits::UserExecute),@$variables[(0x123d+ 2660-0x1c8f)]);
initVariable ((\$NXBits::GroupAll),@$variables[(0x1071+ 1517-0x164b)]);
initVariable ((\$NXBits::GroupRead),@$variables[(0x00a2+ 3678-0x0eec)]);
initVariable ((\$NXBits::GroupWrite),@$variables[(0x1408+ 3380-0x2127)]);
initVariable ((\$NXBits::GroupReadWrite),@$variables[(0x013c+ 8240-0x2156)]);
initVariable ((\$NXBits::GroupExecute),@$variables[(0x19d6+ 2395-0x231a)]);
initVariable ((\$NXBits::OthersAll),@$variables[(0x1108+ 5271-0x2587)]);
initVariable ((\$NXBits::OthersRead),@$variables[(0x1952+ 2496-0x22f9)]);
initVariable ((\$NXBits::OthersWrite),@$variables[(0x1278+ 1802-0x1968)]);
initVariable ((\$NXBits::OthersReadWrite),@$variables[(0x1815+ 781-0x1b07)]);
initVariable ((\$NXBits::OthersExecute),@$variables[(0x03fc+  38-0x0406)]);
initVariable ((\$NXBits::O_RDWR),@$variables[(0x0813+ 675-0x0ab4)]);initVariable
 ((\$NXBits::O_CREAT),@$variables[(0x00fd+ 4136-0x111f)]);initVariable ((
\$NXBits::O_EXCL),@$variables[(0x0117+ 1059-0x0532)]);initVariable ((
\$NXBits::O_WRONLY),@$variables[(0x13d8+ 1759-0x1ab6)]);initVariable ((
\$NXBits::O_APPEND),@$variables[(0x1456+ 1614-0x1a9f)]);initVariable ((
\$NXBits::O_TRUNC),@$variables[(0x1a2a+  69-0x1a68)]);initVariable ((
\$NXBits::O_RDONLY),@$variables[(0x208c+ 178-0x213e)]);initVariable ((
\$NXBits::FileOpenRead),@$variables[(0x0ec3+ 6116-0x26a7)]);initVariable ((
\$NXBits::O_NONBLOCK),@$variables[(0x1258+ 527-0x145b)]);initVariable ((
\$NXBits::TemporaryAll),@$variables[(0x037f+ 3176-0x0fca)]);($NXBits::IPAny=
(0x0429+ 4074-0x1413));($NXBits::IPv4=(0x142a+ 3603-0x223d));($NXBits::IPv6=
(0x08c4+ 1492-0x0e98));($NXBits::IPNone=(0x0fa2+ 3953-0x1f13));(
$NXBits::SOCK_STREAM=(0x0d23+ 1772-0x140f));($NXBits::SOCK_DGRAM=
(0x13b3+ 1253-0x1898));initVariable ((\$NXBits::IPAny),@$variables[
(0x0717+ 5992-0x1e42)]);initVariable ((\$NXBits::IPv4),@$variables[
(0x0104+ 2043-0x08c1)]);initVariable ((\$NXBits::IPv6),@$variables[
(0x0cc2+ 485-0x0e68)]);initVariable ((\$NXBits::IPNone),@$variables[
(0x0776+ 3722-0x15c0)]);initVariable ((\$NXBits::SOCK_STREAM),@$variables[
(0x0dc9+ 2564-0x178c)]);initVariable ((\$NXBits::SOCK_DGRAM),@$variables[
(0x05dc+ 1825-0x0cbb)]);initVariable ((\$NXBITS::SIGHUP),@$variables[
(0x0d60+ 5689-0x234a)]);initVariable ((\$NXBITS::SIGINT),@$variables[
(0x0e5c+ 4986-0x2186)]);initVariable ((\$NXBITS::SIGUSR1),@$variables[
(0x05e0+ 5845-0x1c64)]);initVariable ((\$NXBITS::SIGUSR2),@$variables[
(0x1ee1+ 997-0x2274)]);initVariable ((\$NXBITS::APPEND_STATUS_CREATE),
@$variables[(0x0444+ 1715-0x0aa4)]);initVariable ((
\$NXBITS::APPEND_STATUS_CREATEAFTER),@$variables[(0x069a+ 7802-0x24c0)]);
initVariable ((\$NXBITS::APPEND_STATUS_ADDINZIP),@$variables[
(0x0088+ 3256-0x0ceb)]);initVariable ((\$NXBITS::Z_NO_COMPRESSION),@$variables[
(0x1815+ 3448-0x2537)]);initVariable ((\$NXBITS::Z_BEST_SPEED),@$variables[
(0x0a5b+ 3628-0x1830)]);initVariable ((\$NXBITS::Z_BEST_COMPRESSION),@$variables
[(0x0957+ 5598-0x1edd)]);initVariable ((\$NXBITS::Z_DEFAULT_COMPRESSION),
@$variables[(0x1a4b+ 3327-0x26f1)]);initVariable ((\$NXBITS::SIGCHLD),
@$variables[(0x1626+ 2211-0x1e7c)]);initVariable ((\$NXBITS::SIGTERM),
@$variables[(0x01a6+ 1935-0x08e7)]);($STDERR=(0x01c3+ 6054-0x1967));initVariable
 ((\$STDERR),@$variables[(0x0bb9+ 6262-0x23e9)]);($NXCore::systemExitCodes{
"\x45\x4e\x4f\x45\x4e\x54"}=@$variables[(0x09c5+ 572-0x0bba)]);(
$NXCore::systemExitCodes{"\x45\x41\x43\x43\x45\x53"}=@$variables[
(0x0f11+ 4131-0x1eec)]);($NXCore::systemExitCodes{
"\x45\x43\x4f\x4e\x4e\x52\x45\x46\x55\x53\x45\x44"}=@$variables[
(0x03c7+ 2914-0x0ee0)]);($NXCore::systemExitCodes{"\x45\x49\x4e\x54\x52"}=
@$variables[(0x0356+ 4588-0x14f8)]);($NXCore::systemExitCodes{
"\x45\x4e\x4f\x44\x41\x54\x41"}=@$variables[(0x0f53+ 5773-0x2595)]);(
$NXCore::systemExitCodes{"\x45\x50\x45\x52\x4d"}=@$variables[
(0x0914+ 1423-0x0e57)]);($NXCore::systemExitCodes{
"\x45\x54\x49\x4d\x45\x44\x4f\x55\x54"}=@$variables[(0x032d+ 5060-0x1697)]);(
$NXCore::systemExitCodes{"\x45\x48\x4f\x53\x54\x55\x4e\x52\x45\x41\x43\x48"}=
@$variables[(0x0d20+ 2414-0x1633)]);($NXCore::systemExitCodes{
"\x45\x4e\x45\x54\x55\x4e\x52\x45\x41\x43\x48"}=@$variables[
(0x01a7+ 8900-0x240f)]);($NXCore::systemExitCodes{
"\x45\x41\x44\x44\x52\x4e\x4f\x54\x41\x56\x41\x49\x4c"}=@$variables[
(0x0fd7+ 1210-0x1434)]);($NXCore::systemExitCodes{
"\x45\x48\x4f\x53\x54\x44\x4f\x57\x4e"}=@$variables[(0x0981+ 3304-0x160b)]);
return;}sub addFhToMonitor{(my $handle=shift (@_));(my $callback=shift (@_));(
$NXBegin::MonitoredHandler=$handle);($NXBegin::MonitoredHandlerCallback=
$callback);}sub nxFileDuplicate{(my $descriptorToDuplicate=shift (@_));(my $return
=libnxh::NXFileDuplicate ($descriptorToDuplicate));if (($return>=
(0x098c+ 6664-0x2394))){Logger::debug (((((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".
$descriptorToDuplicate).
"\x20\x77\x61\x73\x20\x64\x75\x70\x6c\x69\x63\x61\x74\x65\x64\x20\x74\x6f\x20\x46\x44\x23"
).$return)."\x2e"));libnxh::NXDescriptorInheritable ($return,
(0x0e86+ 6053-0x262b));return ($return);}else{(my $error=libnxh::NXGetErrorName 
());(my $errorstring=libnxh::NXGetErrorString ());Logger::warning (((((((((
"\x4e\x58\x46\x69\x6c\x65\x44\x75\x70\x6c\x69\x63\x61\x74\x65\x28".
$descriptorToDuplicate)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20").$return)
."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));return (undef);}}sub nxFileClone{(my $descriptorToClone
=shift (@_));(my $target=shift (@_));(my $return=libnxh::NXFileClone (
$descriptorToClone,$target));if (($return>=(0x196d+ 2355-0x22a0))){Logger::debug
 ((((("\x46\x69\x6c\x65\x20\x68\x61\x6e\x64\x6c\x65\x20\x6f\x66\x20\x46\x44\x23"
.$descriptorToClone).
"\x20\x77\x61\x73\x20\x63\x6c\x6f\x6e\x65\x64\x20\x69\x6e\x74\x6f\x20\x46\x44\x23"
).$target)."\x2e"));return ($return);}else{(my $error=libnxh::NXGetErrorName ())
;(my $errorstring=libnxh::NXGetErrorString ());Logger::warning (((((((((((
"\x4e\x58\x46\x69\x6c\x65\x43\x6c\x6f\x6e\x65\x28".$descriptorToClone).
"\x2c\x20").$target)."\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20").$return).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$error)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));return (undef);}}sub nxDescriptorInheritable{(my $fd=
shift (@_));(my $value=(shift (@_)||(0x1ee1+ 1320-0x2409)));(my $return=
libnxh::NXDescriptorInheritable ($fd,$value));if (($return==(-
(0x0894+ 6071-0x204a)))){reportErrorFromNXPL (((((((
"\x4e\x58\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x49\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x28"
.$fd)."\x2c\x20").$value).
"\x29\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$return)."\x2e"));return (undef);}else{if ($value){Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$fd).
"\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x73\x65\x74\x20\x61\x73\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x2e"
));}else{Logger::debug (((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x46\x44\x23".$fd).
"\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x73\x65\x74\x20\x61\x73\x20\x6e\x6f\x74\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x2e"
));}return ($return);}}sub setDescriptorInheritable{(my $fd=shift (@_));return (
nxDescriptorInheritable ($fd,(0x0746+ 5257-0x1bce)));}sub 
setDescriptorNotInheritable{(my $fd=shift (@_));return (nxDescriptorInheritable 
($fd,(0x0bad+ 4823-0x1e84)));}sub getApplicationName{(my $pid=shift (@_));if (
Common::NXProcess::isChildProcess ($pid)){(my ($name,$lifetime)=
Common::NXProcess::getChildNameAndLifetime ($pid));return ($name);}(my $readbuf=
("\x20" x (0x1658+ 893-0x18d3)));(my $name=libnxh::NXProcessGetImage ((\$readbuf
),(0x08d8+ 7494-0x251d),$pid));if ((not (defined ($name)))){Logger::debug (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x2e"));return ((""));}else{Logger::debug (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20".$pid).
"\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x6e\x61\x6d\x65\x20").$name)."\x2e"));
}return ($name);}sub checkIfPidProcessNameIs{(my $pid=shift (@_));(my $name=
shift (@_));(my $realName=getApplicationName ($pid));if (($realName=~ /$name/ ))
{return ((0x23c3+ 473-0x259b));}return ((0x05a5+ 4144-0x15d5));}sub 
__addDebugerNames{(my $names=shift (@_));if ((defined ($GLOBAL::EnableDebug)and 
defined ($GLOBAL::AcceptedDebuggerCommands))){if ((($GLOBAL::EnableDebug eq 
"\x31")and ($GLOBAL::AcceptedDebuggerCommands ne ("")))){(my (@acceptedNames)=
split ( /,/ ,$GLOBAL::AcceptedDebuggerCommands,(0x0716+ 3151-0x1365)));foreach my $acceptedName
 (@acceptedNames){(my (@pathParts)=split ( /$GLOBAL::DIRECTORY_SLASH/ ,
$acceptedName,(0x138f+ 4244-0x2423)));(my $name=(""));foreach my $pathPart (
@pathParts){if (($pathPart ne (""))){($name=$pathPart);}}($names.=("\x7c".substr
 ($name,(0x0449+ 8249-0x2482),(0x0609+ 5777-0x1c8b))));}}}return ($names);}sub 
__isProcessRunnningAndExpectedNameMatch{(my $pid=shift (@_));(my $expectedName=
shift (@_));(my $silent=shift (@_));if (($pid<(0x0185+ 1694-0x0822))){if ((
$silent eq "\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74")){Logger::error (((
"\x57\x72\x6f\x6e\x67\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x69\x64\x2c\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x70\x69\x64\x20"
.$pid)."\x2e"));}return ((0x082f+  97-0x0890));}($expectedName=__addDebugerNames
 ($expectedName));if (Common::NXProcess::isProcessRunning ($pid)){if (
checkIfPidProcessNameIs ($pid,$expectedName)){if (($silent eq 
"\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74")){Logger::debug2 (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20".$expectedName).
"\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
).$pid)."\x2e"));}return ((0x2091+ 196-0x2154));}else{(my $realProcessName=
getApplicationName ($pid));if (($silent eq 
"\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74")){Logger::error (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x68\x61\x73\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x2c\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x20\x77\x61\x73\x20"
.$expectedName).
"\x2c\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x6e\x61\x6d\x65\x20\x77\x61\x73\x20"
).$realProcessName)."\x2e"));}else{Logger::debug (((((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x68\x61\x73\x20\x75\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x2c\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x20\x77\x61\x73\x20"
.$expectedName).
"\x2c\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x6e\x61\x6d\x65\x20\x77\x61\x73\x20"
).$realProcessName)."\x2e"));}}}else{if (($silent eq 
"\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74")){Logger::error (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20".$pid).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));}else{
Logger::debug (((
"\x50\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20".$pid).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"));}}return (
(0x2022+ 1661-0x269f));}sub isProcessRunnningAndExpectedNameMatch{(my $pid=shift
 (@_));(my $name=shift (@_));return (__isProcessRunnningAndExpectedNameMatch (
$pid,$name,"\x6e\x6f\x74\x53\x69\x6c\x65\x6e\x74"));}sub 
isProcessRunnningAndExpectedNameMatchSilent{(my $pid=shift (@_));(my $name=shift
 (@_));return (__isProcessRunnningAndExpectedNameMatch ($pid,$name,
"\x73\x69\x6c\x65\x6e\x74"));}sub copyFile{(my $fileSource=shift (@_));(my $fileDest
=shift (@_));Logger::debug2 (((("\x63\x6f\x70\x79\x46\x69\x6c\x65\x3a\x20".
$fileSource)."\x2c\x20").$fileDest));if ((not (Common::NXFile::fileExists (
$fileSource)))){return ((0x0581+ 4223-0x15ff),((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x74\x61\x74\x20\x27".$fileSource).
"\x27\x20\x66\x69\x6c\x65\x2e"));}(my $copyRet=libnxh::NXFileCopy ($fileSource,
$fileDest));if (($copyRet ne (0x1c99+ 1377-0x21f9))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x66\x72\x6f\x6d\x20\x27".
$fileSource)."\x27\x20\x74\x6f\x20\x27").$fileDest)."\x27\x2e"));Logger::error (
(((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorString)."\x27\x2e"));return ((0x149a+ 3834-0x2394),((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x27".$fileSource).
"\x27\x20\x66\x69\x6c\x65\x20\x74\x6f\x20\x27").$fileDest).
"\x27\x20\x64\x75\x65\x20\x74\x6f\x20\x27").$errorString)."\x27\x2e"));}return (
(0x0f9c+ 550-0x11c2),(""));}sub moveFile{(my $fileSource=shift (@_));(my $fileDest
=shift (@_));if ((not (Common::NXFile::fileExists ($fileSource)))){Logger::error
 ((((("\x6d\x6f\x76\x65\x46\x69\x6c\x65\x3a\x20".$fileSource)."\x2c\x20").
$fileDest).
"\x2e\x20\x46\x69\x6c\x65\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x2e"
));return;}(my $moveRet=libnxh::NXFileMove ($fileSource,$fileDest));if ((
$moveRet ne (0x1382+ 3584-0x2181))){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6f\x76\x65\x20\x27".$fileSource).
"\x27\x20\x66\x69\x6c\x65\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorString)."\x27\x2e"));return ((0x09c3+ 3423-0x1722));}return (
(0x1518+ 1092-0x195b));}sub BEGIN{require Fcntl;do{"\x46\x63\x6e\x74\x6c"->
import ("\x3a\x6d\x6f\x64\x65")};}sub NXStat{(my $file=shift (@_));(my (@list)=
stat ($file));return (@list);}sub NXFileGid{(my $file=shift (@_));return ((
NXStat ($file))[(0x1902+ 301-0x1a2a)]);}sub NXFileUid{(my $file=shift (@_));
return ((NXStat ($file))[(0x1cb0+ 876-0x2018)]);}sub NXFileMode{(my $file=shift 
(@_));return ((NXStat ($file))[(0x04b5+ 1085-0x08f0)]);}sub NXFileMTime{(my $file
=shift (@_));return ((NXStat ($file))[(0x0312+ 202-0x03d3)]);}sub NXFileATime{(my $file
=shift (@_));return ((NXStat ($file))[(0x17e0+ 3566-0x25c6)]);}sub NXFileSize{(my $file
=shift (@_));return ((NXStat ($file))[(0x02a8+ 5280-0x1741)]);}sub NXFileCTime{(my $file
=shift (@_));return ((NXStat ($file))[(0x1566+ 1466-0x1b16)]);}sub 
NXIsFileReadable{(my $file=shift (@_));(my $isReadable=(0x11b6+ 5364-0x26aa));(my $flag
="\x53\x5f\x49\x52\x55\x53\x45\x52");if (Common::NXFile::isExists ($file)){(my $mode
=NXFileMode ($file));($isReadable=($mode&"\x53\x5f\x49\x52\x55\x53\x45\x52"));}
return ($isReadable);}sub decodeDate{(my $code=shift (@_));(my $decode=($code^
(0x0ad6+ 2431-0x13d6)));return ($decode);}sub convertWindowsSidToUsername{
Logger::warning (
"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x63\x6f\x6e\x76\x65\x72\x74\x57\x69\x6e\x64\x6f\x77\x73\x53\x69\x64\x54\x6f\x55\x73\x65\x72\x6e\x61\x6d\x65\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x72\x75\x6e\x20\x6f\x6e\x20\x57\x69\x6e\x64\x6f\x77\x73\x20\x73\x79\x73\x74\x65\x6d\x2e"
);return ((""));}sub getEffectiveUserGroup{if ((
$GLOBAL::CACHE_EFFECTIVE_USERGROUP eq (""))){(my $euid=getEffectiveUid ());(my $usergroup
=userInfoGetGidByUid ($euid));($GLOBAL::CACHE_EFFECTIVE_USERGROUP=$usergroup);}
return ($GLOBAL::CACHE_EFFECTIVE_USERGROUP);}sub getEffectiveUserGroupID{if ((
$GLOBAL::CACHE_EFFECTIVE_USERGROUP_ID ne (""))){return (
$GLOBAL::CACHE_EFFECTIVE_USERGROUP_ID);}(my $userGroup=getEffectiveUserGroup ())
;($GLOBAL::CACHE_EFFECTIVE_USERGROUP_ID=getgrgid ($userGroup));return (
$GLOBAL::CACHE_EFFECTIVE_USERGROUP_ID);}sub getNXExecCommand{return (((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x65\x78\x65\x63"));}sub 
nxwriteOrThrowException{(my $FD=shift (@_));(my $message=shift (@_));(my $bytes=
nxwrite ($FD,$message));if (($bytes==(-(0x0448+ 6720-0x1e87)))){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->throw ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x46\x44\x23".
$FD));}return ($bytes);}sub isSystemUserExist{(my $login=shift (@_));(my $silent
=(0x03b6+ 1856-0x0af5));if (((not (defined ($login)))or ($login eq ("")))){
Logger::error (
"\x4c\x6f\x67\x69\x6e\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2e");
main::nxexit ();}if (__isCachedUserInfoForUsername ($login)){return (
(0x07af+ 204-0x087a));}else{return (__setUserInfoForUsername ($login,$silent));}
}sub getEffectiveUsername{if ((defined ($GLOBAL::CACHE_EFFECTIVE_USERNAME)and (
$GLOBAL::CACHE_EFFECTIVE_USERNAME ne ("")))){return (
$GLOBAL::CACHE_EFFECTIVE_USERNAME);}my ($username);(my $euid=getEffectiveUid ())
;($username=userInfoGetUsernameByUid ($euid));if (defined ($username)){(
$GLOBAL::CACHE_EFFECTIVE_USERNAME=$username);}Logger::debug (((
"\x67\x65\x74\x45\x66\x66\x65\x63\x74\x69\x76\x65\x55\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20"
.$username)."\x2e"));return ($username);}sub ErrnoENOENT{return (
$NXCore::systemExitCodes{"\x45\x4e\x4f\x45\x4e\x54"});}sub ErrnoEACCES{return (
$NXCore::systemExitCodes{"\x45\x41\x43\x43\x45\x53"});}sub ErrnoECONNREFUSED{
return ($NXCore::systemExitCodes{
"\x45\x43\x4f\x4e\x4e\x52\x45\x46\x55\x53\x45\x44"});}sub ErrnoEINTR{return (
$NXCore::systemExitCodes{"\x45\x49\x4e\x54\x52"});}sub ErrnoENODATA{return (
$NXCore::systemExitCodes{"\x45\x4e\x4f\x44\x41\x54\x41"});}sub ErrnoEPERM{return
 ($NXCore::systemExitCodes{"\x45\x50\x45\x52\x4d"});}sub ErrnoETIMEDOUT{return (
$NXCore::systemExitCodes{"\x45\x54\x49\x4d\x45\x44\x4f\x55\x54"});}sub 
ErrnoEHOSTUNREACH{return ($NXCore::systemExitCodes{
"\x45\x48\x4f\x53\x54\x55\x4e\x52\x45\x41\x43\x48"});}sub ErrnoENETUNREACH{
return ($NXCore::systemExitCodes{"\x45\x4e\x45\x54\x55\x4e\x52\x45\x41\x43\x48"}
);}sub ErrnoEADDRNOTAVAIL{return ($NXCore::systemExitCodes{
"\x45\x41\x44\x44\x52\x4e\x4f\x54\x41\x56\x41\x49\x4c"});}sub ErrnoEHOSTDOWN{
return ($NXCore::systemExitCodes{"\x45\x48\x4f\x53\x54\x44\x4f\x57\x4e"});}sub 
isEffectiveUserAdministratorUnix{if (($>eq "\x30")){return (
(0x0236+ 4402-0x1367));}return ((0x0517+ 5549-0x1ac4));}sub clearPwNam{(my $login
=shift (@_));if (((not (defined ($login)))or ($login eq ("")))){Logger::warning 
(
"\x63\x6c\x65\x61\x72\x70\x77\x6e\x61\x6d\x3a\x20\x6c\x6f\x67\x69\x6e\x20\x6e\x61\x6d\x65\x20\x6e\x6f\x74\x20\x70\x72\x6f\x76\x69\x64\x65\x64\x2e"
);return;}Logger::debug (((
"\x63\x6c\x65\x61\x72\x70\x77\x6e\x61\x6d\x3a\x20\x63\x6c\x65\x61\x72\x69\x6e\x67\x20\x63\x61\x63\x68\x65\x20\x66\x6f\x72\x20"
.$login)."\x2e"));__cleanCachedUserInfoForUsername ($login);return;}sub getPwNam
{(my $login=shift (@_));(my $silent=(0x000b+ 9862-0x2691));if (((not (defined (
$login)))or ($login eq ("")))){Logger::error (
"\x67\x65\x74\x50\x77\x4e\x61\x6d\x3a\x20\x4c\x6f\x67\x69\x6e\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2e"
);main::nxexit ();}if (__isNotCachedUserInfoForUsername ($login)){
__setUserInfoForUsername ($login,$silent);}return (
__getCachedUserInfoHashForUsername ($login));}sub 
extractLicenseBodyFromLicenseFile{(my $content=shift (@_));if (($content=~ /(----- Begin subscription data -----.*----- End subscription data -----)/s )
){(my $body=$1);return ($body);}else{return ($content);}}sub 
readInputTillNewline{(my $filehandle=shift (@_));(my $return_buffer=shift (@_));
(my $silence=shift (@_));if ((not (defined ($silence)))){($silence=
(0x00d2+ 3472-0x0e62));}Logger::debug (((
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x43\x6f\x72\x65\x3a\x3a\x72\x65\x61\x64\x49\x6e\x70\x75\x74\x54\x69\x6c\x6c\x4e\x65\x77\x6c\x69\x6e\x65\x3a\x20\x52\x65\x61\x64\x69\x6e\x67\x20\x66\x72\x6f\x6d\x20\x46\x44\x23"
.$filehandle)."\x2e"));(my $fileh=$filehandle);($$return_buffer=(""));my (
$read_buf);(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;$selector->add ($fileh);my ($bytes_read);(my $oldint=$$NXBegin::parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"});($$NXBegin::parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"}=sub{Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x53\x49\x47\x49\x4e\x54\x2c\x20\x67\x6f\x69\x6e\x67\x20\x74\x6f\x20\x65\x6e\x64\x20\x70\x72\x6f\x63\x65\x73\x73"
);if (exists ($INC{"\x4e\x58\x50\x61\x73\x73\x77\x64\x2e\x70\x6d"})){if ((
defined (NXPasswd::getPasswdPid ())and (NXPasswd::getPasswdPid ()!=
(0x1690+ 933-0x1a35)))){Common::NXProcess::sendTerminateWaitAndKill (
NXPasswd::getPasswdPid (),(0x0983+ 406-0x0b17));}}enableConsoleEchoMode ();
nxexit ();});(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});
$selector->add ($signalFd);(my $finish=(0x059d+ 3292-0x1279));while (($finish==
(0x13f7+ 2421-0x1d6c))){(my (@ready)=$selector->can_read);if ((scalar (@ready)==
(0x123b+ 4856-0x2533))){Logger::debug (
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x2e");($finish=
(0x0488+ 8767-0x26c6));}foreach my $fh (@ready){if (($fh==$fileh)){($bytes_read=
main::nxread ($fh,(\$read_buf),(0x104b+ 4378-0x1165)));($$return_buffer.=
$read_buf);if ((not ($silence))){Logger::debug (((((((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x46\x44\x23".$fh)."\x20\x5b").
$read_buf)."\x5d\x20\x5b").$bytes_read)."\x5d"));}if (($bytes_read==
(0x01b3+ 2665-0x0c1c))){Logger::debug (((
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x46\x44\x23"
.$fh)."\x2e"));$selector->remove ($fh);$selector->remove ($signalFd);($finish=
(0x128a+ 922-0x1623));}else{if (($read_buf=~ /\n/ )){$selector->remove ($fileh);
$selector->remove ($signalFd);chomp ($$return_buffer);($$return_buffer=~ s/\r//g )
;($finish=(0x0050+ 7530-0x1db9));}}}}}($$NXBegin::parser{
"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"}=$oldint);}sub 
__setUserInfoForUsernameUnix{(my $username=shift (@_));(my $silent=shift (@_));(my $userBufferSize
=16384);(my $userBuffer=("\x20" x $userBufferSize));if ((libnxh::NXUserExist (
$username)==(0x04c1+ 185-0x057a))){__setCacheUserInfoFieldForUsername ($username
,"\x6e\x61\x6d\x65",(""));__setCacheUserInfoFieldForUsername ($username,
"\x70\x61\x73\x73\x77\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x67\x65\x63\x6f\x73",(""));__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x67\x69\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x64\x69\x72",(""));__setCacheUserInfoFieldForUsername ($username,
"\x73\x68\x65\x6c\x6c",(""));if (($silent==(0x0962+ 2584-0x137a))){
Logger::warning ((("\x55\x73\x65\x72\x20".$username).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x20\x69\x6e\x20\x73\x79\x73\x74\x65\x6d\x2e"
));}return ((0x07e2+ 4577-0x19c3));}(my $returnValue=libnxh::NXGetUserInfo (
$username,$userBuffer,$userBufferSize));if (($returnValue==(-
(0x02ac+ 4784-0x155b)))){if (($silent==(0x1959+ 2530-0x233b))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x75\x73\x65\x72\x20\x69\x6e\x66\x6f\x20\x66\x6f\x72\x20"
.$username)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));}__setCacheUserInfoFieldForUsername ($username,
"\x6e\x61\x6d\x65",(""));__setCacheUserInfoFieldForUsername ($username,
"\x70\x61\x73\x73\x77\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x67\x65\x63\x6f\x73",(""));__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x67\x69\x64",(""));__setCacheUserInfoFieldForUsername ($username,
"\x64\x69\x72",(""));__setCacheUserInfoFieldForUsername ($username,
"\x73\x68\x65\x6c\x6c",(""));return ((0x0280+ 2438-0x0c06));}($userBuffer=substr
 ($userBuffer,(0x1098+ 4797-0x2355),index ($userBuffer,"\x00")));(my (@array)=
split ( /:/ ,$userBuffer,(0x0cf5+ 2118-0x153b)));
__setCacheUserInfoFieldForUsername ($username,"\x6e\x61\x6d\x65",$array[
(0x022b+ 7483-0x1f66)]);__setCacheUserInfoFieldForUsername ($username,
"\x70\x61\x73\x73\x77\x64",$array[(0x165f+ 4222-0x26dc)]);
__setCacheUserInfoFieldForUsername ($username,"\x67\x65\x63\x6f\x73",$array[
(0x0775+ 1407-0x0cf2)]);__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",$array[(0x0425+ 7782-0x2288)]);__setCacheUserInfoFieldForUsername
 ($username,"\x67\x69\x64",$array[(0x21f0+ 661-0x2481)]);
__setCacheUserInfoFieldForUsername ($username,"\x64\x69\x72",$array[
(0x0506+ 446-0x06bf)]);__setCacheUserInfoFieldForUsername ($username,
"\x73\x68\x65\x6c\x6c",$array[(0x00cd+ 1600-0x0707)]);return (
(0x0173+ 6240-0x19d2));}sub __setUserInfoForUsernameWindows{(my $username=shift 
(@_));(my $silent=shift (@_));if ((libnxh::NXUserExist ($username)==
(0x0294+ 5260-0x1720))){__setCacheUserInfoFieldForUsername ($username,
"\x6e\x61\x6d\x65",(""));__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",(""));if (($silent==(0x064b+ 5337-0x1b24))){Logger::warning (((
"\x55\x73\x65\x72\x20".$username).
"\x20\x64\x6f\x65\x73\x6e\x27\x74\x20\x65\x78\x69\x73\x74\x20\x69\x6e\x20\x73\x79\x73\x74\x65\x6d\x2e"
));}return ((0x00fa+ 5375-0x15f9));}(my $size=(0x039d+ 2777-0x0c76));(my $userSidBuffer
=("\x20" x $size));(my $length=($size-(0x04a9+ 8055-0x241f)));(my $retval=
libnxh::NXConvertUsernameToSid ($username,$userSidBuffer,$length));if (($retval
!=(0x051f+ 4686-0x176d))){if (($silent==(0x01e4+ 1178-0x067e))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x75\x73\x65\x72\x20\x73\x69\x64\x20\x66\x6f\x72\x20"
.$username)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorstring)."\x27\x2e"));}__setCacheUserInfoFieldForUsername ($username,
"\x6e\x61\x6d\x65",(""));__setCacheUserInfoFieldForUsername ($username,
"\x75\x69\x64",(""));return ((0x1bf2+ 1645-0x225f));}($userSidBuffer=substr (
$userSidBuffer,(0x035f+ 5981-0x1abc),index ($userSidBuffer,"\x00")));
__setCacheUserInfoFieldForUsername ($username,"\x6e\x61\x6d\x65",$username);
__setCacheUserInfoFieldForUsername ($username,"\x75\x69\x64",$userSidBuffer);
return ((0x0ca1+ 3448-0x1a18));}sub setUserSidForUsername{(my $username=shift (
@_));(my $sid=shift (@_));if (__isCachedUserInfoForUsername ($username)){return;
}Logger::debug ((((("\x55\x73\x65\x72\x6e\x61\x6d\x65\x20".$username).
"\x20\x73\x69\x64\x20").$sid).
"\x20\x73\x65\x74\x20\x64\x69\x72\x65\x63\x74\x6c\x79"));
__setCacheUserInfoFieldForUsername ($username,"\x6e\x61\x6d\x65",$username);
__setCacheUserInfoFieldForUsername ($username,"\x75\x69\x64",$sid);
__setUidHashForUsername ($username,$sid);}sub __setUserInfoForUsername{(my $username
=shift (@_));(my $silent=shift (@_));if ((not (defined ($silent)))){($silent=
(0x0649+ 5856-0x1d29));}return (__setUserInfoForUsernameUnix ($username,$silent)
);}sub userInfoGetUidByUsername{(my $username=shift (@_));(my (%options)=
getPwNam ($username));if ((defined ($options{"\x75\x69\x64"})and ($options{
"\x75\x69\x64"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x75\x69\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x75\x69\x64"})."\x2e"
));return ($options{"\x75\x69\x64"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x75\x69\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x0d9d+ 2666-0x1806)));}sub userInfoGetGidByUsername{(my $username=shift (@_));
(my (%options)=getPwNam ($username));if ((defined ($options{"\x67\x69\x64"})and 
($options{"\x67\x69\x64"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x69\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x67\x69\x64"})."\x2e"
));return ($options{"\x67\x69\x64"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x69\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x12d3+ 3273-0x1f9b)));}sub userInfoGetShellByUsername{(my $username=shift (@_)
);(my (%options)=getPwNam ($username));if ((defined ($options{
"\x73\x68\x65\x6c\x6c"})and ($options{"\x73\x68\x65\x6c\x6c"}ne ("")))){
Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x73\x68\x65\x6c\x6c"}
)."\x2e"));return ($options{"\x73\x68\x65\x6c\x6c"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return (
__getShellIfNotAvailable ());}sub userInfoGetLoginByUsername{(my $username=shift
 (@_));(my (%options)=getPwNam ($username));if ((defined ($options{
"\x6e\x61\x6d\x65"})and ($options{"\x6e\x61\x6d\x65"}ne ("")))){Logger::debug ((
(((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x6c\x6f\x67\x69\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x6e\x61\x6d\x65"}).
"\x2e"));return ($options{"\x6e\x61\x6d\x65"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x6c\x6f\x67\x69\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x021f+ 3349-0x0f33)));}sub userInfoGetPasswdByUsername{(my $username=shift (@_
));(my (%options)=getPwNam ($username));if ((defined ($options{
"\x70\x61\x73\x73\x77\x64"})and ($options{"\x70\x61\x73\x73\x77\x64"}ne ("")))){
Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x70\x61\x73\x73\x77\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{
"\x70\x61\x73\x73\x77\x64"})."\x2e"));return ($options{
"\x70\x61\x73\x73\x77\x64"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x70\x61\x73\x73\x77\x64\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x18aa+ 2736-0x2359)));}sub userInfoGetGecosByUsername{(my $username=shift (@_)
);(my (%options)=getPwNam ($username));if ((defined ($options{
"\x67\x65\x63\x6f\x73"})and ($options{"\x67\x65\x63\x6f\x73"}ne ("")))){
Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x65\x63\x6f\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x67\x65\x63\x6f\x73"}
)."\x2e"));return ($options{"\x67\x65\x63\x6f\x73"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x65\x63\x6f\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x1810+ 2343-0x2136)));}sub userInfoGetDirByUsername{(my $username=shift (@_));
(my (%options)=getPwNam ($username));if ((defined ($options{"\x64\x69\x72"})and 
($options{"\x64\x69\x72"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x64\x69\x72\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x64\x69\x72"})."\x2e"
));return ($options{"\x64\x69\x72"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x64\x69\x72\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20"
.$username)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x028d+ 5470-0x17ea)));}sub userIsSystemAdministrator{(my $username=shift (@_))
;(my $userUid=userInfoGetUidByUsername ($username));if (($userUid eq 
(0x0dfa+ 3298-0x1adc))){return ((0x10fb+ 512-0x12fa));}return (
(0x223d+ 437-0x23f2));}sub getSystemGroups{(my $size=16384);(my $groupBuffer=(
"\x20" x $size));(my $returnValue=libnxh::NXGetAllSystemGroups ($groupBuffer,
$size));if (($returnValue==(-(0x043d+ 2629-0x0e81)))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x61\x6c\x6c\x20\x73\x79\x73\x74\x65\x6d\x20\x67\x72\x6f\x75\x70\x73\x2e"
);Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
libnxh::NXGetError ())."\x2c\x20\x27").libnxh::NXGetErrorString ())."\x27\x2e"))
;return ((""));}(my (@buf)=split ( /\./ ,$groupBuffer,(0x1f42+ 365-0x20af)));(
$groupBuffer=$buf[(0x1619+ 503-0x1810)]);return ($groupBuffer);}sub 
getParentPidByPid{(my $pid=shift (@_));(my $returnValue=(0x0195+ 384-0x0315));(
$returnValue=libnxh::NXGetParentProcessID ($pid));Logger::debug ((((
"\x4e\x58\x47\x65\x74\x50\x61\x72\x65\x6e\x74\x50\x69\x64\x46\x6f\x72\x50\x69\x64\x3a\x20\x50\x61\x72\x65\x6e\x74\x20\x70\x69\x64\x20\x66\x6f\x72\x20\x70\x69\x64\x20"
.$pid)."\x20\x69\x73\x20").$returnValue));return ($returnValue);}sub 
getUserGroupsFromSystem{(my $username=shift (@_));(my $size=16384);(my $groupBuffer
=("\x20" x $size));(my $returnValue=libnxh::NXGetUserSystemGroups ($username,
$groupBuffer,$size));if (($returnValue==(-(0x05e5+ 2848-0x1104)))){
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x79\x73\x74\x65\x6d\x20\x67\x72\x6f\x75\x70\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
.$username)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".libnxh::NXGetError ())."\x2c\x20\x27"
).libnxh::NXGetErrorString ())."\x27\x2e"));return ((""));}elsif (($returnValue>
$size)){($size=$returnValue);Logger::debug ((
"\x50\x72\x6f\x76\x69\x64\x65\x64\x20\x62\x75\x66\x66\x65\x72\x20\x69\x73\x20\x74\x6f\x20\x73\x6d\x61\x6c\x6c\x20\x72\x65\x71\x69\x73\x74\x65\x64\x20\x69\x73\x3a\x20"
.$returnValue));($groupBuffer=("\x20" x $size));($returnValue=
libnxh::NXGetUserSystemGroups ($username,$groupBuffer,$size));if (($returnValue
==(-(0x122b+ 4368-0x233a)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x79\x73\x74\x65\x6d\x20\x67\x72\x6f\x75\x70\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
.$username)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".libnxh::NXGetError ())."\x2c\x20\x27"
).libnxh::NXGetErrorString ())."\x27\x2e"));return ((""));}}(my (@buf)=split ( /\0/ ,
$groupBuffer,(0x1898+ 1985-0x2059)));return ($buf[(0x1a59+ 514-0x1c5b)]);}sub 
nxConnectLocal{(my $port=shift (@_));(my $silence=(shift (@_)||"\x6e\x6f"));(my $error_ref
=shift (@_));(my ($package,$filename,$line,$sub)=caller ((0x07e0+ 6602-0x21a9)))
;if (($sub eq (""))){($sub=$package);}if ((not (defined ($port)))){Logger::error
 (((
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c\x3a\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x63\x61\x6c\x6c\x20\x66\x72\x6f\x6d\x20"
.$sub)."\x2e"));nxexit ();}Logger::debug (((((
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c\x20\x74\x6f\x20\x6c\x6f\x63\x61\x6c\x68\x6f\x73\x74\x3a"
.$port)."\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));(my $returnValue=
libnxh::NXConnectLocal ($port));if (($returnValue==(-(0x18b5+ 1032-0x1cbc)))){(
$$error_ref=libnxh::NXGetConnectionError ());if (($silence eq "\x6e\x6f")){
Logger::warning (((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c\x20\x63\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x6c\x6f\x63\x61\x6c\x68\x6f\x73\x74\x3a"
.$port)."\x3a\x20").$$error_ref)."\x20\x66\x72\x6f\x6d\x20").$sub)."\x2e"));}
return ((-(0x0385+ 7010-0x1ee6)));}Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x4c\x6f\x63\x61\x6c\x20\x72\x65\x74\x75\x72\x6e\x3a\x20\x46\x44\x23"
.$returnValue)."\x2e"));nxDescriptorInheritable ($returnValue,
(0x0bf9+ 2538-0x15e3));closeSocketAtFinish ($returnValue);return ($returnValue);
}sub setAttributeOnWindows{(my $path=shift (@_));(my $attr=shift (@_));(my $value
=(shift (@_)||(0x0b49+ 6912-0x2649)));(my $silent=(shift (@_)||
(0x1677+ 2961-0x2208)));if ((not (defined ($path)))){if (($silent==
(0x1984+ 3399-0x26cb))){Logger::warning (
"\x50\x61\x74\x68\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x61\x74\x74\x72\x69\x62\x75\x74\x65\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x2f\x66\x6f\x6c\x64\x65\x72\x2e"
);}return ((0x0d46+ 5840-0x2416));}if ((not (defined ($attr)))){if (($silent==
(0x0b4b+ 2822-0x1651))){Logger::warning (
"\x41\x74\x74\x72\x69\x62\x75\x74\x65\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x61\x74\x74\x72\x69\x62\x75\x74\x65\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x2f\x66\x6f\x6c\x64\x65\x72\x2e"
);}return ((0x0c63+ 3352-0x197b));}Logger::debug (((((((
"\x4e\x58\x53\x65\x74\x41\x74\x74\x72\x69\x62\x75\x74\x65\x3a\x20\x70\x61\x74\x68\x3a\x20"
.$path)."\x2c\x20\x61\x74\x74\x72\x69\x62\x75\x74\x65\x3a\x20").$attr).
"\x2c\x20\x76\x61\x6c\x75\x65\x3a\x20").$value)."\x2e"));(my $result=
libnxh::NXSetAttribute ($path,$attr,$value));if (($result==(-
(0x0da1+ 1333-0x12d5)))){if (($silent==(0x09d6+  58-0x0a10))){
reportErrorFromNXPL (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x61\x74\x74\x72\x69\x62\x75\x74\x65\x20\x66\x6f\x72\x20"
.$path)."\x2e"));}return ((0x0452+ 1655-0x0ac9));}return ((0x0941+ 5776-0x1fd0))
;}sub setHiddenAttributeOnWindows{(my $path=shift (@_));setAttributeOnWindows (
$path,$GLOBAL::HiddenAttribute,(0x01ad+ 4310-0x1282));}sub 
removeHiddenAttributeOnWindows{(my $path=shift (@_));setAttributeOnWindows (
$path,$GLOBAL::HiddenAttribute,(0x15ac+ 1002-0x1996));}sub 
setReadOnlyAttributeOnWindows{(my $path=shift (@_));return (
setAttributeOnWindows ($path,$GLOBAL::ReadOnlyAttribute,(0x1d84+ 1308-0x229f)));
}sub removeReadOnlyAttributeOnWindows{(my $path=shift (@_));return (
setAttributeOnWindows ($path,$GLOBAL::ReadOnlyAttribute,(0x140c+ 544-0x162c)));}
sub cleanOutLanguageCasesInEnvironemt{libnxh::NXTransSetEnvironment (
"\x4c\x43\x5f\x41\x4c\x4c","\x43");}sub convertProcessPidToHandleAsSuperuser{
Logger::warning (
"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x63\x6f\x6e\x76\x65\x72\x74\x50\x72\x6f\x63\x65\x73\x73\x50\x69\x64\x54\x6f\x48\x61\x6e\x64\x6c\x65\x41\x73\x53\x75\x70\x65\x72\x75\x73\x65\x72\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x72\x75\x6e\x20\x6f\x6e\x20\x57\x69\x6e\x64\x6f\x77\x73\x20\x73\x79\x73\x74\x65\x6d\x2e"
);return ((-(0x0760+ 3011-0x1322)));}sub convertStringFromWindowsCodePageToUtf8{
Logger::warning (
"\x46\x75\x6e\x63\x74\x69\x6f\x6e\x20\x63\x6f\x6e\x76\x65\x72\x74\x53\x74\x72\x69\x6e\x67\x46\x72\x6f\x6d\x57\x69\x6e\x64\x6f\x77\x73\x43\x6f\x64\x65\x50\x61\x67\x65\x54\x6f\x55\x74\x66\x38\x20\x63\x61\x6e\x20\x6f\x6e\x6c\x79\x20\x62\x65\x20\x72\x75\x6e\x20\x6f\x6e\x20\x57\x69\x6e\x64\x6f\x77\x73\x20\x73\x79\x73\x74\x65\x6d\x2e"
);return ((-(0x0efb+ 3543-0x1cd1)));}sub __getCachedUserInfoHashForUsername{(my $login
=shift (@_));return (%{$NXCore::UserInfo{$login};});}sub 
__getCachedUserInfoHashForUid{(my $uid=shift (@_));return (%{$NXCore::UserInfo{
$uid};});}sub __cleanCachedUserInfoForUsername{(my $login=shift (@_));(my $uid=
$NXCore::UserInfo{$login}{"\x75\x69\x64"});undef ($NXCore::UserInfo{$uid});undef
 ($NXCore::UserInfo{$login});}sub __cleanCachedUserInfoForUid{(my $uid=shift (@_
));(my $username=$NXCore::UserInfo{$uid}{"\x6e\x61\x6d\x65"});undef (
$NXCore::UserInfo{$username});undef ($NXCore::UserInfo{$uid});}sub 
__setCacheUserInfoFieldForUsername{(my $login=shift (@_));(my $field=shift (@_))
;(my $value=shift (@_));($NXCore::UserInfo{$login}{$field}=$value);}sub 
__setCacheUserInfoFieldForUid{(my $uid=shift (@_));(my $field=shift (@_));(my $value
=shift (@_));($NXCore::UserInfo{$uid}{$field}=$value);}sub 
__setUidHashForUsername{(my $username=shift (@_));(my $uid=shift (@_));(my $absoluteName
=convertWindowsSidToUsername ($uid));if (($absoluteName ne (""))){(
$NXCore::UserInfo{$uid}=$NXCore::UserInfo{$absoluteName});}else{(
$NXCore::UserInfo{$uid}=$NXCore::UserInfo{$username});}}sub 
__setUsernameHashForUid{(my $username=shift (@_));(my $uid=shift (@_));(
$NXCore::UserInfo{$username}=$NXCore::UserInfo{$uid});}sub 
__isCachedUserInfoForUsername{(my $login=shift (@_));(my (%userInfoHash)=
__getCachedUserInfoHashForUsername ($login));if ((%userInfoHash and (
$userInfoHash{"\x6e\x61\x6d\x65"}ne ("")))){return ((0x014f+ 8137-0x2117));}
return ((0x2212+ 349-0x236f));}sub __isCachedUserInfoForUid{(my $uid=shift (@_))
;(my (%userInfoHash)=__getCachedUserInfoHashForUid ($uid));if ((%userInfoHash 
and ($userInfoHash{"\x75\x69\x64"}ne ("")))){return ((0x0a2f+ 5946-0x2168));}
return ((0x25a6+ 329-0x26ef));}sub __isNotCachedUserInfoForUsername{(my $login=
shift (@_));return ((!__isCachedUserInfoForUsername ($login)));}sub 
__isNotCachedUserInfoForUid{(my $uid=shift (@_));return ((!
__isCachedUserInfoForUid ($uid)));}sub isEffectiveUsernameSystem{return (
(0x03da+ 1108-0x082e));(my $returnValue=libnxh::NXRunningOnSystemAccount ());if 
(($returnValue==(-(0x00d3+ 2115-0x0915)))){Logger::warning (
"\x69\x73\x45\x66\x66\x65\x63\x74\x69\x76\x65\x55\x73\x65\x72\x6e\x61\x6d\x65\x53\x79\x73\x74\x65\x6d\x3a\x20\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x69\x66\x20\x53\x59\x53\x54\x45\x4d\x20\x61\x63\x63\x6f\x75\x6e\x74"
);return ((-(0x18eb+ 642-0x1b6c)));}if (($returnValue==(0x1d34+ 322-0x1e75))){
return ((0x0069+ 4068-0x104c));}return ((0x0915+ 1206-0x0dcb));}sub 
isEffectiveUsernameRoot{if ((getEffectiveUid ()eq "\x30")){return (
(0x0c53+ 3207-0x18d9));}return ((0x06e7+ 3179-0x1352));}sub 
isEffectiveUsernameNX{if ((getEffectiveUsername ()eq "\x6e\x78")){return (
(0x08db+ 6051-0x207d));}return ((0x0d5f+ 2681-0x17d8));}sub 
isEffectiveUserNXRootOrSystem{if (((isEffectiveUsernameSystem ()or 
isEffectiveUsernameRoot ())or isEffectiveUsernameNX ())){return (
(0x0f9b+ 4824-0x2272));}return ((0x07e8+ 6381-0x20d5));}sub getPwUid{(my $uid=
shift (@_));if ((not (defined ($uid)))){Logger::error (
"\x67\x65\x74\x50\x77\x55\x69\x64\x3a\x20\x55\x69\x64\x20\x6e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x2e"
);main::nxexit ();}if (__isNotCachedUserInfoForUid ($uid)){__setUserInfoForUid (
$uid);}return (__getCachedUserInfoHashForUid ($uid));}sub 
__setUserInfoForUidUnix{(my $uid=shift (@_));(my $userBufferSize=16384);(my $userBuffer
=("\x20" x $userBufferSize));(my $returnValue=libnxh::NXGetUserInfoByUid ($uid,
$userBuffer,$userBufferSize));if (($returnValue==(-(0x0122+ 6715-0x1b5c)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x75\x73\x65\x72\x20\x69\x6e\x66\x6f\x20\x66\x6f\x72\x20"
.$uid)."\x2e"));Logger::warning ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));
__setCacheUserInfoFieldForUid ($uid,"\x6e\x61\x6d\x65",(""));
__setCacheUserInfoFieldForUid ($uid,"\x70\x61\x73\x73\x77\x64",(""));
__setCacheUserInfoFieldForUid ($uid,"\x67\x65\x63\x6f\x73",(""));
__setCacheUserInfoFieldForUid ($uid,"\x75\x69\x64",(""));
__setCacheUserInfoFieldForUid ($uid,"\x67\x69\x64",(""));
__setCacheUserInfoFieldForUid ($uid,"\x64\x69\x72",(""));
__setCacheUserInfoFieldForUid ($uid,"\x73\x68\x65\x6c\x6c",(""));return (
(0x05c1+ 4406-0x16f7));}($userBuffer=substr ($userBuffer,(0x19bb+ 1503-0x1f9a),
index ($userBuffer,"\x00")));(my (@array)=split ( /:/ ,$userBuffer,
(0x0c8b+ 4364-0x1d97)));__setCacheUserInfoFieldForUid ($uid,"\x6e\x61\x6d\x65",
$array[(0x19f7+ 2519-0x23ce)]);__setCacheUserInfoFieldForUid ($uid,
"\x70\x61\x73\x73\x77\x64",$array[(0x1685+ 3104-0x22a4)]);
__setCacheUserInfoFieldForUid ($uid,"\x67\x65\x63\x6f\x73",$array[
(0x1747+ 1057-0x1b66)]);__setCacheUserInfoFieldForUid ($uid,"\x75\x69\x64",
$array[(0x06b8+ 7493-0x23fa)]);__setCacheUserInfoFieldForUid ($uid,
"\x67\x69\x64",$array[(0x0994+ 6568-0x2338)]);__setCacheUserInfoFieldForUid (
$uid,"\x64\x69\x72",$array[(0x11f6+ 1370-0x174b)]);__setCacheUserInfoFieldForUid
 ($uid,"\x73\x68\x65\x6c\x6c",$array[(0x167f+ 4211-0x26ec)]);(my $username=
$array[(0x0512+ 2398-0x0e70)]);__setUsernameHashForUid ($username,$uid);return (
(0x19c5+ 228-0x1aa8));}sub __setUserInfoForUidWindows{(my $uid=shift (@_));(my $username
=convertWindowsSidToUsername ($uid));if (($username eq (""))){
__setCacheUserInfoFieldForUid ($uid,"\x6e\x61\x6d\x65",(""));
__setCacheUserInfoFieldForUid ($uid,"\x75\x69\x64",(""));return (
(0x19db+ 2993-0x258c));}__setCacheUserInfoFieldForUid ($uid,"\x6e\x61\x6d\x65",
$username);__setCacheUserInfoFieldForUid ($uid,"\x75\x69\x64",$uid);
__setUsernameHashForUid ($username,$uid);return ((0x0399+ 3107-0x0fbb));}sub 
__setUserInfoForUid{(my $uid=shift (@_));return (__setUserInfoForUidUnix ($uid))
;}sub userInfoGetUsernameByUid{(my $uid=shift (@_));(my (%options)=getPwUid (
$uid));if ((defined ($options{"\x6e\x61\x6d\x65"})and ($options{
"\x6e\x61\x6d\x65"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x6e\x61\x6d\x65"})."\x2e")
);return ($options{"\x6e\x61\x6d\x65"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x095c+ 5953-0x209c)));}sub userInfoGetGidByUid{(my $uid=shift (@_));(my (
%options)=getPwUid ($uid));if ((defined ($options{"\x67\x69\x64"})and ($options{
"\x67\x69\x64"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x69\x64\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x67\x69\x64"})."\x2e"));
return ($options{"\x67\x69\x64"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x67\x69\x64\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((-
(0x1f9d+ 1299-0x24af)));}sub userInfoGetShellByUid{(my $uid=shift (@_));(my (
%options)=getPwUid ($uid));if ((defined ($options{"\x73\x68\x65\x6c\x6c"})and (
$options{"\x73\x68\x65\x6c\x6c"}ne ("")))){Logger::debug (((((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20").$options{"\x73\x68\x65\x6c\x6c"}).
"\x2e"));return ($options{"\x73\x68\x65\x6c\x6c"});}Logger::debug (((
"\x75\x73\x65\x72\x49\x6e\x66\x6f\x3a\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x69\x64\x3a\x20"
.$uid)."\x20\x72\x65\x74\x75\x72\x6e\x20\x2d\x31\x2e"));return ((""));}sub 
getEffectiveUid{if ((defined ($GLOBAL::CACHE_EFFECTIVE_UID)and (
$GLOBAL::CACHE_EFFECTIVE_UID ne ("")))){return ($GLOBAL::CACHE_EFFECTIVE_UID);}(my $uid
=__getEffectiveUidForCurrentProcess ());if (defined ($uid)){(
$GLOBAL::CACHE_EFFECTIVE_UID=$uid);}Logger::debug (((
"\x45\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x69\x64\x20\x69\x73\x3a\x20".$uid)
."\x2e"));return ($uid);}sub __getEffectiveUidForCurrentProcess{my ($uid);(my $returnValue
=libnxh::NXGetEffectiveUid ());if (($returnValue==(-(0x15d4+ 569-0x180c)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x69\x64\x20\x66\x6f\x72\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x70\x72\x6f\x63\x65\x73\x73\x2e\x20\x52\x65\x74\x75\x72\x6e\x20\x76\x61\x6c\x75\x65\x20\x69\x73\x3a\x20"
.$returnValue)."\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20\x27").
$errorString)."\x27\x2e"));return ((""));}($uid=$returnValue);return ($uid);}sub
 getEffectiveShell{if ((defined ($GLOBAL::CACHE_EFFECTIVE_SHELL)and (
$GLOBAL::CACHE_EFFECTIVE_SHELL ne ("")))){return ($GLOBAL::CACHE_EFFECTIVE_SHELL
);}(my $shell=__getEffectiveShell ());if (((not (defined ($shell)))or ($shell eq
 ("")))){($GLOBAL::CACHE_EFFECTIVE_SHELL=__getShellIfNotAvailable ());}else{
Logger::debug (((
"\x45\x66\x66\x65\x63\x74\x69\x76\x65\x20\x73\x68\x65\x6c\x6c\x20\x69\x73\x3a\x20"
.$shell)."\x2e"));($GLOBAL::CACHE_EFFECTIVE_SHELL=$shell);}return (
$GLOBAL::CACHE_EFFECTIVE_SHELL);}sub __getEffectiveShell{my ($shell);(my $uid=
getEffectiveUid ());($shell=userInfoGetShellByUid ($uid));return ($shell);}sub 
uidToUsername{(my $uid=shift (@_));if (((not (defined ($uid)))or ($uid eq ("")))
){Logger::warning (
"\x75\x69\x64\x54\x6f\x55\x73\x65\x72\x6e\x61\x6d\x65\x3a\x20\x75\x69\x64\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e\x20\x47\x65\x74\x74\x69\x6e\x67\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x69\x64\x2e"
);($uid=getEffectiveUid ());}return (userInfoGetUsernameByUid ($uid));}sub 
__getShellIfNotAvailable{(my $euid=getEffectiveUid ());my ($shell);if (
Common::NXFile::isExists ("\x2f\x62\x69\x6e\x2f\x62\x61\x73\x68")){
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x69\x64\x20\x27"
.$euid).
"\x27\x3a\x20\x75\x73\x69\x6e\x67\x20\x27\x2f\x62\x69\x6e\x2f\x62\x61\x73\x68\x27"
),(0x05cd+ 7749-0x2412));($shell="\x2f\x62\x69\x6e\x2f\x62\x61\x73\x68");}else{
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x73\x68\x65\x6c\x6c\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x69\x64\x20\x27"
.$euid).
"\x27\x3a\x20\x75\x73\x69\x6e\x67\x20\x27\x2f\x62\x69\x6e\x2f\x73\x68\x27"),
(0x16a7+ 1877-0x1dfc));($shell="\x2f\x62\x69\x6e\x2f\x73\x68");}return ($shell);
}sub getProcessIdsByNameAndPpidOnWindows{(my $name=shift (@_));(my $ppid=shift (
@_));(my $strict=(0x0d9d+ 6415-0x26ac));return (
__getPidsByNameWithExtensionAndPpidOnWindows ($name,$ppid,$strict));}sub 
getProcessIdsByNameWithExtensionAndPpidOnWindows{(my $name=shift (@_));(my $ppid
=shift (@_));(my $strict=(0x0e42+ 996-0x1225));return (
__getPidsByNameWithExtensionAndPpidOnWindows ($name,$ppid,$strict));}sub 
getProcessIdsByNameWithExtensionOnWindows{(my $name=shift (@_));(my $ppid=
(0x05b3+ 5005-0x1940));(my $strict=(0x0443+ 1700-0x0ae6));return (
__getPidsByNameWithExtensionAndPpidOnWindows ($name,$ppid,$strict));}sub 
getProcessIdsByNameOnWindows{(my $name=shift (@_));(my $ppid=
(0x03fa+ 948-0x07ae));(my $strict=(0x1132+ 2804-0x1c26));return (
__getPidsByNameWithExtensionAndPpidOnWindows ($name,$ppid,$strict));}sub 
__getPidsByNameWithExtensionAndPpidOnWindows{(my $name=shift (@_));(my $ppid=(
shift (@_)||(0x1026+ 2439-0x19ad)));(my $strict=(shift (@_)||
(0x18f4+ 3600-0x2704)));(my $pids=libnxh::NXGetPidsByNameAndParentPid ($name,
$ppid,$strict));return (@$pids);}sub __setConsoleEchoMode{(my $mode=shift (@_));
(my $result=libnxh::NXSetEchoMode ($mode));if (($result!=(0x1cc9+ 2530-0x26ab)))
{reportErrorFromNXPL (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x74\x65\x72\x6d\x69\x6e\x61\x6c\x20\x65\x63\x68\x6f\x20\x6d\x6f\x64\x65\x2e"
);return ((0x0644+ 678-0x08ea));}return ((0x0049+ 9655-0x25ff));}sub 
enableConsoleEchoMode{return (__setConsoleEchoMode ((0x0efd+ 1702-0x15a2)));}sub
 disableConsoleEchoMode{return (__setConsoleEchoMode ((0x23a6+ 658-0x2638)));}
sub loadNXLibrary{(my $library=shift (@_));if (isNXLibraryLoaded ($library)){
Logger::debug ((("\x27".$library).
"\x27\x20\x6c\x69\x62\x72\x61\x72\x79\x20\x77\x61\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x6c\x6f\x61\x64\x65\x64\x2e"
));return;}(my (@backupINC)=@INC);if (($GLOBAL::AgentLibraryPath ne (""))){push 
(@INC,(($GLOBAL::AgentLibraryPath.$GLOBAL::DIRECTORY_SLASH)."\x70\x65\x72\x6c"))
;push (@INC,$GLOBAL::AgentLibraryPath);}push (@INC,(((($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62").$GLOBAL::DIRECTORY_SLASH).
"\x70\x65\x72\x6c"));push (@INC,(($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x6c\x69\x62"));(my $libraryreq=(("\x6e\x78\x63\x6f\x72\x65\x2f".$library).
"\x2e\x70\x6d"));eval{require ($libraryreq);};(@INC=@backupINC);if ($@){(my $errString
=$!);(my $errNo=int ($!));syswrite (STDERR,((
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x6f\x61\x64\x20\x74\x68\x65\x20\x27"
.$library)."\x27\x20\x6c\x69\x62\x72\x61\x72\x79\x2e\x0a"));syswrite (STDERR,(((
(
"\x4e\x58\x3e\x20\x35\x39\x36\x20\x45\x72\x72\x6f\x72\x3a\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errNo)."\x2c\x20\x27").$errString)."\x27\x2e\x0a"));exit (
(0x03b2+ 7788-0x221d));}setNXLibraryLoaded ($library);return (
(0x1855+ 1509-0x1e3a));}sub loadAllModulesLibraries{if (($NXBegin::moduletype eq
 "\x6e\x78\x73\x65\x72\x76\x65\x72")){loadListOfLibraries ((
\@NXCore::NXServerLibraryList));}elsif (($NXBegin::moduletype eq 
"\x6e\x78\x6e\x6f\x64\x65")){loadListOfLibraries ((\@NXCore::NXNodeLibraryList))
;}elsif (($NXBegin::moduletype eq "\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72"
)){loadListOfLibraries ((\@NXCore::NXWebPlayerLibraryList));}}sub 
loadListOfLibraries{(my $libraryList=shift (@_));foreach my $library (@{
$libraryList;}){loadNXLibrary ($library);}}sub loadAgentLibraries{foreach my $library
 (@NXCore::NXAgentLibraryList){loadNXLibrary ($library);}}sub 
isAllServerLibrariesLoaded{foreach my $library (@NXCore::NXServerLibraryList){if
 (($$NXCore::NXLibrary{"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{
$library}==(0x1715+ 2785-0x21f6))){return ((0x143f+ 3403-0x218a));}}return (
(0x1109+ 4635-0x2323));}sub isAllNodeLibrariesLoaded{foreach my $library (
@NXCore::NXNodeLibraryList){if (($$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{$library}==
(0x02ff+ 3937-0x1260))){return ((0x057b+ 2481-0x0f2c));}}return (
(0x1202+ 2995-0x1db4));}sub isAllWebplayerLibrariesLoaded{foreach my $library (
@NXCore::NXWebPlayerLibraryList){if (($$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{$library}==
(0x17d2+ 767-0x1ad1))){return ((0x032b+ 7258-0x1f85));}}return (
(0x0516+ 6804-0x1fa9));}sub isNXLibraryLoaded{(my $library=shift (@_));
Logger::debug (((((
"\x69\x73\x4e\x58\x4c\x69\x62\x72\x61\x72\x79\x4c\x6f\x61\x64\x65\x64\x20\x27".
$library)."\x27\x20\x3d\x20\x27").$$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{$library})."\x27\x2e"));if (
($$NXCore::NXLibrary{"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{
$library}==(0x079c+ 1453-0x0d48))){return ((0x1292+ 4109-0x229e));}else{return (
(0x018f+ 7520-0x1eef));}}sub isNXLibraryLoadedForModule{if ((
$NXBegin::moduletype eq "\x6e\x78\x73\x65\x72\x76\x65\x72")){return (
isAllServerLibrariesLoaded ());}elsif (($NXBegin::moduletype eq 
"\x6e\x78\x6e\x6f\x64\x65")){return (isAllNodeLibrariesLoaded ());}elsif ((
$NXBegin::moduletype eq "\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72")){return 
(isAllWebplayerLibrariesLoaded ());}return ((0x09a5+ 6133-0x219a));}sub 
setNXLibraryLoaded{(my $library=shift (@_));($$NXCore::NXLibrary{
"\x6c\x69\x62\x72\x61\x72\x79\x5f\x72\x65\x66\x73"}{$library}=
(0x0c81+ 6466-0x25c2));}sub listContentInDirectory{(my $path=shift (@_));(my $ref_contentArray
=shift (@_));(my $ref_error=shift (@_));(my $contentString=
libnxh::NXListContentInDirectory ($path));if (($contentString eq (""))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x69\x73\x74\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x63\x6f\x6e\x74\x65\x6e\x74\x2e"
);Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString)."\x2e"));($$ref_error=$errorString);return (
(0x027f+ 2513-0x0c50));}(my (@lines)=split ( /\n/ ,$contentString,
(0x00e4+ 274-0x01f6)));foreach my $line (@lines){if ((($line ne "\x2e")and (
$line ne "\x2e\x2e"))){push (@$ref_contentArray,$line);}}return (
(0x1002+ 3470-0x1d8f));}sub listFilesInDirectory{(my $path=shift (@_));(my $ref_filesArray
=shift (@_));(my $sort=(shift (@_)||(0x20d8+ 963-0x249b)));(my $ref_error=shift 
(@_));(my (@content)=());(my $result=listContentInDirectory ($path,(\@content),
$ref_error));if (($result==(0x0094+ 1941-0x0829))){return ((0x169c+ 1385-0x1c05)
);}my (@files);if ($sort){(@files=sort (@content));}else{(@files=@content);}
foreach my $file (@files){(my $filePath=(($path.$GLOBAL::DIRECTORY_SLASH).$file)
);if (Common::NXFile::fileExists ($filePath)){push (@$ref_filesArray,$file);}}
return ((0x0c0d+ 2397-0x1569));}sub listFoldersInDirectory{(my $path=shift (@_))
;(my $ref_foldersArray=shift (@_));(my $ref_error=shift (@_));(my (@folders)=())
;(my $result=listContentInDirectory ($path,(\@folders),$ref_error));if (($result
==(0x0f02+ 1370-0x145c))){return ((0x114f+ 2062-0x195d));}foreach my $folder (
@folders){(my $folderPath=(($path.$GLOBAL::DIRECTORY_SLASH).$folder));if (-d (
$folderPath)){push (@$ref_foldersArray,$folder);}}return ((0x028f+ 5527-0x1825))
;}sub listSortedFilesInDirectory{(my $path=shift (@_));(my $ref_filesArray=shift
 (@_));(my $ref_error=shift (@_));(my $sort=(0x0899+ 7215-0x24c7));return (
listFilesInDirectory ($path,$ref_filesArray,$sort,$ref_error));}sub 
__createZipFile{(my $destination=shift (@_));(my $ref_paths=shift (@_));(my $ref_names
=shift (@_));(my $ref_excludePaths=shift (@_));(my $append=shift (@_));(my $level
=shift (@_));(my $password=shift (@_));(my $ref_error=shift (@_));
__removeExtraSlashesFromZipPaths ($ref_paths,$ref_names,$ref_excludePaths);(my $returnValue
=libnxh::NXCreateZipFile ($destination,$ref_paths,$ref_names,$ref_excludePaths,
$append,$level,$password));if (($returnValue!=(0x1403+ 2372-0x1d47))){if ((
$returnValue==(-(0x0231+ 9289-0x2679)))){(my $errorNumber=libnxh::NXGetError ())
;(my $errorString=libnxh::NXGetErrorString ());Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x61\x72\x63\x68\x69\x76\x65\x20\x66\x69\x6c\x65\x20"
.$destination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").((
$errorNumber."\x2c\x20").$errorString)));($$ref_error=$errorString);return ((-
(0x1beb+ 1646-0x2258)));}else{(my $nxerrorFilePath=
Common::NXPaths::getNXServerLogPath ());Logger::warning (((
"\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x72\x63\x68\x69\x76\x65\x20\x66\x69\x6c\x65\x20"
.$destination).
"\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x77\x61\x72\x6e\x69\x6e\x67\x73\x2e"
));Logger::warning ((
"\x46\x6f\x72\x20\x6d\x6f\x72\x65\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x20\x70\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20"
.$nxerrorFilePath));return ((0x1cb5+ 1525-0x22aa));}}Logger::debug (((
"\x5a\x69\x70\x20\x66\x69\x6c\x65\x3a\x20".$destination).
"\x20\x63\x72\x65\x61\x74\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79"
));return ((0x127d+ 2240-0x1b3c));}sub __removeExtraSlashesFromZipPaths{(my $ref_paths
=shift (@_));(my $ref_names=shift (@_));(my $ref_excludePaths=shift (@_));
foreach my $path (@$ref_paths){Common::NXPaths::removeExtraSlashesFromPath ((
\$path));}foreach my $path (@$ref_names){
Common::NXPaths::removeExtraSlashesFromPath ((\$path));}foreach my $path (
@$ref_excludePaths){Common::NXPaths::removeExtraSlashesFromPath ((\$path));}}sub
 createZipFileWithBestCompression{(my $destination=shift (@_));(my $ref_paths=
shift (@_));(my $ref_names=shift (@_));(my $ref_excludePaths=shift (@_));(my $ref_error
=shift (@_));my ($password);(my $returnValue=__createZipFile ($destination,
$ref_paths,$ref_names,$ref_excludePaths,$NXBITS::APPEND_STATUS_CREATE,
$NXBITS::Z_BEST_COMPRESSION,$password,$ref_error));return ($returnValue);}sub 
runNextIterationAfterRunCallback{(my $ref_descriptors=shift (@_));(my $ref_result
=shift (@_));(my $nxselectTimeoutTimestamp=shift (@_));(my $actualTime=shift (@_
));(my $timeout=($nxselectTimeoutTimestamp-$actualTime));return (nxselect (
$ref_descriptors,$timeout,$ref_result));}sub 
isCallbackTimestampBeforeSelectTimeout{(my $nxselectTimeout=shift (@_));(my $firstCallbackTimestamp
=shift (@_));if (($nxselectTimeout>$firstCallbackTimestamp)){return (
(0x1fd4+ 1757-0x26b0));}return ((0x0159+ 6835-0x1c0c));}sub 
isTimeToRunTimestampCallback{(my $firstCallbackTimestamp=shift (@_));(my $currentTime
=shift (@_));(my $timeout=($firstCallbackTimestamp-$currentTime));if (($timeout
<=(0x0ecf+ 4595-0x20c2))){return ((0x1015+ 599-0x126b));}return (
(0x06a0+ 4515-0x1843));}sub setNewSelectTimeout{(my $firstCallbackTimestamp=
shift (@_));(my $currentTime=shift (@_));return (($firstCallbackTimestamp-
$currentTime));}sub getCommandLineOfCurrentProcessOnWindows{(my $commandLine=
libnxhs::NXGetCommandLine ());if (($commandLine eq (""))){return ((""));}
libnxh::NXGetConsoleOutput ();libnxh::NXSetConsoleOutputUTF8 ();(
$NXCore::windowsConsoleCPGet=(0x0b28+ 5147-0x1f42));return ($commandLine);}sub 
restoreConsoleCPonWindows{if (($NXCore::windowsConsoleCPGet==
(0x0ca5+ 4884-0x1fb8))){libnxh::NXSetDefaultConsoleOutput ();}}sub 
parseProcessArgumentsFromCommandLineOnWindows{(my $commandLine=
getCommandLineOfCurrentProcessOnWindows ());($commandLine=~ s/"//g );(my (
@arguments)=split ( / {1,}/ ,$commandLine,(0x02bf+ 4277-0x1374)));while (
@arguments){(my $arg=shift (@arguments));if (($arg=~ /nxserver/ )){last;}}return
 (@arguments);}sub convertCommandLineArgumentsOnWindows{(my (@newArguments)=
parseProcessArgumentsFromCommandLineOnWindows ());(my $numberOfNewArguments=
scalar (@newArguments));if ((($numberOfNewArguments>(0x0c3c+ 150-0x0cd2))and (
$numberOfNewArguments==scalar (@ARGV)))){(@ARGV=@newArguments);return (
(0x1345+ 3690-0x21ae));}return ((0x0229+ 1340-0x0765));}sub 
addUserToSystemOnWindows{(my $username=shift (@_));(my $password=shift (@_));(my $ref_error
=shift (@_));(my $returnValue=libnxhs::NXNetUserAdd ($username,$password));if ((
$returnValue!=(0x02d4+ 7442-0x1fe5))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x75\x73\x65\x72\x20".$username).
"\x20\x74\x6f\x20\x73\x79\x73\x74\x65\x6d\x2e"));(my $error=
getErrorStringForErrorCodeOnWindows ($returnValue));if (($error ne (""))){
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$returnValue).
"\x2c\x20").$error)."\x2e"));($$ref_error=$error);}return ((0x1496+ 1235-0x1969)
);}Logger::debug ((("\x41\x64\x64\x65\x64\x20\x75\x73\x65\x72\x20".$username).
"\x20\x74\x6f\x20\x73\x79\x73\x74\x65\x6d\x2e"));return ((0x15cb+ 1145-0x1a43));
}sub deleteUserFromSystemOnWindows{(my $username=shift (@_));(my $ref_error=
shift (@_));(my $returnValue=libnxhs::NXNetUserDel ($username));if ((
$returnValue!=(0x1228+ 4080-0x2217))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x75\x73\x65\x72\x20".
$username)."\x20\x66\x72\x6f\x6d\x20\x73\x79\x73\x74\x65\x6d\x2e"));(my $error=
getErrorStringForErrorCodeOnWindows ($returnValue));if (($error ne (""))){
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$returnValue).
"\x2c\x20").$error)."\x2e"));($$ref_error=$error);}return ((0x1b69+ 349-0x1cc6))
;}Logger::debug ((("\x44\x65\x6c\x65\x74\x65\x64\x20\x75\x73\x65\x72\x20".
$username)."\x20\x66\x72\x6f\x6d\x20\x73\x79\x73\x74\x65\x6d\x2e"));return (
(0x1bc5+ 1069-0x1ff1));}sub setUserSystemPasswordOnWindows{(my $username=shift (
@_));(my $password=shift (@_));(my $ref_error=shift (@_));(my $returnValue=
libnxhs::NXNetUserPass ($username,$password));if (($returnValue!=
(0x2153+ 1256-0x263a))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x75\x73\x65\x72\x20".$username).
"\x20\x70\x61\x73\x73\x73\x77\x6f\x72\x64\x2e"));(my $error=
getErrorStringForErrorCodeOnWindows ($returnValue));if (($error ne (""))){
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$returnValue).
"\x2c\x20").$error)."\x2e"));($$ref_error=$error);}return ((0x021f+ 5739-0x188a)
);}Logger::debug ((("\x55\x73\x65\x72\x20".$username).
"\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x63\x68\x61\x6e\x67\x65\x2e"));return 
((0x0699+ 4172-0x16e4));}sub getErrorStringForErrorCodeOnWindows{(my $errorCode=
shift (@_));(my $returnValue=libnxh::NXGetErrorMessage ($errorCode));if ((
$returnValue ne (""))){chop ($returnValue);chop ($returnValue);return (
$returnValue);}return ((""));}sub __setCurrentNXSelectDescriptos{(my $ref_descriptors
=shift (@_));(++$NXCore::nxselectIteration);foreach $FD (@$ref_descriptors){(
$$NXCore::currentNXSelectDescriptors{$NXCore::nxselectIteration}{$FD}={});}}sub 
__removeDescriptorFromNXSelectCurrentList{(my $FD=shift (@_));for ((my $i=
(0x1e69+ 2127-0x26b7));($i<=$NXCore::nxselectIteration);(++$i)){if (exists (
$$NXCore::currentNXSelectDescriptors{$i}{$FD})){delete (
$$NXCore::currentNXSelectDescriptors{$i}{$FD});}}}sub 
__getCurrentNXSelectDescriptorsAndClean{(my (@descriptors)=keys (%{
$$NXCore::currentNXSelectDescriptors{$NXCore::nxselectIteration};}));
__cleanCurrentNXSelectIteration ();return ((\@descriptors));}sub 
__cleanCurrentNXSelectIteration{($$NXCore::currentNXSelectDescriptors{
$NXCore::nxselectIteration}={});($NXCore::nxselectIteration--);}sub 
leftJustifyString{(my $string=shift (@_));(my $maxLength=shift (@_));(my $character
=(shift (@_)||"\x20"));(my $length=libnxh::NXStringLength ($string));(my $fillCount
=($maxLength-$length));if (($fillCount>(0x0380+ 3604-0x1194))){return (($string.
($character x $fillCount)));}return ($string);}sub leftJustifyOrTrimString{(my $string
=shift (@_));(my $maxLength=shift (@_));(my $character=(shift (@_)||"\x20"));(my $length
=libnxh::NXStringLength ($string));(my $fillCount=($maxLength-$length));if ((
$fillCount>(0x0e76+ 3719-0x1cfd))){return (($string.($character x $fillCount)));
}elsif (($fillCount<(0x0f47+ 390-0x10cd))){return (libnxh::NXSubstring ($string,
(0x16df+ 2722-0x2181),$maxLength));}return ($string);}sub 
isCurrentUserSystemAdmin{(my $user=getEffectiveUsername ());Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x66\x20\x75\x73\x65\x72\x20".$user).
"\x20\x69\x73\x20\x73\x79\x73\x74\x65\x6d\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2e"
));(my $systemgroup=getUserGroupsFromSystem ($user));(my (@groupList)=split ( /,/ ,
$systemgroup,(0x21cc+ 945-0x257d)));foreach my $groupname (@groupList){(my $group
=main::urldecode ($groupname));if (($group eq "\x73\x75\x64\x6f")){Logger::debug
 ((("\x55\x73\x65\x72\x20".$user)."\x20\x69\x73\x20\x73\x75\x64\x6f\x65\x72\x2e"
));return ((0x1e78+ 456-0x203f));}if (($group eq "\x61\x64\x6d\x69\x6e")){
Logger::debug ((("\x55\x73\x65\x72\x20".$user).
"\x20\x69\x73\x20\x61\x64\x6d\x69\x6e\x2e"));return ((0x0e7b+ 3721-0x1d03));}}
return ((0x119c+ 3068-0x1d98));Logger::debug ((("\x55\x73\x65\x72\x20".$user).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x79\x73\x74\x65\x6d\x20\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2e"
));}sub processPurgeArg{(my $msg=shift (@_));Logger::debug3 (((
"\x4e\x58\x43\x6f\x72\x65\x3a\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x50\x75\x72\x67\x65\x41\x72\x67\x28"
.$msg)."\x29\x2e"));libnxh::NXProcessPurgeArg ($msg);Logger::debug3 (((
"\x4e\x58\x43\x6f\x72\x65\x20\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x50\x72\x6f\x63\x65\x73\x73\x50\x75\x72\x67\x65\x41\x72\x67\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$msg)."\x27\x2e"));return ($msg);}return ((0x04a2+ 973-0x086e));
