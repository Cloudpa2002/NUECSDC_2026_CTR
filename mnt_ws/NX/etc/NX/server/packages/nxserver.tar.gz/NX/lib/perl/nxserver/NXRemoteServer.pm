############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXRemoteServer;no warnings;(my $__name="\x6e\x6f\x74\x73\x65\x74");(my $__majorVersion
="\x6e\x6f\x74\x73\x65\x74");(my $__minorVersion="\x6e\x6f\x74\x73\x65\x74");(my $__patchVersion
="\x6e\x6f\x74\x73\x65\x74");(my $__license="\x6e\x6f\x74\x73\x65\x74");(my $__supportsSha256
=(0x2044+ 1054-0x2461));(my $__supportUUIDInHello=(0x02fc+ 1165-0x0788));(my $__supportForwardCnnection
=(0x0077+ 1418-0x0600));(my $__supportCreatingUnencryptedForwarder=
(0x1046+ 1323-0x1571));(my $__supportCheckingMultinodeAvailability=
(0x0931+ 1468-0x0eec));(my $__supportSeparateAuthInMulitServer=
(0x0ae5+ 3945-0x1a4d));(my $__supportCreatingUnencryptedForwarderForServer=
(0x0aaf+ 622-0x0d1d));(my $__supportCheckSslCompatibility=(0x18b2+ 153-0x194b));
sub setName{($__name=shift (@_));}sub setMajorVersion{($__majorVersion=shift (@_
));}sub setMinorVersion{($__minorVersion=shift (@_));}sub setPatchVersion{(
$__patchVersion=shift (@_));}sub setLicense{($__license=shift (@_));}sub 
getLicense{return ($__license);}sub getVersion{return ($__majorVersion);}sub 
handleTypeAndVersion{(my $name=shift (@_));(my $majorVersion=shift (@_));(my $minorVersion
=shift (@_));(my $patchVersion=shift (@_));(my $license=shift (@_));if ((
$license=~ /(.*) (\d+)$/ )){($license=$1);(my $licenseVersion=$2);}Logger::debug
 ((((((((((("\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20".$name).
"\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x28").$majorVersion)."\x2e").$minorVersion
)."\x2e").$patchVersion).
"\x29\x20\x6f\x70\x65\x72\x61\x74\x69\x6e\x67\x20\x6f\x6e\x20\x6c\x69\x63\x65\x6e\x73\x65\x20"
).$license)."\x2e"));setName ($name);setMajorVersion ($majorVersion);
setMinorVersion ($minorVersion);setPatchVersion ($patchVersion);setLicense (
$license);setIfSupportsSha256 ();setSupportUUIDInHelloMessage ();
setSupportCheckingMultinodeAvailability ();setSupportForwardConnection ();
setSupportSeparateAuthInMulitServer ();setSupportsServerListConnections ();
setSupportsCheckServerLoop ();setSupportCheckSslCompatibility ();}sub 
isVersionLesserOrEqual{(my $major=shift (@_));(my $minor=shift (@_));(my $patch=
shift (@_));if ((not (isVersionSet ()))){return ((0x1c94+ 1959-0x243b));}if ((
not (defined ($major)))){Logger::debug (
"\x55\x73\x65\x6c\x65\x73\x73\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x77\x69\x74\x68\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x2e"
);return ((0x21a3+ 391-0x2329));}elsif ((not (defined ($minor)))){($minor=
"\x61\x6e\x79");($patch="\x61\x6e\x79");}elsif ((not (defined ($patch)))){(
$patch="\x61\x6e\x79");}if (($__majorVersion<$major)){return (
(0x04ec+ 2174-0x0d69));}if (($__majorVersion==$major)){if ((($minor eq 
"\x61\x6e\x79")or ($__minorVersion<$minor))){return ((0x10ad+ 2322-0x19be));}if 
(($__minorVersion==$minor)){if ((($patch eq "\x61\x6e\x79")or ($__patchVersion<=
$patch))){return ((0x07e5+ 403-0x0977));}}}return ((0x1be6+ 1696-0x2286));}sub 
isVersionSet{if ((((((($__majorVersion eq "\x6e\x6f\x74\x73\x65\x74")or (
$__majorVersion eq ("")))or ($__minorVersion eq "\x6e\x6f\x74\x73\x65\x74"))or (
$__minorVersion eq ("")))or ($__patchVersion eq "\x6e\x6f\x74\x73\x65\x74"))or (
$__patchVersion eq ("")))){return ((0x0723+ 6193-0x1f54));}return (
(0x1459+ 1293-0x1965));}sub setIfSupportsSha256{if (isVersionLesserOrEqual (
(0x04a9+ 3984-0x1434),(0x2084+ 326-0x21ca),(0x1161+ 4529-0x2305))){(
$__supportsSha256=(0x04e3+ 1383-0x0a4a));}else{($__supportsSha256=
(0x043d+ 2318-0x0d4a));}}sub isSupportingSha256{if (($__supportsSha256==
(0x084d+ 5853-0x1f29))){return ((0x0533+ 4283-0x15ed));}return (
(0x00ad+ 5750-0x1723));}sub setSupportUUIDInHelloMessage{if (
isVersionLesserOrEqual ((0x19b8+ 1438-0x1f51),(0x0af7+ 760-0x0def),
(0x0075+ 2386-0x09a8))){($__supportUUIDInHello=(0x0da4+ 5587-0x2377));}else{(
$__supportUUIDInHello=(0x061c+ 7126-0x21f1));}}sub isSupportUUIDInHelloMessage{
if (($__supportUUIDInHello==(0x0a24+ 6677-0x2438))){return (
(0x0503+ 4557-0x16cf));}return ((0x09ad+ 4139-0x19d8));}sub 
setSupportCheckingMultinodeAvailability{if (isVersionLesserOrEqual (
(0x00af+ 3495-0x0e51),(0x107b+ 5194-0x24c5),(0x0bbd+ 6306-0x2454))){(
$__supportCheckingMultinodeAvailability=(0x12c1+ 2639-0x1d10));}else{(
$__supportCheckingMultinodeAvailability=(0x0853+ 6656-0x2252));}}sub 
isSupportCheckingMultinodeAvailability{if ((
$__supportCheckingMultinodeAvailability==(0x06b7+ 2240-0x0f76))){return (
(0x13b7+ 1672-0x1a3e));}return ((0x082c+ 2784-0x130c));}sub 
setSupportForwardConnection{if (isVersionLesserOrEqual ((0x185f+ 2458-0x21f3),
(0x197b+  30-0x1999),(0x01e0+ 2002-0x099d))){($__supportForwardCnnection=
(0x0155+ 9318-0x25bb));}else{($__supportForwardCnnection=(0x01d1+ 651-0x045b));}
}sub isSupportForwardConnection{if (($__supportForwardCnnection==
(0x061b+ 1092-0x0a5e))){return ((0x1213+ 2815-0x1d11));}return (
(0x0134+ 1430-0x06ca));}sub enableUnencryptedForwarder{Logger::debug (
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x53\x65\x72\x76\x65\x72\x3a\x20\x45\x6e\x61\x62\x6c\x69\x6e\x67\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x66\x6f\x72\x20\x75\x6e\x65\x6e\x63\x72\x79\x70\x74\x65\x64\x20\x66\x6f\x72\x77\x61\x72\x64\x65\x72\x2e"
);($__supportCreatingUnencryptedForwarder=(0x064f+ 1123-0x0ab1));(
$__supportCreatingUnencryptedForwarderForServer=(0x07d8+ 1181-0x0c74));}sub 
isSupportCreatingUnencryptedForwarderForNodes{if ((
$__supportCreatingUnencryptedForwarder==(0x0af5+ 337-0x0c45))){return (
(0x1842+ 2982-0x23e7));}return ((0x01f8+ 3056-0x0de8));}sub 
isSupportCreatingUnencryptedForwarderForServer{if ((
$__supportCreatingUnencryptedForwarderForServer==(0x0622+ 5479-0x1b88))){return 
((0x10d7+ 5559-0x268d));}return ((0x04e3+ 3896-0x141b));}sub 
setSupportSeparateAuthInMulitServer{if (isVersionLesserOrEqual (
(0x060d+ 3718-0x148d),(0x13b9+ 4423-0x24f9),(0x06b0+ 397-0x0832))){(
$__supportSeparateAuthInMulitServer=(0x0469+ 1115-0x08c4));Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x73\x65\x70\x61\x72\x61\x74\x65\x20\x61\x75\x74\x68\x2e"
);}else{($__supportSeparateAuthInMulitServer=(0x0c69+ 6493-0x25c5));
Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x73\x65\x70\x61\x72\x61\x74\x65\x20\x61\x75\x74\x68\x2e"
);}}sub doesSupportSeparateAuthInMulitServer{return (
$__supportSeparateAuthInMulitServer);}sub setSupportsServerListConnections{if (
isVersionLesserOrEqual ((0x196d+ 2663-0x23cd),(0x024b+ 8795-0x24a6),
(0x1647+ 1906-0x1d11))){($__supportServerListConnections=(0x1578+ 665-0x1811));
Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x73\x65\x72\x76\x65\x72\x20\x6c\x69\x73\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x2e"
);}else{($__supportServerListConnections=(0x1491+ 3027-0x2063));Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x73\x65\x72\x76\x65\x72\x20\x6c\x69\x73\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73\x2e"
);}}sub doesSupportServerListConnections{return ($__supportServerListConnections
);}sub setSupportsCheckServerLoop{if (isVersionLesserOrEqual (
(0x16aa+ 522-0x18ad),(0x018b+ 3783-0x1052),(0x1789+ 298-0x17f9))){(
$__supportCheckServerLoop=(0x1c37+ 375-0x1dae));Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x63\x68\x65\x63\x6b\x20\x73\x65\x72\x76\x65\x72\x20\x6c\x6f\x6f\x70\x2e"
);}else{($__supportCheckServerLoop=(0x1340+ 2550-0x1d35));Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20\x63\x68\x65\x63\x6b\x20\x73\x65\x72\x76\x65\x72\x20\x6c\x6f\x6f\x70\x2e"
);}}sub doesSupportCheckServerLoop{return ($__supportServerListConnections);}sub
 setSupportCheckSslCompatibility{if (isVersionLesserOrEqual (
(0x1266+ 3843-0x2161),(0x1820+ 3016-0x23dd),(0x0db5+ 2183-0x1639))){(
$__supportCheckSslCompatibility=(0x0b0d+ 5704-0x2155));Logger::debug (
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x53\x65\x72\x76\x65\x72\x3a\x20\x44\x6f\x65\x73\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x63\x68\x65\x63\x6b\x20\x53\x53\x4c\x20\x63\x6f\x6d\x70\x61\x74\x69\x62\x69\x6c\x69\x74\x79\x2e"
);return ((0x012d+ 2716-0x0bc9));}($__supportCheckSslCompatibility=
(0x200b+ 1740-0x26d6));Logger::debug (
"\x4e\x58\x52\x65\x6d\x6f\x74\x65\x53\x65\x72\x76\x65\x72\x3a\x20\x53\x75\x70\x70\x6f\x72\x74\x73\x20\x63\x68\x65\x63\x6b\x20\x53\x53\x4c\x20\x63\x6f\x6d\x70\x61\x74\x69\x62\x69\x6c\x69\x74\x79\x2e"
);return ((0x023c+ 6774-0x1cb1));}sub doesSupportCheckSslCompatibility{if ((
$__supportCheckSslCompatibility==(0x0c95+ 1158-0x111a))){return (
(0x015b+ 8802-0x23bc));}return ((0x027a+ 9355-0x2705));}return (
(0x11e7+ 2429-0x1b63));
