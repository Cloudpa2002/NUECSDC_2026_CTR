############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXLocate;no warnings;($lastIp=(""));($lastHost=(""));($command=(""));(
$WRITE_LOCATE=(""));($READ_LOCATE=(""));($lastLocateUpdate=
Common::NXTime::getSecondsSinceEpoch ());($commandClear=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x72\x65\x6d\x6f\x76\x65\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x6c\x6f\x63\x61\x6c"
);($inited=(0x03a9+ 2520-0x0d81));($started=(0x0064+ 8888-0x231c));(@array=());(
$serverStartup=(0x03c5+ 7420-0x20c1));($host_Index=(0x02c9+ 8238-0x22f7));(
$ip_Index=(0x094b+ 4517-0x1aef));($type_Index=(0x1874+ 1714-0x1f24));($os_Index=
(0x0671+ 4835-0x1951));($hw_Index=(0x0ca7+ 4272-0x1d53));($nx_Index=
(0x0aaf+ 7186-0x26bc));($ssh_Index=(0x068a+ 1817-0x0d9d));($https_Index=
(0x0ccd+ 4417-0x1e07));($mac_Index=(0x0569+ 580-0x07a5));($uuid_Index=
(0x166a+ 1394-0x1bd3));sub BEGIN{require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub getLastLocateUpdate{return (
$lastLocateUpdate);}sub setLastLocateUpdate{($lastLocateUpdate=
Common::NXTime::getSecondsSinceEpoch ());}sub checkUpdate{(my $now=
Common::NXTime::getSecondsSinceEpoch ());if (((getLastLocateUpdate ()+
updateLocateStep ())<=$now)){setLastLocateUpdate ();if ((checkIpChanged ()or 
checkHostChanged ())){update ();}}}sub checkIpChanged{(my $newIp=(""));if ((
defined ($GLOBAL::NXdListenAddress)and ($GLOBAL::NXdListenAddress ne ("")))){(
$newIp=$GLOBAL::NXdListenAddress);}else{($newIp=NXNodeInfo::getServerIp ());}if 
(($newIp eq $lastIp)){return ((0x0360+ 1192-0x0808));}return (
(0x1625+ 1487-0x1bf3));}sub checkHostChanged{(my $newHost=
Common::NXInfo::getHostInfo ());if (($newHost eq $lastHost)){return (
(0x0558+ 4837-0x183d));}return ((0x1d63+ 1294-0x2270));}sub writeCommand{(my $cmd
=shift (@_));if (($READ_LOCATE eq (""))){Logger::warning (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65\x20\x46\x44\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20"
.$cmd)."\x2e"));return ((0x0065+ 3865-0x0f7e));}Logger::debug (((((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6f\x6e\x20\x46\x44\x23"
.$READ_LOCATE)."\x3a\x20").$cmd)."\x2e"));(my $bytes_write=main::nxwrite (
$READ_LOCATE,($cmd."\x0a")));Logger::debug (((((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x77\x72\x6f\x74\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$READ_LOCATE)."\x3a\x20").$bytes_write)."\x20\x62\x79\x74\x65\x73\x2e"));return
 ($bytes_write);}sub prepareParameters{(my $length=@array);for ((my $i=
(0x04ef+ 2719-0x0f8e));($i<$length);(++$i)){if ((defined ($array[$i])and ($array
[$i]ne ("")))){($array[$i]=~ s/,/ /g );}if ((defined ($array[$i])and ($array[$i]
ne ("")))){($array[$i]=~ s/\s+/ /g );}if ((defined ($array[$i])and ($array[$i]ne
 ("")))){($array[$i]=~ s/\s*$//g );}}}sub buildNewCommand{Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x61\x72\x72\x61\x79\x3a\x20"
.join ($",@array))."\x2e"));(my $commandTMP=(""));if (((__getIp ()ne (""))and (
__getServices ()ne ("")))){prepareParameters ();($commandTMP=((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x6c\x6f\x63\x61\x6c\x2c\x6e\x61\x6d\x65\x73\x3d"
.__getHost ())."\x2c\x69\x70\x3d"));foreach my $f (split ("\x20",__getIp (),
(0x0b9b+ 6148-0x239f))){if (($f ne (""))){($commandTMP.=($f."\x3b"));}}(
$commandTMP=~ s/;$// );if (($commandTMP=~ /,ip=$/ )){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x67\x65\x74\x20\x69\x70\x20\x61\x64\x72\x65\x73\x73\x2e"
);($command=(""));return;}($commandTMP.=(((((("\x2c\x74\x79\x70\x65\x3d".
__getType ())."\x2c\x6f\x73\x3d").__getOs ())."\x2c\x68\x77\x3d").__getHw ()).
"\x2c\x73\x65\x72\x76\x69\x63\x65\x3d"));($commandTMP.=__getServices ());(
$commandTMP.="\x2c\x6d\x61\x63\x3d");($commandTMP.=__getMac ());($commandTMP.=
"\x2c\x75\x75\x69\x64\x3d");($commandTMP.=__getUuid ());($commandTMP.="\x0a");}
else{Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x6e\x6f\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6f\x72\x20\x64\x69\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x69\x70\x20\x61\x64\x72\x65\x73\x73\x2e"
);($command=(""));return;}chomp ($commandTMP);($command=$commandTMP);
Logger::debug ((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x6e\x65\x77\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x69\x73\x3a\x20"
.$commandTMP));}sub update{Logger::debug (
"\x57\x69\x6c\x6c\x20\x75\x70\x64\x61\x74\x65\x20\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x6e\x6f\x77\x2e"
);if ((not (wasStarted ()))){return (run ());}writeCommand ($commandClear);
setNewIp ();setNewHost ();buildNewCommand ();if (($command eq (""))){return (
(0x029a+ 390-0x0420));}writeCommand ($command);return ((0x13a2+ 845-0x16ee));}
sub setNewIp{__setIp ();($lastIp=__getIp ());}sub setNewHost{__setHost (
Common::NXInfo::getHostInfo ());($lastHost=__getHost ());}sub removeService{(my $service
=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x72\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20"
.$service)."\x2e"));if (($service eq "\x6e\x78\x64")){__setNx ((""));}elsif (((
$service eq "\x73\x73\x68\x64")or ($service eq "\x6e\x78\x73\x73\x68\x64"))){
__setSsh ((""));}elsif (($service eq "\x6e\x78\x68\x74\x64")){__setHttps ((""));
}update ();}sub addService{(my $service=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x61\x64\x64\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x3a\x20"
.$service)."\x2e"));if (($service eq "\x6e\x78\x64")){__setNx (
NXNodeInfo::getNxdPortIfEnabled ());}elsif ((($service eq "\x73\x73\x68\x64")or 
($service eq "\x6e\x78\x73\x73\x68\x64"))){__setSsh (NXNodeInfo::getSshdPort ())
;}elsif (($service eq "\x6e\x78\x68\x74\x64")){__setHttps (
NXNodeInfo::getHttpsPort ());}update ();}sub setInitCommand{__setHost (
Common::NXInfo::getHostInfo ());__setIp ();__setType (NXNodeInfo::getServerType 
());__setOs (Common::NXInfo::getDistroInfo ());__setHw (
Common::NXInfo::getHwInfo ());__setNx (NXNodeInfo::getNxdPortIfEnabled ());
__setSsh (NXNodeInfo::getSshdPort ());__setHttps (NXNodeInfo::getHttpsPort ());
__setMac (__getMacAddress ());__setUuid ($GLOBAL::UUID);buildNewCommand ();}sub 
initInfo{Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x69\x6e\x69\x74\x69\x61\x6c\x69\x7a\x69\x6e\x67"
);setInitCommand ();setServerStartup ();($inited=(0x0e7c+ 2170-0x16f5));}sub run
{if (wasStarted ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x77\x61\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x74\x61\x72\x74\x65\x64\x2e"
);return ((0x1b11+ 2097-0x2341));}if (($inited!=(0x1240+ 1206-0x16f5))){initInfo
 ();}Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x4e\x58\x4c\x6f\x63\x61\x74\x65");if (
main::nxPipeCreateBi ((\$READ_LOCATE),(\$WRITE_LOCATE))){Logger::debug (((((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x63\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x5b"
.$READ_LOCATE)."\x2f").$WRITE_LOCATE)."\x5d"));}else{Logger::error (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x70\x61\x69\x72\x2e"
);return ((0x0951+ 5072-0x1d21));}(my $setInheritableReturn=
libnxh::NXDescriptorInheritable ($READ_LOCATE,(0x15ac+ 2004-0x1d7f)));(my $homeDir
=NXPaths::getUserNXHomeDir ());libnxh::NXTransSetEnvironment ("\x48\x4f\x4d\x45"
,$homeDir);(my $writeLocateOutput=Common::NXCore::nxFileDuplicate ($WRITE_LOCATE
));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x4c\x6f\x63\x61\x74\x65\x43\x6c\x69\x65\x6e\x74\x43\x72\x65\x61\x74\x65\x28"
.$WRITE_LOCATE)."\x2c\x20").$writeLocateOutput).
"\x29\x20\x73\x74\x61\x72\x74\x2e\x20"));(my $ret=libnxhs::NXLocateClientCreate 
($WRITE_LOCATE,$writeLocateOutput));Logger::debug (((((((
"\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x4c\x6f\x63\x61\x74\x65\x43\x6c\x69\x65\x6e\x74\x43\x72\x65\x61\x74\x65\x28"
.$WRITE_LOCATE)."\x2c\x20").$writeLocateOutput).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x3a\x20").$ret)."\x2e"));
Common::NXCore::doNotCloseSocketAtFinish ($WRITE_LOCATE);if (($ret!=
(0x0ca5+ 3613-0x1ac1))){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x61\x72\x74\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65"
);main::nxclose ($READ_LOCATE);main::nxclose ($WRITE_LOCATE);return ($ret);}(
$started=(0x1472+ 4166-0x24b7));(my $msg=$command);return (writeCommand ($msg));
}sub wasStarted{return ($started);}sub NXLocateLogFile{return (((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x6c\x6f\x63\x61\x74\x65\x2e\x6c\x6f\x67"));}
sub isNXLocateEnabled{if ((Server::isDirectAccessDisabled ()or (not (
NXLicense::isDirectConnectionFeature ())))){return ((0x22c0+ 430-0x246e));}
return ($GLOBAL::EnableNetworkBroadcast);}sub close{if (isNXLocateEnabled ()){
Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x69\x73\x20\x63\x6c\x6f\x73\x69\x6e\x67\x2e"
);(my $ret=libnxhs::NXLocateClientDestroy ());if (($ret!=(0x1834+ 1408-0x1db3)))
{Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x74\x6f\x70\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65\x2e"
);return ($ret);}($started=(0x026b+ 7229-0x1ea8));Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x4c\x6f\x63\x61\x74\x65\x43\x6c\x69\x65\x6e\x74\x44\x65\x73\x74\x72\x6f\x79\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x3a\x20"
.$ret)."\x2e"));}else{return ((0x06ad+ 8129-0x266e));}}sub requestToRemove{(my $service
=shift (@_));if (((((($service ne "\x6e\x78\x68\x74\x64")and ($service ne 
"\x6e\x78\x64"))and ($service ne "\x73\x73\x68\x64"))and ($service ne 
"\x6e\x78\x73\x73\x68\x64"))or checkIfServerStartup ())){return;}unless (
NXSystemDaemons::isRunning ("\x6e\x78\x73\x65\x72\x76\x65\x72")){return (
(0x23f2+  66-0x2434));}Logger::debug (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x3a\x20\x27"
.$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x2e"));unless (
openConnectionToStartup ()){return ((0x0557+ 5227-0x19c2));}(my $res=
NXClientSystemDaemons::sendMessage ((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXLOCATE_STOP)."\x20").$service)."\x0a")));
closeConnectionWithStartup ();return ((0x1675+ 360-0x17dc));}sub requestToAdd{(my $service
=shift (@_));if (((((($service ne "\x6e\x78\x68\x74\x64")and ($service ne 
"\x6e\x78\x64"))and ($service ne "\x73\x73\x68\x64"))and ($service ne 
"\x6e\x78\x73\x73\x68\x64"))or checkIfServerStartup ())){return;}Logger::debug (
((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x6f\x20\x61\x64\x64\x3a\x20\x27"
.$service)."\x27\x20\x73\x65\x72\x76\x69\x63\x65\x2e"));unless (
openConnectionToStartup ()){return ((0x14a4+ 1359-0x19f3));}(my $res=
NXClientSystemDaemons::sendMessage ((((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXLOCATE_START)."\x20").$service)."\x0a")));
closeConnectionWithStartup ();return ((0x0307+ 2934-0x0e7c));}sub 
checkIfServerStartup{if (($serverStartup==(0x0562+ 3312-0x1251))){Logger::debug2
 ("\x53\x65\x72\x76\x65\x72\x20\x53\x74\x61\x72\x74\x75\x70");return (
(0x16b5+ 3893-0x25e9));}Logger::debug2 (
"\x4e\x6f\x74\x20\x53\x65\x72\x76\x65\x72\x20\x53\x74\x61\x72\x74\x75\x70");
return ((0x1dab+ 1726-0x2469));}sub setServerStartup{Logger::debug (
"\x53\x65\x74\x74\x69\x6e\x67\x20\x53\x65\x72\x76\x65\x72\x20\x53\x74\x61\x72\x74\x75\x70\x20\x74\x6f\x20\x31\x2e"
);($serverStartup=(0x1254+ 628-0x14c7));}sub restart{stop ();start ();}sub start
{if (isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x2e");
unless (openConnectionToStartup ()){return ((0x2456+ 618-0x26c0));}(my $res=
NXClientSystemDaemons::sendMessage ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXLOCATE_START)."\x20\x73\x74\x61\x72\x74\x0a")));
closeConnectionWithStartup ();return ((0x10a2+ 5450-0x25eb));}else{return (
(0x05ea+ 7802-0x2464));}}sub stop{if (isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x73\x74\x6f\x70\x70\x69\x6e\x67\x2e");
unless (openConnectionToStartup ()){return ((0x17ed+ 1594-0x1e27));}(my $res=
NXClientSystemDaemons::sendMessage ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_NXLOCATE_STOP)."\x20\x73\x74\x6f\x70\x0a")));
closeConnectionWithStartup ();return ((0x0c65+ 2605-0x1691));}else{return (
(0x0d95+ 5398-0x22ab));}}sub openConnectionToStartup{unless (
NXClientSystemDaemons::openConnection ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x63\x6f\x6e\x6e\x65\x63\x74\x20\x74\x6f\x20\x73\x65\x72\x76\x65\x72\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x2e"
);return ((0x007a+ 7770-0x1ed4));}return ((0x21da+ 584-0x2421));}sub 
closeConnectionWithStartup{NXClientSystemDaemons::closeConnection ();}sub 
__getMacAddress{(my (%macs)=__getMacs ());(my $mac=(""));(my $ipAdresses=__getIp
 ());if (($ipAdresses ne (""))){foreach my $ip (split ( /,/ ,$ipAdresses,
(0x006f+ 1057-0x0490))){while ((($name,$value)=each (%macs))){if (($name eq $ip)
){($mac.=($value."\x3b"));}}}if (($mac ne (""))){($mac=~ s/;$//g );}if (($mac ne
 (""))){if ((length ($mac)==(0x1020+ 1053-0x143d))){($mac=
"\x55\x6e\x64\x65\x66\x69\x6e\x65\x64");}}else{($mac=
"\x55\x6e\x64\x65\x66\x69\x6e\x65\x64");Logger::debug2 (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x75\x61\x62\x6c\x65\x20\x74\x6f\x20\x67\x65\x74\x20\x4d\x41\x43\x20\x61\x64\x64\x72\x65\x73\x73\x2e"
);}}else{($mac="\x55\x6e\x64\x65\x66\x69\x6e\x65\x64");Logger::debug2 (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x67\x65\x74\x20\x49\x50\x20\x61\x64\x64\x72\x65\x73\x73\x2e"
);}Logger::debug2 (((
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x3a\x20\x4d\x41\x43\x20\x61\x64\x64\x72\x65\x73\x73\x3a\x20"
.$mac)."\x2e"));__setMac ($mac);return ($mac);}sub __getMacs{(my (%macs)=());
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x28\x29\x20\x73\x74\x61\x72\x74\x2e"
);(my $networkInterfaces=libnxh::NXGetNetworkInterfaces ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x28\x29\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x3a\x20"
.$networkInterfaces)."\x2e"));if (($networkInterfaces ne (""))){(my (@lines)=
split ( /\n/ ,$networkInterfaces,(0x0999+ 1276-0x0e95)));foreach my $line (
@lines){Logger::debug ((("\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20".$line).
"\x2e"));if (($line=~ /(^.*)\s+AF_INET\s+([0-9A-Fa-f:]*)\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/ )
){(my $ip=$3);(my $mc=$2);if (($mc=~ /([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})/ )
){($macs{$ip}=$mc);}}}}else{Logger::debug2 (
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x66\x65\x74\x63\x68\x20\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x28\x29\x2e"
);}return (%macs);}sub updateLocateStep{return ($GLOBAL::LocateUpdateStep);}sub 
__setHost{(my $host=shift (@_));($array[$host_Index]=$host);($lastHost=__getHost
 ());}sub __getHost{if (($array[$host_Index]eq (""))){return (
"\x55\x6e\x6b\x6e\x6f\x77\x6e");}return ($array[$host_Index]);}sub __setIp{if ((
defined ($GLOBAL::NXdListenAddress)and ($GLOBAL::NXdListenAddress ne ("")))){(
$array[$ip_Index]=$GLOBAL::NXdListenAddress);($lastIp=__getIp ());}else{($array[
$ip_Index]=NXNodeInfo::getServerIp ());($lastIp=__getIp ());}}sub __getIp{return
 ($array[$ip_Index]);}sub __setType{($array[$type_Index]=shift (@_));}sub 
__getType{if (($array[$type_Index]eq (""))){return (
"\x55\x6e\x6b\x6e\x6f\x77\x6e");}return ($array[$type_Index]);}sub __setOs{(
$array[$os_Index]=shift (@_));}sub __getOs{if (($array[$os_Index]eq (""))){
return ("\x55\x6e\x6b\x6e\x6f\x77\x6e");}return ($array[$os_Index]);}sub __setHw
{($array[$hw_Index]=shift (@_));}sub __getHw{if (($array[$hw_Index]eq (""))){
return ("\x55\x6e\x6b\x6e\x6f\x77\x6e");}return ($array[$hw_Index]);}sub __setNx
{($array[$nx_Index]=shift (@_));}sub __getNx{return ($array[$nx_Index]);}sub 
__setSsh{($array[$ssh_Index]=shift (@_));}sub __getSsh{return ($array[$ssh_Index
]);}sub __setHttps{($array[$https_Index]=shift (@_));}sub __getHttps{return (
$array[$https_Index]);}sub __getServices{($commandTMP=(""));if ((__getNx ()ne 
(""))){($commandTMP.=(("\x6e\x78\x3a".__getNx ())."\x3b"));}if ((__getSsh ()ne 
(""))){($commandTMP.=(("\x73\x73\x68\x3a".__getSsh ())."\x3b"));}if ((__getHttps
 ()ne (""))){($commandTMP.=(("\x68\x74\x74\x70\x73\x3a".__getHttps ())."\x3b"));
}if (($commandTMP ne (""))){($commandTMP=~ s/;$//g );}else{Logger::debug2 (
"\x4e\x58\x4c\x63\x61\x74\x65\x3a\x3a\x5f\x5f\x67\x65\x74\x53\x65\x72\x76\x69\x63\x65\x73\x28\x29\x3a\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"
);}return ($commandTMP);}sub __setMac{($array[$mac_Index]=shift (@_));}sub 
__getMac{return ($array[$mac_Index]);}sub __setUuid{($array[$uuid_Index]=shift (
@_));}sub __getUuid{return ($array[$uuid_Index]);}return ((0x013b+ 9092-0x24be))
;
