############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::XDMSessionMissingHost::BEGIN{package 
Exception::XDMSessionMissingHost;no warnings;require base;do{"\x62\x61\x73\x65"
->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63"
)};}sub Exception::XDMSessionMissingHost::BEGIN{package 
Exception::XDMSessionMissingHost;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::XDMSessionMissingHost::notify{package 
Exception::XDMSessionMissingHost;no warnings;(my $self=shift (@_));
NXMsg::register_error ((""),
"\x65\x58\x44\x4d\x53\x65\x73\x73\x69\x6f\x6e\x4d\x69\x73\x73\x69\x6e\x67\x48\x6f\x73\x74"
,(0x21d2+ 509-0x217a));NXMsg::error (
"\x65\x58\x44\x4d\x53\x65\x73\x73\x69\x6f\x6e\x4d\x69\x73\x73\x69\x6e\x67\x48\x6f\x73\x74"
,"\x67\x65\x6e\x65\x72\x61\x6c");}package Exception::XDMSessionMissingHost;no 
warnings;"\x3f\x3f\x3f";
