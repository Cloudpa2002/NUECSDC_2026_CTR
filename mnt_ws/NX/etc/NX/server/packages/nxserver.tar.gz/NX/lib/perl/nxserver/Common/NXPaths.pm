############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package Common::NXPaths;no warnings;require Common::NXFile;(
$NXPaths::cacheUserHomeDirectory=(""));((%NXPaths::cacheRealUserHomePath)=());((
%NXPaths::cacheNXDirPerUserPath)=());sub __isNXDirPerUserCached{(my $username=
shift (@_));if (($username eq (""))){return ((0x245f+ 297-0x2588));}if (exists (
$NXPaths::cacheNXDirPerUserPath{$username})){return ((0x1694+ 755-0x1986));}else
{return ((0x0b94+ 4960-0x1ef4));}}sub __setNXDirPerUserCached{(my $username=
shift (@_));(my $userNxDir=__handleUserNXDirectoryPathForUser ($username));(
$NXPaths::cacheNXDirPerUserPath{$username}=$userNxDir);}sub 
__setUsersNXDirPerUserCached{(my $username=shift (@_));(my $userNxDir=
__handleUsersDirectoryPathForUser ($username));($NXPaths::cacheNXDirPerUserPath{
$username}=$userNxDir);}sub __getNXDirPerUserCached{(my $username=shift (@_));
return ($NXPaths::cacheNXDirPerUserPath{$username});}sub __isRealUserHomeCached{
(my $username=shift (@_));if (($username eq (""))){return ((0x01eb+ 5872-0x18db)
);}if (exists ($NXPaths::cacheRealUserHomePath{$username})){return (
(0x0779+ 6721-0x21b9));}else{return ((0x14b9+ 4447-0x2618));}}sub 
__setRealUserHomeCached{(my $username=shift (@_));(my $homePath=
__getUserHomeDirectoryByUsername ($username));($NXPaths::cacheRealUserHomePath{
$username}=$homePath);}sub __getRealUserHomeCached{(my $username=shift (@_));
return ($NXPaths::cacheRealUserHomePath{$username});}sub 
__getUserHomeDirectoryWindows{(my $username=shift (@_));(my $size=
(0x02d5+ 7892-0x20a4));(my $homeBuffer=("\x20" x $size));(my $length=($size-
(0x0a0f+ 6038-0x21a4)));(my $ret=libnxh::NXHomeDirGet ($homeBuffer,$length,
$username));if (($ret==(-(0x1290+ 671-0x152e)))){Logger::debug (((
"\x55\x73\x65\x72\x20".$username).
"\x20\x68\x6f\x6d\x65\x64\x69\x72\x65\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x74\x6f\x20\x75\x73\x65\x72\x20\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x70\x61\x74\x68\x2e"
));return (((getSystemTMPPath ().$GLOBAL::DIRECTORY_SLASH).$username));}(my (
@buffer)=split ( /\000/ ,$homeBuffer,(0x0630+ 7566-0x23be)));Logger::debug (((((
"\x55\x73\x65\x72\x20\x27".$username).
"\x27\x20\x68\x6f\x6d\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x27").
$buffer[(0x061c+ 4988-0x1998)])."\x27\x2e"));return ($buffer[
(0x0cf7+ 1048-0x110f)]);}sub getFailbackHomeDirectoryPathFromNXTemp{return (((
getSystemTMPPath ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x54\x6d\x70\x48\x6f\x6d\x65"));}sub 
getNxDirectoryInEffectiveUserHomeDirectory{return (((
getEffectiveUserHomeDirectory ().$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));}sub
 getNxDirectoryInUserHomeDirectory{(my $username=shift (@_));return (((
getUserHomeDirectory ($username).$GLOBAL::DIRECTORY_SLASH)."\x2e\x6e\x78"));}sub
 getHomeDirectoryOfDesktopOwnerWindows{(my ($userName,$tmp)=
NXLocalSession::getDisplayOwnerAndType ());if (((not (defined ($userName)))or (
$userName eq ("")))){(my $failbackDirectory=
getFailbackHomeDirectoryPathFromNXTemp ());Logger::debug ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x79\x65\x74\x2e\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x74\x65\x6d\x70\x6f\x72\x61\x72\x79\x20\x68\x6f\x6d\x65\x20\x64\x69\x72\x20\x74\x6f\x20"
.$failbackDirectory));return ($failbackDirectory);}return (
__getUserHomeDirectoryWindows ($userName));}sub 
getNxDirectoryInHomeOfDesktopOwnerOnWindows{(my $ref_errorName=shift (@_));(my (
$userName,$tmp)=NXLocalSession::getDisplayOwnerAndType ());my (
$userDirectoryPath);if ((($GLOBAL::UsersDirectoryPath ne (""))and ($userName ne 
"\x6e\x78"))){($userDirectoryPath=__handleUsersDirectoryPathForUser ($userName))
;}elsif (($GLOBAL::UserNXDirectoryPath ne (""))){($userDirectoryPath=
__handleUserNXDirectoryPathForUser ($userName));}else{if (((not (defined (
$userName)))or ($userName eq ("")))){($userDirectoryPath=
getFailbackHomeDirectoryPathFromNXTemp ());Logger::debug ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x20\x79\x65\x74\x2e\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x74\x65\x6d\x70\x6f\x72\x61\x72\x79\x20\x68\x6f\x6d\x65\x20\x64\x69\x72\x20\x74\x6f\x20"
.$userDirectoryPath));}else{($userDirectoryPath=__getUserHomeDirectoryWindows (
$userName));}}(my $nxDirectoryPath=(($userDirectoryPath.$GLOBAL::DIRECTORY_SLASH
)."\x2e\x6e\x78"));if ((not (Common::NXFile::directoryExists ($nxDirectoryPath))
)){Logger::debug (((
"\x2e\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x69\x6e\x20\x75\x73\x65\x72\x27\x73\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$nxDirectoryPath)."\x2e"));if ((not (
NXPaths::createAndCorrectUserNXDirectoryOnWindows ($nxDirectoryPath,
$ref_errorName)))){Logger::warning (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x73\x65\x74\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x61\x74\x20"
.$nxDirectoryPath)."\x2e"));}}return ($nxDirectoryPath);}sub 
getEffectiveUserHomeDirectory{return (getUserHomeDirectory (
Common::NXCore::getEffectiveUsername ()));}sub getUserXauthorityFile{(my $path=(
getUserRealHomeDirectoryByEffectiveUser ().
"\x2f\x2e\x58\x61\x75\x74\x68\x6f\x72\x69\x74\x79"));return ($path);}sub 
__getUserHomeDirectoryByUsername{(my $userName=shift (@_));return (
__getUserHomeDirectoryUnix ($userName));}sub __getUserHomeDirectoryUnix{(my $userName
=shift (@_));return (Common::NXCore::userInfoGetDirByUsername ($userName));}sub 
getUserRealHomeDirectoryByEffectiveUser{(my $username=
Common::NXCore::getEffectiveUsername ());if (($username eq (""))){
Common::NXCore::reportErrorFromNXPL (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x2e"
);main::nxexit ((0x0ed0+ 3456-0x1c4f));}return (
getUserRealHomeDirectoryByUsername ($username));}sub 
getUserRealHomeDirectoryByUsername{(my $username=shift (@_));if (
__isRealUserHomeCached ($username)){return (__getRealUserHomeCached ($username))
;}else{__setRealUserHomeCached ($username);return (__getRealUserHomeCached (
$username));}}sub getUserHomeDirectory{(my $userName=shift (@_));if ((($userName
 eq (""))or (not (defined ($userName))))){Logger::error (
"\x43\x61\x6e\x20\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x68\x6f\x6d\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x66\x6f\x72\x20\x65\x6d\x70\x74\x79\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x2e"
);main::nxexit ((0x125c+ 1610-0x18a5));}if ((($GLOBAL::UsersDirectoryPath ne 
(""))and ($userName ne "\x6e\x78"))){if (__isNXDirPerUserCached ($userName)){
return (__getNXDirPerUserCached ($userName));}__setUsersNXDirPerUserCached (
$userName);return (__getNXDirPerUserCached ($userName));}elsif ((
$GLOBAL::UserNXDirectoryPath ne (""))){if (__isNXDirPerUserCached ($userName)){
return (__getNXDirPerUserCached ($userName));}__setNXDirPerUserCached ($userName
);return (__getNXDirPerUserCached ($userName));}else{return (
getUserRealHomeDirectoryByUsername ($userName));}}sub getLanguageFile{(my $language
=shift (@_));(my $languageFile=((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)
."\x73\x68\x61\x72\x65").$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x63\x61\x6c\x65").
$GLOBAL::DIRECTORY_SLASH));($languageFile.=(
"\x6e\x78\x73\x65\x72\x76\x65\x72\x5f".$language));return ($languageFile);}sub 
getUserNXHomeDir{if (defined ($NXPaths::UserNXHomeDir)){return (
$NXPaths::UserNXHomeDir);}($NXPaths::UserNXHomeDir=
"\x2f\x76\x61\x72\x2f\x4e\x58\x2f\x6e\x78");return ($NXPaths::UserNXHomeDir);}
sub __handleUsersDirectoryPathForUser{(my $user=shift (@_));(my $ref_errorName=
shift (@_));if ((not (defined ($user)))){($user=
Common::NXCore::getEffectiveUsername ());}(my $DirPathExist=
(0x12eb+ 1713-0x199b));if ((not (Common::NXFile::directoryExists (
$GLOBAL::UsersDirectoryPath)))){Logger::debug ((((("\x55\x73\x65\x72\x20".$user)
.
"\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
).$GLOBAL::UsersDirectoryPath)."\x2e"));($DirPathExist=
createAccessibleForAllDirectory ($ref_errorName,$GLOBAL::UsersDirectoryPath));}
if ($DirPathExist){(my $userDirPath=(($GLOBAL::UsersDirectoryPath.
$GLOBAL::DIRECTORY_SLASH).$user));if ((not (Common::NXFile::directoryExists (
$userDirPath)))){Logger::debug ((((("\x55\x73\x65\x72\x20".$user).
"\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
).$userDirPath)."\x2e"));if ((createAccessibleForUserDirectory ($ref_errorName,
$userDirPath,$user)==(0x0e24+ 749-0x1111))){if (((not (defined ($$ref_errorName)
))or ($$ref_errorName eq ("")))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$userDirPath)."\x2e"));}else{Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$userDirPath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").
$$ref_errorName));}}}return ($userDirPath);}Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
.$users)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").$$ref_errorName));
return (undef);}sub __handleUserNXDirectoryPathForUser{(my $user=shift (@_));(my $ref_errorName
=shift (@_));if ((not (defined ($user)))){($user=
Common::NXCore::getEffectiveUsername ());}(my $DirPathExist=
(0x01d4+ 5978-0x192d));if ((not (Common::NXFile::directoryExists (
$GLOBAL::UserNXDirectoryPath)))){Logger::debug (((
"\x55\x73\x65\x72\x20\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$GLOBAL::UserNXDirectoryPath)."\x2e"));($DirPathExist=
createAccessibleForAllDirectory ($ref_errorName,$GLOBAL::UserNXDirectoryPath));}
if ($DirPathExist){(my $userDirPath=(($GLOBAL::UserNXDirectoryPath.
$GLOBAL::DIRECTORY_SLASH).$user));if ((not (Common::NXFile::directoryExists (
$userDirPath)))){Logger::debug (((
"\x55\x73\x65\x72\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x61\x74\x20"
.$userDirPath)."\x2e"));if ((createAccessibleForUserDirectory ($ref_errorName,
$userDirPath,$user)==(0x0620+ 4207-0x168f))){if (((not (defined ($$ref_errorName
)))or ($$ref_errorName eq ("")))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$userDirPath)."\x2e"));}else{Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$userDirPath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").
$$ref_errorName));}}}return ($userDirPath);}Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x78\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
.$$ref_errorName));return (undef);}sub makePath{(my ($ref_errorMessage,$path,
$verbose,$mode)=@_);(my $success=(0x0727+ 4094-0x1724));($$ref_errorMessage=("")
);Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x28".
$path)."\x2c\x20").$mode)."\x29"));(my $returnValue=libnxh::NXMakePath ($path,
$mode));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x4d\x61\x6b\x65\x50\x61\x74\x68\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$returnValue)."\x27\x2e"));if (($returnValue!=(0x1a1f+ 1495-0x1ff6))){(my $errorNumber
=libnxh::NXGetError ());($$ref_errorMessage=libnxh::NXGetErrorString ());(
$success=(0x1260+ 1948-0x19fc));Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$path)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$$ref_errorMessage)."\x27\x2e"));}return ($success
);}sub rmtree{(my $path=shift (@_));(my $returnValue=libnxh::NXRemovePath ($path
));if (($returnValue!=(0x0c08+ 5765-0x228d))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20"
.$path)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));return ($returnValue);}
Logger::debug2 (((
"\x72\x6d\x74\x72\x65\x65\x3a\x20\x53\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x20\x72\x65\x6d\x6f\x76\x65\x64\x20"
.$path)."\x2e"));return ((0x04c3+ 681-0x076c));}sub identityServerFilePath{
return ((((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x68\x61\x72\x65").$GLOBAL::DIRECTORY_SLASH)."\x6b\x65\x79\x73").
$GLOBAL::DIRECTORY_SLASH).
"\x73\x65\x72\x76\x65\x72\x2e\x69\x64\x5f\x64\x73\x61\x2e\x6b\x65\x79"));}sub 
getSystemdServicePath{(my $serverServicePath=((((((($GLOBAL::DIRECTORY_SLASH.
"\x6c\x69\x62").$GLOBAL::DIRECTORY_SLASH)."\x73\x79\x73\x74\x65\x6d\x64").
$GLOBAL::DIRECTORY_SLASH)."\x73\x79\x73\x74\x65\x6d").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x73\x65\x72\x76\x69\x63\x65"));if (
Common::NXFile::isExists ($serverServicePath)){return ($serverServicePath);}(
$serverServicePath=(($GLOBAL::DIRECTORY_SLASH."\x75\x73\x72").$serverServicePath
));if (Common::NXFile::isExists ($serverServicePath)){return ($serverServicePath
);}return (undef);}sub createAccessibleForAllDirectory{(my $ref_errorMessage=
shift (@_));(my $path=shift (@_));if ((not (makePath ($ref_errorMessage,$path)))
){return ((0x1955+ 2939-0x24d0));}else{if ((
Common::NXFile::setPermissionsFullForAllDirectory ($path,$ref_errorMessage)==(-
(0x0480+ 2100-0x0cb3)))){return ((0x10a9+ 2106-0x18e3));}}return (
(0x04c0+ 5741-0x1b2c));}sub createAccessibleForUserDirectory{(my $ref_errorMessage
=shift (@_));(my $path=shift (@_));(my $user=shift (@_));if ((not (makePath (
$ref_errorMessage,$path)))){return ((0x1692+ 443-0x184d));}else{if ((not (
defined ($user)))){($user=Common::NXCore::getEffectiveUsername ());}if ((
Common::NXFile::setOwnershipForUser ($path,$user,$ref_errorMessage)==(-
(0x008f+ 7959-0x1fa5)))){return ((0x038f+ 4008-0x1337));}if ((
Common::NXFile::setPermissionsFullForUserDirectory ($path,$user,
$ref_errorMessage)==(-(0x0efb+ 5333-0x23cf)))){return ((0x0441+ 1114-0x089b));}}
return ((0x0570+ 4413-0x16ac));}sub createNodeRootDirectory{(my $ref_errorMessage
=shift (@_));(my $path=shift (@_));(my $resultOwnership=(-(0x06f0+ 6068-0x1ea3))
);(my $username=Common::NXCore::getEffectiveUsername ());if ((
$GLOBAL::CommonLogDirectory ne (""))){return (createAccessibleForAllDirectory ((
\$createDirectoryError),$path));}if ((not (makePath ($ref_errorMessage,$path))))
{return ((0x0758+ 1666-0x0dda));}else{if (
Common::NXCore::isEffectiveUsernameRoot ()){($resultOwnership=
Common::NXFile::setOwnershipForUserNXGroupRoot ($path,$ref_errorMessage));}else{
($resultOwnership=Common::NXFile::setOwnershipForUser ($path,$username,
$ref_errorMessage));}if (($resultOwnership==(-(0x05a8+ 2239-0x0e66)))){return (
(0x02cf+ 2178-0x0b51));}if ((Common::NXFile::setPermissionsUserNodeRootDirectory
 ($path,$username,$ref_errorMessage)==(-(0x056c+ 4503-0x1702)))){return (
(0x03c1+ 4402-0x14f3));}}return ((0x07c0+ 7155-0x23b2));}sub 
createAccessibleForNXDirectory{(my $ref_errorMessage=shift (@_));(my $path=shift
 (@_));unless (makePath ($ref_errorMessage,$path)){return ((0x0d5d+ 2625-0x179e)
);}if ((Common::NXFile::setOwnerShipNXAndFullPermissions ($path,
$ref_errorMessage)==(-(0x0041+ 3917-0x0f8d)))){return ((0x1e2c+ 975-0x21fb));}
return ((0x0606+ 3100-0x1221));}sub getNodeRootDirectoryPath{return (((
getDirectoryForLogsPath ().$GLOBAL::DIRECTORY_SLASH)."\x6e\x6f\x64\x65"));}sub 
sessionDirPathToClientPidFile{(my $sessionDir=shift (@_));(my $path=$sessionDir)
;($path.=($GLOBAL::DIRECTORY_SLASH."\x63\x6c\x69\x65\x6e\x74"));($path.=(
$GLOBAL::DIRECTORY_SLASH."\x70\x69\x64"));return ($path);}sub 
getPathForCommandOfProcessPid{(my $pid=shift (@_));(my $path=(((((
$GLOBAL::DIRECTORY_SLASH."\x70\x72\x6f\x63").$GLOBAL::DIRECTORY_SLASH).$pid).
$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6d\x6d"));return ($path);}sub 
getUserNodeCfgPath{(my $user=shift (@_));(my $path=((((($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH).$user).
"\x2e\x6e\x6f\x64\x65\x2e\x63\x66\x67"));return ($path);}sub 
getPathToLocalNXserverPlist{(my $path=((((($GLOBAL::DIRECTORY_SLASH.
"\x4c\x69\x62\x72\x61\x72\x79").$GLOBAL::DIRECTORY_SLASH).
"\x4c\x61\x75\x6e\x63\x68\x41\x67\x65\x6e\x74\x73").$GLOBAL::DIRECTORY_SLASH).
"\x63\x6f\x6d\x2e\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2e\x6c\x6f\x63\x61\x6c\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x70\x6c\x69\x73\x74"
));return ($path);}sub getPathToNXDPlist{(my $path=((((($GLOBAL::DIRECTORY_SLASH
."\x4c\x69\x62\x72\x61\x72\x79").$GLOBAL::DIRECTORY_SLASH).
"\x4c\x61\x75\x6e\x63\x68\x44\x61\x65\x6d\x6f\x6e\x73").$GLOBAL::DIRECTORY_SLASH
).
"\x63\x6f\x6d\x2e\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2e\x6e\x78\x64\x2e\x70\x6c\x69\x73\x74"
));return ($path);}sub getPathToServerDaemonPlist{(my $path=(((((
$GLOBAL::DIRECTORY_SLASH."\x4c\x69\x62\x72\x61\x72\x79").
$GLOBAL::DIRECTORY_SLASH)."\x4c\x61\x75\x6e\x63\x68\x44\x61\x65\x6d\x6f\x6e\x73"
).$GLOBAL::DIRECTORY_SLASH).
"\x63\x6f\x6d\x2e\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2e\x73\x65\x72\x76\x65\x72\x2e\x70\x6c\x69\x73\x74"
));return ($path);}sub getSpecialUsersLogFolderPath{(my $path=((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67"));return ($path);}sub
 getSpecialUsersNXServerLogPath{(my $path=((getSpecialUsersLogFolderPath ().
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67"));
return ($path);}sub getDirectoryForLogsPath{if (($GLOBAL::CommonLogDirectory ne 
(""))){return ($GLOBAL::CommonLogDirectory);}if (
Common::NXCore::isEffectiveUserNXRootOrSystem ()){return (
getSpecialUsersLogFolderPath ());}return (
getNxDirectoryInEffectiveUserHomeDirectory ());}sub getNXServerLogPath{return ((
(getDirectoryForLogsPath ().$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67"));}sub 
removeExtraSlashesFromPath{(my $ref_path=shift (@_));($$ref_path=~ s/\/+/\//g );
}sub getSystemTMPPath{return (($GLOBAL::DIRECTORY_SLASH."\x74\x6d\x70"));}sub 
windowsGetTempPath{();}return ((0x0ad9+ 2412-0x1444));
