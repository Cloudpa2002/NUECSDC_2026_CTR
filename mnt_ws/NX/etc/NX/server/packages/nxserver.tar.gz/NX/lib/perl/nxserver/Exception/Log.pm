############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::Log::BEGIN{package Exception::Log;no warnings;require base;do{
"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::Log::BEGIN{package Exception::Log;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub Exception::Log::notify{package 
Exception::Log;no warnings;(my $self=shift (@_));(my $statusId=
main::get_unique_id ());($statusId=~ s/(........).*/$1/ );(my $indexString=
$$self{"\x69\x6e\x64\x65\x78\x53\x74\x72\x69\x6e\x67"});(my $ref_parameters=
$$self{"\x72\x65\x66\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});if (
Common::NXMsg::check_msg ($indexString)){Common::NXMsg::error ($indexString,
@$ref_parameters);}else{NXMsg::register_response ((""),
"\x65\x47\x55\x49\x4c\x6f\x67",(0x15b0+ 1583-0x198c));NXMsg::send_response (
"\x65\x47\x55\x49\x4c\x6f\x67","\x67\x65\x6e\x65\x72\x61\x6c",$self->text);}(my $trace
=$self->stacktrace);($trace=~ s/\n[^\w]+/\n/ );($trace=~ s/\t//gm );(my (@aTrace
)=split ( /\n/ ,$trace,(0x07ac+ 5292-0x1c58)));Logger::multilineLog (((
"\x28\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x20\x69\x64\x20".$statusId)."\x29"),
@aTrace);}package Exception::Log;no warnings;"\x3f\x3f\x3f";
