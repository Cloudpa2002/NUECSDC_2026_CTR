############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXClusterTools::generateClusterGUID{package NXClusterTools;no warnings;(my (
@command)=());push (@command,$GLOBAL::COMMAND_NXKEYGEN);push (@command,
"\x2d\x75");(my (@options)=());push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(((
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x48\x4f\x4d\x45\x3d".NXPaths::getUserNXHomeDir ()));(my ($cmdErr,$cmdOut,
$exitValue)=main::nxRunCommand ((\@command),(\@options)));if (($exitValue!=
(0x0d86+ 2444-0x1712))){Logger::warning (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20\x47\x55\x49\x44\x2e"
);return ((""));}chomp ($cmdOut);return ($cmdOut);}sub 
NXClusterTools::generateClusterKeys{package NXClusterTools;no warnings;(my (
@command)=());push (@command,$GLOBAL::COMMAND_NXKEYGEN);(my $priv=
NXPaths::getClusterRSAPrivateKey ());(my $pub=NXPaths::getClusterRSAPublicKey ()
);push (@command,"\x2d\x6b",$priv);push (@command,"\x2d\x70",$pub);push (
@command,"\x2d\x74","\x72\x73\x61");(my (@options)=());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(((
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x48\x4f\x4d\x45\x3d".NXPaths::getUserNXHomeDir ()));(my ($cmd_err,$cmd_out,
$exit_value)=main::nxRunCommand ((\@command),(\@options)));
changeFileOwnershipToNxIfRoot ($priv);changeFileOwnershipToNxIfRoot ($pub);if ((
Common::NXFile::setPermissionsReadWriteForNX ($priv)==(-(0x1fa0+ 811-0x22ca)))){
Logger::warning (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20\x27"
.$priv)."\x27\x2e"));}if ((
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($pub)==(-
(0x0f87+ 4877-0x2293)))){Logger::warning (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20"
.$pub)."\x2e"));}}sub NXClusterTools::generateClusterHostCerts{package 
NXClusterTools;no warnings;(my (@command)=());push (@command,
$GLOBAL::COMMAND_NXKEYGEN);(my $priv=NXPaths::getClusterHostPrivateCert ());(my $pub
=NXPaths::getClusterHostPublicCert ());push (@command,"\x2d\x6b",$priv);push (
@command,"\x2d\x63",$pub);(my (@options)=());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(((
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));(my $homeDir=NXPaths::getUserNXHomeDir ());push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".$homeDir));(my ($cmd_err,
$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@options)));
changeFileOwnershipToNxIfRoot ($priv);changeFileOwnershipToNxIfRoot ($pub);if ((
Common::NXFile::setPermissionsReadWriteForNX ($priv)==(-(0x09ef+ 3190-0x1664))))
{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20"
.$priv)."\x2e"));}if ((
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($pub)==(-
(0x0019+ 305-0x0149)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x74\x6f\x20"
.$pub)."\x2e"));}}sub NXClusterTools::cleanInterface{package NXClusterTools;no 
warnings;(my $interface=$GLOBAL::ClusterInterface);(my $clusterHost=
$GLOBAL::ClusterHost);(my $mask=$GLOBAL::ClusterNetmask);if ((
$GLOBAL::ScriptClusterClearSharedIP ne (""))){main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");return (NXScripts::runScript (
"\x73\x63\x72\x69\x70\x74\x5f\x63\x6c\x75\x73\x74\x65\x72\x5f\x63\x6c\x65\x61\x72\x5f\x73\x68\x61\x72\x65\x64\x5f\x69\x70"
,$interface,$clusterHost,$mask));}(my (%interfaces)=getInterfaces ());if ((
$interfaces{$interface}eq (""))){Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x3a\x20\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$interface).
"\x27\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x65\x61\x6e\x20\x75\x70\x2e"))
;(($interface,$clusterHost)=__readInterfaceFromFile ());if (($interfaces{
$interface}eq (""))){Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x3a\x20\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$interface).
"\x27\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x63\x6c\x65\x61\x6e\x20\x75\x70\x2e"
));return ((0x1ab1+ 2705-0x2542));}}Logger::debug (((((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x3a\x20\x43\x6c\x65\x61\x6e\x20\x75\x70\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$interface)."\x27\x20\x68\x6f\x73\x74\x20\x27").$clusterHost)."\x27\x2e"));(my (
@command)=());sub BEGIN{require NXTools;do{"\x4e\x58\x54\x6f\x6f\x6c\x73"->
import};}if ((not (($interface=~ /(.*):(\d+)/ )))){if ((not (
NXMsg::isMessageRegistered (
"\x65\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x49\x6e\x76\x61\x6c\x69\x64\x49\x6e\x74\x65\x72\x66\x61\x63\x65"
)))){NXMsg::register_error (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73",
"\x65\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x49\x6e\x76\x61\x6c\x69\x64\x49\x6e\x74\x65\x72\x66\x61\x63\x65"
,$GLOBAL::MSG_ERROR);}Common::NXMsg::error (
"\x65\x43\x4d\x44\x43\x6c\x75\x73\x74\x65\x72\x49\x6e\x76\x61\x6c\x69\x64\x49\x6e\x74\x65\x72\x66\x61\x63\x65"
,$interface);return ((0x0808+ 3253-0x14bc));}(my $device=$1);if ((
$GLOBAL::ForceClusterIfconfig eq "\x31")){push (@command,
NXTools::getUnixCommandPath ("\x69\x66\x63\x6f\x6e\x66\x69\x67"));push (@command
,$interface);push (@command,"\x64\x6f\x77\x6e");}else{push (@command,
NXTools::getUnixCommandPath ("\x69\x70"));push (@command,
"\x61\x64\x64\x72\x65\x73\x73","\x64\x65\x6c\x65\x74\x65");push (@command,((
$clusterHost."\x2f").$mask));push (@command,"\x64\x65\x76",$device);push (
@command,"\x6c\x61\x62\x65\x6c",$interface);}(my (@options)=());(my ($cmdOut,
$cmdErr,$exitValue)=main::nxRunCommand ((\@command),(\@options)));Logger::debug 
((((((("\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x6f\x75\x74\x70\x75\x74\x20\x27".
$cmdOut)."\x27\x20\x27").$cmdErr).
"\x27\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20\x27").$exitValue)."\x27\x2e"))
;if (($exitValue!=(0x15ec+ 3477-0x2381))){Logger::error (((((((((
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x64\x65\x6c\x65\x74\x65\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$interface)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$exitValue)
."\x27\x2e\x20\x27").$cmdOut)."\x27\x20\x27").$cmdErr)."\x27\x2e"));}
removeInterfaceFile ();return ($exitValue);}sub 
NXClusterTools::saveInterfaceToFile{package NXClusterTools;no warnings;(my $interface
=shift (@_));(my $clusterHost=shift (@_));(my $filename=
NXPaths::getClusterInterfaceFile ());(my $fileExisted=(0x0758+  32-0x0778));if (
Common::NXFile::fileExists ($filename)){($fileExisted=(0x02f3+ 984-0x06ca));}(my $FH
=main::nxopen ($filename,($NXBits::O_RDWR+$NXBits::O_CREAT),((
$NXBits::OthersRead+$NXBits::UserReadWrite)+$NXBits::GroupRead)));if ((not (
defined ($FH)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring=
libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".$filename
)."\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorNumber)."\x2c\x20").$errorstring).
"\x2e"));return ((0x047a+ 8323-0x24fc));}if ((main::nxwrite ($FH,((($interface.
"\x0a").$clusterHost)."\x0a"))==(-(0x0d28+ 1962-0x14d1)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x2e"));main::nxclose ($FH);if ((not ($fileExisted))){
changeFileOwnershipToNxIfRoot ($filename);}return ((0x06ec+ 3237-0x1390));}
main::nxclose ($FH);if ((not ($fileExisted))){changeFileOwnershipToNxIfRoot (
$filename);}return ((0x0dd0+ 684-0x107c));}sub 
NXClusterTools::removeInterfaceFile{package NXClusterTools;no warnings;(my $filename
=NXPaths::getClusterInterfaceFile ());if (Common::NXFile::isExists ($filename)){
Common::NXFile::removeFile ($filename);}}sub 
NXClusterTools::doesInterfaceFileExist{package NXClusterTools;no warnings;(my $filename
=NXPaths::getClusterInterfaceFile ());if (Common::NXFile::fileExists ($filename)
){Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$filename)."\x27\x20\x65\x78\x69\x73\x74\x73\x2e"));return (
(0x031d+ 5310-0x17da));}Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$filename).
"\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));return 
((0x0305+ 6740-0x1d59));}sub NXClusterTools::__readInterfaceFromFile{package 
NXClusterTools;no warnings;if ((not (doesInterfaceFileExist ()))){return ((""),
(""));}(my $filename=NXPaths::getClusterInterfaceFile ());(my $FH=main::nxopen (
$filename,$NXBits::O_RDONLY,(0x1126+ 2644-0x1b7a)));if ((not (defined ($FH)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$filename)."\x27\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorstring)."\x2e"));return ((""),(""));}my ($interface);my (
$clusterHost);main::nxreadLine ($FH,(\$interface));main::nxreadLine ($FH,(
\$clusterHost));main::nxclose ($FH);chomp ($interface);chomp ($clusterHost);
return ($interface,$clusterHost);}sub NXClusterTools::getInterfaces{package 
NXClusterTools;no warnings;(my (%interfaces)=());Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73"
);(my $return=libnxh::NXGetNetworkInterfaces ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));(my (@lines)=split ( /\n/ ,$return,(0x109f+ 1493-0x1674))
);foreach my $line (@lines){if (($line=~ /(^[\w:\d]+)\s+AF_INET\s+([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})+\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/ )
){Logger::debug ((((((("\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27".$1).
"\x27\x2c\x20\x49\x50\x20\x27").$4)."\x27\x20\x6d\x61\x73\x6b\x20\x27").$5).
"\x27\x2e"));($interfaces{$1}={"\x69\x70",$4,"\x6d\x61\x73\x6b",$5});}}return (
%interfaces);}sub NXClusterTools::getIPs{package NXClusterTools;no warnings;
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73"
);(my $return=libnxh::NXGetNetworkInterfaces ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x4e\x65\x74\x77\x6f\x72\x6b\x49\x6e\x74\x65\x72\x66\x61\x63\x65\x73\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));(my (%IPs)=());(my (@lines)=split ( /\n/ ,$return,
(0x0e0b+ 1327-0x133a)));foreach my $line (@lines){if (($line=~ /(^[\w:\d]+)\s+AF_INET\s+([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})+\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+\.\d+\.\d+\.\d+)/ )
){(my $iface=$1);(my $ip=$4);(my $mask=$5);Logger::debug (((((((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27"
.$iface)."\x27\x20\x49\x50\x20\x27").$ip)."\x27\x20\x6d\x61\x73\x6b\x20\x27").
$mask)."\x27\x2e"));($IPs{$ip}={"\x69\x6e\x74\x65\x72\x66\x61\x63\x65",$iface,
"\x6d\x61\x73\x6b",$mask});}}return (%IPs);}sub NXClusterTools::isIPExists{
package NXClusterTools;no warnings;(my $IP=shift (@_));Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x65\x61\x72\x63\x68\x20\x49\x50\x20\x27"
.$IP).
"\x27\x20\x6f\x6e\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x6c\x69\x73\x74\x2e"
));(my (%interfaces)=getInterfaces ());foreach my $name (keys (%interfaces)){if 
(($interfaces{$name}{"\x69\x70"}eq $ip)){Logger::debug (((((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x46\x6f\x75\x6e\x64\x20\x49\x50\x20\x27"
.$IP)."\x27\x20\x6f\x6e\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x27").$name)
."\x27\x2e"));return ((0x03fc+ 1973-0x0bb0));}}Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x49\x50\x20\x27"
.$IP)."\x27\x2e"));return ((0x0479+ 2890-0x0fc3));}sub 
NXClusterTools::getClusterPublicKey{package NXClusterTools;no warnings;(my $file
=NXPaths::getClusterRSAPublicKey ());if ((not (Common::NXFile::fileExists ($file
)))){generateClusterKeys ();}(my $content=Common::NXFile::getFileContent ($file)
);if (($content eq (""))){(my $message=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x70\x75\x6c\x69\x63\x20\x6b\x65\x79\x20\x66\x72\x6f\x6d\x20\x70\x61\x74\x68\x20\x27"
.$file)."\x27"));Logger::error ($message);die ($message);}return ($content);}sub
 NXClusterTools::__setDatabaseBackup{package NXClusterTools;no warnings;(my $database
=shift (@_));(my $content=shift (@_));if (__isDatabaseBackupExist ($database)){
Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x44\x61\x74\x61\x62\x61\x73\x65\x20\x62\x61\x63\x6b\x75\x70\x20\x27"
.$database).
"\x27\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x65\x78\x69\x73\x74\x73\x2e"));return 
((0x0650+ 6186-0x1e7a));}if (($content eq (""))){Logger::debug (((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x44\x61\x74\x61\x62\x61\x73\x65\x20\x62\x61\x63\x6b\x75\x70\x20\x27"
.$database)."\x27\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"));return (
(0x0a42+ 2816-0x1542));}($content=main::urlencode ($content));NXRedis::sendToDb 
(((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x65\x74\x6e\x78\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x62\x61\x63\x6b\x75\x70\x2e"
.$database)."\x2c\x76\x61\x6c\x75\x65\x3d").$content)."\x0a"));}sub 
NXClusterTools::getNodesDB{package NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x73");return (NXNodes::getDatabaseInString ());}sub 
NXClusterTools::getClusterDB{package NXClusterTools;no warnings;return (
getDatabaseInString ());}sub NXClusterTools::getProfilesDB{package 
NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42");return (
NXProfilesDB::getDatabaseInString ());}sub NXClusterTools::getUsersDB{package 
NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");return (
NXUsersManager::getDatabaseInString ());}sub NXClusterTools::getAdministratorsDB
{package NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);return (NXAdministratorsManager::getDatabaseInString ());}sub 
NXClusterTools::getGroupsDB{package NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x47\x72\x6f\x75\x70\x73");return (NXGroups::getDatabaseInString ());}
sub NXClusterTools::getNodeGroupsDB{package NXClusterTools;no warnings;
main::nxrequire ("\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73",
"\x69\x6e\x69\x74");return (NXNodeGroups::getDatabaseInString ());}sub 
NXClusterTools::getServerGroupsDB{package NXClusterTools;no warnings;
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x47\x72\x6f\x75\x70\x73",
"\x69\x6e\x69\x74");return (NXServerGroups::getDatabaseInString ());}sub 
NXClusterTools::getNXCerts{package NXClusterTools;no warnings;main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");return (NXServers::getNXCertsString ());
}sub NXClusterTools::getSSHCerts{package NXClusterTools;no warnings;
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");return (
NXServers::getSSHCertsString ());}sub NXClusterTools::getNetworkDB{package 
NXClusterTools;no warnings;return (Common::NXFile::getFileContent (
NXPaths::getNetworkDB ()));}sub NXClusterTools::getNetworkFile{package 
NXClusterTools;no warnings;return (Common::NXFile::getFileContent (
NXPaths::getNetworkFile ()));}sub NXClusterTools::getServerDSAPublicKey{package 
NXClusterTools;no warnings;(my $file=NXPaths::getServerDSAPublicKey ());if ((not
 (Common::NXFile::fileExists ($file)))){return ((""));}return (
Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::getServerDSAPrivateKey{package NXClusterTools;no warnings;(my $file
=NXPaths::getServerDSAPrivateKey ());if ((not (Common::NXFile::fileExists ($file
)))){return ((""));}return (Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::getServerRSAPublicKey{package NXClusterTools;no warnings;(my $file
=NXPaths::getServerRSAPublicKey ());if ((not (Common::NXFile::fileExists ($file)
))){return ((""));}return (Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::getServerRSAPrivateKey{package NXClusterTools;no warnings;(my $file
=NXPaths::getServerRSAPrivateKey ());if ((not (Common::NXFile::fileExists ($file
)))){return ((""));}return (Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::getPlayerCerts{package NXClusterTools;no warnings;(my $file=
NXPaths::getUserNXKnownCerts ());(my $content=Common::NXFile::getFileContent (
$file));return ($content);}sub NXClusterTools::getClusterMasterCertPub{package 
NXClusterTools;no warnings;(my $file=NXPaths::getClusterHostPublicCert ());if ((
not (Common::NXFile::fileExists ($file)))){generateClusterHostCerts ();}(my $content
=Common::NXFile::getFileContent ($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getClusterMasterCertPriv{package NXClusterTools;no warnings;(my $file
=NXPaths::getClusterHostPrivateCert ());if ((not (Common::NXFile::fileExists (
$file)))){generateClusterHostCerts ();}(my $content=
Common::NXFile::getFileContent ($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getHttpHostPrivateCert{package NXClusterTools;no warnings;(my $file
=NXPaths::getHttpHostPrivateCert ());(my $content=Common::NXFile::getFileContent
 ($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getHttpHostPublicCert{package NXClusterTools;no warnings;(my $file
=NXPaths::getHttpHostPublicCert ());(my $content=Common::NXFile::getFileContent 
($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getClusterHttpMasterCertPub{package NXClusterTools;no warnings;(my $file
=NXPaths::getClusterHttpHostPublicCert ());(my $content=
Common::NXFile::getFileContent ($file));if (($content eq (""))){(my $message=(
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$file));Logger::error ($message);die ($message);}return ($content);}sub 
NXClusterTools::getSSHHostKeyDSAPrivate{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyDSAPrivate ());(my $content=
Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyDSAPublic{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyDSAPublic ());(my $content=Common::NXFile::getFileContent
 ($file));return ($content);}sub NXClusterTools::getSSHHostKeyRSAPrivate{package
 NXClusterTools;no warnings;(my $file=NXPaths::getSSHHostKeyRSAPrivate ());(my $content
=Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyRSAPublic{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyRSAPublic ());(my $content=Common::NXFile::getFileContent
 ($file));return ($content);}sub NXClusterTools::getSSHHostKeyECDSAPrivate{
package NXClusterTools;no warnings;(my $file=NXPaths::getSSHHostKeyECDSAPrivate 
());(my $content=Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyECDSAPublic{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyECDSAPublic ());(my $content=
Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyED25519Private{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyED25519Private ());(my $content=
Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getSSHHostKeyED25519Public{package NXClusterTools;no warnings;(my $file
=NXPaths::getSSHHostKeyED25519Public ());(my $content=
Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::getUserKnownHostsSSH{package NXClusterTools;no warnings;return (
Common::NXFile::getFileContent (NXPaths::getUserKnownHostsSSH ()));}sub 
NXClusterTools::__unsync{package NXClusterTools;no warnings;(my $file=shift (@_)
);(my $owner=shift (@_));(my $emptyFile=($file."\x2e\x65\x6d\x70\x74\x79"));if (
Common::NXFile::fileExists ($emptyFile)){__remove ($emptyFile);__remove ($file);
return ((0x00a3+ 3306-0x0d8d));}(my $fileBackup=($file.
"\x2e\x62\x61\x63\x6b\x75\x70"));if (Common::NXFile::fileExists ($fileBackup)){
Logger::debug ((((("\x52\x65\x6e\x61\x6d\x65\x20\x27".$fileBackup).
"\x27\x20\x74\x6f\x20\x27").$file)."\x27\x2e"));unless (rename ($fileBackup,
$file)){Logger::error ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$fileBackup)."\x27\x20\x74\x6f\x20\x27").$file)."\x27\x2e\x20").$!));return (
(0x1920+ 2185-0x21a8));}if (($owner ne "\x72\x6f\x6f\x74")){
changeFileOwnershipToNxIfRoot ($file);}}return ((0x1b58+ 899-0x1edb));}sub 
NXClusterTools::__unsyncDatabases{package NXClusterTools;no warnings;
Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x64\x65\x73\x79\x6e\x63\x68\x72\x6f\x6e\x69\x7a\x65\x20\x64\x61\x74\x61\x62\x61\x73\x65\x73\x2e"
);if (__isDatabaseBackupExist ("\x6e\x6f\x64\x65\x73")){main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x73");NXNodes::cleanDb ();NXNodes::setDatabaseByString
 (__getDatabaseBackup ("\x6e\x6f\x64\x65\x73"));}if (__isDatabaseBackupExist (
"\x70\x72\x6f\x66\x69\x6c\x65\x73")){main::nxrequire (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42");NXProfilesDB::cleanDb ();
NXProfilesDB::setDatabaseByString (__getDatabaseBackup (
"\x70\x72\x6f\x66\x69\x6c\x65\x73"));}main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73");NXNodeGroups::cleanDb ();
NXRemoteMachinesGroups::cleanLoadedGroups ();if (__isDatabaseBackupExist (
"\x6e\x6f\x64\x65\x67\x72\x6f\x75\x70\x73")){NXNodeGroups::setDatabaseByString (
__getDatabaseBackup ("\x6e\x6f\x64\x65\x67\x72\x6f\x75\x70\x73"));}
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x47\x72\x6f\x75\x70\x73");
NXServerGroups::cleanDb ();NXRemoteMachinesGroups::cleanLoadedGroups ();if (
__isDatabaseBackupExist ("\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x73")){
NXServerGroups::setDatabaseByString (__getDatabaseBackup (
"\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x73"));}if (
__isDatabaseBackupExist ("\x75\x73\x65\x72\x73")){main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");
NXUsersManager::cleanDb ();NXUsersManager::setDatabaseByString (
__getDatabaseBackup ("\x75\x73\x65\x72\x73"));}if (__isDatabaseBackupExist (
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73")){main::nxrequire (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXAdministratorsManager::cleanDb ();
NXAdministratorsManager::setDatabaseByString (__getDatabaseBackup (
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73"));}if (
__isDatabaseBackupExist ("\x63\x65\x72\x74\x73\x4e\x58")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");NXServers::setNXCertsByString (undef,
__getDatabaseBackup ("\x63\x65\x72\x74\x73\x4e\x58"));}if (
__isDatabaseBackupExist ("\x63\x65\x72\x74\x73\x53\x53\x48")){main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x73");NXServers::setSSHCertsByString (undef,
__getDatabaseBackup ("\x63\x65\x72\x74\x73\x53\x53\x48"));}if (
__isDatabaseBackupExist ("\x67\x72\x6f\x75\x70\x73")){main::nxrequire (
"\x4e\x58\x47\x72\x6f\x75\x70\x73");NXGroups::cleanDb ();
NXGroups::setDatabaseByString (__getDatabaseBackup ("\x67\x72\x6f\x75\x70\x73"))
;}}sub NXClusterTools::__isDatabaseBackupExist{package NXClusterTools;no 
warnings;(my $database=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x65\x78\x69\x73\x74\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x62\x61\x63\x6b\x75\x70\x2e"
.$database)."\x0a"));return (NXRedis::get ());}sub 
NXClusterTools::__getDatabaseBackup{package NXClusterTools;no warnings;(my $database
=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x62\x61\x63\x6b\x75\x70\x2e"
.$database)."\x0a"));return (main::urldecode (NXRedis::get ()));}sub 
NXClusterTools::__remove{package NXClusterTools;no warnings;(my $file=shift (@_)
);if (Common::NXFile::fileExists ($file)){Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x5b".$file)."\x5d"));if ((not (unlink (
$file)))){Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20".
$file)."\x20").$!));}}}sub NXClusterTools::unsynchronize{package NXClusterTools;
no warnings;(my $host=shift (@_));__unsync (NXPaths::getUserNXKnownCerts ());
__unsync (NXPaths::getNXAuthorizedKeysPath ("\x6e\x78"));__unsync (
NXPaths::getNodePublicKeys ());if ((
Common::NXFile::setOwnerShipAndPermissionsReadOnlyForNX (
NXPaths::getNodePublicKeys ())==(-(0x0f24+ 1138-0x1395)))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x66\x69\x6c\x65\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x3a\x20"
.NXPaths::getNodePublicKeys ()));}__unsync (NXPaths::getUserKnownHostsSSH ());
__unsyncDatabases ();__remove (NXPaths::getClusterHostPublicCert ());__remove (
NXPaths::getClusterHostPrivateCert ());if (($host ne "\x6c\x6f\x63\x61\x6c")){
cleanDb ();}__unsync (NXPaths::getNetworkFile ());__unsync (
NXPaths::getNetworkDB ());}sub NXClusterTools::cleanSSHKeys{package 
NXClusterTools;no warnings;__unsync (NXPaths::getSSHHostKeyDSAPrivate (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyDSAPublic (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyRSAPrivate (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyRSAPublic (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyECDSAPrivate (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyECDSAPublic (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyED25519Private (),
"\x72\x6f\x6f\x74");__unsync (NXPaths::getSSHHostKeyED25519Public (),
"\x72\x6f\x6f\x74");}sub NXClusterTools::addClusterKey{package NXClusterTools;no
 warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getNXAuthorizedKeysPath ("\x6e\x78"));(my $rights=
$NXBits::UserReadWrite);return (__appendFile ($file,$rights,$fileContent,
(0x1967+ 3128-0x241f)));}sub NXClusterTools::setNodesDB{package NXClusterTools;
no warnings;(my $fileContent=shift (@_));main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x73");__setDatabaseBackup ("\x6e\x6f\x64\x65\x73",
NXNodes::getDatabaseInString ());NXNodes::cleanDb ();return (
NXNodes::setDatabaseByString ($fileContent));}sub 
NXClusterTools::setNodeGroupsDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));main::nxrequire ("\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73"
,"\x69\x6e\x69\x74");__setDatabaseBackup (
"\x6e\x6f\x64\x65\x67\x72\x6f\x75\x70\x73",NXNodeGroups::getDatabaseInString ())
;NXNodeGroups::cleanDb ();return (NXNodeGroups::setDatabaseByString (
$fileContent));}sub NXClusterTools::setServerGroupsDB{package NXClusterTools;no 
warnings;(my $fileContent=shift (@_));main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x47\x72\x6f\x75\x70\x73","\x69\x6e\x69\x74");
__setDatabaseBackup ("\x73\x65\x72\x76\x65\x72\x67\x72\x6f\x75\x70\x73",
NXServerGroups::getDatabaseInString ());NXServerGroups::cleanDb ();
NXServerGroups::cleanLoadedGroups ();return (NXServerGroups::setDatabaseByString
 ($fileContent));}sub NXClusterTools::setClusterDB{package NXClusterTools;no 
warnings;(my $fileContent=shift (@_));cleanDb ();return (setDatabaseByString (
$fileContent));}sub NXClusterTools::setProfilesDB{package NXClusterTools;no 
warnings;(my $fileContent=shift (@_));main::nxrequire (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42");__setDatabaseBackup (
"\x70\x72\x6f\x66\x69\x6c\x65\x73",NXProfilesDB::getDatabaseInString ());
NXProfilesDB::cleanDb ();return (NXProfilesDB::setDatabaseByString ($fileContent
));}sub NXClusterTools::setUsersDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));main::nxrequire (
"\x4e\x58\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72");__setDatabaseBackup 
("\x75\x73\x65\x72\x73",NXUsersManager::getDatabaseInString ());
NXUsersManager::cleanDb ();return (NXUsersManager::setDatabaseByString (
$fileContent));}sub NXClusterTools::setAdministratorsDB{package NXClusterTools;
no warnings;(my $fileContent=shift (@_));main::nxrequire (
"\x4e\x58\x41\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);__setDatabaseBackup (
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x73",
NXAdministratorsManager::getDatabaseInString ());
NXAdministratorsManager::cleanDb ();return (
NXAdministratorsManager::setDatabaseByString ($fileContent));}sub 
NXClusterTools::setGroupsDB{package NXClusterTools;no warnings;(my $fileContent=
shift (@_));main::nxrequire ("\x4e\x58\x47\x72\x6f\x75\x70\x73");
__setDatabaseBackup ("\x67\x72\x6f\x75\x70\x73",NXGroups::getDatabaseInString ()
);NXGroups::cleanDb ();return (NXGroups::setDatabaseByString ($fileContent));}
sub NXClusterTools::setNXCertsDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x4e\x58\x20\x63\x65\x72\x74\x73\x2e"
);main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");(my $ref_certs=
NXServers::getNXCertsHash ());(my $backup=NXShell::hashParameters2Url (
%$ref_certs));__setDatabaseBackup ("\x63\x65\x72\x74\x73\x4e\x58",$backup);
return (NXServers::setNXCertsByString ($ref_certs,$fileContent));}sub 
NXClusterTools::setSSHCertsDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x53\x53\x48\x20\x63\x65\x72\x74\x73\x2e"
);main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");(my $ref_certs=
NXServers::getSSHCertsHash ());(my $backup=NXShell::hashParameters2Url (
%$ref_certs));__setDatabaseBackup ("\x63\x65\x72\x74\x73\x53\x53\x48",$backup);
return (NXServers::setSSHCertsByString ($ref_certs,$fileContent));}sub 
NXClusterTools::setNetworkDB{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getNetworkDB ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x0c6c+ 1305-0x1005)));}sub NXClusterTools::setNetworkFile{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getNetworkFile ());(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));return (__setFile ($file,$rights,
$fileContent,(0x1c43+ 674-0x1d41)));}sub NXClusterTools::setServerDSAPublicKey{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getServerDSAPublicKey ());(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));return (__setFile ($file,$rights,
$fileContent,(0x0295+ 1988-0x08b5)));}sub NXClusterTools::setServerDSAPrivateKey
{package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getServerDSAPrivateKey ());(my $rights=$NXBits::UserReadWrite);return (
__setFile ($file,$rights,$fileContent,(0x1158+ 5794-0x267a)));}sub 
NXClusterTools::setServerRSAPublicKey{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getServerRSAPublicKey ());(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));return (
__setFile ($file,$rights,$fileContent,(0x0c28+ 6541-0x2411)));}sub 
NXClusterTools::setServerRSAPrivateKey{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getServerRSAPrivateKey ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x0373+ 3000-0x0dab)));}sub NXClusterTools::setClientCerts{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getUserNXKnownCerts ());(my $rights=$NXBits::UserReadWrite);return (
__setFile ($file,$rights,$fileContent,(0x0403+ 5303-0x173a)));}sub 
NXClusterTools::setAuthorizedCerts{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getNXAuthorizedKeysPath ("\x6e\x78"));(my $rights
=$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x0561+ 8668-0x25bd)));}sub NXClusterTools::addSSHAuthorizedCerts{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getNodePublicKeys ());if (Common::NXFile::fileExists ($file)){my (
$error);if ((Common::NXFile::setPermissionsReadWriteForNX ($file,(\$error))==(-
(0x082a+  45-0x0856)))){Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20\x27"
.$file)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$error).
"\x27\x2e"));return ((0x10fd+ 3748-0x1fa0));}}(my $rights=$NXBits::UserReadWrite
);return (__appendFile ($file,$rights,$fileContent,(0x128f+ 2906-0x1c69)));}sub 
NXClusterTools::setSSHAuthorizedCerts{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getNodePublicKeys ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x0896+ 4746-0x19a0)));}sub NXClusterTools::__setHostPrivateCert{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getHostPrivateCert ());(my $rights=$NXBits::UserReadWrite);return (
__setFile ($file,$rights,$fileContent,(0x079b+ 5688-0x1c53)));}sub 
NXClusterTools::__setHostPublicCert{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getHostPublicCert ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x1851+ 1097-0x1b1a)));}sub NXClusterTools::setClusterMasterCertPub{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getClusterHostPublicCert ());(my $rights=$NXBits::UserReadWrite);return
 (__setFile ($file,$rights,$fileContent,(0x15aa+ 428-0x15d6)));}sub 
NXClusterTools::setClusterMasterCertPriv{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getClusterHostPrivateCert ());(my $rights=
$NXBits::UserReadWrite);return (__setFile ($file,$rights,$fileContent,
(0x119f+ 3276-0x1ceb)));}sub NXClusterTools::setKnownHostsSSH{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getUserKnownHostsSSH ());(my $rights=$NXBits::UserReadWrite);return (
__setFile ($file,$rights,$fileContent,(0x1934+ 2066-0x1fc6)));}sub 
NXClusterTools::setSSHHostKeyDSAPrivate{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getSSHHostKeyDSAPrivate ());(my $rights=
$NXBits::UserReadWrite);__setFile ($file,$rights,$fileContent,
(0x0f57+ 5844-0x24ab),"\x72\x6f\x6f\x74");return ((0x0ec1+ 3368-0x1be9));}sub 
NXClusterTools::setSSHHostKeyDSAPublic{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getSSHHostKeyDSAPublic ());(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));__setFile (
$file,$rights,$fileContent,(0x2253+ 645-0x2334),"\x72\x6f\x6f\x74");return (
(0x0921+ 6870-0x23f7));}sub NXClusterTools::setSSHHostKeyRSAPrivate{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getSSHHostKeyRSAPrivate ());(my $rights=$NXBits::UserReadWrite);
__setFile ($file,$rights,$fileContent,(0x0aa0+ 5787-0x1fbb),"\x72\x6f\x6f\x74");
return ((0x0535+ 8304-0x25a5));}sub NXClusterTools::setSSHHostKeyRSAPublic{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getSSHHostKeyRSAPublic ());(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));__setFile ($file,$rights,$fileContent,
(0x11d7+ 4918-0x2369),"\x72\x6f\x6f\x74");return ((0x218f+ 257-0x2290));}sub 
NXClusterTools::setSSHHostKeyECDSAPrivate{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getSSHHostKeyECDSAPrivate ());(my $rights=
$NXBits::UserReadWrite);__setFile ($file,$rights,$fileContent,
(0x05e2+ 4011-0x140d),"\x72\x6f\x6f\x74");return ((0x055d+ 4441-0x16b6));}sub 
NXClusterTools::setSSHHostKeyECDSAPublic{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getSSHHostKeyECDSAPublic ());(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));__setFile (
$file,$rights,$fileContent,(0x1e29+ 2386-0x25d7),"\x72\x6f\x6f\x74");return (
(0x10c7+ 5026-0x2469));}sub NXClusterTools::setSSHHostKeyED25519Private{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getSSHHostKeyED25519Private ());(my $rights=$NXBits::UserReadWrite);
__setFile ($file,$rights,$fileContent,(0x1fa8+ 898-0x21aa),"\x72\x6f\x6f\x74");
return ((0x0649+ 8259-0x268c));}sub NXClusterTools::setSSHHostKeyED25519Public{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getSSHHostKeyED25519Public ());(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));__setFile ($file,$rights,$fileContent,
(0x1184+ 3373-0x1d0d),"\x72\x6f\x6f\x74");return ((0x0bfc+ 6422-0x2512));}sub 
NXClusterTools::__backupPrevious{package NXClusterTools;no warnings;(my $path=
shift (@_));(my $rights=shift (@_));(my $owner=shift (@_));(my $body=shift (@_))
;if ((not (Common::NXFile::fileExists ($path)))){(my $emptyFile=($path.
"\x2e\x65\x6d\x70\x74\x79"));(my $FH=main::nxopen ($emptyFile,($NXBits::O_RDWR+
$NXBits::O_CREAT),(($NXBits::OthersRead+$NXBits::UserReadWrite)+
$NXBits::GroupRead)));if ((not (defined ($FH)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x27"
.$emptyFile)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorNumber)."\x2c\x20").$errorString).
"\x2e"));return ((0x0e98+ 4819-0x216a));}main::nxclose ($FH);if (($owner ne 
"\x72\x6f\x6f\x74")){changeFileOwnershipToNxIfRoot ($emptyFile);}return (
(0x108c+ 839-0x13d3));}(my $backup=($path."\x2e\x62\x61\x63\x6b\x75\x70"));if (
Common::NXFile::fileExists ($backup)){($backup.=("\x2d".NXTools::getTimeMs ()));
}if (($body ne (""))){(my $FH=main::nxopen ($backup,($NXBits::O_RDWR+
$NXBits::O_CREAT),$NXBits::UserReadWrite));if ((not (defined ($FH)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x27"
.$emptyFile)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorNumber)."\x2c\x20").$errorString).
"\x2e"));return ((0x0902+ 3436-0x166d));}if ((main::nxwrite ($FH,$body)==(-
(0x1493+ 624-0x1702)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$backup)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));main::nxclose ($FH);if (($backupOwner ne 
"\x72\x6f\x6f\x74")){changeFileOwnershipToNxIfRoot ($backup);}return (
(0x0c86+ 5046-0x203b));}main::nxclose ($FH);if (($owner ne "\x72\x6f\x6f\x74")){
changeFileOwnershipToNxIfRoot ($backup);}return ((0x18a2+ 1811-0x1fb5));}else{(my (
$retValue,$outMsg)=Common::NXCore::copyFile ($path,$backup));if (($outMsg ne 
(""))){Logger::error (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x27".$path).
"\x27\x20\x74\x6f\x20\x27").$backup).
"\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$outMsg)."\x27\x2e"));
return ((0x1589+ 2919-0x20ef));}}my ($error);if ((Common::NXFile::setPermission 
($backup,$rights,(\$error))==(-(0x1479+ 1232-0x1948)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20"
.$backup)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$error)."\x27\x2e"
));return ((0x173f+ 238-0x182c));}unless (Common::NXFile::fileExists ($backup)){
Logger::error (((((
"\x46\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x20\x62\x61\x63\x6b\x75\x70\x20\x27"
.$backup)."\x27\x20\x66\x6f\x72\x20\x27").$path)."\x27\x2e"));return (
(0x231d+ 799-0x263b));}if ((($owner ne "\x72\x6f\x6f\x74")and ($owner ne 
"\x6e\x78\x68\x74\x64"))){changeFileOwnershipToNxIfRoot ($backup);}return (
(0x0e4a+ 2274-0x172c));}sub NXClusterTools::__setFile{package NXClusterTools;no 
warnings;(my $file=shift (@_));(my $rights=shift (@_));(my $fileBody=shift (@_))
;(my $backupRights=shift (@_));(my $backupOwner=shift (@_));(my $backupBody=
shift (@_));if (__backupPrevious ($file,$backupRights,$backupOwner,$backupBody))
{return ((0x1220+ 1878-0x1975));}(my $fileBackup=($file."\x2e\x74\x6d\x70"));(my $fileDesc
=main::nxopen ($fileBackup,($NXBits::O_WRONLY+$NXBits::O_CREAT),$rights));unless
 (defined ($fileDesc)){Logger::error (((
"\x45\x72\x72\x6f\x72\x20\x6f\x70\x65\x6e\x69\x6e\x67\x20\x66\x69\x6c\x65\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x27"
.$fileBackup)."\x27\x2e"));return ((0x0ac9+ 4734-0x1d46));}if ((main::nxwrite (
$fileDesc,$fileBody)==(-(0x0a0b+ 4818-0x1cdc)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$fileBackup)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));main::nxclose ($fileDesc);if ((($backupOwner ne 
"\x72\x6f\x6f\x74")and ($backupOwner ne "\x6e\x78\x68\x74\x64"))){
changeFileOwnershipToNxIfRoot ($fileBackup);}return ((0x07da+ 2127-0x1028));}
main::nxclose ($fileDesc);if ((($backupOwner ne "\x72\x6f\x6f\x74")and (
$backupOwner ne "\x6e\x78\x68\x74\x64"))){changeFileOwnershipToNxIfRoot (
$fileBackup);}unless (rename ($fileBackup,$file)){Logger::error (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$fileBackup)."\x27\x20\x74\x6f\x20\x27").$file).
"\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$!)."\x27\x2e"));return 
((0x093c+ 3458-0x16bd));}return ((0x0757+ 302-0x0885));}sub 
NXClusterTools::__appendFile{package NXClusterTools;no warnings;(my $file=shift 
(@_));(my $rights=shift (@_));(my $fileBody=shift (@_));(my $rightBackup=shift (
@_));(my $ownerBackup=shift (@_));if (__backupPrevious ($file,$rightBackup,
$ownerBackup)){return ((0x0e15+ 4458-0x1f7e));}(my $fileExisted=
(0x108d+ 4435-0x21e0));if (Common::NXFile::fileExists ($file)){($fileExisted=
(0x0858+ 2451-0x11ea));}(my $fileDesc=main::nxopen ($file,(($NXBits::O_WRONLY+
$NXBits::O_CREAT)+$NXBits::O_APPEND),$rights));unless (defined ($fileDesc)){
Logger::error (((
"\x45\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x6f\x70\x65\x6e\x69\x6e\x67\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x74\x6f\x20\x61\x70\x70\x65\x6e\x64\x2e"));return (
(0x07ed+ 2614-0x1222));}if ((main::nxwrite ($fileDesc,$fileBody)==(-
(0x1482+ 2268-0x1d5d)))){(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20"
.$file)."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20").$errorstring)."\x2e"));main::nxclose ($fileDesc);if ((
not ($fileExisted))){if (($ownerBackup ne "\x72\x6f\x6f\x74")){
changeFileOwnershipToNxIfRoot ($file);}}return ((0x20bb+ 667-0x2355));}
main::nxclose ($fileDesc);if ((not ($fileExisted))){
changeFileOwnershipToNxIfRoot ($file);}return ((0x0817+ 2035-0x100a));}sub 
NXClusterTools::__addClusterNodeKey{package NXClusterTools;no warnings;(my $message
=shift (@_));($message=main::urldecode ($message));return (addClusterKey (
$message));}sub NXClusterTools::checkUserNXConfigDir{package NXClusterTools;no 
warnings;(my $path=NXPaths::getConfigDir ());unless (
Common::NXFile::directoryExists ($path)){my ($error);unless (
Common::NXPaths::createAccessibleForNXDirectory ((\$error),$path)){return (
(0x1dd0+  29-0x1ded));}}return ((0x0512+ 5095-0x18f8));}sub 
NXClusterTools::prepareNXKnownCerts{package NXClusterTools;no warnings;(my $refClusterHash
=shift (@_));my ($file);foreach my $key (keys (%$refClusterHash)){(my $value=
$$refClusterHash{$key});chomp ($value);if (
Common::NXShellCreate::isHostInCertFile ($key,NXPaths::getCurrentUserKnownCerts 
())){Common::NXShellCreate::removeCertificate ($key,$value,
NXPaths::getUserNXKnownCerts ());}($file.=(((("\x48\x6f\x73\x74\x3a".$key).
"\x0a").$value)."\x0a"));}(my $myIp=$GLOBAL::ClusterOldLocal);(my $myCert=
getHostPublicCert ());chomp ($myCert);if (
Common::NXShellCreate::isHostInCertFile ($myIp,NXPaths::getCurrentUserKnownCerts
 ())){Common::NXShellCreate::removeCertificate ($myIp,$myCert,
NXPaths::getUserNXKnownCerts ());}($file.=(((("\x48\x6f\x73\x74\x3a".$myIp).
"\x0a").$myCert)."\x0a"));(my $hostCert=getClusterMasterCertPub ());if (
NXCluster::isSingleCert ()){($hostCert=getHostPublicCert ());}chomp ($hostCert);
if (Common::NXShellCreate::isHostInCertFile ($GLOBAL::ClusterHost,
NXPaths::getCurrentUserKnownCerts ())){Common::NXShellCreate::removeCertificate 
($GLOBAL::ClusterHost,$hostCert,NXPaths::getUserNXKnownCerts ());}($file.=((((
"\x48\x6f\x73\x74\x3a".$GLOBAL::ClusterHost)."\x0a").$hostCert)."\x0a"));($file
.=getPlayerCerts ());setClientCerts ($file);(my $path=
NXPaths::getUserNXKnownCerts ());changeFileOwnershipToNxIfRoot ($path);return (
$file);}sub NXClusterTools::__preparePublicKeys{package NXClusterTools;no 
warnings;(my $ref_publicKeys=shift (@_));(my $protocol=shift (@_));Logger::debug
 (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x50\x72\x65\x70\x61\x72\x65\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x73\x2e"
);(my $file=(""));my ($filePath);if (($protocol eq "\x53\x53\x48")){($filePath=
NXPaths::getNodePublicKeys ());}else{($filePath=NXPaths::getNXAuthorizedKeysPath
 ("\x6e\x78"));}(my $fileContent=Common::NXFile::getFileContent ($filePath));(my (
@oldContent)=split ( /\n/ ,$fileContent,(0x1a21+ 1984-0x21e1)));(my $prefix=
"\x6e\x6f\x2d\x70\x6f\x72\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c\x6e\x6f\x2d\x61\x67\x65\x6e\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c"
);($prefix.=(("\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x22".$GLOBAL::ETC_DIR).
$GLOBAL::DIRECTORY_SLASH));($prefix.=
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x72\x65\x6d\x6f\x74\x65\x6c\x6f\x67\x69\x6e\x22\x20"
);foreach my $key (keys (%$ref_publicKeys)){(my $potentialKey=$$ref_publicKeys{
$key});(my $add=(0x0c40+ 1298-0x1151));chomp ($potentialKey);($potentialKey=~ s/\r//g )
;if (($protocol eq "\x53\x53\x48")){($potentialKey=($prefix.$potentialKey));}
else{($potentialKey.=
"\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x43\x6c\x75\x73\x74\x65\x72");}foreach my $line
 (@oldContent){chomp ($line);($line=~ s/\r//g );if (($potentialKey eq $line)){(
$add=(0x1ad4+ 942-0x1e82));last;}}if (($add==(0x1b99+ 1900-0x2304))){($file.=(
$potentialKey."\x0a"));}}(my $potentialKey=getClusterPublicKey ());chomp (
$potentialKey);($potentialKey=~ s/\r//g );if (($protocol eq "\x53\x53\x48")){(
$potentialKey=($prefix.$potentialKey));}else{($potentialKey.=
"\x20\x4e\x6f\x4d\x61\x63\x68\x69\x6e\x65\x43\x6c\x75\x73\x74\x65\x72");}(my $add
=(0x0973+ 2335-0x1291));foreach my $line (@oldContent){chomp ($line);($line=~ s/\r//g )
;if (($potentialKey eq $line)){($add=(0x1abb+ 1793-0x21bc));last;}}if (($add==
(0x1a18+ 2602-0x2441))){($file.=($potentialKey."\x0a"));}($file.=$fileContent);
if (($protocol eq "\x53\x53\x48")){setSSHAuthorizedCerts ($file);}else{
setAuthorizedCerts ($file);}return ($file);}sub 
NXClusterTools::prepareNXDPublicKeys{package NXClusterTools;no warnings;(my $ref_publicKeys
=shift (@_));return (__preparePublicKeys ($ref_publicKeys,"\x4e\x58"));}sub 
NXClusterTools::prepareSSHPublicKeys{package NXClusterTools;no warnings;(my $ref_publicKeys
=shift (@_));return (__preparePublicKeys ($ref_publicKeys,"\x53\x53\x48"));}sub 
NXClusterTools::prepareSSHClusterKey{package NXClusterTools;no warnings;(my $prefix
=
"\x6e\x6f\x2d\x70\x6f\x72\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c\x6e\x6f\x2d\x61\x67\x65\x6e\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c"
);($prefix.=((("\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x22".$GLOBAL::ETC_DIR).
$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x72\x65\x6d\x6f\x74\x65\x6c\x6f\x67\x69\x6e\x22\x20"
));(my $key=($prefix.getClusterPublicKey ()));return ($key);}sub 
NXClusterTools::prepareKnownHostsSSH{package NXClusterTools;no warnings;(my $host
=shift (@_));(my $sshCrt=shift (@_));($sshCrt=~ s/\015//gs );my ($file);if ((
$sshCrt ne (""))){($file=(((($GLOBAL::ClusterPool."\x2c").$GLOBAL::ClusterHost).
"\x20").$sshCrt));}Common::NXShellCreate::removeCertificateSSH (
$GLOBAL::ClusterHost,(""),NXPaths::getUserKnownHostsSSH ());(my (@hosts)=split ( /,/ ,
$GLOBAL::ClusterPool,(0x0201+ 8937-0x24ea)));foreach my $host (@hosts){
Common::NXShellCreate::removeCertificateSSH ($host,(""),
NXPaths::getUserKnownHostsSSH ());}($file.=getUserKnownHostsSSH ());
setKnownHostsSSH ($file);return ($file);}sub NXClusterTools::checkKeys{package 
NXClusterTools;no warnings;Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x66\x69\x6c\x65\x73\x2e"
);if ((not (Common::NXFile::fileExists (NXPaths::getClusterRSAPrivateKey ())))){
generateClusterKeys ();}if ((not (Common::NXFile::fileExists (
NXPaths::getClusterRSAPublicKey ())))){generateClusterKeys ();}if ((not (
Common::NXFile::fileExists (NXPaths::getClusterHostPublicCert ())))){
generateClusterHostCerts ();}if ((not (Common::NXFile::fileExists (
NXPaths::getClusterHostPrivateCert ())))){generateClusterHostCerts ();}}sub 
NXClusterTools::changeFileOwnershipToNxIfRoot{package NXClusterTools;no warnings
;(my $file=shift (@_));(my $user=Common::NXCore::getEffectiveUsername ());if ((
$user eq "\x72\x6f\x6f\x74")){Logger::debug2 (((
"\x53\x65\x74\x74\x69\x6e\x67\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x6e\x78\x20\x27"
.$file)."\x27\x2e"));my ($errorName);my ($errorCode);if ((
Common::NXFile::setOwnershipForUserSilent ($file,"\x6e\x78",(\$errorName),(
\$errorCode))==(-(0x1338+ 717-0x1604)))){Logger::error ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x69\x6c\x65\x20"
.$file)."\x2e\x20").$errorCode)."\x20").$errorName));NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x4f\x77\x6e\x65\x72\x73\x68\x69\x70",
"\x4e\x58\x53\x68\x65\x6c\x6c",(($file."\x2e\x20").$errorName));unlink ($file);
main::nxexit ((0x00b2+ 4977-0x1423));}}return ((0x135b+ 1929-0x1ae4));}sub 
NXClusterTools::__getPathToPublicKey{package NXClusterTools;no warnings;if (
__isRSAKeyAvailable ()){return (NXPaths::getClusterRSAPrivateKey ());}return (
NXPaths::getClusterDSAPrivateKey ());}sub NXClusterTools::getDatabaseInString{
package NXClusterTools;no warnings;(my $request=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e\x63\x6f\x6e\x66\x69\x67\x2c\x66\x69\x65\x6c\x64\x3d\x6d\x61\x73\x74\x65\x72\x2c\x66\x69\x65\x6c\x64\x3d\x73\x68\x61\x72\x65\x64\x2c\x66\x69\x65\x6c\x64\x3d\x70\x72\x6f\x74\x6f\x2c\x66\x69\x65\x6c\x64\x3d\x67\x72\x61\x63\x65"
);($request.=
"\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x74\x72\x79\x2c\x66\x69\x65\x6c\x64\x3d\x70\x72\x6f\x62\x65\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x74\x65\x72\x76\x61\x6c\x2c\x66\x69\x65\x6c\x64\x3d\x74\x69\x6d\x65\x6f\x75\x74\x2c\x66\x69\x65\x6c\x64\x3d\x6d\x61\x69\x6e\x43\x6c\x75\x73\x74\x65\x72\x55\x55\x49\x44\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x75\x73\x74\x65\x72\x47\x55\x49\x44\x0a"
);(my $databaseString=(""));NXRedis::sendToDb ($request);(my $config=
NXRedis::get ());($config=~ s/ /,/g );($databaseString.=($config."\x0a"));
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x0a"
);(my $clusterList=NXRedis::get ());(my (@list)=split ( / / ,$clusterList,
(0x0bd6+ 6204-0x2412)));foreach $host (@list){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.$host).
"\x2c\x66\x69\x65\x6c\x64\x3d\x68\x6f\x73\x74\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x2c\x66\x69\x65\x6c\x64\x3d\x6e\x65\x74\x6d\x61\x73\x6b\x0a"
));(my $line=NXRedis::get ());($line=~ s/ /,/g );($databaseString.=($line."\x0a"
));}return ($databaseString);}sub NXClusterTools::setDatabaseByString{package 
NXClusterTools;no warnings;(my $string=shift (@_));(my (@clusterList)=split ( /\n/ ,
$string,(0x0ce2+ 6417-0x25f3)));(my $redisString=__setConfigLine ($clusterList[
(0x08d2+ 5437-0x1e0f)]));NXRedis::sendToDb ($redisString);(my ($host1data,
$host1set)=__setHostLineS ($clusterList[(0x0a94+ 6576-0x2443)]));
NXRedis::sendToDb ($host1data);NXRedis::sendToDb ($host1set);(my ($host2data,
$host2set)=__setHostLineS ($clusterList[(0x03f1+ 7284-0x2063)]));
NXRedis::sendToDb ($host2data);NXRedis::sendToDb ($host2set);return (
(0x0b86+ 2702-0x1614));}sub NXClusterTools::__setConfigLine{package 
NXClusterTools;no warnings;(my $configLine=shift (@_));(my $record=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e\x63\x6f\x6e\x66\x69\x67"
);(my (@options)=split ( /,/ ,$configLine,(0x1b24+ 2376-0x246c)));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x6d\x61\x73\x74\x65\x72\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x142d+ 661-0x16c2)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x73\x68\x61\x72\x65\x64\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x1147+ 3933-0x20a3)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x70\x72\x6f\x74\x6f\x2c\x76\x61\x6c\x75\x65\x3d".
$options[(0x025c+ 3697-0x10cb)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x67\x72\x61\x63\x65\x2c\x76\x61\x6c\x75\x65\x3d".
$options[(0x1189+ 2375-0x1acd)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x74\x72\x79\x2c\x76\x61\x6c\x75\x65\x3d".
$options[(0x01bb+ 6002-0x1929)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x70\x72\x6f\x62\x65\x2c\x76\x61\x6c\x75\x65\x3d".
$options[(0x07f8+ 333-0x0940)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x74\x65\x72\x76\x61\x6c\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x0669+ 3192-0x12db)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x74\x69\x6d\x65\x6f\x75\x74\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x02a3+ 7035-0x1e17)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x6d\x61\x69\x6e\x43\x6c\x75\x73\x74\x65\x72\x55\x55\x49\x44\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x0a8f+ 7166-0x2685)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x75\x73\x74\x65\x72\x47\x55\x49\x44\x2c\x76\x61\x6c\x75\x65\x3d"
.$options[(0x0ae1+ 1807-0x11e7)]));($record.="\x0a");return ($record);}sub 
NXClusterTools::__setHostLineS{package NXClusterTools;no warnings;(my $hostLine=
shift (@_));(my (@host)=split ( /,/ ,$hostLine,(0x08d9+ 2694-0x135f)));(my $record
=(
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.$host[(0x043d+  80-0x048d)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x68\x6f\x73\x74\x2c\x76\x61\x6c\x75\x65\x3d".$host
[(0x0667+ 6802-0x20f9)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x2c\x76\x61\x6c\x75\x65\x3d"
.$host[(0x243c+ 369-0x25ac)]));($record.=(
"\x2c\x66\x69\x65\x6c\x64\x3d\x6e\x65\x74\x6d\x61\x73\x6b\x2c\x76\x61\x6c\x75\x65\x3d"
.$host[(0x0a22+ 1745-0x10f1)]));($record.="\x0a");(my $setRecord=((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2c\x66\x69\x65\x6c\x64\x3d"
.$host[(0x1791+ 1854-0x1ecf)])."\x0a"));return ($record,$setRecord);}sub 
NXClusterTools::cleanDb{package NXClusterTools;no warnings;NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x0a"
);(my (@hosts)=split ( / / ,NXRedis::get (),(0x11e8+ 2595-0x1c0b)));
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x0a"
);foreach my $host (@hosts){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.$host)."\x0a"));}NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e\x63\x6f\x6e\x66\x69\x67\x0a"
);return ((0x0e0c+ 1459-0x13bf));}sub NXClusterTools::getServerCfgFile{package 
NXClusterTools;no warnings;(my $file=$GLOBAL::CONFIG_FILE);return (
Common::NXFile::getFileContent ($file));}sub NXClusterTools::setServerCfgFile{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
$GLOBAL::CONFIG_FILE);(my $rights=(($NXBits::UserReadWrite+$NXBits::GroupRead)+
$NXBits::OthersRead));__setFile ($file,$rights,$fileContent,
(0x078b+ 7032-0x215f));return ((0x08d7+ 3959-0x184e));}sub 
NXClusterTools::getNodeCfgFile{package NXClusterTools;no warnings;(my $file=
$GLOBAL::NODE_CONFIG_FILE);return (Common::NXFile::getFileContent ($file));}sub 
NXClusterTools::setNodeCfgFile{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=$GLOBAL::NODE_CONFIG_FILE);(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));__setFile (
$file,$rights,$fileContent,(0x03f3+ 2332-0x0b6b));return ((0x075b+ 216-0x0833));
}sub NXClusterTools::sync{package NXClusterTools;no warnings;if ((
$GLOBAL::ClusterSyncDisabled==(0x0e1b+ 1499-0x13f5))){Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x6c\x75\x73\x74\x65\x72\x20\x73\x79\x6e\x63\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x1a60+ 797-0x1d7c));}main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((not (NXCluster::isClusterConfigured
 ()))){Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x6b\x69\x70\x20\x73\x79\x6e\x63\x20\x66\x6f\x72\x20\x6e\x6f\x74\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x65\x64\x20\x63\x6c\x75\x73\x74\x65\x72\x2e"
);return;}Logger::debug (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x73\x79\x6e\x63\x2e"
);(my (@command)=());push (@command,($GLOBAL::ETC_DIR.
"\x2f\x6e\x78\x73\x65\x72\x76\x65\x72"));(my $user=
Common::NXCore::getEffectiveUsername ());if (($user eq "\x72\x6f\x6f\x74")){push
 (@command,"\x2d\x2d\x63\x6c\x75\x73\x74\x65\x72\x65\x64\x69\x74");}else{push (
@command,"\x2d\x2d\x73\x79\x6e\x63\x68\x72\x6f\x6e\x69\x7a\x65");}(my (@options)
=());(my $logfile=Common::NXPaths::getNXServerLogPath ());push (@options,
"\x73\x74\x64\x65\x72\x72",$logfile);push (@options,"\x73\x74\x64\x6f\x75\x74",
$logfile);push (@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53\x3d".libnxh::NXTransGetEnvironment
 ("\x4e\x58\x5f\x46\x45\x41\x54\x55\x52\x45\x53")));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e\x3d".
libnxh::NXTransGetEnvironment ("\x4e\x58\x5f\x56\x45\x52\x53\x49\x4f\x4e")));
main::run_command ((\@command),(\@options));}sub NXClusterTools::getWebCfgFile{
package NXClusterTools;no warnings;(my $file=$GLOBAL::HTD_CONFIG_FILE);return (
Common::NXFile::getFileContent ($file));}sub NXClusterTools::setWebCfgFile{
package NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
$GLOBAL::HTD_CONFIG_FILE);(my $rights=(($NXBits::UserReadWrite+
$NXBits::GroupRead)+$NXBits::OthersRead));__setFile ($file,$rights,$fileContent,
(0x162f+ 400-0x161b),"\x6e\x78\x68\x74\x64");return (changeFileOwnershipToNxhtd 
($file,"\x63\x6f\x6e\x66\x69\x67"));}sub 
NXClusterTools::setHttpHostPublicCertFile{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getHttpHostPublicCert ());(my $rights=((
$NXBits::UserReadWrite+$NXBits::GroupRead)+$NXBits::OthersRead));(my $ret=
__setFile ($file,$rights,$fileContent,(0x16f9+ 2637-0x1fa2),
"\x6e\x78\x68\x74\x64"));return (changeFileOwnershipToNxhtd ($file,
"\x70\x75\x62\x6c\x69\x63\x43\x65\x72\x74"));}sub 
NXClusterTools::setHttpHostPrivateCertFile{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getHttpHostPrivateCert ());(my $rights=
$NXBits::UserReadWrite);(my $orginalContent=(""));(my $user=
Common::NXCore::getEffectiveUsername ());if (($user ne "\x72\x6f\x6f\x74")){(
$orginalContent=getHttpHostPrivateCertContent ($file));}(my $ret=__setFile (
$file,$rights,$fileContent,(0x03c5+ 1625-0x089e),"\x6e\x78\x68\x74\x64",
$orginalContent));return (changeFileOwnershipToNxhtd ($file,
"\x70\x72\x69\x76\x61\x74\x65\x43\x65\x72\x74"));}sub 
NXClusterTools::changeFileOwnershipToNxhtd{package NXClusterTools;no warnings;(my $file
=shift (@_));(my $param=shift (@_));(my $user=
Common::NXCore::getEffectiveUsername ());if (($user eq "\x72\x6f\x6f\x74")){(my (
@htdUsers)=NXTools::getNXHtdUser ());Logger::debug (((((
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20"
.$htdUsers[(0x0682+ 2718-0x1120)])."\x2c\x20").$file)."\x2e"));my ($errorName);my (
$errorCode);if ((Common::NXFile::setOwnershipForUserSilent ($file,$htdUsers[
(0x0418+ 1727-0x0ad7)],(\$errorName),(\$errorCode))==(-(0x1221+ 1522-0x1812)))){
Logger::error ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x69\x6c\x65\x20"
.$file)."\x2e\x20").$errorCode)."\x20").$errorName));NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x4f\x77\x6e\x65\x72\x73\x68\x69\x70",
"\x4e\x58\x53\x68\x65\x6c\x6c",(($file."\x2e\x20").$errorName));unlink ($file);
main::nxexit ((0x0eb2+ 5521-0x2443));}}else{(my (@command)=());(my (@parameters)
=());push (@command,$GLOBAL::CommandNXexec,$GLOBAL::SCRIPT_NXHTDCHOWN,$param);(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x0865+ 4587-0x1a50))){Logger::error (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x74\x6f\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27").
$exit_value)."\x27\x20").$cmd_out)."\x20").$cmd_err)."\x2e"));if (($cmd_out ne 
(""))){($file.=("\x2e\x20".$cmd_out));}NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x4f\x77\x6e\x65\x72\x73\x68\x69\x70",
"\x4e\x58\x53\x68\x65\x6c\x6c",$file);main::nxexit ((0x0083+ 6869-0x1b58));}}
return ((0x0022+ 1668-0x06a6));}sub 
NXClusterTools::getHttpHostPrivateCertContent{package NXClusterTools;no warnings
;(my $file=shift (@_));(my (@command)=());(my (@parameters)=());push (@command,
$GLOBAL::CommandNXexec,$GLOBAL::SCRIPT_NXWEBHOSTCERTGET);(my ($cmd_err,$cmd_out,
$exit_value)=main::run_command ((\@command),(\@parameters)));if (($exit_value!=
(0x09d1+ 3551-0x17b0))){Logger::error (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x66\x69\x6c\x65\x20\x27".$file).
"\x27\x20\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
).$exit_value)."\x27\x20").$cmd_out)."\x20").$cmd_err)."\x2e"));if (($cmd_out ne
 (""))){($file.=("\x2e\x20".$cmd_out));}NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x46\x69\x6c\x65",
"\x4e\x58\x53\x68\x65\x6c\x6c",$file);main::nxexit ((0x039f+ 7535-0x210e));}
return ($cmd_out);return ((""));}sub NXClusterTools::getHostPrivateCert{package 
NXClusterTools;no warnings;(my $file=NXPaths::getHostPrivateCert ());(my $content
=Common::NXFile::getFileContent ($file));return ($content);}sub 
NXClusterTools::setHostPrivateCert{package NXClusterTools;no warnings;(my $fileContent
=shift (@_));(my $file=NXPaths::getHostPrivateCert ());(my $rights=
$NXBits::UserReadWrite);__setFile ($file,$rights,$fileContent,
(0x049f+ 6007-0x1a96));return ((0x007b+ 5229-0x14e8));}sub 
NXClusterTools::getHostPublicCert{package NXClusterTools;no warnings;(my $file=
NXPaths::getHostPublicCert ());(my $content=Common::NXFile::getFileContent (
$file));return ($content);}sub NXClusterTools::setHostPublicCert{package 
NXClusterTools;no warnings;(my $fileContent=shift (@_));(my $file=
NXPaths::getHostPublicCert ());(my $rights=$NXBits::UserReadWrite);__setFile (
$file,$rights,$fileContent,(0x1884+ 1063-0x1b2b));return ((0x01cc+ 1787-0x08c7))
;}package NXClusterTools;no warnings;return ((0x020a+ 929-0x05aa));
