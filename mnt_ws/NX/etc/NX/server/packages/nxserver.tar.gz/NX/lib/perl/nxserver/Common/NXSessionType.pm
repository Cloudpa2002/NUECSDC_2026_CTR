############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXSessionType::BEGIN{package Common::NXSessionType;no warnings;
require Common::NXDistro;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x44\x69\x73\x74\x72\x6f"->import};}
package Common::NXSessionType;no warnings;my (%internal);my (%external);(
$NXSessionType::physicalDesktop=
"\x70\x68\x79\x73\x69\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70");($internal{
$NXSessionType::physicalDesktop}=
"\x70\x68\x79\x73\x69\x63\x61\x6c\x2d\x64\x65\x73\x6b\x74\x6f\x70");($external{
"\x70\x68\x79\x73\x69\x63\x61\x6c\x2d\x64\x65\x73\x6b\x74\x6f\x70"}=
$NXSessionType::physicalDesktop);($external{
"\x73\x68\x61\x64\x6f\x77\x2d\x77\x69\x6e\x64\x6f\x77\x73"}=
$NXSessionType::physicalDesktop);($external{
"\x73\x68\x61\x64\x6f\x77\x2d\x6d\x61\x63"}=$NXSessionType::physicalDesktop);(
$NXSessionType::physicalAttachDesktop=
"\x70\x68\x79\x73\x69\x63\x61\x6c\x41\x74\x74\x61\x63\x68\x44\x65\x73\x6b\x74\x6f\x70"
);($internal{$NXSessionType::physicalAttachDesktop}=
"\x70\x68\x79\x73\x69\x63\x61\x6c\x2d\x64\x65\x73\x6b\x74\x6f\x70");(
$NXSessionType::virtualDefault=
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x66\x61\x75\x6c\x74");($internal{
$NXSessionType::virtualDefault}=
"\x75\x6e\x69\x78\x2d\x78\x73\x65\x73\x73\x69\x6f\x6e\x2d\x64\x65\x66\x61\x75\x6c\x74"
);($external{
"\x75\x6e\x69\x78\x2d\x78\x73\x65\x73\x73\x69\x6f\x6e\x2d\x64\x65\x66\x61\x75\x6c\x74"
}=$NXSessionType::virtualDefault);($NXSessionType::virtualGnome=
"\x76\x69\x72\x74\x75\x61\x6c\x47\x6e\x6f\x6d\x65");($internal{
$NXSessionType::virtualGnome}="\x75\x6e\x69\x78\x2d\x67\x6e\x6f\x6d\x65");(
$external{"\x75\x6e\x69\x78\x2d\x67\x6e\x6f\x6d\x65"}=
$NXSessionType::virtualGnome);($NXSessionType::virtualKde=
"\x76\x69\x72\x74\x75\x61\x6c\x4b\x64\x65");($internal{
$NXSessionType::virtualKde}="\x75\x6e\x69\x78\x2d\x6b\x64\x65");($external{
"\x75\x6e\x69\x78\x2d\x6b\x64\x65"}=$NXSessionType::virtualKde);(
$NXSessionType::virtualCde="\x76\x69\x72\x74\x75\x61\x6c\x43\x64\x65");(
$internal{$NXSessionType::virtualCde}="\x75\x6e\x69\x78\x2d\x63\x64\x65");(
$external{"\x75\x6e\x69\x78\x2d\x63\x64\x65"}=$NXSessionType::virtualCde);(
$NXSessionType::virtualConsole=
"\x76\x69\x72\x74\x75\x61\x6c\x43\x6f\x6e\x73\x6f\x6c\x65");($internal{
$NXSessionType::virtualConsole}=
"\x75\x6e\x69\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65");($external{
"\x75\x6e\x69\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65"}=
$NXSessionType::virtualConsole);($NXSessionType::virtualApplicationDefault=
"\x76\x69\x72\x74\x75\x61\x6c\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x44\x65\x66\x61\x75\x6c\x74"
);($internal{$NXSessionType::virtualApplicationDefault}=
"\x75\x6e\x69\x78\x2d\x64\x65\x66\x61\x75\x6c\x74");($external{
"\x75\x6e\x69\x78\x2d\x64\x65\x66\x61\x75\x6c\x74"}=
$NXSessionType::virtualApplicationDefault);($NXSessionType::virtualDesktop=
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70");($internal{
$NXSessionType::virtualDesktop}=
"\x75\x6e\x69\x78\x2d\x64\x65\x73\x6b\x74\x6f\x70");($external{
"\x75\x6e\x69\x78\x2d\x64\x65\x73\x6b\x74\x6f\x70"}=
$NXSessionType::virtualDesktop);($NXSessionType::virtualXdm=
"\x76\x69\x72\x74\x75\x61\x6c\x58\x64\x6d");($internal{
$NXSessionType::virtualXdm}="\x75\x6e\x69\x78\x2d\x78\x64\x6d");($external{
"\x75\x6e\x69\x78\x2d\x78\x64\x6d"}=$NXSessionType::virtualXdm);(
$NXSessionType::virtualVms="\x76\x69\x72\x74\x75\x61\x6c\x56\x6d\x73");(
$internal{$NXSessionType::virtualVms}="\x76\x6d\x73");($external{"\x76\x6d\x73"}
=$NXSessionType::virtualVms);($NXSessionType::virtualVnc=
"\x76\x69\x72\x74\x75\x61\x6c\x56\x6e\x63");($internal{
$NXSessionType::virtualVnc}="\x76\x6e\x63");($external{"\x76\x6e\x63"}=
$NXSessionType::virtualVnc);($NXSessionType::virtualRDP=
"\x76\x69\x72\x74\x75\x61\x6c\x52\x44\x50");($internal{
$NXSessionType::virtualRDP}="\x77\x69\x6e\x64\x6f\x77\x73");($external{
"\x77\x69\x6e\x64\x6f\x77\x73"}=$NXSessionType::virtualRDP);(
$NXSessionType::virtualUnixApplication=
"\x76\x69\x72\x74\x75\x61\x6c\x55\x6e\x69\x78\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e"
);($internal{$NXSessionType::virtualUnixApplication}=
"\x75\x6e\x69\x78\x2d\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e");($external{
"\x75\x6e\x69\x78\x2d\x61\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e"}=
$NXSessionType::virtualUnixApplication);($NXSessionType::customForeignMaster=
"\x63\x75\x73\x74\x6f\x6d\x46\x6f\x72\x65\x69\x67\x6e\x4d\x61\x73\x74\x65\x72");
($internal{$NXSessionType::customForeignMaster}=
"\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65\x2d\x63\x75\x73\x74\x6f\x6d");(
$external{
"\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65\x2d\x63\x75\x73\x74\x6f\x6d"}=
$NXSessionType::customForeignMaster);($NXSessionType::foreignDesktop=
"\x66\x6f\x72\x65\x69\x67\x6e\x44\x65\x73\x6b\x74\x6f\x70");($internal{
$NXSessionType::foreignDesktop}="\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65");
($external{"\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65"}=
$NXSessionType::foreignDesktop);($NXSessionType::foreignAttach=
"\x66\x6f\x72\x65\x69\x67\x6e\x41\x74\x74\x61\x63\x68");($internal{
$NXSessionType::foreignAttach}="\x75\x6e\x69\x78\x2d\x72\x65\x6d\x6f\x74\x65");(
$NXSessionType::virtualAttach=
"\x76\x69\x72\x74\x75\x61\x6c\x41\x74\x74\x61\x63\x68");($internal{
$NXSessionType::virtualAttach}="\x73\x68\x61\x64\x6f\x77");($external{
"\x73\x68\x61\x64\x6f\x77"}=$NXSessionType::virtualAttach);(
$NXSessionType::nxFrameBuffer=
"\x6e\x78\x46\x72\x61\x6d\x65\x42\x75\x66\x66\x65\x72");($internal{
$NXSessionType::nxFrameBuffer}="\x6e\x78\x76\x66\x62");($external{
"\x6e\x78\x76\x66\x62"}=$NXSessionType::nxFrameBuffer);(
$NXSessionType::nxConsole="\x6e\x78\x43\x6f\x6e\x73\x6f\x6c\x65");($internal{
$NXSessionType::nxConsole}="\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65");(
$external{"\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65"}=$NXSessionType::nxConsole)
;($NXSessionType::nxConsoleShadow=
"\x6e\x78\x43\x6f\x6e\x73\x6f\x6c\x65\x53\x68\x61\x64\x6f\x77");($internal{
$NXSessionType::nxConsoleShadow}=
"\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65\x2d\x73\x68\x61\x64\x6f\x77");(
$external{"\x6e\x78\x2d\x63\x6f\x6e\x73\x6f\x6c\x65\x2d\x73\x68\x61\x64\x6f\x77"
}=$NXSessionType::nxConsoleShadow);($NXSessionType::automaticRecording=
"\x72\x65\x63\x6f\x72\x64\x69\x6e\x67");($internal{
$NXSessionType::automaticRecording}="\x73\x68\x61\x64\x6f\x77");(
$NXSessionType::connectionMonitor=
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72");(
$NXSessionType::nodeConnectionMonitor=
"\x6e\x6f\x64\x65\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);($NXSessionType::serverConnectionMonitor=
"\x73\x65\x72\x76\x65\x72\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72"
);($NXSessionType::sessionNegotiate=
"\x73\x65\x73\x73\x69\x6f\x6e\x4e\x65\x67\x6f\x74\x69\x61\x74\x65");($internal{
$NXSessionType::sessionNegotiate}=
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2d\x6f\x6e\x6c\x79");($external{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2d\x6f\x6e\x6c\x79"}=
$NXSessionType::sessionNegotiate);my (%translateFromClient35);(
$translateFromClient35{
"\x73\x68\x61\x64\x6f\x77\x2d\x77\x69\x6e\x64\x6f\x77\x73"}=
$NXSessionType::physicalDesktop);($translateFromClient35{
"\x73\x68\x61\x64\x6f\x77\x2d\x6d\x61\x63"}=$NXSessionType::physicalDesktop);(
$translateFromClient35{"\x58\x31\x31\x2d\x6c\x6f\x63\x61\x6c"}=
$NXSessionType::physicalDesktop);my (%translateToClient35);($translateToClient35
{"\x77\x69\x6e\x64\x6f\x77\x73"}=
"\x73\x68\x61\x64\x6f\x77\x2d\x77\x69\x6e\x64\x6f\x77\x73");(
$translateToClient35{"\x6d\x61\x63"}="\x73\x68\x61\x64\x6f\x77\x2d\x6d\x61\x63")
;($translateToClient35{"\x6c\x69\x6e\x75\x78"}=
"\x58\x31\x31\x2d\x6c\x6f\x63\x61\x6c");($translateToClient35{
"\x73\x6f\x6c\x61\x72\x69\x73"}="\x58\x31\x31\x2d\x6c\x6f\x63\x61\x6c");sub 
isNotVirtual{return ((!isVirtual (shift (@_))));}sub isVirtual{(my $sessionType=
shift (@_));if (((((((((($sessionType eq $NXSessionType::physicalDesktop)or (
$sessionType eq $NXSessionType::physicalAttachDesktop))or ($sessionType eq 
$NXSessionType::virtualAttach))or ($sessionType eq $NXSessionType::foreignAttach
))or ($sessionType eq $NXSessionType::connectionMonitor))or ($sessionType eq 
$NXSessionType::nodeConnectionMonitor))or ($sessionType eq 
$NXSessionType::serverConnectionMonitor))or ($sessionType eq 
$NXSessionType::foreignDesktop))or ($sessionType eq 
$NXSessionType::nxConsoleShadow))){return ((0x1e08+ 1990-0x25ce));}return (
(0x014d+ 4466-0x12be));}sub isNotPhysical{return ((!isPhysical (shift (@_))));}
sub isPhysical{(my $sessionType=shift (@_));if (($sessionType eq 
$NXSessionType::physicalDesktop)){return ((0x0bbc+ 990-0x0f99));}return (
(0x193a+ 2859-0x2465));}sub getForeignAttach{return (
$NXSessionType::foreignAttach);}sub isForeignAttach{(my $sessionType=shift (@_))
;if (($sessionType eq $NXSessionType::foreignAttach)){return (
(0x0cf0+ 979-0x10c2));}return ((0x0df3+ 5112-0x21eb));}sub isNotForeignAttach{
return ((!isForeignAttach (shift (@_))));}sub isForeignMaster{(my $sessionType=
shift (@_));if ((($sessionType eq $NXSessionType::customForeignMaster)or (
$sessionType eq $NXSessionType::foreignDesktop))){return ((0x0020+ 2326-0x0935))
;}return ((0x1878+ 2111-0x20b7));}sub isForeignDesktop{(my $sessionType=shift (
@_));if (($sessionType eq $NXSessionType::foreignDesktop)){return (
(0x13f5+ 406-0x158a));}return ((0x1d41+ 1938-0x24d3));}sub isCustomForeignMaster
{(my $sessionType=shift (@_));if (($sessionType eq 
$NXSessionType::customForeignMaster)){return ((0x0f2a+ 4957-0x2286));}return (
(0x16ed+ 2006-0x1ec3));}sub isNotForeignMaster{return ((!isForeignMaster (shift 
(@_))));}sub isVirtualAttach{(my $sessionType=shift (@_));if (((($sessionType eq
 $NXSessionType::virtualAttach)or ($sessionType eq $NXSessionType::foreignAttach
))or ($sessionType eq $NXSessionType::nxConsoleShadow))){return (
(0x18f9+ 302-0x1a26));}return ((0x0b62+ 1145-0x0fdb));}sub isNotPhysicalAttach{
return ((!isPhysicalAttach (shift (@_))));}sub getTypeForOptionsFile{(my $type=
shift (@_));if (($type eq $NXSessionType::virtualUnixApplication)){return (
"\x64\x65\x73\x6b\x74\x6f\x70");}(my $tmp=$internal{$type});($tmp=~ s/unix-// );
($tmp=~ s/xsession-.*/xsession-local/ );return ($tmp);}sub isPhysicalAttach{(my $sessionType
=shift (@_));if ((($sessionType eq $NXSessionType::physicalAttachDesktop)or (
$sessionType eq $NXSessionType::foreignAttach))){return ((0x0a1f+ 6749-0x247b));
}return ((0x1e47+ 249-0x1f40));}sub typeNotExist{return ((!typeExist (shift (@_)
)));}sub typeExist{(my $sessionType=shift (@_));if (defined ($internal{
$sessionType})){return ((0x0f8b+ 3412-0x1cde));}return ((0x1ac3+ 969-0x1e8c));}
sub translateToClient{(my $type=shift (@_));(my $platform=shift (@_));
Logger::debug ((((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x74\x6f\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20\x69\x73\x3a\x20"
.$type)."\x2c").$platform));my ($sessionType);if (((
$GLOBAL::CLIENT_MAJOR_VERSION lt (0x1699+ 2925-0x2202))or (((
$GLOBAL::CLIENT_MAJOR_VERSION eq (0x1207+ 3025-0x1dd4))and (
$GLOBAL::CLIENT_MINOR_VERSION eq (0x14a5+ 2049-0x1ca6)))and (
$GLOBAL::CLIENT_PATCH_VERSION lt (0x183a+ 3334-0x2485))))){if (
Common::NXDistro::isLinux ($platform)){($platform="\x6c\x69\x6e\x75\x78");}if ((
$type eq $NXSessionType::physicalDesktop)){($sessionType=$translateToClient35{
$platform});}else{if ((not (defined ($internal{$type})))){
__setInternalAndExternalForFoundXSessions ($type);}($sessionType=$internal{$type
});}}else{if ((not (defined ($internal{$type})))){
__setInternalAndExternalForFoundXSessions ($type);}($sessionType=$internal{$type
});}Logger::debug (((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x72\x65\x73\x75\x6c\x74\x20\x69\x73\x3a\x20\x5b"
.$sessionType)."\x5d"));return ($sessionType);}sub translateFromClient{(my $type
=shift (@_));if ((($GLOBAL::CLIENT_MAJOR_VERSION lt (0x0364+ 6859-0x1e2b))or (((
$GLOBAL::CLIENT_MAJOR_VERSION eq (0x1338+  84-0x1388))and (
$GLOBAL::CLIENT_MINOR_VERSION eq (0x00f8+ 7572-0x1e8c)))and (
$GLOBAL::CLIENT_PATCH_VERSION lt (0x16d6+ 3301-0x2300))))){return (
__translateFromClient35 ($type));}else{return (__translateFromClient4 ($type));}
}sub __translateFromClient35{(my $type=shift (@_));Logger::debug2 (((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x5b".$type).
"\x5d\x20\x74\x6f\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20\x66\x6f\x72\x20\x33\x2e\x35\x20\x63\x6c\x69\x65\x6e\x74\x2e"
));(my $sessionType=$translateFromClient35{$type});if (($sessionType eq (""))){(
$sessionType=$external{$type});}if (($sessionType eq (""))){Logger::debug2 (((((
"\x5f\x5f\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x46\x72\x6f\x6d\x43\x6c\x69\x65\x6e\x74\x33\x35\x20\x6e\x6f\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20"
.$type)."\x20\x5b").$sessionType)."\x5d"));($sessionType=$type);}else{
Logger::debug2 (((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x72\x65\x73\x75\x6c\x74\x20\x69\x73\x3a\x20\x5b"
.$sessionType)."\x5d"));}return ($sessionType);}sub __translateFromClient4{(my $type
=shift (@_));my ($sessionType);Logger::debug2 ((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x74\x6f\x20\x74\x72\x61\x6e\x73\x6c\x61\x74\x65\x20\x69\x73\x3a\x20"
.$type));if (typeExist ($type)){Logger::debug2 (((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x72\x65\x73\x75\x6c\x74\x20\x69\x73\x3a\x20\x5b"
.$type)."\x5d"));return ($type);}if (($type eq $internal{
$NXSessionType::physicalDesktop})){($sessionType=
$NXSessionType::physicalAttachDesktop);}elsif (($type eq $internal{
$NXSessionType::foreignDesktop})){($sessionType=$NXSessionType::foreignAttach);}
else{($sessionType=$external{$type});}if ((($sessionType eq (""))and ($type=~ /^xsession-/ )
)){getXsessionTypes ();($sessionType=$external{$type});}if (($sessionType eq 
(""))){Logger::debug2 (("\x4e\x6f\x20\x74\x79\x70\x65\x20\x66\x6f\x72\x20\x3a".
$type));($sessionType=$type);}else{Logger::debug2 (((
"\x54\x72\x61\x6e\x73\x6c\x61\x74\x65\x64\x20\x72\x65\x73\x75\x6c\x74\x20\x69\x73\x3a\x20\x5b"
.$sessionType)."\x5d"));}return ($sessionType);}sub convertToInternal{(my $externalType
=shift (@_));if (typeExist ($externalType)){return ($externalType);}if ((
$externalType ne $external{$NXSessionType::physicalDesktop})){if (((
$externalType=~ /^xsession-/ )and (not (defined ($external{$externalType}))))){
getXsessionTypes ();}return ($external{$externalType});}(my $internalType=
$externalType);return ($internalType);}sub convertListToInternal{(my $list=shift
 (@_));(my (@sessionsArray)=split ( /,/ ,$list,(0x01c5+ 6241-0x1a26)));(my $sessions
=(""));foreach my $session (@sessionsArray){($sessions.=(convertToInternal (
$session)."\x2c"));}($sessions=~ s/,$// );return ($sessions);}sub 
convertToExternal{(my $internalType=shift (@_));if ((not (defined ($internal{
$internalType})))){__setInternalAndExternalForFoundXSessions ($internalType);}
return ($internal{$internalType});}sub convertListToExternal{(my $list=shift (@_
));(my (@sessionsArray)=split ( /,/ ,$list,(0x10c4+ 4695-0x231b)));(my $sessions
=(""));foreach my $session (@sessionsArray){($sessions.=(convertToExternal (
$session)."\x2c"));}($sessions=~ s/,$// );return ($sessions);}sub 
convertExternalList{(my $externalList=shift (@_));Logger::debug2 (((
"\x4c\x69\x73\x74\x20\x74\x6f\x20\x63\x6f\x6e\x76\x65\x72\x74\x20\x69\x73\x3a\x20\x5b"
.$externalList)."\x5d"));my ($internalList);(my (@types)=split ( /,/ ,
$externalList,(0x08e0+ 2610-0x1312)));foreach my $type (@types){my ($sessionType
);if (((($type eq "\x73\x68\x61\x64\x6f\x77\x2d\x77\x69\x6e\x64\x6f\x77\x73")or 
($type eq "\x73\x68\x61\x64\x6f\x77\x2d\x6d\x61\x63"))or ($type eq 
"\x58\x31\x31\x2d\x6c\x6f\x63\x61\x6c"))){($sessionType=
$NXSessionType::physicalDesktop);}else{($sessionType=$external{$type});}if ((
$internalList ne (""))){($internalList.="\x2c");}($internalList.=$sessionType);}
Logger::debug2 (((
"\x43\x6f\x6e\x76\x65\x72\x74\x65\x64\x20\x69\x6e\x74\x65\x72\x6e\x61\x6c\x20\x6c\x69\x73\x74\x20\x69\x73\x3a\x20\x5b"
.$internalList)."\x5d"));return ($internalList);}sub isMirror{(my $sessionType=
shift (@_));if (($sessionType eq $NXSessionType::physicalAttachDesktop)){return 
((0x025f+ 2712-0x0cf6));}return ((0x04d1+ 3788-0x139d));}sub isNotAttach{return 
((!isAttach (shift (@_))));}sub isAttach{(my $sessionType=shift (@_));if (((((
$sessionType eq $NXSessionType::physicalAttachDesktop)or ($sessionType eq 
$NXSessionType::virtualAttach))or ($sessionType eq $NXSessionType::foreignAttach
))or ($sessionType eq $NXSessionType::nxConsoleShadow))){return (
(0x00d7+ 7766-0x1f2c));}return ((0x18dc+ 2858-0x2406));}sub isVirtualDefault{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualDefault)){return (
(0x00a7+ 6764-0x1b12));}return ((0x07ab+ 4360-0x18b3));}sub getVirtualDefault{
return ($NXSessionType::virtualDefault);}sub isUnixDefault{(my $sessionType=
shift (@_));if (($sessionType eq $NXSessionType::virtualApplicationDefault)){
return ((0x0ec8+ 1659-0x1542));}return ((0x0df6+ 5676-0x2422));}sub isUnixGnome{
(my $sessionType=shift (@_));if (($sessionType eq $NXSessionType::virtualGnome))
{return ((0x0a15+ 5099-0x1dff));}return ((0x16bf+ 233-0x17a8));}sub isUnixXdm{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualXdm)){return (
(0x14b0+ 3467-0x223a));}return ((0x1c51+ 2218-0x24fb));}sub isUnixApplication{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualUnixApplication)){
return ((0x0585+ 5757-0x1c01));}return ((0x11c7+ 1610-0x1811));}sub isUnixKDE{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualKde)){return (
(0x0169+ 7640-0x1f40));}return ((0x1486+ 4164-0x24ca));}sub isUnixCde{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualCde)){return (
(0x16e8+ 4075-0x26d2));}return ((0x0dca+ 1248-0x12aa));}sub isUnixConsole{(my $sessionType
=shift (@_));if (($sessionType eq $NXSessionType::virtualConsole)){return (
(0x1583+ 443-0x173d));}return ((0x1b83+ 508-0x1d7f));}sub isUnixDesktop{(my $sessionType
=shift (@_));if ((($sessionType eq $NXSessionType::virtualDesktop)or (
$sessionType eq $NXSessionType::foreign))){return ((0x0114+  30-0x0131));}return
 ((0x06a4+ 5974-0x1dfa));}sub isSessionSomeShadow{(my $sessionType=shift (@_));
if (($sessionType=~ /shadow.*/ )){return ((0x036d+ 1668-0x09f0));}return (
(0x1a03+ 1942-0x2199));}sub isUnixAny{(my $sessionType=shift (@_));if ((((((((((
$sessionType eq $NXSessionType::virtualGnome)or ($sessionType eq 
$NXSessionType::virtualKde))or ($sessionType eq $NXSessionType::virtualCde))or (
$sessionType eq $NXSessionType::virtualConsole))or ($sessionType eq 
$NXSessionType::virtualApplicationDefault))or ($sessionType eq 
$NXSessionType::virtualDesktop))or ($sessionType eq $NXSessionType::virtualXdm))
or ($sessionType eq $NXSessionType::virtualUnixApplication))or ($sessionType eq 
$NXSessionType::nxFrameBuffer))){return ((0x04c7+ 7386-0x21a0));}return (
(0x0f96+ 2475-0x1941));}sub isUnixVirtual{(my $sessionType=shift (@_));if ((((((
(($sessionType eq $NXSessionType::virtualGnome)or ($sessionType eq 
$NXSessionType::virtualKde))or ($sessionType eq $NXSessionType::virtualCde))or (
$sessionType eq $NXSessionType::virtualConsole))or ($sessionType eq 
$NXSessionType::virtualApplicationDefault))or ($sessionType eq 
$NXSessionType::virtualDesktop))or ($sessionType eq $NXSessionType::virtualXdm))
){return ((0x0027+ 1699-0x06c9));}return ((0x0a99+ 3818-0x1983));}sub 
isVirtualRDP{(my $sessionType=shift (@_));if (($sessionType eq 
$NXSessionType::virtualRDP)){return ((0x1658+ 401-0x17e8));}return (
(0x17ff+ 2577-0x2210));}sub isVirtualRDPOrVnc{(my $sessionType=shift (@_));if ((
($sessionType eq $NXSessionType::virtualRDP)or ($sessionType eq 
$NXSessionType::virtualVnc))){return ((0x15ff+ 646-0x1884));}return (
(0x0183+ 5758-0x1801));}sub isVirtualVms{(my $sessionType=shift (@_));if ((
$sessionType eq $NXSessionType::virtualVms)){return ((0x1f5c+ 654-0x21e9));}
return ((0x00ad+ 6736-0x1afd));}sub isVirtualVnc{(my $sessionType=shift (@_));if
 (($sessionType eq $NXSessionType::virtualVnc)){return ((0x14a4+ 808-0x17cb));}
return ((0x02f0+ 6957-0x1e1d));}sub isConnectionMonitor{(my $sessionType=shift (
@_));if (($sessionType eq $NXSessionType::connectionMonitor)){return (
(0x03ea+ 2561-0x0dea));}return ((0x0e0d+ 4598-0x2003));}sub 
isNodeConnectionMonitor{(my $sessionType=shift (@_));if (($sessionType eq 
$NXSessionType::nodeConnectionMonitor)){return ((0x07a6+ 4536-0x195d));}return (
(0x0cc5+ 3269-0x198a));}sub isServerConnectionMonitor{(my $sessionType=shift (@_
));if (($sessionType eq $NXSessionType::serverConnectionMonitor)){return (
(0x211a+ 1229-0x25e6));}return ((0x0532+ 8561-0x26a3));}sub getPhysicalDesktop{
return ($NXSessionType::physicalDesktop);}sub getForeignDesktop{return (
$NXSessionType::foreignDesktop);}sub getCustomForeignMaster{return (
$NXSessionType::customForeignMaster);}sub isShadowable{(my $sessionType=shift (
@_));if ((((isPhysical ($sessionType)or isVirtual ($sessionType))or isVirtualVms
 ($sessionType))or isForeignDesktop ($sessionType))){return (
(0x01ec+ 4798-0x14a9));}return ((0x00a0+ 8984-0x23b8));}sub isReconnectable{(my $sessionType
=shift (@_));if (isVirtual ($sessionType)){return ((0x04c7+ 3153-0x1117));}
return ((0x2354+ 884-0x26c8));}sub getSessionVms{return (
$NXSessionType::virtualVms);}sub getVirtualAttach{return (
$NXSessionType::virtualAttach);}sub getPhysicalAttach{return (
$NXSessionType::physicalAttachDesktop);}sub getUnixDefault{return (
$NXSessionType::virtualApplicationDefault);}sub getUnixDesktop{return (
$NXSessionType::virtualDesktop);}sub getConnectionMonitor{return (
$NXSessionType::connectionMonitor);}sub getNodeConnectionMonitor{return (
$NXSessionType::nodeConnectionMonitor);}sub getServerConnectionMonitor{return (
$NXSessionType::serverConnectionMonitor);}sub getSessionNegotiate{return (
$NXSessionType::sessionNegotiate);}sub getAllTypes{my ($allTypes);while ((my (
$key,$value)=each (%external))){($allTypes.=(convertToInternal ($key)."\x2c"));}
chop ($allTypes);return ($allTypes);}sub getAllExternalTypes{my ($allTypes);
while ((my ($key,$value)=each (%external))){($allTypes.=($key."\x2c"));}chop (
$allTypes);return ($allTypes);}sub getDefaultTypesForLocalNode{(my $availableSessions
=(""));($availableSessions.=((($NXSessionType::virtualApplicationDefault."\x2c")
.$NXSessionType::virtualUnixApplication)."\x2c"));($availableSessions.=((
$NXSessionType::virtualDesktop."\x2c").$NXSessionType::virtualConsole));return (
$availableSessions);}sub isRootless{if ((not (defined ($GLOBAL::parameters{
"\x72\x6f\x6f\x74\x6c\x65\x73\x73"})))){return ((0x0232+ 429-0x03df));}else{
return ($GLOBAL::parameters{"\x72\x6f\x6f\x74\x6c\x65\x73\x73"});}}sub 
sessionTypeTerminateOnSIGCHLD{(my $sessionType=shift (@_));if ((((((((((
$sessionType eq $NXSessionType::virtualGnome)or ($sessionType eq 
$NXSessionType::virtualVms))or ($sessionType eq $NXSessionType::virtualVnc))or (
$sessionType eq $NXSessionType::virtualRDP))or ($sessionType eq 
$NXSessionType::virtualKde))or ($sessionType eq $NXSessionType::virtualCde))or (
$sessionType eq $NXSessionType::virtualDefault))or ($sessionType eq 
$NXSessionType::nxFrameBuffer))or ($sessionType=~ /^xsession-/ ))){return (
(0x0d04+ 4260-0x1da7));}if (($sessionType eq 
$NXSessionType::virtualApplicationDefault)){if ((not (isRootless ()))){return (
(0x049f+ 6726-0x1ee4));}}return ((0x00dd+ 7956-0x1ff1));}sub getNXFrameBuffer{
return ($NXSessionType::nxFrameBuffer);}sub isNxFrameBuffer{(my $sessionType=
shift (@_));if (($sessionType eq $NXSessionType::nxFrameBuffer)){return (
(0x0526+ 7816-0x23ad));}return ((0x06b2+ 865-0x0a13));}sub 
isTypeWhichStoreApplicationPid{(my $sessionType=shift (@_));if ((((((
$sessionType eq $NXSessionType::physicalDesktop)or ($sessionType eq 
$NXSessionType::physicalAttachDesktop))or ($sessionType eq 
$NXSessionType::virtualXdm))or ($sessionType eq $NXSessionType::virtualAttach))
or ($sessionType eq $NXSessionType::nxConsole))){return ((0x0725+ 710-0x09eb));}
return ((0x13d1+ 946-0x1782));}sub isSessionTypeNotCalculatedForLBScript{(my $sessionType
=shift (@_));if (((((((($sessionType eq $NXSessionType::connectionMonitor)or (
$sessionType eq $NXSessionType::nodeConnectionMonitor))or ($sessionType eq 
$NXSessionType::serverConnectionMonitor))or ($sessionType eq 
$NXSessionType::physicalDesktop))or ($sessionType eq 
$NXSessionType::foreignDesktop))or ($sessionType eq 
$NXSessionType::foreignAttach))or ($sessionType eq 
$NXSessionType::customForeignMaster))){return ((0x0af4+ 1204-0x0fa7));}return (
(0x01a2+ 1799-0x08a9));}sub isVirtualFamily{(my $sessionType=shift (@_));if ((
$sessionType eq $NXSessionType::virtualAttach)){return ((0x110c+ 3976-0x2093));}
if (isVirtual ($sessionType)){return ((0x0e41+ 2212-0x16e4));}return (
(0x0971+ 3476-0x1705));}sub isNxConsoleFamily{(my $sessionType=shift (@_));if ((
($sessionType eq $NXSessionType::nxConsole)or ($sessionType eq 
$NXSessionType::nxConsoleShadow))){return ((0x068f+ 1299-0x0ba1));}return (
(0x0c36+ 316-0x0d72));}sub isNxConsoleShadow{(my $sessionType=shift (@_));if ((
$sessionType eq $NXSessionType::nxConsoleShadow)){return ((0x18ad+ 1728-0x1f6c))
;}return ((0x0569+ 922-0x0903));}sub isNxConsole{(my $sessionType=shift (@_));if
 (($sessionType eq $NXSessionType::nxConsole)){return ((0x1a16+ 1088-0x1e55));}
return ((0x1459+ 2740-0x1f0d));}sub getNxConsoleShadow{return ($internal{
$NXSessionType::nxConsoleShadow});}sub getAutomaticRecording{return (
$NXSessionType::automaticRecording);}sub isAutomaticRecording{(my $sessionType=
shift (@_));if (($sessionType eq $NXSessionType::automaticRecording)){return (
(0x0596+ 8031-0x24f4));}return ((0x07f4+ 1055-0x0c13));}sub getXsessionTypes{
Logger::debug (
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x44\x65\x73\x6b\x74\x6f\x70\x73\x20\x73\x74\x61\x72\x74\x2e"
);(my $typesString=libnxh::NXGetDesktops ());Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x47\x65\x74\x44\x65\x73\x6b\x74\x6f\x70\x73\x20\x72\x65\x74\x75\x72\x6e\x20\x74\x79\x70\x65\x73\x3a\x20"
.$typesString)."\x2e"));(my (@types)=split ( /,/ ,$typesString,
(0x01ec+ 6819-0x1c8f)));foreach my $type (@types){
__setInternalAndExternalForFoundXSessions ($type);}return ($typesString);}sub 
__setInternalAndExternalForFoundXSessions{(my $type=shift (@_));(my $external=lc
 ($type));($internal{$type}=$external);($external{$external}=$type);}sub 
isSystemXsession{(my $sessionType=shift (@_));if (($sessionType=~ /^xsession-/ )
){return ((0x0427+ 3498-0x11d0));}return ((0x0d34+ 1770-0x141e));}return (
(0x06dd+ 1287-0x0be3));
