############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXSessionManager::BEGIN{package NXSessionManager;no warnings;require 
NXSession2;do{"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x32"->import};}package 
NXSessionManager;no warnings;($sessionCloseStarted=(0x0ab4+ 3063-0x16ab));sub 
listConnectedSessions{(my (@param)=@_);($sessionId=$param[(0x061d+ 2758-0x10e2)]
);($sessionId=~ s/^.*=// );if (($sessionId=~ /(\w{32})$/ )){if ((not (
NXSession2::existSession ($sessionId)))){NXMsg::error (
"\x65\x4e\x6f\x4d\x61\x74\x63\x68\x46\x6f\x72\x53\x65\x73\x73\x69\x6f\x6e",
"\x6d\x61\x69\x6e",$sessionId);return ((0x13dd+ 1409-0x195e));}(my (
@connectedSessions)=NXSession2::listConnectedSessions ($sessionId));
main::nxwrite (main::nxgetSTDOUT (),
"\x0a\x53\x65\x73\x73\x69\x6f\x6e\x73\x49\x64\x0a");main::nxwrite (
main::nxgetSTDOUT (),(("\x2d" x (0x0502+ 1907-0x0c55))."\x0a"));my ($sessionId);
foreach my $sessionId (@connectedSessions){($sessionId=sprintf (
"\x25\x2d\x33\x32\x73",$sessionId));main::nxwrite (main::nxgetSTDOUT (),(
$sessionId."\x0a"));}Logger::debug (
"\x52\x65\x70\x6f\x72\x74\x65\x64\x20\x64\x61\x74\x61\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x2e"
);main::nxwrite (main::nxgetSTDOUT (),"\x0a");return ((0x0555+ 3454-0x12d2));}
else{if (($sessionId eq (""))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x6c\x65\x63\x74\x53\x65\x73\x73\x69\x6f\x6e\x4d\x69\x73\x73\x69\x6e\x67\x41\x72\x67"
,"\x6d\x61\x69\x6e");}else{NXMsg::error (
"\x65\x4e\x6f\x4d\x61\x74\x63\x68\x46\x6f\x72\x53\x65\x73\x73\x69\x6f\x6e",
"\x6d\x61\x69\x6e",$sessionId);}}return ((0x0d4a+ 4581-0x1f2f));}sub 
listConnectedSessionUsers{(my (@param)=@_);(my $message=(""));if ((
Server::isClientNxwebclient ()or Server::isClientNxclient ())){($sessionId=
$param[(0x08b4+ 4305-0x1985)]);}else{($sessionId=$param[(0x047a+ 962-0x083b)]);}
($sessionId=~ s/^.*=// );if (($sessionId=~ /(\w{32})$/ )){if ((not (
NXSession2::existSession ($sessionId)))){NXMsg::error (
"\x65\x4e\x6f\x4d\x61\x74\x63\x68\x46\x6f\x72\x53\x65\x73\x73\x69\x6f\x6e",
"\x6d\x61\x69\x6e",$sessionId);return ((0x1c5f+ 1401-0x21d8));}(my (
@connectedSessions)=NXSession2::listConnectedSessions ($sessionId));
main::nxwrite (main::nxgetSTDOUT (),
"\x55\x73\x65\x72\x6e\x61\x6d\x65\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a"
);main::nxwrite (main::nxgetSTDOUT (),(((("\x2d" x (0x0443+ 2948-0x0fa6))."\x20"
).("\x2d" x (0x0b43+ 786-0x0e35)))."\x0a"));foreach my $session (
@connectedSessions){($session=sprintf ("\x25\x2d\x33\x32\x73",$session));(my $username
=NXSession2::getUsernameBySessionId ($session));($username=sprintf (
"\x25\x2d\x33\x33\x73",$username));($message=((($username."\x20").$session).
"\x0a"));main::nxwrite (main::nxgetSTDOUT (),$message);}if ((
Server::isClientNxwebclient ()or Server::isClientNxclient ())){Logger::debug (((
"\x52\x65\x70\x6f\x72\x74\x65\x64\x20\x64\x61\x74\x61\x20\x74\x6f\x20\x63\x6c\x69\x65\x6e\x74\x5b"
.$message)."\x5d\x2e"));}}else{if (($sessionId eq (""))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x6c\x65\x63\x74\x53\x65\x73\x73\x69\x6f\x6e\x4d\x69\x73\x73\x69\x6e\x67\x41\x72\x67"
,"\x6d\x61\x69\x6e");}else{NXMsg::error (
"\x65\x4e\x6f\x4d\x61\x74\x63\x68\x46\x6f\x72\x53\x65\x73\x73\x69\x6f\x6e",
"\x6d\x61\x69\x6e",$sessionId);}}return ((0x05cb+ 7693-0x23d8));}sub 
considerSessionReconnect{if (((Common::NXSessionType::isVirtualAttach (
NXSessionParameters::getSessionType ())and NXSessionParameters::isReconnectable 
())and NXSessionParameters::isRestoreSession ())){return ((0x0ebf+ 646-0x1144));
}else{return ((0x18c2+ 3093-0x24d7));}}sub considerBeforeSessionDisconnect{if ((
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ())and (
not (Server::isMasterGoingToShutdown ())))){NXEvent::beforeSessionDisconnect ();
}}sub considerAfterSessionDisconnect{if ((Common::NXSessionType::isVirtual (
NXSessionParameters::getSessionType ())and (not (Server::isMasterGoingToShutdown
 ())))){NXEvent::afterSessionDisconnect ();}}sub considerBeforeSessionStart{if (
(NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::beforeSessionStart ();}}sub 
considerBeforeSessionClose{if ((((isNotSessionCloseStarted ()and 
NXSessionParameters::getSessionType ())and Common::NXSessionType::isVirtual (
NXSessionParameters::getSessionType ()))or Common::NXSessionType::isAttach (
NXSessionParameters::getSessionType ()))){if ((
NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::beforeSessionClose ();}}}sub
 considerAfterSessionClose{if (((NXSessionParameters::getSessionType ()and 
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ()))or 
Common::NXSessionType::isAttach (NXSessionParameters::getSessionType ()))){if ((
NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::afterSessionClose ();}}}sub 
considerBeforeSessionFailure{if (((NXSessionParameters::getSessionType ()and 
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ()))or 
Common::NXSessionType::isAttach (NXSessionParameters::getSessionType ()))){if ((
NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::beforeSessionFailure ();}}}
sub considerAfterSessionFailure{if (((NXSessionParameters::getSessionType ()and 
Common::NXSessionType::isVirtual (NXSessionParameters::getSessionType ()))or 
Common::NXSessionType::isAttach (NXSessionParameters::getSessionType ()))){if ((
NXSessionParameters::isNotRestoreSession ()and 
NXSessionParameters::isNotFirstAttach ())){NXEvent::afterSessionFailure ();}}}
sub setSessionCloseStarted{($NXSession::sessionCloseStarted=(0x0315+ 376-0x048c)
);}sub isSessionCloseStarted{return ($NXSession::sessionCloseStarted);}sub 
isNotSessionCloseStarted{return ((!isSessionCloseStarted ()));}return (
(0x0bbc+ 5562-0x2175));
