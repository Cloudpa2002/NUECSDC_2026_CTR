############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXFirewall::BEGIN{package NXFirewall;no warnings;require NXTools;do{
"\x4e\x58\x54\x6f\x6f\x6c\x73"->import};}package NXFirewall;no warnings;(
$checkUfwCommand=(-(0x080c+ 589-0x0a58)));($oldUfwCommand=(0x0561+ 5347-0x1a44))
;sub addFirewallRules{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x73\x20\x74\x6f\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2e"
);if (($GLOBAL::EnableFirewallConfiguration==(0x0646+ 3874-0x1568))){
Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e\x63\x66\x67\x20\x66\x69\x6c\x65\x2e"
);return ((0x045d+ 5521-0x19ee));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x10da+ 675-0x137d))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x73\x2e"
);return ((0x14bc+ 3375-0x21eb));}(my $tcpPorts=(""));(my $udpPorts=(""));if ((
NXSystemDaemons::isNxdEnabled ()and NXSystemDaemons::isNxdStartupKeyEnabled ()))
{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x4e\x58\x44\x20\x72\x75\x6c\x65\x73\x2e"
);($tcpPorts.=(NXNodeInfo::getNxdPort ()."\x2c"));($udpPorts.=(
NXNodeInfo::getNxdUDPPort ()."\x2c"));}else{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x4e\x6f\x74\x20\x61\x64\x64\x69\x6e\x67\x20\x4e\x58\x44\x20\x72\x75\x6c\x65\x2e"
);}if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){(my $httpsPort=
NXTools::getNXHtdPort ());Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x48\x54\x54\x50\x53\x20\x72\x75\x6c\x65\x2e"
);($tcpPorts.=($httpsPort."\x2c"));}else{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x4e\x6f\x74\x20\x61\x64\x64\x69\x6e\x67\x20\x4e\x58\x48\x54\x44\x20\x72\x75\x6c\x65\x2e"
);}if (NXLocate::isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x41\x64\x64\x69\x6e\x67\x20\x6d\x44\x4e\x53\x20\x72\x75\x6c\x65\x2e"
);($udpPorts.=($GLOBAL::MSDNPort."\x2c"));(my $returnValue=__addRule ((
\@firewallStatus),$ref_iptablesV6,$GLOBAL::MSDNPort,"\x75\x64\x70"));if ((
$returnValue==(0x0c63+ 4740-0x1ee7))){__saveAddedRule ($GLOBAL::MSDNPort,
"\x75\x64\x70");}}else{Logger::debug (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c\x3a\x20\x4e\x6f\x74\x20\x61\x64\x64\x69\x6e\x67\x20\x6d\x44\x4e\x53\x20\x72\x75\x6c\x65\x2e"
);}if (($tcpPorts ne (""))){($tcpPorts=~ s/,$// );(my $returnValue=__addRule ((
\@firewallStatus),$ref_iptablesV6,$tcpPorts,"\x74\x63\x70"));if (($returnValue==
(0x0a89+ 1440-0x1029))){__saveAddedRule ($tcpPorts,"\x74\x63\x70");}}if ((
$udpPorts ne (""))){($udpPorts=~ s/,$// );(my $returnValue=__addRule ((
\@firewallStatus),$ref_iptablesV6,$udpPorts,"\x75\x64\x70"));if (($returnValue==
(0x108f+ 5722-0x26e9))){__saveAddedRule ($udpPorts,"\x75\x64\x70");}}}sub 
__checkFirewallInstall{if (((Common::NXShellCommands::isApplicationInKnownPath (
"\x69\x70\x74\x61\x62\x6c\x65\x73\x2d\x78\x6d\x6c")or 
Common::NXShellCommands::isApplicationInKnownPath (
"\x69\x70\x74\x61\x62\x6c\x65\x73"))or 
Common::NXShellCommands::isApplicationInKnownPath (
"\x69\x70\x36\x74\x61\x62\x6c\x65\x73"))){return ((0x0990+ 1184-0x0e2f));}else{
return ((0x1f83+ 933-0x2328));}}sub __checkUfw{if (($checkUfwCommand!=(-
(0x0301+ 1139-0x0773)))){return ($checkUfwCommand);}if ((not ((lc (
Common::NXInfo::getDistroInfo ())=~ /ubuntu/ )))){($checkUfwCommand=
(0x00f8+ 3093-0x0d0d));return ((0x0c22+ 2729-0x16cb));}Logger::debug (
"\x53\x65\x74\x20\x27\x75\x66\x77\x27\x20\x61\x73\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e"
);($checkUfwCommand=(0x0f8b+ 2019-0x176d));if ((lc (
Common::NXInfo::getDistroInfo ())=~ /ubuntu 8.04|ubuntu 8.10|ubuntu 9.04/ )){
Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6f\x6c\x64\x20\x27\x75\x66\x77\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e"
);($oldUfwCommand=(0x007c+ 2357-0x09b0));}return ((0x03c6+ 496-0x05b5));}sub 
__checkFirewalldInstall{if (Common::NXShellCommands::isApplicationInKnownPath (
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64")){return (
(0x0a35+ 2337-0x1355));}else{return ((0x11cb+ 4994-0x254d));}}sub 
__getFirewalldStatus{Logger::debug (
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x64\x20\x73\x74\x61\x74\x75\x73\x2e"
);(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ("\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64")
);push (@command,"\x2d\x2d\x7a\x6f\x6e\x65\x3d\x70\x75\x62\x6c\x69\x63");push (
@command,"\x2d\x2d\x6c\x69\x73\x74\x2d\x70\x6f\x72\x74\x73");}else{push (
@command,$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x67\x65\x74\x2e\x73\x68");push
 (@command,"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64",
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64",(0x1682+ 1797-0x1d87));push (
@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x10c8+ 4344-0x21c0))){Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x64\x20\x73\x74\x61\x74\x75\x73\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
.$exit_value)."\x27\x2e").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));return ((0x18ea+ 1470-0x1ea8));}Logger::debug (((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x2d\x2d\x6c\x69\x73\x74\x2d\x70\x6f\x72\x74\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));return (split ( / / ,$cmd_out,(0x1040+ 3432-0x1da8)));}
sub __getFirewallStatus{(my $ref_iptablesV6=shift (@_));if (__checkUfw ()){
return (__getUfw ());}elsif (__checkFirewalldInstall ()){return (
__getFirewalldStatus ());}elsif (__checkFirewallInstall ()){(my (@iptablesV6)=
__getIptablesV6 ("\x49\x4e\x50\x55\x54"));($$ref_iptablesV6=(\@iptablesV6));
return (__getIptables ("\x49\x4e\x50\x55\x54"));}}sub __getUfw{Logger::debug (
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x75\x66\x77\x20\x73\x74\x61\x74\x75\x73\x2e"
);(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ("\x75\x66\x77"));push (@command,
"\x73\x74\x61\x74\x75\x73");if (($oldUfwCommand==(0x1c6f+ 954-0x2028))){push (
@parameters,"\x73\x65\x74\x20\x65\x6e\x76",
"\x50\x41\x54\x48\x3d\x2f\x73\x62\x69\x6e");}}else{push (@command,
$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x67\x65\x74\x2e\x73\x68");push (
@command,"\x75\x66\x77","\x75\x66\x77");if (($oldUfwCommand==
(0x19bc+ 3279-0x268a))){push (@command,(0x0987+ 1325-0x0eb3));}else{push (
@command,(0x0de6+ 319-0x0f25));}push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x0a2a+ 1241-0x0f03))){Logger::warning ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20\x75\x66\x77\x20\x73\x74\x61\x74\x75\x73\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
.$exit_value)."\x27\x2e").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));return ((0x02e2+ 8816-0x2552));}Logger::debug2 (((
"\x55\x66\x77\x20\x73\x74\x61\x74\x75\x73\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));return (split ( /\n/ ,$cmd_out,(0x06df+ 3241-0x1388)));}
sub __getIptablesV6{return (__getIptables (@_,(0x049d+ 5309-0x1959)));}sub 
__getIptables{(my $chain=shift (@_));(my $IPv6=(shift (@_)||
(0x167b+ 2558-0x2079)));(my $name="\x69\x70\x74\x61\x62\x6c\x65\x73");if (($IPv6
==(0x169b+ 3139-0x22dd))){($name="\x69\x70\x36\x74\x61\x62\x6c\x65\x73");}(my (
@command)=());(my (@parameters)=());if (main::effectiveUserIsAdministrator ()){
push (@command,NXTools::getUnixCommandPath ($name));push (@command,"\x2d\x4c",
$chain,"\x2d\x2d\x6c\x69\x6e\x65\x2d\x6e\x75\x6d\x62\x65\x72\x73",
"\x2d\x2d\x6e\x75\x6d\x65\x72\x69\x63");}else{push (@command,
$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x67\x65\x74\x2e\x73\x68");push (
@command,$name,$chain,(0x1b4d+ 1705-0x21f6));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x0aa3+ 6021-0x2228))){Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x65\x63\x6b\x20".$name).
"\x20\x73\x74\x61\x74\x75\x73\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
).$exit_value)."\x27\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));return (undef);}return (split ( /\n/ ,$cmd_out,(0x14aa+ 1737-0x1b73)));}sub 
__checkFirewallStatus{(my ($ref_firewallStatus,$ref_iptablesV6)=@_);if ((
$ref_firewallStatus eq (""))){Logger::error (((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x73\x74\x61\x74\x75\x73\x20\x27".
$ref_firewallStatus).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e"));
return ((0x1b0b+  69-0x1b4f));}Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x73\x74\x61\x74\x75\x73\x3a\x20\x27"
.$$ref_firewallStatus[(0x17c6+ 931-0x1b69)])."\x27\x2e"));if (__checkUfw ()){(
$$ref_firewallStatus[(0x04e0+ 1167-0x096f)]=~ s/^\s+|\s+$//g );if ((((
$$ref_firewallStatus[(0x05bb+ 5464-0x1b13)]=~ /^Status: inactive$/ )or (
$$ref_firewallStatus[(0x15ff+ 2763-0x20ca)]=~ /^Firewall not loaded$/ ))or (
$$ref_firewallStatus[(0x062a+ 7524-0x238e)]=~ /^Status: not loaded$/ ))){return 
((0x0aaf+ 5804-0x215b));}else{return ((0x2395+ 415-0x2533));}}elsif (
__checkFirewalldInstall ()){($$ref_firewallStatus[(0x0d44+ 1477-0x1309)]=~ s/^\s+|\s+$//g )
;if (($$ref_firewallStatus[(0x0622+ 615-0x0889)]=~ /^FirewallD is not running$/ )
){return ((0x03b8+ 8878-0x2666));}else{return ((0x086d+ 6351-0x213b));}}else{(my $number
=__getRuleNr ($ref_firewallStatus));if ((($number==(0x10bd+ 5321-0x2586))and 
defined (@$ref_firewallStatus))){return ((0x0cc7+ 4768-0x1f66));}else{($number=
__getRuleNrIPv6 ($ref_iptablesV6));if ((($number==(0x150d+ 2438-0x1e93))and 
defined ($ref_iptablesV6))){return ((0x0e34+ 6293-0x26c8));}}return ($number);}}
sub __getRuleNrIPv6{return (__getRuleNr (@_,(0x04a1+ 6080-0x1c60)));}sub 
__getRuleNr{(my $ref_firewallStatus=shift (@_));(my $IPv6=(shift (@_)||
(0x112c+ 4056-0x2104)));foreach my $rule (@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g )
;if (($rule=~ /^(\d+)\s+(\w+)\s+(\w+)\s+(.*)$/ )){(my $num=$1);(my $target=$2);(my $prot
=$3);(my $rest=$4);(my (@additionalOptions)=split ( / {1,}/ ,$rest,
(0x09d2+ 6934-0x24e8)));if ((((($target eq "\x52\x45\x4a\x45\x43\x54")and ($prot
 eq "\x61\x6c\x6c"))and ($additionalOptions[(0x1a03+ 2886-0x2546)]eq ("")))or ((
($target eq "\x44\x52\x4f\x50")and ($prot eq "\x61\x6c\x6c"))and (
$additionalOptions[(0x1009+ 5091-0x23e9)]eq (""))))){return ($num);}if (($target
=~ /[a-z]/ )){my (@newChainToCheck);if (($IPv6==(0x23ab+ 606-0x2609))){(
@newChainToCheck=__getIptables ($target));}else{(@newChainToCheck=
__getIptablesV6 ($target));}(my ($number,$chain)=__getRuleNr ((\@newChainToCheck
),$IPv6));if (($number!=(0x03f7+ 4243-0x148a))){return ($num);}}}elsif (($rule=~ /^(\d+)\s+(\w+)\s+(.*)$/ )
){(my $num=$1);(my $prot=$2);(my $rest=$3);(my (@additionalOptions)=split ( / {1,}/ ,
$rest,(0x0645+ 7722-0x246f)));if ((($prot eq "\x61\x6c\x6c")and (
$additionalOptions[(0x0b40+ 1677-0x11ca)]eq ("")))){return ($num);}}}return (
(0x028a+ 7812-0x210e));}sub __addRule{(my $ref_firewallStatus=shift (@_));(my $ref_iptablesV6
=shift (@_));(my $ports=shift (@_));(my $proto=shift (@_));(my $sessionRule=
shift (@_));if (((($ref_firewallStatus eq (""))or ($ports eq ("")))or ($proto eq
 ("")))){Logger::error (((((((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x73\x74\x61\x74\x75\x73\x20\x27".
$ref_firewallStatus)."\x27\x2c\x20\x70\x6f\x72\x74\x73\x20\x27").$ports).
"\x27\x20\x6f\x72\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$proto).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e"));
return ((0x0059+ 2648-0x0ab0));}if (__checkUfw ()){if (__allRulesAreSetUfw (
$ref_firewallStatus,$ports,$proto)){return ((0x15cc+ 4408-0x2703));}}elsif (
__checkFirewalldInstall ()){if (__allRulesAreSetFirewalld ($ref_firewallStatus,
$ports,$proto)){return ((0x1777+ 3571-0x2569));}}else{if (__ruleIsSetIptables (
$ref_firewallStatus,$ports,$proto)){if (__ruleIsSetIptables ($ref_iptablesV6,
$ports,$proto)){return ((0x0da5+ 6456-0x26dc));}}}if (($sessionRule ne 
"\x73\x65\x73\x73\x69\x6f\x6e\x52\x75\x6c\x65")){if (__isRuleInFile ($ports,
$proto)){__removeRuleFromFile ($ports,$proto);}}if (__checkUfw ()){return (
__addRuleByUfw ($ports,$proto));}elsif (__checkFirewalldInstall ()){return (
__addRuleByFirewalld ($ports,$proto));}elsif (__checkFirewallInstall ()){(my $return
=__addRuleByIptables ($ref_firewallStatus,$ports,$proto));(my $returnV6=
__addRuleByIptablesV6 ($ref_iptablesV6,$ports,$proto));if (($return and 
$returnV6)){return ((0x0171+ 2106-0x09aa));}return ((0x093d+ 7261-0x259a));}}sub
 __ruleIsNotSetFirewalld{(my $ref_firewallStatus=shift (@_));(my $ports=shift (
@_));(my $proto=shift (@_));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x2c\x20\x27").$proto)."\x27\x2e"));(my (@portsTab)=split ( /,/ ,
$ports,(0x125c+ 648-0x14e4)));foreach my $port (@portsTab){foreach my $rule (
@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g );if (($rule eq (($port."\x2f").
$proto))){Logger::debug (((((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));return 
((0x0cfa+ 4290-0x1dbc));}}}Logger::debug (((((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x27").$proto).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));return (
(0x04c6+ 7459-0x21e8));}sub __allRulesAreSetFirewalld{(my $ref_firewallStatus=
shift (@_));(my $ports=shift (@_));(my $proto=shift (@_));(my (@portsTab)=split 
( /,/ ,$ports,(0x0a0a+ 2030-0x11f8)));(my $portsCount=@portsTab);(my $isRuleSet=
(0x05f5+ 3488-0x1395));foreach my $port (@portsTab){foreach my $rule (
@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g );if (($rule eq (""))){next;}
Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$port)."\x27\x2c\x20\x27").$proto)."\x27\x2e"));if (($rule eq (($port."\x2f").
$proto))){Logger::debug (((((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));(++
$isRuleSet);last;}}}Logger::debug (((((
"\x46\x6f\x75\x6e\x64\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20"
.$isRuleSet)."\x2f").$portsCount)."\x2e"));if (($isRuleSet>=$portsCount)){
Logger::debug (((
"\x41\x6c\x6c\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x61\x72\x65\x20\x73\x65\x74\x2e"));return (
(0x0d42+ 6054-0x24e7));}Logger::debug (((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));return (
(0x1355+ 3765-0x220a));}sub __ruleIsSetFirewalld{(my $ref_firewallStatus=shift (
@_));(my $ports=shift (@_));(my $proto=shift (@_));return ((!
__ruleIsNotSetFirewalld ($ref_firewallStatus,$ports,$proto)));}sub 
__allRulesAreSetUfw{(my $ref_firewallStatus=shift (@_));(my $ports=shift (@_));(my $proto
=shift (@_));(my (@portsTab)=split ( /,/ ,$ports,(0x00ca+ 3077-0x0ccf)));(my $portsCount
=@portsTab);(my $isRuleSet=(0x005b+ 4466-0x11cd));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x2c\x20\x27").$proto)."\x27\x2e"));foreach my $port (@portsTab){
foreach my $rule (@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g );if (($rule eq 
(""))){next;}Logger::debug2 (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x3a\x20\x27"
.$rule)."\x27\x2e"));if ((($rule=~ /^([\w,]+)[\/:](\w+) \(v6\)\s+(\w+)\s+(.*)$/ )
or ($rule=~ /^([\w,]+)[\/:](\w+)\s+(\w+)\s+(.*)$/ ))){(my $f_port=$1);(my $f_proto
=$2);(my $f_allow=$3);if ((($f_proto ne $proto)or ($f_allow ne 
"\x41\x4c\x4c\x4f\x57"))){next;}if (($f_port eq $port)){Logger::debug (((((
"\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27".
$port)."\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));(++
$isRuleSet);last;}}}}if (($portsCount>(0x1289+ 4683-0x24d3))){Logger::debug ((((
(
"\x46\x6f\x75\x6e\x64\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20"
.$isRuleSet)."\x2f").$portsCount)."\x2e"));}if (($isRuleSet>=$portsCount)){if ((
$portsCount>(0x1585+ 892-0x1900))){Logger::debug (((
"\x41\x6c\x6c\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x73\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x61\x72\x65\x20\x73\x65\x74\x2e"));}return (
(0x07d3+ 5177-0x1c0b));}Logger::debug (((((
"\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x27").$proto).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));return (
(0x0772+ 6892-0x225e));}sub __ruleIsSetUfw{(my $ref_firewallStatus=shift (@_));(my $ports
=shift (@_));(my $proto=shift (@_));return ((!__ruleIsNotSetUfw (
$ref_firewallStatus,$ports,$proto)));}sub __ruleIsNotSetUfw{(my $ref_firewallStatus
=shift (@_));(my $ports=shift (@_));(my $proto=shift (@_));(my (@portsTab)=split
 ( /,/ ,$ports,(0x087c+ 2357-0x11b1)));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x2c\x20\x27").$proto)."\x27\x2e"));foreach my $rule (
@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g );if (($rule eq (""))){next;}if ((
($rule=~ /^([\w\/,:]+) \(v6\)\s+(\w+)\s+(.*)$/ )or ($rule=~ /^([\w\/,:]+)\s+(\w+)\s+(.*)$/ )
)){foreach my $port (@portsTab){if (((($1 eq (($port."\x2f").$proto))and ($2 eq 
"\x41\x4c\x4c\x4f\x57"))or (($1 eq (($port."\x3a").$proto))and ($2 eq 
"\x41\x4c\x4c\x4f\x57")))){Logger::debug (((((
"\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27".
$port)."\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));return (
(0x0098+ 1007-0x0487));}}}}Logger::debug (((((
"\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x73\x20\x27"
.$ports)."\x27\x20\x27").$proto).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"));return (
(0x12a4+ 4107-0x22ae));}sub __ruleIsSetIptables{(my $ref_firewallStatus=shift (
@_));(my $ports=shift (@_));(my $proto=shift (@_));return ((!
__ruleIsNotSetIptables ($ref_firewallStatus,$ports,$proto)));}sub 
__ruleIsNotSetIptables{(my $ref_firewallStatus=shift (@_));(my $ports=shift (@_)
);(my $proto=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x69\x73\x20\x72\x75\x6c\x65\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$ports)."\x27\x2e"));foreach my $rule (@$ref_firewallStatus){($rule=~ s/^\s+|\s+$//g )
;if (($rule=~ /^(\d+)\s+(\w+)\s+(\w+)\s+(.*)$/ )){if (((($2 eq 
"\x41\x43\x43\x45\x50\x54")and ($3 eq $proto))and ($4=~ /multiport dports $ports$/ )
)){Logger::debug (((((
"\x52\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27".$ports).
"\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x73\x65\x74\x2e"));return (
(0x06e4+ 2847-0x1203));}}}Logger::debug (((((
"\x52\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27".$ports).
"\x27\x20\x27").$proto)."\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2e"))
;return ((0x1ae0+ 1310-0x1ffd));}sub __addRuleByFirewalld{(my $ports=shift (@_))
;(my $proto=shift (@_));Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20"
.$ports)."\x2e"));(my (@command)=());(my (@parameters)=());if ((
main::effectiveUserIsAdministrator ()and (not (($ports=~ /,/ ))))){push (
@command,NXTools::getUnixCommandPath (
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64"));push (@command,
"\x2d\x2d\x7a\x6f\x6e\x65\x3d\x70\x75\x62\x6c\x69\x63");push (@command,(((
"\x2d\x2d\x61\x64\x64\x2d\x70\x6f\x72\x74\x3d".$ports)."\x2f").$proto));}else{
push (@command,$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x61\x64\x64\x2e\x73\x68"
);push (@command,"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64");push (
@command,$ports);push (@command,$proto);push (@command,(0x0828+ 1986-0x0fea),
(0x0728+ 509-0x0925));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
Logger::debug (((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x61\x64\x64\x20\x72\x75\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));if (($exit_value!=(0x0443+ 5956-0x1b87))){
Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20"
.$ports).
"\x20\x77\x69\x74\x68\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20"
).$exit_value)."\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __addRuleByUfw{(my $ports=shift (@_));(my $proto=
shift (@_));(my (@portsTab)=split ( /,/ ,$ports,(0x1028+ 2648-0x1a80)));(my $ret
=(0x0f71+ 4622-0x217f));foreach my $port (@portsTab){($ret=__addSingleRuleByUfw 
($port,$proto));}return ($ret);}sub __addSingleRuleByUfw{(my $port=shift (@_));(my $proto
=shift (@_));Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x3a\x20\x27"
.$port)."\x27\x2e"));(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ("\x75\x66\x77"));push (@command,
"\x61\x6c\x6c\x6f\x77");push (@command,"\x70\x72\x6f\x74\x6f",$proto);push (
@command,"\x66\x72\x6f\x6d","\x61\x6e\x79","\x74\x6f","\x61\x6e\x79");push (
@command,"\x70\x6f\x72\x74",$port);if (($oldUfwCommand==(0x0179+ 1115-0x05d3))){
push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",
"\x50\x41\x54\x48\x3d\x2f\x73\x62\x69\x6e");}}else{push (@command,
$GLOBAL::CommandNXexec,"\x6e\x78\x66\x77\x61\x64\x64\x2e\x73\x68");push (
@command,"\x75\x66\x77");push (@command,$port);push (@command,$proto);push (
@command,(0x1354+ 3577-0x214d));if (($oldUfwCommand==(0x09a9+ 665-0x0c41))){push
 (@command,(0x02d1+ 8014-0x221e));}else{push (@command,(0x1357+ 366-0x14c5));}
push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
Logger::debug (((
"\x75\x66\x77\x20\x61\x64\x64\x20\x72\x75\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));if (($exit_value!=(0x2116+ 1117-0x2573))){
Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20"
.$port).
"\x20\x77\x69\x74\x68\x20\x75\x66\x77\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20").
$exit_value)."\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __addRuleByIptablesV6{__addRuleByIptables (@_,
(0x1df9+ 205-0x1ec5));}sub __addRuleByIptables{(my $ref_firewallStatus=shift (@_
));(my $ports=shift (@_));(my $proto=shift (@_));(my $IPv6=(shift (@_)||
(0x19e3+ 630-0x1c59)));(my $name="\x69\x70\x74\x61\x62\x6c\x65\x73");if (($IPv6
==(0x0746+ 2443-0x10d0))){($name="\x69\x70\x36\x74\x61\x62\x6c\x65\x73");if ((
$ref_firewallStatus eq (""))){return ((0x00cd+ 1720-0x0784));}}Logger::debug (((
((((
"\x41\x64\x64\x69\x6e\x67\x20\x69\x70\x74\x61\x62\x6c\x65\x73\x20\x72\x75\x6c\x65\x20\x62\x79\x20"
.$name)."\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20").$ports).
"\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x20").$proto)."\x2e"));(my ($ruleNr,
$chain)=__getRuleNr ($ref_firewallStatus));if (($chain eq (""))){($chain=
"\x49\x4e\x50\x55\x54");}if ((($ruleNr==(0x13f5+ 1442-0x1997))and defined (
@$ref_firewallStatus))){($ruleNr=(0x18ac+ 1239-0x1d82));}if (($ruleNr==
(0x1bd1+ 2004-0x23a5))){Logger::debug (
"\x4e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x20\x72\x65\x6a\x65\x63\x74\x2f\x64\x72\x6f\x70\x2f\x69\x6e\x70\x75\x74\x5f\x65\x78\x74\x20\x69\x70\x74\x61\x62\x6c\x65\x73\x20\x72\x75\x6c\x65\x2e"
);return ((0x0ded+ 4227-0x1e6f));}(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ($name));push (@command,"\x2d\x49",$chain,$ruleNr);
push (@command,"\x2d\x70",$proto);push (@command,"\x2d\x2d\x6d\x61\x74\x63\x68",
"\x6d\x75\x6c\x74\x69\x70\x6f\x72\x74");push (@command,
"\x2d\x2d\x64\x70\x6f\x72\x74\x73",$ports);push (@command,"\x2d\x6a",
"\x41\x43\x43\x45\x50\x54");}else{push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x66\x77\x61\x64\x64\x2e\x73\x68");push (@command,$name);push (@command
,$ports);push (@command,$proto);push (@command,$ruleNr);push (@command,
(0x0786+ 7488-0x24c6));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x06d0+ 5133-0x1add))){Logger::warning ((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x27"
.$ports)."\x27\x20\x77\x69\x74\x68\x20\x27").$name).
"\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
).$exit_value)."\x27\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub delFirewallRules{Logger::debug (
"\x44\x65\x6c\x65\x74\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x73\x2e"
);(my (@rules)=__getFirewallRules ());if ((scalar (@rules)==
(0x15d6+ 3240-0x227e))){Logger::debug (
"\x4e\x6f\x20\x72\x75\x6c\x65\x73\x20\x74\x6f\x20\x64\x65\x6c\x65\x74\x65\x2e");
return ((0x0c2d+ 6325-0x24e2));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x1020+ 242-0x1112))){Logger::debug (((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x73\x3a\x20"
.join ($",@rules))."\x2e"));return ((0x0c05+ 2434-0x1587));}foreach my $rule (
@rules){(my ($ports,$proto)=split ( /:/ ,$rule,(0x0c2c+ 3992-0x1bc1)));__delRule
 ((\@firewallStatus),$ref_iptablesV6,$ports,$proto);if (__isRuleInFile ($ports,
$proto)){__removeRuleFromFile ($ports,$proto);}}}sub __getFirewallRules{(my (
@ports)=());(my $filename=__getFirewallFile ());if ((not (
Common::NXFile::isExists ($filename)))){return (@ports);}(my $FILE=main::nxopen 
($filename,$NXBits::O_RDONLY,(0x1421+ 3470-0x21af)));if ((not (defined ($FILE)))
){return (@ports);}while (main::nxreadLine ($FILE,(\$_))){($line=$_);if (($line
=~ /^Added exception for port: (.*)$/ )){push (@ports,$1);}}main::nxclose ($FILE
);return (@ports);}sub __delRule{(my $ref_firewallStatus=shift (@_));(my $ref_iptablesV6
=shift (@_));(my $ports=shift (@_));(my $proto=shift (@_));if ((($ports eq (""))
or ($proto eq ("")))){Logger::error ((((("\x50\x6f\x72\x74\x20\x27".$ports).
"\x27\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").$proto).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x65\x6d\x70\x74\x79\x2e"));
return ((0x05b2+ 7614-0x236f));}if (__checkUfw ()){__delRuleByUfw (
$ref_firewallStatus,$ports,$proto);}elsif (__checkFirewalldInstall ()){return (
__delRuleByFirewalld ($ref_firewallStatus,$ports,$proto));}elsif (
__checkFirewallInstall ()){__delRuleByIftables ($ref_firewallStatus,$ports,
$proto);__delRuleByIftablesV6 ($ref_iptablesV6,$ports,$proto);}}sub 
__delRuleByFirewalld{(my $ref_firewallStatus=shift (@_));(my $ports=shift (@_));
(my $proto=shift (@_));Logger::debug (((((
"\x44\x65\x6c\x65\x74\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27"
.$ports)."\x27\x20\x77\x69\x74\x68\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27")
.$proto)."\x27\x2e"));if (__ruleIsNotSetFirewalld ($ref_firewallStatus,$ports,
$proto)){Logger::debug (((((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20"
.$proto)."\x20").$ports).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x2e"
));return ((0x00f9+ 1833-0x0822));}(my (@command)=());(my (@parameters)=());if (
(main::effectiveUserIsAdministrator ()and (not (($ports=~ /,/ ))))){push (
@command,NXTools::getUnixCommandPath (
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64"));push (@command,
"\x2d\x2d\x7a\x6f\x6e\x65\x3d\x70\x75\x62\x6c\x69\x63");push (@command,(((
"\x2d\x2d\x72\x65\x6d\x6f\x76\x65\x2d\x70\x6f\x72\x74\x3d".$ports)."\x2f").
$proto));}else{push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x66\x77\x64\x65\x6c\x2e\x73\x68");push (@command,
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64");push (@command,$ports);push 
(@command,$proto);push (@command,(0x0b02+ 1616-0x1152));push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
Logger::debug (((
"\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x20\x72\x65\x6d\x6f\x76\x65\x20\x72\x75\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));if (($exit_value!=(0x0dc6+ 2094-0x15f4))){
Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x27"
.$ports).
"\x27\x20\x77\x69\x74\x68\x20\x27\x66\x69\x72\x65\x77\x61\x6c\x6c\x2d\x63\x6d\x64\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
).$exit_value)."\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __delRuleByUfw{(my $ref_firewallStatus=shift (@_))
;(my $ports=shift (@_));(my $proto=shift (@_));if (__ruleIsNotSetUfw (
$ref_firewallStatus,$ports,$proto)){Logger::debug (((((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20"
.$proto)."\x20").$ports).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x2e"
));return ((0x003d+ 9212-0x2439));}(my (@portsTab)=split ( /,/ ,$ports,
(0x0c76+ 4604-0x1e72)));(my $ret=(0x1507+ 1368-0x1a5f));foreach my $port (
@portsTab){Logger::debug (((((
"\x44\x65\x6c\x65\x74\x69\x6e\x67\x20\x75\x66\x77\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x20\x77\x69\x74\x68\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x27").
$proto)."\x27\x2e"));($ret=__delSingleRuleByUfw ($port,$proto));}return ($ret);}
sub __delSingleRuleByUfw{(my $ports=shift (@_));(my $proto=shift (@_));(my (
@command)=());(my (@parameters)=());if (main::effectiveUserIsAdministrator ()){
push (@command,NXTools::getUnixCommandPath ("\x75\x66\x77"));push (@command,
"\x64\x65\x6c\x65\x74\x65","\x61\x6c\x6c\x6f\x77");push (@command,
"\x70\x72\x6f\x74\x6f",$proto);push (@command,"\x66\x72\x6f\x6d","\x61\x6e\x79",
"\x74\x6f","\x61\x6e\x79");push (@command,"\x70\x6f\x72\x74",$ports);if ((
$oldUfwCommand==(0x165d+ 1956-0x1e00))){push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76","\x50\x41\x54\x48\x3d\x2f\x73\x62\x69\x6e");}}
else{push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x66\x77\x64\x65\x6c\x2e\x73\x68");push (@command,"\x75\x66\x77");push 
(@command,$ports);push (@command,$proto);if (($oldUfwCommand==
(0x0a55+ 7342-0x2702))){push (@command,(0x00c0+ 537-0x02d8));}else{push (
@command,(0x088b+ 2204-0x1127));}push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
Logger::debug (((
"\x75\x66\x77\x20\x72\x65\x6d\x6f\x76\x65\x20\x72\x75\x6c\x65\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20\x27"
.$cmd_out)."\x27\x2e"));if (($exit_value!=(0x0d64+ 6253-0x25d1))){
Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x27"
.$ports).
"\x27\x20\x77\x69\x74\x68\x20\x27\x75\x66\x77\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x3a\x20"
).$exit_value)."\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __delRuleByIftablesV6{__delRuleByIftables (@_,
(0x08c6+ 7714-0x26e7));}sub __delRuleByIftables{(my $ref_firewallStatus=shift (
@_));(my $ports=shift (@_));(my $proto=shift (@_));(my $IPv6=(shift (@_)||
(0x07b7+ 3511-0x156e)));(my $name="\x69\x70\x74\x61\x62\x6c\x65\x73");if (($IPv6
==(0x0e21+ 6149-0x2625))){($name="\x69\x70\x36\x74\x61\x62\x6c\x65\x73");if ((
$ref_firewallStatus eq (""))){return ((0x033d+ 5225-0x17a5));}}Logger::debug (((
(((("\x44\x65\x6c\x65\x74\x69\x6e\x67\x20".$name).
"\x20\x72\x75\x6c\x65\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27").$ports).
"\x27\x20\x61\x6e\x64\x20\x27").$proto)."\x27\x2e"));if ((__ruleIsNotSetIptables
 ($ref_firewallStatus,$ports,$proto)==(0x1805+ 1468-0x1dc0))){Logger::debug ((((
((("\x46\x69\x72\x65\x77\x61\x6c\x6c\x20".$name).
"\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20").$proto)."\x20").$ports).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x65\x74\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x2e"
));return ((0x04f7+ 1506-0x0ad9));}(my (@command)=());(my (@parameters)=());if (
main::effectiveUserIsAdministrator ()){push (@command,
NXTools::getUnixCommandPath ($name));push (@command,"\x2d\x44",
"\x49\x4e\x50\x55\x54");push (@command,"\x2d\x70",$proto);push (@command,
"\x2d\x2d\x6d\x61\x74\x63\x68","\x6d\x75\x6c\x74\x69\x70\x6f\x72\x74");push (
@command,"\x2d\x2d\x64\x70\x6f\x72\x74\x73",$ports);push (@command,"\x2d\x6a",
"\x41\x43\x43\x45\x50\x54");}else{push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x66\x77\x64\x65\x6c\x2e\x73\x68");push (@command,$name);push (@command
,$ports);push (@command,$proto);push (@command,(0x0303+ 7872-0x21c3));push (
@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}(my (
$cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),(\@parameters)));
if (($exit_value!=(0x1252+ 2498-0x1c14))){Logger::warning ((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x27"
.$ports)."\x27\x20\x77\x69\x74\x68\x20\x27").$name).
"\x27\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e\x20\x45\x78\x69\x74\x20\x76\x61\x6c\x75\x65\x20\x27"
).$exit_value)."\x27\x2e\x20").
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exit_value);}sub __getFirewallFile{(my $path=$GLOBAL::VAR_ROOT);(
$path.=($GLOBAL::DIRECTORY_SLASH."\x64\x62"));($path.=($GLOBAL::DIRECTORY_SLASH.
"\x73\x65\x72\x76\x65\x72"));($path.=($GLOBAL::DIRECTORY_SLASH.
"\x66\x69\x72\x65\x77\x61\x6c\x6c"));return ($path);}sub __saveAddedRule{(my $port
=shift (@_));(my $proto=shift (@_));(my $filename=__getFirewallFile ());(my $FH=
main::nxopen ($filename,(($NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND)
,$NXBits::UserReadWrite));if ((not (defined ($FH)))){return (
(0x02d5+ 5118-0x16d2));}(my $ruleEntry=((((
"\x41\x64\x64\x65\x64\x20\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x3a\x20"
.$port)."\x3a").$proto)."\x0a"));if ((main::nxwrite ($FH,$ruleEntry)==(-
(0x0694+ 7482-0x23cd)))){main::nxclose ($FH);return ((0x1400+ 1448-0x19a7));}
main::nxclose ($FH);my ($errorName);my ($errorCode);if ((
Common::NXFile::setOwnershipForUserNXSilent ($filename,(\$errorName),(
\$errorCode))==(-(0x02c7+ 5826-0x1988)))){Logger::error ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x2e\x20").$errorCode)."\x20").$errorName));return (
(0x1674+ 2651-0x20ce));}}sub __isRuleInFile{(my $port=shift (@_));(my $proto=
shift (@_));(my $filename=__getFirewallFile ());if ((not (
Common::NXFile::isExists ($filename)))){return ((0x044d+ 1714-0x0aff));}(my $FILE
=main::nxopen ($filename,$NXBits::O_RDONLY,(0x07b2+ 5855-0x1e91)));if ((not (
defined ($FILE)))){return ((0x1f4c+ 178-0x1ffe));}while (main::nxreadLine ($FILE
,(\$_))){($line=$_);if (($line=~ /^Added exception for port: $port:$proto$/ )){
main::nxclose ($FILE);return ((0x1cfb+ 314-0x1e34));}}main::nxclose ($FILE);
return ((0x0139+ 9663-0x26f8));}sub __removeRuleFromFile{(my $ports=shift (@_));
(my $proto=shift (@_));Logger::debug (((((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20"
.$ports)."\x20\x61\x6e\x64\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20").$proto).
"\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x2e"));(my $filename=__getFirewallFile
 ());(my $tmp=(($filename."\x2e\x74\x6d\x70\x2e").$ $));
 (my $FILE=main::nxopen
 ($filename,$NXBits::O_RDONLY,(0x0760+ 3795-0x1633)));if ((not (defined ($FILE))
)){return ((0x0332+ 6176-0x1b51));}(my $TEMP_FILE=main::nxopen ($tmp,((
$NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND),$NXBits::UserReadWrite));
if ((not (defined ($TEMP_FILE)))){main::nxclose ($FILE);return (
(0x111b+ 1775-0x1809));}(my $flagDel=(0x06f3+ 5476-0x1c56));while (
main::nxreadLine ($FILE,(\$_))){(my $line=$_);if (($line=~ /^Added exception for port: $ports:$proto$/ )
){($flagDel=(0x1041+ 2151-0x18a8));}else{main::nxwrite ($TEMP_FILE,$line);}}
main::nxclose ($TEMP_FILE);main::nxclose ($FILE);if ((not (rename ($tmp,
$filename)))){Logger::warning ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x3a\x20\x27"
.$tmp)."\x27\x20\x6f\x6e\x20\x27").$filename)."\x27\x20").$!));}my ($error);if (
(Common::NXFile::setOwnershipForUserNXSilent ($filename,(\$error))==(-
(0x00e0+ 8228-0x2103)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x66\x69\x6c\x65\x20\x27"
.$filename)."\x27\x20").$error)."\x2e"));return ((0x0f49+ 2359-0x187f));}return 
($flag_del);}sub addFirewallUdpPort{(my $port=shift (@_));Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x75\x64\x70\x20\x72\x75\x6c\x65\x20\x74\x6f\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));if (($GLOBAL::EnableFirewallConfiguration==
(0x02d1+ 2761-0x0d9a))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e\x63\x66\x67\x20\x66\x69\x6c\x65\x2e"
);return ((0x05d8+ 4152-0x1610));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x00ac+ 7695-0x1ebb))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x2e"
);return ((0x126d+ 1406-0x17eb));}(my $returnValue=__addRule ((\@firewallStatus)
,$ref_iptablesV6,$port,"\x75\x64\x70",
"\x73\x65\x73\x73\x69\x6f\x6e\x52\x75\x6c\x65"));if (($returnValue==
(0x0aa3+ 2933-0x1618))){__setFirewallUdpPort ($port);
NXSession2::saveFirewallRule (Server::getMySessionID (),$port);}}sub 
addFirewallNXDPort{(my $port=NXNodeInfo::getNxdPort ());Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x4e\x58\x44\x20\x72\x75\x6c\x65\x20\x74\x6f\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));if (($GLOBAL::EnableFirewallConfiguration==
(0x0ca4+ 641-0x0f25))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e\x63\x66\x67\x20\x66\x69\x6c\x65\x2e"
);return ((0x0db0+ 3175-0x1a17));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x041f+ 6950-0x1f45))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x2e"
);return ((0x0356+ 8075-0x22e1));}(my $returnValue=__addRule ((\@firewallStatus)
,$ref_iptablesV6,$port,"\x74\x63\x70"));if (($returnValue==(0x14e0+ 2549-0x1ed5)
)){__saveAddedRule ($port,"\x74\x63\x70");}($port=NXNodeInfo::getNxdUDPPort ());
(my $returnValue=__addRule ((\@firewallStatus),$ref_iptablesV6,$port,
"\x75\x64\x70"));if (($returnValue==(0x1d08+ 2191-0x2597))){__saveAddedRule (
$port,"\x75\x64\x70");}}sub addFirewallNXHtdPort{(my $port=NXTools::getNXHtdPort
 ());Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x4e\x58\x48\x74\x64\x20\x72\x75\x6c\x65\x20\x74\x6f\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));if (($GLOBAL::EnableFirewallConfiguration==
(0x0162+ 4846-0x1450))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x73\x65\x72\x76\x65\x72\x2e\x63\x66\x67\x20\x66\x69\x6c\x65\x2e"
);return ((0x03ff+ 8087-0x2396));}my ($ref_iptablesV6);(my (@firewallStatus)=
__getFirewallStatus ((\$ref_iptablesV6)));if ((__checkFirewallStatus ((
\@firewallStatus),$ref_iptablesV6)==(0x061c+ 3046-0x1202))){Logger::debug (
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x61\x64\x64\x69\x6e\x67\x20\x72\x75\x6c\x65\x2e"
);return ((0x110a+ 2757-0x1bcf));}(my $returnValue=__addRule ((\@firewallStatus)
,$ref_iptablesV6,$port,"\x74\x63\x70"));if (($returnValue==(0x1298+ 4791-0x254f)
)){__saveAddedRule ($port,"\x74\x63\x70");}}sub delFirewallUdpPort{(my $port=
__getFirewallUdpPort ());if (($port ne (""))){my ($ref_iptablesV6);(my (
@firewallStatus)=__getFirewallStatus ((\$ref_iptablesV6)));if ((
__checkFirewallStatus ((\@firewallStatus),$ref_iptablesV6)==
(0x0b81+ 5429-0x20b6))){Logger::debug (((
"\x46\x69\x72\x65\x77\x61\x6c\x6c\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2c\x20\x73\x6b\x69\x70\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x20\x55\x44\x50\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20"
.$port)."\x2e"));return ((0x12e3+ 2094-0x1b11));}Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x66\x69\x72\x65\x77\x61\x6c\x6c\x20\x75\x64\x70\x20\x72\x75\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));__delRule ((\@firewallStatus),$ref_iptablesV6,$port,
"\x75\x64\x70");__cleanFirewallUdpPort ();}}sub __setFirewallUdpPort{(
$firewallUdpPort=shift (@_));}sub __getFirewallUdpPort{return ($firewallUdpPort)
;}sub __cleanFirewallUdpPort{($firewallUdpPort=(""));}return (
(0x1110+ 3004-0x1ccb));
