############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::NXUser::UserNotInPwDB::BEGIN{package 
Exception::NXUser::UserNotInPwDB;no warnings;require base;do{"\x62\x61\x73\x65"
->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x55\x73\x65\x72\x3a\x3a\x42\x61\x73\x65"
)};}sub Exception::NXUser::UserNotInPwDB::BEGIN{package 
Exception::NXUser::UserNotInPwDB;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::NXUser::UserNotInPwDB::notify{package 
Exception::NXUser::UserNotInPwDB;no warnings;(my $self=shift (@_));(my $text=
$self->text);(my $statusId=main::get_unique_id ());($statusId=~ s/(........).*/$1/ )
;NXMsg::register_response ((""),
"\x65\x55\x73\x65\x72\x4e\x6f\x74\x49\x6e\x50\x77\x44\x42",(0x0c95+ 197-0x0b40))
;NXMsg::send_response (
"\x65\x55\x73\x65\x72\x4e\x6f\x74\x49\x6e\x50\x77\x44\x42",
"\x67\x65\x6e\x65\x72\x61\x6c",$text,$text);(my $trace=$self->stacktrace);(
$trace=~ s/\n[^\w]+/\n/ );($trace=~ s/\t//gm );(@aTrace=split ( ?\n? ,$trace,
(0x0861+ 4122-0x187b)));shift (@aTrace);Logger::multilineLog (((
"\x28\x65\x78\x63\x65\x70\x74\x69\x6f\x6e\x20\x69\x64\x20".$statusId)."\x29"),(
$ErrStr,@aTrace));}package Exception::NXUser::UserNotInPwDB;no warnings;
"\x3f\x3f\x3f";
