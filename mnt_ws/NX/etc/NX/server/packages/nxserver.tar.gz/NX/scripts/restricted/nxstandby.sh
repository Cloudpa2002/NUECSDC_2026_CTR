#!/bin/bash
######################################################################
#                                                                    #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.     #
#                                                                    #
#  All rights reserved.                                              #
#                                                                    #
######################################################################

RunDir=${0%nxstandby.sh}
RestrictedDir=$(cd "${RunDir}" && pwd)

PARAMS_COUNT_MIN=2
PARAMS_COUNT_MAX=3

. "${RestrictedDir}"/nxfunct.sh

isRunByServer

COMMAND_SERVER="${NX_ROOT}/bin/nxserver"

MODE="$3"

if test "x${MODE}" = "xforce"; then
  exec "${COMMAND_SERVER}" --standby --force
else
  exec "${COMMAND_SERVER}" --standby
fi

exit $?
