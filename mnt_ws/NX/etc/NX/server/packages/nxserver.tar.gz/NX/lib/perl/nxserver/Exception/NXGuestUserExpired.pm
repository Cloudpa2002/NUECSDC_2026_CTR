############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::NXGuestUserExpired::BEGIN{package Exception::NXGuestUserExpired;
no warnings;require base;do{"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::NXGuestUserExpired::BEGIN{package Exception::NXGuestUserExpired;no 
warnings;require overload;do{"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import (
"\x22\x22","\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::NXGuestUserExpired::notify{package Exception::NXGuestUserExpired;no 
warnings;(my $self=shift (@_));NXMsg::error (
"\x65\x47\x75\x65\x73\x74\x45\x78\x70\x69\x72\x65\x64",
"\x4e\x58\x47\x75\x65\x73\x74\x73\x4d\x61\x6e\x61\x67\x65\x72",$self->text);}
package Exception::NXGuestUserExpired;no warnings;return ((0x0170+ 8782-0x23bd))
;
