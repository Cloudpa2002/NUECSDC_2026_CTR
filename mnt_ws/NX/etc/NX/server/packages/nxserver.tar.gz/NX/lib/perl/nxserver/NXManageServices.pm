############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXManageServices::BEGIN{package NXManageServices;no warnings;require Error;
do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}package 
NXManageServices;no warnings;(my $__nxdName="\x4e\x58\x54\x43\x50");(my $__nxUDPName
="\x4e\x58\x55\x44\x50");(my $__nxhtdName="\x4e\x58\x48\x54\x44");(my $__nxsshdName
="\x4e\x58\x53\x53\x48\x44");sub getNXDName{return ($__nxdName);}sub 
getNXTCPMsgName{return ("\x4e\x58\x20\x54\x43\x50");}sub getNXUDPMsgName{return 
("\x4e\x58\x20\x55\x44\x50");}sub getNXHtdName{return ($__nxhtdName);}sub 
getNXSshName{return ($__nxsshdName);}sub translateToServerKeyNames{(my $key=
shift (@_));if (($key eq "\x4e\x58\x44")){return (
"\x53\x74\x61\x72\x74\x4e\x58\x44\x61\x65\x6d\x6f\x6e");}elsif (($key eq 
"\x4e\x58\x48\x54\x44")){return (
"\x53\x74\x61\x72\x74\x48\x54\x54\x50\x44\x61\x65\x6d\x6f\x6e");}elsif (($key eq
 "\x4e\x58\x53\x53\x48\x44")){return (
"\x53\x74\x61\x72\x74\x53\x53\x48\x44\x61\x65\x6d\x6f\x6e");}}sub setStartMode{(my $service
=shift (@_));(my $mode=shift (@_));return (main::changeServerCfgKey (
translateToServerKeyNames ($service),$mode));}sub getStartMode{(my $service=
shift (@_));if (($service ne (""))){(my ($exitValue,$status)=
main::getValueFromConfigFile ($GLOBAL::CONFIG_FILE,translateToServerKeyNames (
$service)));if ((($status eq "\x31")or ($status eq ("")))){($status=
"\x41\x75\x74\x6f\x6d\x61\x74\x69\x63");}elsif (($status eq "\x30")){($status=
"\x4d\x61\x6e\x75\x61\x6c");}return ($status);}(my $status=
"\x4d\x61\x6e\x75\x61\x6c");(my (@options)=());(my (@command)=());push (@command
,($GLOBAL::NODE_ROOT.
"\x2f\x73\x63\x72\x69\x70\x74\x73\x2f\x73\x65\x74\x75\x70\x2f\x6e\x78\x73\x65\x72\x76\x65\x72"
));push (@command,"\x2d\x2d\x63\x68\x65\x63\x6b\x73\x65\x72\x76\x69\x63\x65\x73"
);(my ($cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@options
)));chomp ($exit_value);if (($exit_value eq "\x31")){($status=
"\x41\x75\x74\x6f\x6d\x61\x74\x69\x63");}return ($status);}sub servicePort{(my $ref_parameters
=shift (@_));if (($$ref_parameters{"\x74\x61\x72\x67\x65\x74"}ne (""))){
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");if ((
NXServers::normalizeTargetParameter ($ref_parameters)==(-(0x1093+ 5218-0x24f4)))
){NXMsg::error (
"\x65\x47\x55\x49\x54\x61\x72\x67\x65\x74\x53\x65\x72\x76\x65\x72\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x4e\x58\x53\x65\x72\x76\x65\x72\x73",$$ref_parameters{
"\x74\x61\x72\x67\x65\x74"});NXShell::setExitRequestCommandFinished ();return (
(0x18e9+ 2157-0x2155));}main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72")
;if ((($$ref_parameters{"\x74\x61\x72\x67\x65\x74"}ne Server::getMyUUID ())and (
$$ref_parameters{"\x74\x61\x72\x67\x65\x74"}ne NXCluster::getClusterGUID ()))){(my $isForwarded
=(0x0e2c+ 2726-0x18d2));if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}ne (""))){if (($$ref_parameters{
"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x0f5c+ 4090-0x1f55))){($isForwarded=
(0x0dc0+ 277-0x0ed4));}}($$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"
}=(0x0907+  97-0x0967));NXServers::forwardCommand (
"\x73\x65\x72\x76\x69\x63\x65\x70\x6f\x72\x74",$ref_parameters);if ((
$isForwarded==(0x1906+ 3079-0x250c))){NXShell::setCommandForwarded ();
NXShell::setExitRequestCommandFinished ();}else{
NXShell::startGetCommandStateMachine ();}return ((0x08c4+ 3468-0x164f));}if ((
$$ref_parameters{"\x66\x6f\x72\x77\x61\x72\x64\x65\x64"}==(0x2374+ 123-0x23ee)))
{NXShell::setCommandForwarded ();NXShell::setExitRequestCommandFinished ();}}(
$$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}=uc ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}));if (($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}ne (""))){if (((((($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}ne $__nxdName)and ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}ne $__nxhtdName))and ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}ne $__nxsshdName))and ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}ne "\x41\x4c\x4c"))and ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}ne $__nxUDPName))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x76\x61\x6c\x69\x64\x4e\x61\x6d\x65"
,"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
$$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"});return ((0x0fe3+ 3959-0x1f59))
;}}if (($$ref_parameters{"\x70\x6f\x72\x74"}eq (""))){return (listPorts (
$ref_parameters));}else{main::nxrequire ("\x4e\x58\x54\x6f\x6f\x6c\x73");if ((
not (NXTools::isCorrectPort ($$ref_parameters{"\x70\x6f\x72\x74"})))){
NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x49\x6e\x76\x61\x6c\x69\x64\x50\x6f\x72\x74"
,"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
$$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"},$port);return (
(0x0543+ 3967-0x14c1));}}return (setPort ($ref_parameters));}sub listPorts{(my $ref_parameters
=shift (@_));if (((($$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq (""))or (
$$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq "\x41\x4c\x4c"))or (
$$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"}eq $__nxdName))){main::nxrequire
 ("\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f");(my $port=NXNodeInfo::getNxdPort 
());NXMsg::send_response (
"\x69\x43\x4d\x44\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74",
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
getNXTCPMsgName (),$port);}if (((($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq (""))or ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x41\x4c\x4c"))or ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq $__nxUDPName))){main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x49\x6e\x66\x6f");(my $port=NXNodeInfo::getNxdUDPPort 
());NXMsg::send_response (
"\x69\x43\x4d\x44\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74",
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
getNXUDPMsgName (),$port);}if (((($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq (""))or ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq "\x41\x4c\x4c"))or ($$ref_parameters{
"\x73\x65\x72\x76\x69\x63\x65"}eq $__nxhtdName))){if (
NXLicense::isHttpdSupportFeature ()){main::nxrequire (
"\x4e\x58\x54\x6f\x6f\x6c\x73");(my $port=NXTools::getNXHtdPort ());
NXMsg::send_response (
"\x69\x43\x4d\x44\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74",
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",getNXHtdName 
(),$port);}}return ((0x0d4a+ 849-0x109b));}sub addLocalhostCertificateForNxhtd{(my $port
=shift (@_));(my $ref_errror=shift (@_));(my $host=(
"\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x20".$port));main::nxrequire (
"\x4e\x58\x54\x6f\x6f\x6c\x73");(my ($nxhtdUser,$nxhtdGroup)=
NXTools::getNXHtdUser ());(my $file=NXPaths::getUserKnownCerts ($nxhtdUser));if 
(Common::NXShellCreate::isHostInCertFile ($host,$file)){return (
(0x02da+ 6743-0x1d30));}(my $certPath=NXPaths::getHostPublicCert ());(my $content
=Common::NXFile::getFileContent ($certPath));(my $certificate=(((
"\x48\x6f\x73\x74\x3a\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x20".$port)."\x0a").
$content));my ($lockHandle);&try (sub{($lockHandle=main::lockFileDirect ($file,
$NXBits::LOCK_EX));},"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"
->catch (&with (sub{($lockHandle=undef);})));if ((not (defined ($lockHandle)))){
($ref_errror=((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x6f\x63\x6b\x20\x66\x69\x6c\x65\x20\x27".$file
)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));return (
(0x244d+ 467-0x2620));}(my $FD=main::nxopen ($file,($NXBits::O_WRONLY+
$NXBits::O_APPEND),$NXBits::UserReadWrite));if ((not (defined ($FD)))){
main::unLockFileDirect ($lockHandle);(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());($ref_errror=((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".$file
).
"\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
).$errorNumber)."\x2c\x20").$errorString)."\x2e"));return ((0x1680+ 1111-0x1ad7)
);}main::nxwrite ($FD,$certificate);main::nxclose ($FD);main::unLockFileDirect (
$lockHandle);return ((0x0c48+ 6407-0x254e));}sub updateNxdPortForNxhtd{(my $port
=shift (@_));(my $ref_errror=shift (@_));if (NXLicense::isHttpdSupportFeature ()
){(my $key="\x50\x6f\x72\x74");if (main::changeServerCfgKeySetError ($key,$port,
$ref_errror)){addLocalhostCertificateForNxhtd ($port,$ref_errror);return (
(0x0028+ 5778-0x16b9));}return ((0x05fb+ 5070-0x19c9));}return (
(0x01cb+ 4602-0x13c4));}sub setPort{(my $ref_parameters=shift (@_));(my $service
=$$ref_parameters{"\x73\x65\x72\x76\x69\x63\x65"});(my $port=$$ref_parameters{
"\x70\x6f\x72\x74"});Logger::debug (((((
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x20\x53\x65\x74\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x27").$service
)."\x27\x2e"));if (($service eq $__nxdName)){(my $key=
"\x4e\x58\x54\x43\x50\x50\x6f\x72\x74");(my $error=(""));if (
main::changeServerCfgKeySetError ($key,$port,(\$error))){($GLOBAL::NXTCPPort=
$port);if (updateNxdPortForNxhtd ($port,(\$error))){NXMsg::info (
"\x69\x43\x4d\x44\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74",
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
getNXTCPMsgName (),$port);return ((0x0554+ 6214-0x1d9a));}}NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74"
,"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
getNXTCPMsgName (),$error);}elsif (($service eq $__nxUDPName)){(my $key=
"\x4e\x58\x55\x44\x50\x50\x6f\x72\x74");(my $error=(""));if (
main::changeServerCfgKeySetError ($key,$port,(\$error))){NXMsg::info (
"\x69\x43\x4d\x44\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74",
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
getNXUDPMsgName (),$port);return ((0x0bda+ 2503-0x15a1));}NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74"
,"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
getNXUDPMsgName (),$error);}elsif (($service eq $__nxhtdName)){(my $key=
"\x4c\x69\x73\x74\x65\x6e");(my $value=(("\x30\x2e\x30\x2e\x30\x2e\x30\x3a".
$port)."\x20\x68\x74\x74\x70\x73"));(my $error=(""));(my $lessStrict=
(0x01b9+ 957-0x0575));if (main::changeCfgKeySetError ($key,$value,
$GLOBAL::HTD_CONFIG_FILE,(\$error),$lessStrict)){($key=
"\x3c\x56\x69\x72\x74\x75\x61\x6c\x48\x6f\x73\x74");($value=((
"\x30\x2e\x30\x2e\x30\x2e\x30\x3a".$port)."\x3e"));($error=(""));if (
main::changeCfgKeySetError ($key,$value,$GLOBAL::HTD_CONFIG_FILE,(\$error),
$lessStrict)){NXMsg::info (
"\x69\x43\x4d\x44\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74",
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",$__nxhtdName,
$port);return ((0x1e35+ 1920-0x25b5));}}NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74"
,"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",$__nxhtdName
,$error);}return ((0x0030+ 6069-0x17e4));}NXMsg::register_response (
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
"\x69\x43\x4d\x44\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74",
$GLOBAL::MSG_SERVICES_LIST);NXMsg::register_response (
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
"\x69\x43\x4d\x44\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74",
$GLOBAL::MSG_SERVICES_SET);NXMsg::register_error (
"\x4e\x58\x4d\x61\x6e\x61\x67\x65\x53\x65\x72\x76\x69\x63\x65\x73",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x53\x65\x72\x76\x69\x63\x65\x50\x6f\x72\x74"
,$GLOBAL::MSG_ERROR);return ((0x0059+ 6202-0x1892));
