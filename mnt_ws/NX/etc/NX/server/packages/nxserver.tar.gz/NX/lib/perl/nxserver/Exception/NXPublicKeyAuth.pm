############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::NXPublicKeyAuth::BEGIN{package Exception::NXPublicKeyAuth;no 
warnings;require base;do{"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::NXPublicKeyAuth::BEGIN{package Exception::NXPublicKeyAuth;no warnings
;require overload;do{"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub Exception::NXPublicKeyAuth::notify
{package Exception::NXPublicKeyAuth;no warnings;(my $self=shift (@_));
NXMsg::register_error ((""),
"\x65\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x41\x75\x74\x68\x46\x61\x69\x6c\x64",
(0x0990+ 7740-0x25d8));NXMsg::error (
"\x65\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x41\x75\x74\x68\x46\x61\x69\x6c\x64",
"\x67\x65\x6e\x65\x72\x61\x6c");}package Exception::NXPublicKeyAuth;no warnings;
"\x3f\x3f\x3f";
