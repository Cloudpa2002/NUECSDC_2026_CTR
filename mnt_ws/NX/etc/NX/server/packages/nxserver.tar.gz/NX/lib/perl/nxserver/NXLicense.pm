############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXLicense::BEGIN{package NXLicense;no warnings;require NXProfilesManager;do{
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x4d\x61\x6e\x61\x67\x65\x72"->import};
}sub NXLicense::BEGIN{package NXLicense;no warnings;require Time::Local;do{
"\x54\x69\x6d\x65\x3a\x3a\x4c\x6f\x63\x61\x6c"->import};}package NXLicense;no 
warnings;require NXShell;($virtualSessionsFeature=(0x05e0+ 4127-0x15ff));(
$x11SessionsFeature=(0x108d+ 2780-0x1b69));($rdpFeature=(0x176c+ 3977-0x26f5));(
$guestsFeature=(0x06a2+ 5316-0x1b66));($profilesFeature=(0x0cfd+ 1794-0x13ff));(
$multinodeFeature=(0x1d9c+ 370-0x1f0e));($terminalNodeSelectFeature=
(0x053c+ 4902-0x1862));($redirectFeature=(0x0a73+ 2102-0x12a9));(
$httpdSupportFeature=(0x14eb+ 2674-0x1f5d));($sshFeature=(0x0aa7+ 518-0x0cad));(
$groupsFeature=(0x0aa9+ 3267-0x176c));($clusterFeature=(0x0185+ 5390-0x1693));(
$clusterCreateFeature=(0x1545+ 1077-0x197a));($directConnections=
(0x0907+ 3024-0x14d6));($serverAvailableAsRemoteNode=(0x0d8d+ 1747-0x1460));(
$serverAvailableAsRemoteServer=(0x0359+ 645-0x05de));($nxFrameBufferFeature=
(0x0224+ 3092-0x0e38));($notSystemUserFeature=(0x0573+ 8181-0x2568));(
$nodeSynchronization=(0x1428+ 3685-0x228d));($multiserverFeature=
(0x0d22+ 2137-0x157b));($automaticRecordingFeature=(0x123b+ 3667-0x208e));(
$killingLeftoverCMonStarup=(0x0dc3+ 145-0x0e54));($subCloudServersFeature=
(0x1885+ 624-0x1af5));($foreignServersFeature=(0x1267+ 312-0x139f));(
$reverseClientFeature=(0x12db+ 4738-0x255d));($visitorAccessFeature=
(0x0322+ 5972-0x1a76));($guestAccessFeature=(0x0205+ 4825-0x14de));(
$virtualGuestDesktopSharingFeature=(0x0119+ 9047-0x2470));(
$physicalGuestDesktopSharingFeature=(0x1a83+ 1477-0x2048));($defaultUpdateMode=
(0x1055+ 5316-0x2518));($customFreeSubscriptionMessage=(0x1a7c+ 2680-0x24f4));(
$LicenseVirtualDesktopsLimit=(-(0x08fb+ 6976-0x243a)));($ignoreRolesConfigKeys=
(0x0818+ 1609-0x0e61));($isLicenseExpired=(0x0725+ 5800-0x1dcd));($expiryDate=
(""));($expiryTimestamp=(""));($expiryReadableDate=(""));($productIdInLicense=
(""));($platformInLicense=(""));($SubscriptionVersion=(-(0x0611+ 726-0x08e6)));(
$usingNodeLicenseFile=(0x1d69+ 701-0x2026));($licenseProcessorsCount=
(0x17e5+ 715-0x1ab0));($__checkProcessorsCountDelay=(0x08ab+ 7916-0x266b));(
$__lastCheckProcessorsCount=(0x1a34+ 1723-0x20ef));($__warningBeforeExpiryPeriod
=5184000);($isNoLicenseFile=(0x0995+ 7491-0x26d8));(
$isNotSuitableLicenseForPackage=(0x0b8c+ 6960-0x26bc));(
$isWrongPlatformLicenseForPackage=(0x1db8+ 1931-0x2543));(
$GLOBAL::licenseConnectionsLimit=(0x0fa1+ 5013-0x2336));(my $__evaluationPeriodExpired
=(0x0690+ 3475-0x1423));(my $__evaluation=(0x22c4+ 620-0x2530));(my $__acronymId
=(-(0x0479+ 5128-0x1880)));sub enableCustomFreeSubscriptionMessage{(
$customFreeSubscriptionMessage=(0x0ad9+ 3745-0x1979));}sub getProductIdInLicense
{return ($productIdInLicense);}sub getPlatformInLicense{return (
$platformInLicense);}sub isCustomFreeSubscriptionMessage{return (
$customFreeSubscriptionMessage);}sub initializeFilePaths{($codecLicFile=((((
$GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x64\x65\x63\x2e\x6c\x69\x63"));(
$cloudLicFile=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x63\x6c\x6f\x75\x64\x2e\x6c\x69\x63"));(
$serverLicFile=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x73\x65\x72\x76\x65\x72\x2e\x6c\x69\x63"));(
$nodeLicFile=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x6f\x64\x65\x2e\x6c\x69\x63"));($clusterLicFile=
(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x65\x74\x63").
$GLOBAL::DIRECTORY_SLASH)."\x63\x6c\x75\x73\x74\x65\x72\x2e\x6c\x69\x63"));}sub 
saveExpiryDate{(my $expiry=(shift (@_)||("")));($expiryDate=$expiry);}sub 
saveExpiryTimestamp{(my $expiry=shift (@_));($expiryTimestamp=$expiry);}sub 
getExpiryTimestamp{return ($expiryTimestamp);}sub getExpiryReadableDate{return (
$expiryReadableDate);}sub handleSubscriptionExpiryByDaemon{if (((not (
Server::isDaemonProcess ()))or isEvaluation ())){return;}(my $msg=
Common::NXMsg::getEnglishTextOneLine (
"\x65\x43\x4d\x44\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x56\x65\x72\x73\x69\x6f\x6e\x37\x45\x78\x70\x69\x72\x79"
));Logger::error ($msg);}sub checkIfLicenseExpired{if (($expiryDate eq (""))){
Logger::error (
"\x55\x6e\x64\x65\x66\x69\x6e\x65\x64\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x27\x70\x45\x78\x70\x69\x72\x79\x27"
,(0x1c81+ 176-0x1d31));NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);($isLicenseExpired=(0x1a8b+ 1045-0x1e9f));NXShell::handle_command (
"\x65\x78\x69\x74");return ((0x01b6+ 5940-0x18e9));}elsif (($expiryDate eq 
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64")){($isLicenseExpired=(0x0db0+ 525-0x0fbd)
);return ((0x0429+ 7259-0x2084));}else{(my (@ltime)=Common::NXTime::getLocalTime
 ());(my $now=($ltime[(0x140a+ 2207-0x1ca4)]+(0x11bf+ 3356-0x176f)));($now=($now
.sprintf ("\x25\x30\x32\x64",($ltime[(0x1d01+ 906-0x2087)]+(0x1b81+ 1304-0x2098)
))));($now=($now.sprintf ("\x25\x30\x32\x64",$ltime[(0x03ef+ 8569-0x2565)])));(
$now=($now.sprintf ("\x25\x30\x32\x64",$ltime[(0x0e67+ 5312-0x2325)])));($now=(
$now.sprintf ("\x25\x30\x32\x64",$ltime[(0x1849+ 350-0x19a6)])));($now=($now.
sprintf ("\x25\x30\x32\x64",$ltime[(0x0ce3+ 602-0x0f3d)])));if (($now ge 
$expiryDate)){($isLicenseExpired=(0x18fa+ 3560-0x26e1));
handleSubscriptionExpiryByDaemon ();return ((0x07b9+ 412-0x0954));}(
$isLicenseExpired=(0x0eb0+ 4371-0x1fc3));NXEvent::subscribe (
NXEvent::getLicenseExpiredEventName (),
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x3a\x68\x61\x6e\x64\x6c\x65\x4c\x69\x63\x65\x6e\x73\x65\x43\x68\x61\x6e\x67\x65\x64"
);return ((0x12f9+ 5039-0x26a8));}}sub isLicenseExpired{return (
$isLicenseExpired);}sub isNoLicenseFile{return ($isNoLicenseFile);}sub 
isNotSuitableLicenseForPackage{return ($isNotSuitableLicenseForPackage);}sub 
isWrongPlatformLicenseForPackage{return ($isWrongPlatformLicenseForPackage);}sub
 setNotSuitableLicenseForPackage{($isNotSuitableLicenseForPackage=
(0x040f+ 157-0x04ab));}sub setWrongPlatformLicenseForPackage{(
$isWrongPlatformLicenseForPackage=(0x0b00+ 2037-0x12f4));}sub 
enableDirectConnections{($directConnections=(0x0aca+ 7134-0x26a7));}sub 
disableDirectConnections{($directConnections=(0x1323+ 2308-0x1c27));}sub 
enableServerAvailableAsRemoteNode{($serverAvailableAsRemoteNode=
(0x1a95+ 2284-0x2380));}sub enableServerAvailableAsRemoteServer{(
$serverAvailableAsRemoteServer=(0x1dc7+ 593-0x2017));}sub enableRdpFeature{(
$rdpFeature=(0x0cfa+ 4895-0x2018));}sub enableVirtualSessionsFeature{(
$virtualSessionsFeature=(0x13e8+ 684-0x1693));}sub enableX11SessionsFeature{(
$x11SessionsFeature=(0x1519+ 3655-0x235f));}sub enableGuestsFeature{(
$guestsFeature=(0x017c+ 6533-0x1b00));}sub enableProfilesFeature{(
$profilesFeature=(0x01a3+ 2553-0x0b9b));}sub enableMultiNodeFeature{(
$multinodeFeature=(0x1fd5+ 1492-0x25a8));}sub enableTerminalServerNodeSelect{(
$terminalNodeSelectFeature=(0x066f+ 875-0x09d9));}sub enableMultiserverFeature{(
$multiserverFeature=(0x0389+ 3318-0x107e));}sub enableKillingLeftoverCMonStarup{
($killingLeftoverCMonStarup=(0x0c2f+ 4352-0x1d2e));}sub enableGroupsFeature{(
$groupsFeature=(0x0862+ 7452-0x257d));}sub enableRedirectFeature{(
$redirectFeature=(0x05a2+ 241-0x0692));}sub enableHttpdSupportFeature{(
$httpdSupportFeature=(0x1561+ 1502-0x1b3e));}sub enableClusterFeature{(
$clusterFeature=(0x08d7+ 1348-0x0e1a));}sub enableClusterCreateFeature{(
$clusterCreateFeature=(0x1b18+ 2346-0x2441));}sub 
enableAutomaticRecordingFeature{($automaticRecordingFeature=
(0x1a47+ 2504-0x240e));}sub enableSshFeature{($sshFeature=(0x1320+ 780-0x162b));
}sub enableNxFrameBufferFeature{($nxFrameBufferFeature=(0x0ff5+ 5454-0x2542));}
sub enableGuestAccessFeature{($guestAccessFeature=(0x06f3+ 6795-0x217d));}sub 
isGuestAccessFeature{return ($guestAccessFeature);}sub 
enableVisitorAccessFeature{($visitorAccessFeature=(0x2057+ 1167-0x24e5));}sub 
isVisitorAccessFeature{return ($visitorAccessFeature);}sub 
isGuestAccessFeatureEnabled{if (isGuestAccessFeature ()){(my $key=lc (
$GLOBAL::PhysicalDesktopAccessNodes));if ((($key=~ /guest/ )or ($key=~ /all/ )))
{return ((0x12c9+ 925-0x1665));}($key=lc ($GLOBAL::VirtualDesktopAccessNodes));
if ((($key=~ /guest/ )or ($key=~ /all/ ))){return ((0x0eb0+ 2958-0x1a3d));}if ((
$__guestAccessLogged!=(0x0720+ 2164-0x0f93))){Logger::debug (((((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x47\x75\x65\x73\x74\x20\x61\x63\x63\x65\x73\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x27"
.$GLOBAL::PhysicalDesktopAccessNodes)."\x27\x20\x27").
$GLOBAL::VirtualDesktopAccessNodes)."\x27\x2e"));($__guestAccessLogged=
(0x01d0+ 2297-0x0ac8));}return ((0x0077+ 4535-0x122e));}return (
(0x0185+ 1443-0x0728));}sub isVisitorAccessFeatureEnabled{if (
isVisitorAccessFeature ()){(my $key=lc ($GLOBAL::PhysicalDesktopAccessNodes));if
 ((($key=~ /visitor/ )or ($key=~ /all/ ))){return ((0x0966+ 711-0x0c2c));}($key=
lc ($GLOBAL::VirtualDesktopAccessNodes));if ((($key=~ /visitor/ )or ($key=~ /all/ )
)){return ((0x0f64+ 4704-0x21c3));}if (($__visitorAccessLogged==
(0x0f4a+ 4251-0x1fe4))){Logger::debug (((((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x56\x69\x73\x69\x74\x6f\x72\x20\x61\x63\x63\x65\x73\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x27"
.$GLOBAL::PhysicalDesktopAccessNodes)."\x27\x20\x27").
$GLOBAL::VirtualDesktopAccessNodes)."\x27\x2e"));($__visitorAccessLogged=
(0x169c+ 1806-0x1da9));}return ((0x0ddc+ 3266-0x1a9e));}return (
(0x102f+ 4409-0x2168));}sub isGuestAccessFeatureDisabled{return ((!
isGuestAccessFeatureEnabled ()));}sub isNodeAccessAvailbleForGuest{if ((
$GLOBAL::EnableGuestAccessNode eq "\x30")){return ((0x0288+ 7892-0x215c));}(my $key
=lc ($GLOBAL::PhysicalDesktopAccessNodes));if (((($key=~ /visitor/ )or ($key=~ /all/ )
)or ($key=~ /guest/ ))){return ((0x0a2f+ 4870-0x1d34));}($key=lc (
$GLOBAL::VirtualDesktopAccessNodes));if (((($key=~ /visitor/ )or ($key=~ /all/ )
)or ($key=~ /guest/ ))){return ((0x229d+ 194-0x235e));}Logger::debug (((((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x67\x75\x65\x73\x74\x20\x27"
.$GLOBAL::PhysicalDesktopAccessNodes)."\x27\x20\x27").
$GLOBAL::VirtualDesktopAccessNodes)."\x27\x2e"));return ((0x0c38+ 2030-0x1426));
}sub enablePhysicalGuestDesktopSharingFeature{(
$physicalGuestDesktopSharingFeature=(0x2343+ 505-0x253b));}sub 
isPhysicalGuestDesktopSharingFeature{return ($physicalGuestDesktopSharingFeature
);}sub isPhysicalGuestDesktopSharingFeatureEnabled{main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");if ((
isPhysicalGuestDesktopSharingFeature ()and 
NXLocalSession::isPhysicalDesktopAccessAvailbleForGuest ())){return (
(0x1779+ 2949-0x22fd));}return ((0x0e65+   7-0x0e6c));}sub 
isPhysicalGuestDesktopSharingFeatureDisabled{main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");if ((
isPhysicalGuestDesktopSharingFeature ()and (not (
NXLocalSession::isPhysicalDesktopAccessAvailbleForGuest ())))){return (
(0x1d31+ 1970-0x24e2));}return ((0x143a+ 2711-0x1ed1));}sub 
enableVirtualGuestDesktopSharingFeature{Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x45\x6e\x61\x62\x6c\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x67\x75\x65\x73\x74\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x66\x65\x61\x74\x75\x72\x65\x2e"
);($virtualGuestDesktopSharingFeature=(0x1518+ 1970-0x1cc9));}sub 
isVirtualGuestDesktopSharingFeature{return ($virtualGuestDesktopSharingFeature);
}sub isVirtualGuestDesktopSharingFeatureEnabled{main::nxrequire (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73");
if ((isVirtualGuestDesktopSharingFeature ()and 
NXSessionParameters::isVirtualDesktopAccessAvailbleForGuest ())){return (
(0x0a1d+ 3112-0x1644));}return ((0x0df9+ 673-0x109a));}sub 
isVirtualGuestDesktopSharingFeatureDisabled{main::nxrequire (
"\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73");
if ((isVirtualGuestDesktopSharingFeature ()and (not (
NXSessionParameters::isVirtualDesktopAccessAvailbleForGuest ())))){return (
(0x018a+ 6332-0x1a45));}return ((0x159d+ 1739-0x1c68));}sub 
enableSubCloudServersFeature{($subCloudServersFeature=(0x009f+ 1394-0x0610));}
sub enableForeignServersFeature{($foreignServersFeature=(0x0952+ 6434-0x2273));}
sub enableNotSystemUserFeature{($notSystemUserFeature=(0x0565+ 7173-0x2169));}
sub enableNodeSynchronization{($nodeSynchronization=(0x0252+ 1223-0x0718));}sub 
enableGuestsForNode{($guestForNode=(0x006b+ 233-0x0153));}sub 
isGuestsForNodeEnabled{if (($guestForNode==(0x0472+ 7376-0x2141))){Logger::debug
 (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x47\x75\x65\x73\x74\x73\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x61\x72\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x2e"
);return ((0x08c6+ 6426-0x21df));}return ((0x10a4+ 3506-0x1e56));}sub 
isGuestsForNodeDisabled{return ((!isGuestsForNodeEnabled ()));}sub 
disableSshFeature{($sshFeature=(0x11b6+ 1338-0x16f0));}sub isRdpFeature{return (
$rdpFeature);}sub isDirectConnectionFeature{return ($directConnections);}sub 
isServerAvailableAsRemoteServer{return ($serverAvailableAsRemoteServer);}sub 
isServerAvailableAsRemoteNode{return ($serverAvailableAsRemoteNode);}sub 
isVirtualSessionsFeature{return ($virtualSessionsFeature);}sub 
isX11SessionsFeature{return ($x11SessionsFeature);}sub isGuestFeature{return (
$guestsFeature);}sub isNotGuestFeature{return ((!isGuestFeature ()));}sub 
isGuestFeatureEnabled{if ((isGuestFeature ()and (
$GLOBAL::EnableGuestCreateVirtualDesktop==(0x06af+ 1424-0x0c3e)))){return (
(0x1c92+  91-0x1cec));}return ((0x03df+ 6066-0x1b91));}sub isProfilesFeature{
return ($profilesFeature);}sub isNotProfilesFeature{return ((!isProfilesFeature 
()));}sub isMultiNodeFeature{return ($multinodeFeature);}sub 
isMultiServerFeature{return ($multiserverFeature);}sub 
isTerminalNodeSelectFeature{return ($terminalNodeSelectFeature);}sub 
isNotMultiServerFeature{return ((!isMultiServerFeature ()));}sub 
isKillingLeftoverCMonStarup{return ($killingLeftoverCMonStarup);}sub 
isNotMultiNodeFeature{return ((!isMultiNodeFeature ()));}sub isGroupsFeature{
return ($groupsFeature);}sub isNotGroupsFeature{return ((!isGroupsFeature ()));}
sub isRedirectFeature{return ($redirectFeature);}sub isNotRedirectFeature{return
 ((!isRedirectFeature ()));}sub isHttpdSupportFeature{return (
$httpdSupportFeature);}sub isClusterFeature{return ($clusterFeature);}sub 
isClusterCreateFeature{return ($clusterCreateFeature);}sub 
isAutomaticRecordingFeature{return ($automaticRecordingFeature);}sub 
isNotHttpdSupportFeature{return ((!isHttpdSupportFeature ()));}sub isSshFeature{
return ($sshFeature);}sub isNxFrameBufferFeature{return ($nxFrameBufferFeature);
}sub isVirtualSharingFeature{return ($virtualSharingFeature);}sub 
isSubCloudServerFeature{return ($subCloudServersFeature);}sub 
isForeignServersFeature{return ($foreignServersFeature);}sub 
isNotForeignServersFeature{return ((!isForeignServersFeature ()));}sub 
isNotsshFeature{return ((!isSshFeature ()));}sub isNotSystemUserFeature{return (
$notSystemUserFeature);}sub isNodeSynchronization{return ($nodeSynchronization);
}sub isEnterpriseServer{return ($EnterpriseServer);}sub 
isEnterpriseTerminalServer{return ($EnterpriseTerminalServer);}sub 
getConnectionsLimit{return ($GLOBAL::licenseConnectionsLimit);}sub 
getVirtualSessionLimit{if (isNxFrameBufferFeature ()){return (
(0x05f9+ 1315-0x0b1b));}return ($LicenseVirtualDesktopsLimit);}sub 
__setUpdateMode{(my $mode=(shift (@_)||(0x1d78+ 2355-0x26aa)));(
$defaultUpdateMode=$mode);}sub getUpdateMode{return ($defaultUpdateMode);}sub 
checkNodeLicence{(my (@command)=($GLOBAL::CommandNXNode,
"\x2d\x2d\x76\x65\x72\x73\x69\x6f\x6e"));(my (@param)=());(my ($std_err,$std_out
,$ret_val)=main::run_command ((\@command),(\@param)));if (($std_out=~ /NXNODE - Version/ )
){return ((0x0b09+ 4245-0x1b9e));}else{main::nxwrite (main::nxgetSTDOUT (),
$std_out);return ((0x050c+ 2561-0x0f0c));}}sub readLicenseFile{(my $licensePath=
shift (@_));my ($license);Logger::debug (((
"\x52\x65\x61\x64\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x77\x69\x74\x68\x20\x65\x66\x66\x65\x63\x74\x69\x76\x65\x20\x75\x69\x64\x20\x27"
.$>)."\x27\x2e"));if ((defined ($licensePath)and ($licensePath ne ("")))){(
$license=$licensePath);Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x47\x69\x76\x65\x6e\x20\x70\x61\x74\x68\x20\x74\x6f\x20\x74\x68\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$license)."\x2e"));}else{($license=$GLOBAL::PRODUCT_KEY_FILE);Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x50\x61\x74\x68\x20\x74\x6f\x20\x74\x68\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$license)."\x2e"));}(my $mode=Common::NXCore::NXFileMode ($license));if ((not (
defined ($mode)))){Logger::error (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x66\x69\x6c\x65\x3a\x20\x27"
.$license)."\x27\x20\x64\x6f\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));
return ("\x4d\x69\x73\x73\x65\x64");}if ((($mode&(0x1050+ 5517-0x15de))ne 
(0x0238+ 4537-0x12f1))){Logger::warning ((((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$license).
"\x27\x20\x68\x61\x73\x20\x77\x72\x6f\x6e\x67\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x2e"
).
"\x20\x43\x6f\x72\x72\x65\x63\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x61\x72\x65\x20\x30\x34\x30\x30\x2e"
));}(my $content=(""));(my $FILE=main::nxopen ($license,$NXBits::O_RDONLY,
(0x0695+ 6546-0x2027),{"\x45\x41\x43\x43\x45\x53","\x73\x69\x6c\x65\x6e\x74"}));
if ($FILE){while (main::nxreadLine ($FILE,(\$_))){($content.=$_);}main::nxclose 
($FILE);}else{if (($>eq (0x1b2c+ 2482-0x24de))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());if ((
$errorNumber eq Common::NXCore::ErrnoENOENT ())){return (
"\x4d\x69\x73\x73\x65\x64");}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$license)."\x27\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20".$errorNumber)."\x20\x27").$errorString).
"\x27\x2e"));NXMsg::error (
"\x65\x52\x65\x61\x64\x69\x6e\x67\x54\x68\x65\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4f\x6e\x54\x68\x65\x53\x65\x72\x76\x65\x72"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");NXShell::handle_command (
"\x65\x78\x69\x74");}}(my (@command)=$GLOBAL::CommandNXexec);push (@command,
"\x2d\x2d\x73\x65\x72\x76\x65\x72\x6c\x69\x63\x65\x6e\x73\x65");(my (@params)=()
);push (@params,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");(my (
$cmd_err,$cmd_out,$exit_value)=main::nxRunCommand ((\@command),(\@params)));if (
$exit_value){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x73\x73\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$license).
"\x27\x20\x74\x68\x72\x6f\x75\x67\x68\x20\x6e\x78\x65\x78\x65\x63\x2e"));
NXMsg::error (
"\x65\x52\x65\x61\x64\x69\x6e\x67\x54\x68\x65\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4f\x6e\x54\x68\x65\x53\x65\x72\x76\x65\x72"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");NXShell::handle_command (
"\x65\x78\x69\x74");}else{($content=$cmd_out);}}($content=
Common::NXCore::extractLicenseBodyFromLicenseFile ($content));return ($content);
}sub chk_license{(my $subscription_mode=shift (@_));(my $showWarnings=
(0x001c+ 8171-0x2006));if (($subscription_mode eq 
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x2d\x73\x74\x61\x72\x74")){(
$showWarnings=(0x0f63+ 3452-0x1cdf));}if (($subscription_mode eq 
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e")){($subscription_mode=
(0x20e9+ 613-0x234d));}else{($subscription_mode=(0x1dbb+ 388-0x1f3f));}(my (
%parameters)=());($parameters{"\x75\x73\x65\x72\x73"}=(0x00aa+ 4736-0x1329));(
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=
(0x0ab2+ 4465-0x1c22));(my $content=readLicenseFile ());if (($content ne 
"\x4d\x69\x73\x73\x65\x64")){($isNoLicenseFile=(0x1129+ 5471-0x2688));
setLicenseParameters ($content,(\%parameters));if (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4e\x6f\x74\x56\x61\x6c\x69\x64")){($isNoLicenseFile=(0x0872+ 6566-0x2217));
goto CONFIG_END;}checkNXProduct ((\%parameters));($GLOBAL::FLAG_SEND_PRODUCT_KEY
=(0x0029+ 2293-0x091d));}else{($isNoLicenseFile=(0x059a+ 5070-0x1967));
setMissedLicenseParameters ($content,(\%parameters));}Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x50\x72\x6f\x64\x75\x63\x74\x20\x49\x44\x20\x27"
.$parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"})."\x27\x2e"));if (
libnxh::NXIsNomachineFreeServer ($__acronymId)){enableX11SessionsFeature ();
enablePhysicalGuestDesktopSharingFeature ();enableNxFrameBufferFeature ();
__setUpdateMode ((0x09e1+ 299-0x0b0a));if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x1025+ 4872-0x232d))){(
$GLOBAL::licenseConnectionsLimit=(0x01ec+ 6077-0x19a9));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}else{(
$GLOBAL::licenseConnectionsLimit=(0x02e7+ 7510-0x203c));}
changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if (($users=~ /^-?\d/ )
){($GLOBAL::USERS_LIMIT=$parameters{"\x75\x73\x65\x72\x73"});}else{(
$GLOBAL::USERS_LIMIT=(0x0de9+ 1305-0x1302));}($GLOBAL::PRODUCT_MARK=
$GLOBAL::PRODUCT_ID);($GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});
enableCustomFreeSubscriptionMessage ();setIgnoreRolesConfigKeys ();}elsif ((((((
(((libnxh::NXIsEnterpriseServer ($__acronymId)or libnxh::NXIsCloudServer (
$__acronymId))or libnxh::NXIsQuickServer ($__acronymId))or 
libnxh::NXIsNomachineNetworkServer ($__acronymId))or 
libnxh::NXIsEnterpriseTerminalServer ($__acronymId))or 
libnxh::NXIsEnterpriseCloudServer ($__acronymId))or 
libnxh::NXIsEnterpriseTerminalServerCluster ($__acronymId))or 
libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId))or 
libnxh::NXIsSmallBusinessCloudServer ($__acronymId))){if (
libnxh::NXIsEnterpriseServer ($__acronymId)){($GLOBAL::PRODUCT_NAME=~ s/NoMachine Portal Server/NoMachine Enterprise Terminal Server/ )
;($GLOBAL::PRODUCT_NAME=~ s/NoMachine Enterprise Server/NoMachine Enterprise Terminal Server/ )
;enableVirtualSessionsFeature ();enableMultiNodeFeature ();($parameters{
"\x70\x72\x6f\x64\x75\x63\x74"}=$GLOBAL::PRODUCT_NAME);}elsif ((((
libnxh::NXIsCloudServer ($__acronymId)or libnxh::NXIsEnterpriseCloudServer (
$__acronymId))or libnxh::NXIsSmallBusinessCloudServer ($__acronymId))or 
libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId))){if ((
$SubscriptionVersion==(0x05c1+ 707-0x087d))){($GLOBAL::PRODUCT_NAME=~ s/NoMachine Cloud Server/NoMachine Enterprise Cloud Server/ )
;($parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}="\x45\x43\x53");(
$GLOBAL::PRODUCT_ID=($parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}
.$parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($__acronymId=
libnxh::NXParseServerProductId ($parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}enableMultiserverFeature ();
enableKillingLeftoverCMonStarup ();enableGuestAccessFeature ();
enableVisitorAccessFeature ();}if ((libnxh::NXIsEnterpriseCloudServer (
$__acronymId)or libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId))){
enableRedirectFeature ();enableClusterFeature ();enableSubCloudServersFeature ()
;enableForeignServersFeature ();}if ((libnxh::NXIsEnterpriseTerminalServer (
$__acronymId)or libnxh::NXIsEnterpriseTerminalServerCluster ($__acronymId))){
enableMultiNodeFeature ();enableVirtualSessionsFeature ();enableRedirectFeature 
();enableClusterFeature ();enableGuestsFeature ();
enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableTerminalServerNodeSelect ();}if
 ((libnxh::NXIsEnterpriseTerminalServerCluster ($__acronymId)or 
libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId))){
enableClusterCreateFeature ();}enableServerAvailableAsRemoteServer ();
enableReverseClientFeture ();enableRdpFeature ();enableX11SessionsFeature ();
enableProfilesFeature ();enableGroupsFeature ();enableRedirectFeature ();
enableSshFeature ();enableAutomaticRecordingFeature ();if ((not (
libnxh::NXIsNomachineNetworkServer ($__acronymId)))){enableHttpdSupportFeature 
();}if (($parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq 
(0x14c7+ 2589-0x1ee4))){($GLOBAL::licenseConnectionsLimit=(0x0bbc+ 663-0x0e53));
}elsif (($parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )
){($GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});if (($GLOBAL::ConnectionsLimit>
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"})){(
$GLOBAL::ConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}}else{(
$GLOBAL::licenseConnectionsLimit=(0x101c+ 5078-0x23ee));if ((
$GLOBAL::ConnectionsLimit>(0x0229+ 7441-0x1f36))){($GLOBAL::ConnectionsLimit=
(0x0fc1+ 1224-0x1485));}}changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x1a97+ 2478-0x2445));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif (
libnxh::NXIsEnterpriseDesktop ($__acronymId)){
enableServerAvailableAsRemoteServer ();enableReverseClientFeture ();
enableX11SessionsFeature ();enableSshFeature ();enableHttpdSupportFeature ();
enableAutomaticRecordingFeature ();enablePhysicalGuestDesktopSharingFeature ();
enableRedirectFeature ();enableGroupsFeature ();enableNxFrameBufferFeature ();if
 (($parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq 
(0x0125+ 342-0x027b))){($GLOBAL::licenseConnectionsLimit=(0x1ae6+ 453-0x1cab));}
elsif (($parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ ))
{($GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});if (($GLOBAL::ConnectionsLimit>
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"})){(
$GLOBAL::ConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}}else{(
$GLOBAL::licenseConnectionsLimit=(0x134c+ 4150-0x237e));if ((
$GLOBAL::ConnectionsLimit>(0x0005+ 7796-0x1e75))){($GLOBAL::ConnectionsLimit=
(0x12e2+ 4989-0x265b));}}changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x0eeb+ 2703-0x197a));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif (
libnxh::NXIsTerminalServer ($__acronymId)){enableVirtualSessionsFeature ();
enableX11SessionsFeature ();enableSshFeature ();enableGuestsFeature ();
enableProfilesFeature ();enableGroupsFeature ();enableRdpFeature ();
enableHttpdSupportFeature ();enableServerAvailableAsRemoteServer ();
enableReverseClientFeture ();enableAutomaticRecordingFeature ();
enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableRedirectFeature ();if ((
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq 
(0x051a+ 3388-0x1256))){($GLOBAL::licenseConnectionsLimit=(0x0968+  60-0x09a4));
}elsif (($parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )
){($GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});if (($GLOBAL::ConnectionsLimit>
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"})){(
$GLOBAL::ConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}}else{(
$GLOBAL::licenseConnectionsLimit=(0x08bb+ 4415-0x19f6));if ((
$GLOBAL::ConnectionsLimit>(0x09b1+ 6578-0x235f))){($GLOBAL::ConnectionsLimit=
(0x03cf+ 8306-0x243d));}}changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x02a6+ 3114-0x0ed0));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif ((
libnxh::NXIsSmallBusinessServer ($__acronymId)or 
libnxh::NXIsSmallBusinessTerminalServer ($__acronymId))){if ((
$SubscriptionVersion==(0x0666+ 7158-0x2255))){($GLOBAL::PRODUCT_NAME=~ s/NoMachine Small Business Server/NoMachine Small Business Terminal Server/ )
;($parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}="\x53\x42\x54\x53");(
$GLOBAL::PRODUCT_ID=($parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}
.$parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($__acronymId=
libnxh::NXParseServerProductId ($parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}
enableServerAvailableAsRemoteServer ();enableReverseClientFeture ();
enableVirtualSessionsFeature ();enableX11SessionsFeature ();enableSshFeature ();
enableHttpdSupportFeature ();enableAutomaticRecordingFeature ();
enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableRedirectFeature ();
enableGroupsFeature ();if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x185f+ 2919-0x23c6))){(
$GLOBAL::licenseConnectionsLimit=(0x0ae6+  32-0x0b06));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});if (($GLOBAL::ConnectionsLimit>
$parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"})){(
$GLOBAL::ConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}}else{(
$GLOBAL::licenseConnectionsLimit=(0x0079+ 2860-0x0ba1));if ((
$GLOBAL::ConnectionsLimit>(0x0a31+ 2529-0x140e))){($GLOBAL::ConnectionsLimit=
(0x1553+ 2766-0x201d));}}changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x009a+ 3030-0x0c70));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif ((
libnxh::NXIsTerminalServerNode ($__acronymId)or 
libnxh::NXIsEnterpriseTerminalServerNode ($__acronymId))){if (
libnxh::NXIsTerminalServerNode ($__acronymId)){if (($SubscriptionVersion<=
(0x1a70+ 2179-0x22ec))){($GLOBAL::PRODUCT_NAME=~ s/NoMachine Terminal Server Node/NoMachine Enterprise Terminal Server Node/ )
;($parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}="\x45\x54\x53\x4e");(
$GLOBAL::PRODUCT_ID=($parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}
.$parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($__acronymId=
libnxh::NXParseServerProductId ($parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}}enableRdpFeature ();
enableVirtualSessionsFeature ();enableX11SessionsFeature ();enableSshFeature ();
disableDirectConnections ();enableServerAvailableAsRemoteNode ();
enableAutomaticRecordingFeature ();enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableGuestsFeature ();
enableGuestsForNode ();if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x1a0f+ 2266-0x22e9))){(
$GLOBAL::licenseConnectionsLimit=(0x0601+ 1409-0x0b82));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}
changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x0651+ 1192-0x0af9));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}elsif (
libnxh::NXIsWorkstation ($__acronymId)){enableVirtualSessionsFeature ();
enableX11SessionsFeature ();enableSshFeature ();enableHttpdSupportFeature ();
enableServerAvailableAsRemoteServer ();enableReverseClientFeture ();
enableAutomaticRecordingFeature ();enablePhysicalGuestDesktopSharingFeature ();
enableVirtualGuestDesktopSharingFeature ();enableRedirectFeature ();
enableGroupsFeature ();if (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}eq (0x1a74+ 1146-0x1eee))){(
$GLOBAL::licenseConnectionsLimit=(0x0ed1+ 5965-0x261e));}elsif (($parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /^-?\d/ )){(
$GLOBAL::licenseConnectionsLimit=$parameters{
"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"});}
changeVirtualDesktopsLimitToLicense ($parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"});if ((
$parameters{"\x75\x73\x65\x72\x73"}=~ /^-?\d/ )){($GLOBAL::USERS_LIMIT=
$parameters{"\x75\x73\x65\x72\x73"});}else{($GLOBAL::USERS_LIMIT=
(0x139a+ 931-0x173d));}($GLOBAL::PRODUCT_MARK=$GLOBAL::PRODUCT_ID);(
$GLOBAL::SUBSCRIPTION_ID=$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"});}else{
Logger::error (
"\x4e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x6c\x69\x63\x65\x6e\x73\x65\x2e"
);NXMsg::error (
"\x65\x47\x55\x49\x49\x6e\x76\x61\x6c\x69\x64\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"
);main::nxexit ((0x04c6+ 6950-0x1fec));}updateLicenseDependantConfigKeys ();
checkLegacyPortKeys ();CONFIG_END:Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}).
"\x27\x2e"));if (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4d\x69\x73\x73\x65\x64")){NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4e\x6f\x74\x45\x78\x69\x73\x74"
);}elsif (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4e\x6f\x74\x56\x61\x6c\x69\x64")){NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);}elsif ((($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4e\x6f\x6e\x65")and isCustomFreeSubscriptionMessage ())){if (
$subscription_mode){Common::NXMsg::send_response (
"\x77\x43\x6d\x64\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x46\x72\x65\x65"
);}}elsif (((($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x4e\x6f\x6e\x65")or ($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x50\x61\x72\x74\x6e\x65\x72"))or ($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x44\x65\x76\x65\x6c\x6f\x70\x65\x72"))){if ($subscription_mode){NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x55\x6e\x73\x75\x62\x73\x63\x72\x69\x62\x65\x64"
);}}elsif (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e")){setEvaluation ();if (
$subscription_mode){Common::NXMsg::send_response (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e"
,$parameters{"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"});}}
elsif (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64")){if (
$showWarnings){NXMsg::error (
"\x65\x47\x55\x49\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");}setEvaluationPeriodExpired ();}elsif (
($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x53\x74\x61\x6e\x64\x61\x72\x64")){if ($subscription_mode){
main::subscriptionInfo ($parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"},
$parameters{"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"},
$parameters{"\x70\x65\x72\x69\x6f\x64"},$parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"},
$parameters{"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"});}}
elsif (($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}eq 
"\x53\x74\x61\x6e\x64\x61\x72\x64\x45\x78\x70\x69\x72\x65\x64")){if (
$showWarnings){NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x45\x78\x70\x69\x72\x65\x64"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");}}if (((
$GLOBAL::EnableGuestCreateVirtualDesktop==(0x01fb+ 3000-0x0db2))and 
isNotGuestFeature ())){Logger::warning (
"\x47\x75\x65\x73\x74\x20\x75\x73\x65\x72\x73\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x2e"
);Logger::warning (
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x74\x65\x72\x6d\x73\x20\x61\x6e\x64\x20\x63\x6f\x6e\x64\x69\x74\x69\x6f\x6e\x73\x20\x6f\x66\x20\x79\x6f\x75\x72\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x2e"
);}if ((($GLOBAL::EnableUserProfile eq "\x31")and isNotProfilesFeature ())){
Logger::warning (
"\x50\x72\x6f\x66\x69\x6c\x65\x73\x20\x61\x72\x65\x20\x6e\x6f\x74\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x2e"
);Logger::warning (
"\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x74\x65\x72\x6d\x73\x20\x61\x6e\x64\x20\x63\x6f\x6e\x64\x69\x74\x69\x6f\x6e\x73\x20\x6f\x66\x20\x79\x6f\x75\x72\x20\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x2e"
);}return ($parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"});}sub 
changeVirtualDesktopsLimitToLicense{(my $virtualDesktops=shift (@_));(my $limit=
__getFromLicenseVirtualSessionLimit ($virtualDesktops));(
$LicenseVirtualDesktopsLimit=$limit);}sub checkNodeProductID{(my $node_id=shift 
(@_));(my $server_id=shift (@_));if (($node_id=~ /^$server_id(EN|N|SN|PSN)$/ )){
return ((0x0d31+ 1273-0x1229));}(my $serverAcronymId=
libnxh::NXParseServerProductId ($server_id));(my $nodeAcronymId=
libnxh::NXParseNodeProductId ($node_id));if ((libnxh::NXIsEnterpriseServer (
$serverAcronymId)and libnxh::NXIsEnterpriseDesktopNode ($nodeAcronymId))){return
 ((0x03f5+ 7078-0x1f9a));}return ((0x0985+ 7372-0x2651));}sub 
load_system_settings{Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4c\x6f\x61\x64\x20\x73\x79\x73\x74\x65\x6d\x20\x73\x65\x74\x74\x69\x6e\x67\x73\x2e"
);if (isProfilesFeature ()){if (__ifUserNXOrAdmin ()){if (
NXProfilesManager::isProfilesEnabled ()){($GLOBAL::EnableUserProfile=
(0x0225+ 3450-0x0f9e));}else{($GLOBAL::EnableUserProfile=(0x032f+ 4208-0x139f));
}}else{($GLOBAL::EnableUserProfile=(0x0e87+ 5542-0x242d));}}if (
isGuestsForNodeEnabled ()){($GLOBAL::EnableGuestCreateVirtualDesktop=
(0x13ac+ 407-0x1542));}loadWelcomeString ();}sub __ifUserNXOrAdmin{return ((($>
eq (0x1f1f+  39-0x1f46))||(Common::NXCore::getEffectiveUsername ()eq "\x6e\x78")
));}sub loadWelcomeString{if ((defined ($GLOBAL::LICENSE)and length (
$GLOBAL::LICENSE))){if (($GLOBAL::LICENSE eq "\x4e\x6f\x6e\x65")){(
$GLOBAL::WELCOME_STR=((((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").$GLOBAL::PRODUCT_MARK));(
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}elsif 
((($GLOBAL::LICENSE eq "\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e")or (
$GLOBAL::LICENSE eq 
"\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"))){(
$GLOBAL::WELCOME_STR=(((((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").$GLOBAL::PRODUCT_MARK).
"\x20\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e"));($GLOBAL::MESSAGES_FORMAT{
$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}elsif (($GLOBAL::LICENSE eq 
"\x4d\x69\x73\x73\x65\x64")){($GLOBAL::WELCOME_STR=((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION));($GLOBAL::CLIENT_WELCOME_STR=(((
$GLOBAL::SOFTWARE_NAME."\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").
$GLOBAL::SOFTWARE_MAJ_VERSION).$GLOBAL::SOFTWARE_MIN_VERSION));(
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}elsif 
(($GLOBAL::LICENSE eq "\x53\x74\x61\x6e\x64\x61\x72\x64")){($GLOBAL::WELCOME_STR
=((((($GLOBAL::SOFTWARE_NAME."\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").
$GLOBAL::SOFTWARE_MAJ_VERSION).$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").
$GLOBAL::PRODUCT_MARK));($GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=
$GLOBAL::WELCOME_STR);}elsif (($GLOBAL::LICENSE eq 
"\x53\x74\x61\x6e\x64\x61\x72\x64\x45\x78\x70\x69\x72\x65\x64")){(
$GLOBAL::WELCOME_STR=((((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").$GLOBAL::PRODUCT_MARK));(
$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_WELCOME_STR}=$GLOBAL::WELCOME_STR);}(
$GLOBAL::LONG_WELCOME_STR=((($GLOBAL::PRODUCT_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION));($GLOBAL::MESSAGES_FORMAT{
$GLOBAL::LONG_WELCOME_STR}=$GLOBAL::LONG_WELCOME_STR);(
$GLOBAL::CLIENT_WELCOME_STR=((((($GLOBAL::SOFTWARE_NAME.
"\x20\x2d\x20\x56\x65\x72\x73\x69\x6f\x6e\x20").$GLOBAL::SOFTWARE_MAJ_VERSION).
$GLOBAL::SOFTWARE_MIN_VERSION)."\x20\x2d\x20").$GLOBAL::PRODUCT_NAME));}else{
NXShell::handle_command ("\x65\x78\x69\x74");}}sub 
__getFromLicenseVirtualSessionLimit{(my $valueFromLicense=shift (@_));if ((
$valueFromLicense eq (0x20d8+ 1339-0x2613))){return ((0x0df5+ 2277-0x16da));}
elsif (($valueFromLicense=~ /^-?\d/ )){return ($valueFromLicense);}else{return (
(-(0x0cab+ 3426-0x1a0c)));}}sub Activate{(my $activateFile=shift (@_));(my $destination
=__findDestination ($activateFile));if ((not (defined ($destination)))){return (
(0x1bb7+ 1837-0x22e3));}if (__backupLicenseFile ($destination)){return (
(0x0a32+ 206-0x0aff));}if (__copyLicToDestination ($activateFile,$destination)){
return ((0x0156+ 1647-0x07c4));}my ($errorName);my ($errorCode);if ((
$destination ne $cloudLicFile)){if ((Common::NXFile::setOwnershipForUserNX (
$destination,(\$errorName),(\$errorCode))==(-(0x0be4+ 2465-0x1584)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x4f\x77\x6e\x65\x72\x73\x68\x69\x70",
"\x4e\x58\x53\x68\x65\x6c\x6c",(($destination."\x2e\x20").$errorName));return (
(0x1f2d+ 592-0x217c));}if ((Common::NXFile::setPermissionReadOnlyForNX (
$destination,(\$errorName),(\$errorCode))==(-(0x05c8+  23-0x05de)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4e\x58\x53\x68\x65\x6c\x6c",(($destination."\x2e\x20").$errorName));return (
(0x0eb6+ 4784-0x2165));}}else{(my (@htdUsers)=NXTools::getNXHtdUser ());(my $user
=$htdUsers[(0x08e6+ 3399-0x162d)]);if ((Common::NXFile::setOwnershipForUser (
$destination,$user,(\$errorName),(\$errorCode))==(-(0x2418+ 578-0x2659)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x4f\x77\x6e\x65\x72\x73\x68\x69\x70",
"\x4e\x58\x53\x68\x65\x6c\x6c",(($destination."\x2e\x20").$errorName));return (
(0x191c+ 2173-0x2198));}if ((Common::NXFile::setPermissionsReadOnlyForUser (
$destination,$user,(\$errorName),(\$errorCode))==(-(0x029a+ 6052-0x1a3d)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4e\x58\x53\x68\x65\x6c\x6c",(($destination."\x2e\x20").$errorName));return (
(0x04a8+ 5639-0x1aae));}}main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);NXClientSystemDaemons::sendToServerDaemonNewLicenseActivated ();if ((not (
NXMsg::isMessageRegistered (
"\x69\x4c\x69\x63\x65\x6e\x73\x65\x41\x63\x74\x69\x76\x61\x74\x65\x64")))){
NXMsg::register_response ("\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x69\x4c\x69\x63\x65\x6e\x73\x65\x41\x63\x74\x69\x76\x61\x74\x65\x64",
$GLOBAL::MSG_LICENSE_ACTIVATED);}NXMsg::send_response (
"\x69\x4c\x69\x63\x65\x6e\x73\x65\x41\x63\x74\x69\x76\x61\x74\x65\x64",
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$destination);return (
(0x04b0+ 2879-0x0fef));}sub __backupLicenseFile{(my $orginal=shift (@_));if ((
not (Common::NXFile::fileExists ($orginal)))){return;}(my $backup=($orginal.
"\x2e\x62\x61\x63\x6b\x75\x70"));if (Common::NXFile::fileExists ($backup)){(
$backup.=("\x2d".NXTools::getTimeMs ()));}(my ($retValue,$outMsg)=
Common::NXCore::copyFile ($orginal,$backup));if (($outMsg ne (""))){
NXMsg::send_response (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x70\x79\x54\x6f\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$orginal,$backup,$outMsg);return (
(0x0248+ 1030-0x064d));}my ($errorName);my ($errorCode);if ((
Common::NXFile::setPermissionReadOnlyForNX ($backup,(\$errorName),(\$errorCode))
==(-(0x20a7+ 963-0x2469)))){NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4e\x58\x53\x68\x65\x6c\x6c",(($backup."\x2e\x20").$errorName));return (
(0x0005+ 372-0x0178));}}sub __getMd5FromFile{(my $filename=shift (@_));(my $content
=(""));(my $KEY_FD=main::nxopen ($filename,$NXBits::O_RDONLY,
(0x038d+ 8374-0x2443),{"\x45\x41\x43\x43\x45\x53","\x73\x69\x6c\x65\x6e\x74"}));
while (main::nxreadLine ($KEY_FD,(\$_))){($content.=$_);}main::nxclose ($KEY_FD)
;if (($content ne (""))){return (Common::NXCore::digestMd5Hex ($content));}
return ((""));}sub __copyLicToDestination{(my $source=shift (@_));(my $destination
=shift (@_));if (($source eq $destination)){NXMsg::register_response (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x69\x43\x4d\x44\x4c\x69\x63\x65\x6e\x73\x65\x41\x6c\x72\x65\x61\x64\x79\x41\x63\x74\x69\x76\x65"
,(0x1015+ 391-0x0ec0));NXMsg::send_response (
"\x69\x43\x4d\x44\x4c\x69\x63\x65\x6e\x73\x65\x41\x6c\x72\x65\x61\x64\x79\x41\x63\x74\x69\x76\x65"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$source);return ((0x14a4+ 4143-0x24d2));
}if (Common::NXFile::fileExists ($destination)){(my $source_md5=__getMd5FromFile
 ($source));(my $destination_md5=__getMd5FromFile ($destination));if ((((
$source_md5 ne (""))and ($destination_md5 ne ("")))and ($source_md5 eq 
$destination_md5))){return;}}my ($error);if ((
Common::NXFile::setPermissionsReadWriteForNX ($destination,(\$error))==(-
(0x1992+ 2032-0x2181)))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x70\x79\x54\x6f\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$source,$destination,$error);return (
(0x033d+ 2380-0x0c89));}(my ($retValue,$outMsg)=Common::NXCore::copyFile (
$source,$destination));if (($outMsg ne (""))){NXMsg::send_response (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x70\x79\x54\x6f\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$source,$destination,$outMsg);return (
(0x07f5+ 6633-0x21dd));}Common::NXFile::setPermissionReadOnlyForNX ($destination
);return ((0x09c6+ 1452-0x0f72));}sub getLicense{(my $path=shift (@_));(my $license
=(""));(my $FD=main::nxopen ($path,$NXBits::O_RDONLY,(0x000c+ 4980-0x1380)));if 
((not (defined ($FD)))){return (undef);}while (main::nxreadLine ($FD,(\$_))){(
$license.=$_);}main::nxclose ($FD);return ($license);}sub getServerLicense{
return (getLicense ($GLOBAL::PRODUCT_KEY_FILE));}sub reportServerLicense{(my $KEY_FD
=main::nxopen ($GLOBAL::PRODUCT_KEY_FILE,$NXBits::O_RDONLY,(0x1738+ 317-0x1875))
);if ((not (defined ($KEY_FD)))){main::nxexit ((0x1d59+ 743-0x203f));}else{while
 (main::nxreadLine ($KEY_FD,(\$_))){main::nxwrite (main::nxgetSTDOUT (),$_);}
main::nxclose ($KEY_FD);}}sub __findDestination{(my $file=shift (@_));(my $KEY_FD
=main::nxopen ($file,$NXBits::O_RDONLY,(0x08d0+ 2083-0x10f3)));if ((not (defined
 ($KEY_FD)))){(my $err=$file);(my $errorstring=libnxh::NXGetErrorString ());if (
($errorstring ne (""))){($err.=("\x20".$errorstring));}NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x46\x69\x6c\x65",$err);return (
undef);}(my $platform=(""));(my $productId=(""));(my $platformInNewLicense=(""))
;while (main::nxreadLine ($KEY_FD,(\$_))){if ( /^Platform: +(.*)\n$/ ){(
$platformInNewLicense=$1);}if ( /^Product Id: +(.)(.*)\n$/ ){($platform=$1);(
$productId=$2);}}main::nxclose ($KEY_FD);if ((($platform eq (""))or ($productId 
eq ("")))){NXMsg::register_response ("\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x4c\x69\x63\x65\x6e\x73\x65\x54\x79\x70\x65\x4e\x6f\x74\x52\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64"
,(0x0764+ 6630-0x1f56));NXMsg::send_response (
"\x65\x4c\x69\x63\x65\x6e\x73\x65\x54\x79\x70\x65\x4e\x6f\x74\x52\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65");return (undef);}if (($platform ne 
$GLOBAL::BUILD_PLATFORM)){unless (((($platform eq "\x41")||($platform eq "\x4c")
)and ($GLOBAL::BUILD_PLATFORM eq "\x52"))){NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x6c\x61\x74\x66\x6f\x72\x6d"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$platformInNewLicense,
Common::NXInfo::getOsInfo ());return (undef);}}if ((($productId eq "\x41\x50")or
 ($productId eq "\x41\x50\x53"))){return ($codecLicFile);}(my $acronymId=(""));
if (__isUsingNodeLicenseFile ()){($acronymId=libnxh::NXParseNodeProductId (
$productId));}else{($acronymId=libnxh::NXParseServerProductId ($productId));}if 
(libnxh::NXIsValidAcronymId ($acronymId)){return ($serverLicFile);}
NXMsg::register_response ("\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x4c\x69\x63\x65\x6e\x73\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64",
(0x0b6d+ 4173-0x19c6));NXMsg::send_response (
"\x65\x4c\x69\x63\x65\x6e\x73\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64",
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$productId);return (undef);}sub 
checkRemoteNodeLicense{(my $license=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b".
$license).
"\x5d\x20\x66\x6f\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x2e"
));(my $acronymId=libnxh::NXParseNodeProductId ($license));if ((
libnxh::NXIsEnterpriseTerminalServerNode ($acronymId)or 
libnxh::NXIsTerminalServerNode ($acronymId))){Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x54\x65\x72\x6d\x69\x6e\x61\x6c\x20\x53\x65\x72\x76\x65\x72\x20\x4e\x6f\x64\x65\x2e"
);return ((0x0344+ 7449-0x205c));}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b"
.$license)."\x5d\x2e"));return ((0x0698+ 3515-0x1453));}sub 
checkRemoteServerLicense{(my $license=shift (@_));(my $acronymId=
libnxh::NXParseServerProductId ($license));if (((((((
libnxh::NXIsEnterpriseDesktop ($acronymId)or 
libnxh::NXIsSmallBusinessTerminalServer ($acronymId))or 
libnxh::NXIsEnterpriseTerminalServer ($acronymId))or libnxh::NXIsTerminalServer 
($acronymId))or libnxh::NXIsWorkstation ($acronymId))or 
libnxh::NXIsSmallBusinessServer ($acronymId))or 
libnxh::NXIsEnterpriseTerminalServerCluster ($acronymId))){Logger::debug (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x2e"));return ((0x246b+ 161-0x250b));}if (
isSubCloudServerFeature ()){if ((((libnxh::NXIsEnterpriseCloudServer ($acronymId
)or libnxh::NXIsCloudServer ($acronymId))or libnxh::NXIsSmallBusinessCloudServer
 ($acronymId))or libnxh::NXIsEnterpriseCloudServerCluster ($acronymId))){
Logger::debug (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x20\x77\x69\x74\x68\x20\x73\x75\x62\x63\x6c\x6f\x75\x64\x2e"));
return ((0x0597+ 3034-0x1170));}}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x2e"));return ((0x16b7+ 2215-0x1f5e));}sub 
checkInverseServerLicense{(my $license=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b".
$license).
"\x5d\x20\x66\x6f\x72\x20\x69\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x61\x63\x63\x65\x73\x73\x2e"
));(my $acronymId=libnxh::NXParseServerProductId ($license));if ((((
libnxh::NXIsCloudServer ($acronymId)or libnxh::NXIsEnterpriseCloudServer (
$acronymId))or libnxh::NXIsSmallBusinessCloudServer ($acronymId))or 
libnxh::NXIsEnterpriseCloudServerCluster ($acronymId))){Logger::debug (
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x43\x6c\x6f\x75\x64\x20\x53\x65\x72\x76\x65\x72\x2e"
);return ((0x1ac9+ 1585-0x20f9));}Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b"
.$license)."\x5d\x2e"));return ((0x091f+ 1155-0x0da2));}sub 
remoteVersionAvailableAsNode{(my $version=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x76\x65\x72\x73\x69\x6f\x6e\x20".$version)
.
"\x20\x66\x6f\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x2e"
));if (($version le "\x36")){Logger::warning (
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x36\x20\x6f\x72\x20\x6c\x6f\x77\x65\x72\x2e"
);return ((0x13f1+ 2583-0x1e08));}return ((0x0aa8+ 3900-0x19e3));}sub 
remoteLicenseAndVersionAvailableAsNode{(my $license=shift (@_));(my $version=
shift (@_));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x72\x65\x6d\x6f\x74\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x20\x76\x65\x72\x73\x69\x6f\x6e\x20").$version).
"\x20\x66\x6f\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x2e"
));if (($version le "\x35")){Logger::warning (
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x35\x20\x6f\x72\x20\x6c\x6f\x77\x65\x72\x2e"
);return ((0x18c4+ 2776-0x239c));}if (($license=~ /terminal server node/ )){
Logger::debug (
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x54\x65\x72\x6d\x69\x6e\x61\x6c\x20\x53\x65\x72\x76\x65\x72\x20\x4e\x6f\x64\x65\x2e"
);return ((0x2317+ 994-0x26f8));}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x6e\x6f\x64\x65\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20"
.$license)."\x2e"));return ((0x0542+ 5643-0x1b4d));}sub 
isRemoteServerAvailableAsCluster{(my $license=shift (@_));if (
isLicenseCloudServerCluster ($license)){return ((0x1235+ 4029-0x21f1));}elsif (
isLicenseEnterpriseTerminalServerCluster ($license)){return (
(0x0100+ 9186-0x24e1));}return ((0x2201+ 260-0x2305));}sub 
wasRemoteServerAvailableAsClusterAsV7{(my $license=shift (@_));if (
isLicenseCloudServer ($license)){return ((0x0178+ 1914-0x08f1));}elsif (
isLicenseEnterpriseTerminalServer ($license)){return ((0x04ba+ 4109-0x14c6));}
return ((0x07cf+ 160-0x086f));}sub remoteLicenseAndVersionAvailableAsInverse{(my $license
=shift (@_));(my $version=shift (@_));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x72\x65\x6d\x6f\x74\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x20\x61\x6e\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x27").
$version).
"\x27\x20\x66\x6f\x72\x20\x69\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x61\x63\x63\x65\x73\x73\x2e"
));if ((not (isReverseClientFeture ()))){Logger::warning (
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
);return ((0x0bcf+ 5838-0x229d));}if (($version le "\x37")){Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x20"
.$version)."\x20\x6f\x72\x20\x6c\x6f\x77\x65\x72\x2e"));return (
(0x009c+ 967-0x0463));}if (($license=~ /terminal server node/ )){Logger::warning
 (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x0584+ 603-0x07df));}if (($license=~ /enterprise cloud server/ )
){Logger::debug (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x72\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x2e"));return ((0x0793+ 1276-0x0c8e));}if (($license=~ /cloud server/ )
){if (isMultiServerFeature ()){Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x73\x75\x62\x2d\x63\x6c\x6f\x75\x64\x20\x27"
.$license)."\x27\x2e"));return ((0x0184+ 6420-0x1a98));}Logger::debug (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x2e"));return ((0x1384+ 788-0x1697));}Logger::warning (((
"\x49\x6e\x76\x65\x72\x73\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x129b+ 4520-0x2443));}sub 
remoteLicenseAndVersionAvailableAsServer{(my $license=shift (@_));(my $version=
shift (@_));Logger::debug (((((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x72\x65\x6d\x6f\x74\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x20\x61\x6e\x64\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x27").
$version).
"\x27\x20\x66\x6f\x72\x20\x72\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x61\x63\x63\x65\x73\x73\x2e"
));if (($version le "\x35")){Logger::warning (
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x76\x65\x72\x73\x69\x6f\x6e\x20\x35\x20\x6f\x72\x20\x6c\x6f\x77\x65\x72\x2e"
);return ((0x1d00+ 1563-0x231b));}if (($license=~ /terminal server node/ )){
Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x200a+ 236-0x20f6));}if (($license=~ /cloud server/ )
){if (isSubCloudServerFeature ()){Logger::debug (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x27"
.$license)."\x27\x20\x77\x69\x74\x68\x20\x73\x75\x62\x63\x6c\x6f\x75\x64\x2e"));
return ((0x1a23+ 943-0x1dd1));}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x135b+ 1665-0x19dc));}if ((((($license=~ /enterprise desktop/ )
or ($license=~ /workstation/ ))or ($license=~ /terminal server/ ))or ($license=~ /small business server/ )
)){Logger::debug (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x05e5+ 7737-0x241d));}Logger::warning (((
"\x52\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x61\x6c\x69\x74\x79\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$license)."\x27\x2e"));return ((0x1478+ 3994-0x2412));}sub checkClusterLicense{
(my $license=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b".
$license).
"\x5d\x20\x66\x6f\x72\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x61\x63\x63\x65\x73\x73\x2e"
));(my $acronymId=libnxh::NXParseServerProductId ($license));if ((((
libnxh::NXIsEnterpriseServer ($acronymId)or libnxh::NXIsCloudServer ($acronymId)
)or libnxh::NXIsNomachineNetworkServer ($acronymId))or 
libnxh::NXIsEnterpriseTerminalServer ($acronymId))){Logger::debug (
"\x43\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x45\x6e\x74\x65\x72\x70\x72\x69\x73\x65\x2f\x43\x6c\x6f\x75\x64\x20\x53\x65\x72\x76\x65\x72\x2e"
);return ((0x0fe0+ 3260-0x1c9b));}Logger::warning (((
"\x43\x6c\x75\x73\x74\x65\x72\x20\x6e\x6f\x64\x65\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x5b"
.$license)."\x5d\x2e"));return ((0x1549+ 862-0x18a7));}sub 
errorEvaluationLicenseDuringUpgradeFromV3toV4{NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x55\x70\x67\x72\x61\x64\x65\x46\x72\x6f\x6d\x33\x54\x6f\x34\x4e\x6f\x74\x50\x6f\x73\x73\x69\x62\x6c\x65"
);NXShell::handle_command ("\x65\x78\x69\x74");}sub isEvaluationPeriodExpired{
return ($__evaluationPeriodExpired);}sub setEvaluationPeriodExpired{(
$__evaluationPeriodExpired=(0x080a+ 6768-0x2279));}sub setIgnoreRolesConfigKeys{
($ignoreRolesConfigKeys=(0x20ba+ 1032-0x24c1));}sub isIgnoreRolesConfigKeys{
return ($ignoreRolesConfigKeys);}sub isLicenseTerminalServerNode{(my $licenseString
=lc (shift (@_)));if (($licenseString=~ /terminal server node/ )){return (
(0x1495+ 2145-0x1cf5));}return ((0x0282+ 1912-0x09fa));}sub 
amITerminalServerNode{return (isLicenseTerminalServerNode ($GLOBAL::PRODUCT_NAME
));}sub isLicenseCloudServer{(my $license=lc (shift (@_)));if (($license=~ /cloud server/ )
){return ((0x03d2+ 4487-0x1558));}return ((0x0a5c+ 883-0x0dcf));}sub 
isLicenseCloudServerCluster{(my $license=lc (shift (@_)));if (($license=~ /cloud server cluster/ )
){return ((0x00c1+ 7370-0x1d8a));}return ((0x144f+ 3675-0x22aa));}sub 
amICloudServer{return (isLicenseCloudServer ($GLOBAL::PRODUCT_NAME));}sub 
isLicenseEnterpriseTerminalServer{(my $license=lc (shift (@_)));if (($license=~ /enterprise terminal server/ )
){return ((0x0e4f+ 5871-0x253d));}return ((0x0e25+ 5096-0x220d));}sub 
isLicenseEnterpriseTerminalServerCluster{(my $license=lc (shift (@_)));if ((
$license=~ /enterprise terminal server cluster/ )){return ((0x1282+ 2672-0x1cf1)
);}return ((0x1882+ 1469-0x1e3f));}sub amIEnterpriseTerminalServer{return (
isLicenseEnterpriseTerminalServer ($GLOBAL::PRODUCT_NAME));}sub setEvaluation{(
$__evaluation=(0x2317+ 199-0x23dd));}sub isEvaluation{return ($__evaluation);}
sub __setUsingNodeLicenseFile{($usingNodeLicenseFile=(0x10f8+  60-0x1133));}sub 
__isUsingNodeLicenseFile{return ($usingNodeLicenseFile);}sub 
isNomachineFreeServer{if (libnxh::NXIsNomachineFreeServer ($__acronymId)){return
 ((0x08fb+ 653-0x0b87));}return ((0x1244+ 749-0x1531));}sub 
isTimeForCheckProcessorsCount{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $delay=$__checkProcessorsCountDelay
);if ((($__lastCheckProcessorsCount+$delay)<$currentTime)){return (
(0x0693+ 1284-0x0b96));}return ((0x0263+ 8648-0x242b));}sub checkProcessorsCount
{($__lastCheckProcessorsCount=Common::NXTime::getSecondsSinceEpoch ());(my $procCount
=libnxh::NXGetPhysicalCores ());if ((($licenseProcessorsCount!=
(0x07cc+ 7376-0x249c))and ($procCount>$licenseProcessorsCount))){Logger::warning
 (((("\x59\x6f\x75\x72\x20\x73\x79\x73\x74\x65\x6d\x20\x72\x75\x6e\x73\x20".
$procCount).
"\x20\x63\x6f\x72\x65\x73\x20\x77\x68\x69\x6c\x65\x20\x79\x6f\x75\x72\x20\x6c\x69\x63\x65\x6e\x73\x65\x20"
).(("\x6f\x6e\x6c\x79\x20\x73\x75\x70\x70\x6f\x72\x74\x73\x20".
$licenseProcessorsCount)."\x2e")));}}sub removeLicenseEvents{
NXEvent::removeEvent (NXEvent::getLicenseExpiredEventName ());}sub 
handleLicenseChanged{removeLicenseEvents ();($__evaluationPeriodExpired=
(0x12b5+ 913-0x1646));($__evaluation=(0x1143+ 1274-0x163d));chk_license ();
main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x4d\x6f\x6e\x69\x74\x6f\x72");
NXConnectionMonitor::propagateNewLicense ();
NXConnectionMonitor::propagateNewLicenseToNodes ();(my $message=(
$GLOBAL::MSG_LICENSE_CHANGE.
"\x20\x4c\x69\x63\x65\x6e\x73\x65\x20\x63\x68\x61\x6e\x67\x65\x64\x20"));if (
isNoLicenseFile ()){($message.=
"\x74\x79\x70\x65\x3d\x6d\x69\x73\x73\x69\x6e\x67\x20");if (Server::isCluster ()
){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.Server::getMyUUID ()).
"\x2c\x66\x69\x65\x6c\x64\x3d\x73\x74\x61\x74\x75\x73\x2c\x76\x61\x6c\x75\x65\x3d\x66\x61\x69\x6c\x65\x64\x0a"
));}if (Server::isDaemonProcess ()){NXRedisSubscription::publishToSubscribers (
$message);}}elsif ((isEvaluationPeriodExpired ()or isLicenseExpired ())){(
$message.="\x74\x79\x70\x65\x3d\x65\x78\x70\x69\x72\x65\x64\x20");if (
Server::isCluster ()){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x63\x6c\x75\x73\x74\x65\x72\x2e"
.Server::getMyUUID ()).
"\x2c\x66\x69\x65\x6c\x64\x3d\x73\x74\x61\x74\x75\x73\x2c\x76\x61\x6c\x75\x65\x3d\x66\x61\x69\x6c\x65\x64\x0a"
));}if (Server::isDaemonProcess ()){NXRedisSubscription::publishToSubscribers (
$message);}}else{NXConnectionMonitor::propagateMap ();}}sub 
enableReverseClientFeture{Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x45\x6e\x61\x62\x6c\x65\x20\x72\x65\x76\x65\x72\x73\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x66\x65\x61\x74\x75\x72\x65\x2e"
);($reverseClientFeature=(0x10ea+ 1390-0x1657));}sub isReverseClientFeture{
return ($reverseClientFeature);}sub clearLicenseDependantConfigKeys{(
$GLOBAL::PhysicalDesktopAccess=undef);(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=undef);($GLOBAL::VirtualDesktopAccess
=undef);($GLOBAL::VirtualDesktopAccessNoAcceptance=undef);}sub 
updateLicenseDependantConfigKeys{Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x4c\x69\x63\x65\x6e\x73\x65\x44\x65\x70\x65\x6e\x64\x61\x6e\x74\x43\x6f\x6e\x66\x69\x67\x4b\x65\x79\x73\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27"
.$__acronymId)."\x27\x2e"));if (libnxh::NXIsNomachineFreeServer ($__acronymId)){
if ((not (defined ($GLOBAL::PhysicalDesktopAccess)))){(
$GLOBAL::PhysicalDesktopAccess=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72\x2c\x73\x79\x73\x74\x65\x6d\x2c\x67\x75\x65\x73\x74"
);if (($GLOBAL::PhysicalDesktopSharing eq "\x30")){(
$GLOBAL::PhysicalDesktopAccess="\x6f\x77\x6e\x65\x72");}elsif ((
$GLOBAL::PhysicalDesktopSharing eq "\x32")){($GLOBAL::PhysicalDesktopAccess=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72"
);}}if ((not (defined ($GLOBAL::PhysicalDesktopAccessNoAcceptance)))){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72"
);if (($GLOBAL::PhysicalDesktopAuthorization eq "\x30")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance="\x73\x79\x73\x74\x65\x6d");}elsif ((
$GLOBAL::PhysicalDesktopAuthorization eq "\x31")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=
"\x74\x72\x75\x73\x74\x65\x64\x2c\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72"
);}elsif (($GLOBAL::PhysicalDesktopAuthorization eq "\x32")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance="\x74\x72\x75\x73\x74\x65\x64");}}}
else{if ((not (defined ($GLOBAL::PhysicalDesktopAccess)))){(
$GLOBAL::PhysicalDesktopAccess=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72\x2c\x73\x79\x73\x74\x65\x6d"
);if (($GLOBAL::PhysicalDesktopSharing eq "\x30")){(
$GLOBAL::PhysicalDesktopAccess="\x6f\x77\x6e\x65\x72");}elsif ((
$GLOBAL::PhysicalDesktopSharing eq "\x31")){($GLOBAL::PhysicalDesktopAccess=
"\x73\x79\x73\x74\x65\x6d");}}if ((not (defined (
$GLOBAL::PhysicalDesktopAccessNoAcceptance)))){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=
"\x61\x64\x6d\x69\x6e\x69\x73\x74\x72\x61\x74\x6f\x72\x2c\x74\x72\x75\x73\x74\x65\x64\x2c\x6f\x77\x6e\x65\x72"
);if (($GLOBAL::PhysicalDesktopAuthorization eq "\x30")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance="\x73\x79\x73\x74\x65\x6d");}elsif ((
$GLOBAL::PhysicalDesktopAuthorization eq "\x32")){(
$GLOBAL::PhysicalDesktopAccessNoAcceptance="\x74\x72\x75\x73\x74\x65\x64");}}}(
$GLOBAL::PhysicalDesktopAccess=lc ($GLOBAL::PhysicalDesktopAccess));(
$GLOBAL::PhysicalDesktopAccessNoAcceptance=lc (
$GLOBAL::PhysicalDesktopAccessNoAcceptance));if ((lc (
$GLOBAL::PhysicalDesktopAccessNoAcceptance)=~ /guest/ )){Logger::warning (
"\x47\x75\x65\x73\x74\x20\x76\x61\x6c\x75\x65\x20\x6d\x75\x73\x74\x20\x6e\x6f\x74\x20\x62\x65\x20\x69\x6e\x63\x6c\x75\x64\x65\x64\x20\x69\x6e\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x41\x63\x63\x65\x73\x73\x4e\x6f\x41\x63\x63\x65\x70\x74\x61\x6e\x63\x65\x20\x6b\x65\x79\x2e"
);($GLOBAL::PhysicalDesktopAccessNoAcceptance=~ s/guest//g );}Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x4c\x69\x63\x65\x6e\x73\x65\x44\x65\x70\x65\x6e\x64\x61\x6e\x74\x43\x6f\x6e\x66\x69\x67\x4b\x65\x79\x73\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x41\x63\x63\x65\x73\x73\x20\x27"
.$GLOBAL::PhysicalDesktopAccess)."\x27\x2e"));Logger::debug (((
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x75\x70\x64\x61\x74\x65\x4c\x69\x63\x65\x6e\x73\x65\x44\x65\x70\x65\x6e\x64\x61\x6e\x74\x43\x6f\x6e\x66\x69\x67\x4b\x65\x79\x73\x20\x50\x68\x79\x73\x69\x63\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x41\x63\x63\x65\x73\x73\x4e\x6f\x41\x63\x63\x65\x70\x74\x61\x6e\x63\x65\x20\x27"
.$GLOBAL::PhysicalDesktopAccessNoAcceptance)."\x27\x2e"));}sub saveTempLicense{(my $content
=shift (@_));(my $tempPath=(($serverLicFile."\x2e\x74\x6d\x70\x2e").$ $));
 (my $OUTFILE
=main::nxopen ($tempPath,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND
),$NXBits::UserReadWrite));if ((not (defined ($OUTFILE)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$tempPath)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x2e"));
Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString)."\x2e"));return (undef);}main::nxwrite ($OUTFILE,
$content);main::nxclose ($OUTFILE);return ($tempPath);}sub checkLegacyPortKeys{
if (($GLOBAL::SSHDPort ne (""))){Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4b\x65\x65\x70\x20\x6c\x65\x67\x61\x63\x79\x20\x6b\x65\x79\x20\x27\x53\x53\x48\x44\x50\x6f\x72\x74\x27\x2e"
);($GLOBAL::SSHPort=$GLOBAL::SSHDPort);}if (($GLOBAL::SSHDUPnPPort ne (""))){
Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4b\x65\x65\x70\x20\x6c\x65\x67\x61\x63\x79\x20\x6b\x65\x79\x20\x27\x53\x53\x48\x44\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x2e"
);($GLOBAL::SSHUPnPPort=$GLOBAL::SSHDUPnPPort);}if (($GLOBAL::NXPort ne (""))){
Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4b\x65\x65\x70\x20\x6c\x65\x67\x61\x63\x79\x20\x6b\x65\x79\x20\x27\x4e\x58\x50\x6f\x72\x74\x27\x2e"
);($GLOBAL::NXTCPPort=$GLOBAL::NXPort);}if (($GLOBAL::NXUPnPPort ne (""))){
Logger::debug (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65\x3a\x20\x4b\x65\x65\x70\x20\x6c\x65\x67\x61\x63\x79\x20\x6b\x65\x79\x20\x27\x4e\x58\x55\x50\x6e\x50\x50\x6f\x72\x74\x27\x2e"
);($GLOBAL::NXTCPUPnPPort=$GLOBAL::NXUPnPPort);}}sub setLicenseParameters{(my $content
=shift (@_));(my $ref_parameters=shift (@_));if (($content=~ /^Date: +(.*)$/m ))
{($$ref_parameters{"\x64\x61\x74\x65\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=$1);}
if (($content=~ /^Product: +(.*)$/m )){($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74"}=$1);($GLOBAL::PRODUCT_NAME=$$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74"});}if (($content=~ /^Customer: +(.*)$/m )){(
$$ref_parameters{"\x63\x75\x73\x74\x6f\x6d\x65\x72"}=$1);}if (($content=~ /^Product Id: +(.)(.*)$/m )
){($$ref_parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}=$1);(
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=$2);(
$productIdInLicense=$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}
);($GLOBAL::PRODUCT_ID=($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}.$$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}($__acronymId=
libnxh::NXParseServerProductId ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));if (($content=~ /^Subscription Id: +(.*)$/m )
){($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"}=$1);}if ((
$content=~ /^Subscription Type: +(.*)$/m )){($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}=$1);}if 
(($content=~ /^(Expiration|Expiry): +(.*)$/m )){($$ref_parameters{
"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=$2);}if ((
$content=~ /^Platform: +(.*)$/m )){($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d"}=$1);($platformInLicense=$$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d"});}if (($content=~ /^Users: +(.*)$/m )){(
$$ref_parameters{"\x75\x73\x65\x72\x73"}=$1);if (($$ref_parameters{
"\x75\x73\x65\x72\x73"}=~ /nlimited$/ )){($$ref_parameters{
"\x75\x73\x65\x72\x73"}=(0x139d+ 3707-0x2218));}}if (($content=~ /^Connections: +(.*)$/m )
){($$ref_parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=$1);if ((
$$ref_parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=~ /nlimited$/ )
){($$ref_parameters{"\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x73"}=
(0x1747+ 788-0x1a5b));}}if (($content=~ /^Virtual Desktops: +(.*)$/m )){(
$$ref_parameters{"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}
=$1);if (($$ref_parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}=~ /None$/ )){(
$$ref_parameters{"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}
=(-(0x1e2f+ 1699-0x24d1)));}elsif (($$ref_parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}=~ /nlimited$/ ))
{($$ref_parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}=
(0x00cc+ 7605-0x1e81));}}if ((($content=~ /^Processors: +(\d+)$/m )or ($content
=~ /^Processors: +\d+-(\d+)$/m ))){($licenseProcessorsCount=$1);}if (($content=~ /^Product Key: +(.*)$/m )
){($$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"}=$1);(
$GLOBAL::PRODUCT_KEY=$$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x6b\x65\x79"});}if (($content=~ /^Subscription Key: +(.*)$/m )
){($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x6b\x65\x79"}=$1);}if ((
$content=~ /^Subscription Version: +(.*)$/m )){($SubscriptionVersion=$1);}elsif 
(($SubscriptionVersion==(-(0x0b62+ 3037-0x173e)))){($SubscriptionVersion=
$GLOBAL::defaultLegacyLicenseVersion);}($content=~ s/^(Subscription Key: +).*$/$1/m )
;($content=~ s/----- Begin subscription data -----\n//m );($content=~ s/----- End subscription data -----\n*//m )
;my ($c_subscription_key);(my $add_chr=substr (Common::NXCore::digestMd5Hex (
$$ref_parameters{"\x64\x61\x74\x65\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}),
(0x160c+ 2230-0x1ec2),(0x00a7+ 3519-0x0e5e)));($content=~ s/^(Subscription Key: +).*$/$1/m )
;($c_subscription_key=(Common::NXCore::digestMd5Hex (($content.
$GLOBAL::PRODUCT_KEY_SALT)).$add_chr));if (($c_subscription_key ne 
$$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x6b\x65\x79"})){(
$$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}=
"\x4e\x6f\x74\x56\x61\x6c\x69\x64");return;}if (($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}ne $GLOBAL::BUILD_PLATFORM)){
unless ((("\x52" eq $GLOBAL::BUILD_PLATFORM)and (($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}eq "\x4c")||($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}eq "\x41")))){NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x6c\x61\x74\x66\x6f\x72\x6d"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$platformInNewLicense,
Common::NXInfo::getOsInfo ());setWrongPlatformLicenseForPackage ();}}my ($sec,
$min,$hour,$mday,$mon,$year);my ($now);if (($$ref_parameters{
"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}ne 
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64")){if (($$ref_parameters{
"\x65\x78\x70\x69\x72\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=~ /^(... )(...) *(\d+) +(\d\d):(\d\d):(\d\d) (.*) (\d\d\d\d)/ )
){(($sec,$min,$hour,$mday,$mon,$year)=($6,$5,$4,$3,$2,$8));($mon=~ s/Jan/00/i );
($mon=~ s/Feb/01/i );($mon=~ s/Mar/02/i );($mon=~ s/Apr/03/i );($mon=~ s/May/04/i )
;($mon=~ s/Jun/05/i );($mon=~ s/Jul/06/i );($mon=~ s/Aug/07/i );($mon=~ s/Sep/08/i )
;($mon=~ s/Oct/09/i );($mon=~ s/Nov/10/i );($mon=~ s/Dec/11/i );(++$mon);}else{
NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x4c\x69\x63\x65\x6e\x63\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}($$ref_parameters{
"\x65\x78\x70\x69\x72\x79"}=((((($year.sprintf ("\x25\x30\x32\x64",$mon)).
sprintf ("\x25\x30\x32\x64",$mday)).sprintf ("\x25\x30\x32\x64",$hour)).sprintf 
("\x25\x30\x32\x64",$min)).sprintf ("\x25\x30\x32\x64",$sec)));saveExpiryDate (
$$ref_parameters{"\x65\x78\x70\x69\x72\x79"});(my $expiry_timestamp=
Time::Local::timelocal ($sec,$min,$hour,$mday,($mon-(0x008a+ 4740-0x130d)),$year
));saveExpiryTimestamp ($expiry_timestamp);if (checkIfLicenseExpired ()){(
$$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}=(
$$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}.
"\x45\x78\x70\x69\x72\x65\x64"));}else{NXEvent::createEventOnTime (
NXEvent::getLicenseExpiredEventName (),$expiry_timestamp);}if (($$ref_parameters
{"\x64\x61\x74\x65\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=~ /^(... )(...) *(\d+) +(\d\d):(\d\d):(\d\d) (.*) (\d\d\d\d)/ )
){(($sec,$min,$hour,$mday,$mon,$year)=($6,$5,$4,$3,$2,$8));($mon=~ s/Jan/00/i );
($mon=~ s/Feb/01/i );($mon=~ s/Mar/02/i );($mon=~ s/Apr/03/i );($mon=~ s/May/04/i )
;($mon=~ s/Jun/05/i );($mon=~ s/Jul/06/i );($mon=~ s/Aug/07/i );($mon=~ s/Sep/08/i )
;($mon=~ s/Oct/09/i );($mon=~ s/Nov/10/i );($mon=~ s/Dec/11/i );(++$mon);}elsif 
(($$ref_parameters{"\x64\x61\x74\x65\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=~ /^.*(\d\d\d\d)-(\d\d)-(\d\d)/ )
){($year=$1);($mon=$2);($mday=$3);}else{NXMsg::error (
"\x77\x42\x72\x61\x6e\x64\x4d\x65\x73\x73\x61\x67\x65\x44\x61\x74\x65\x4e\x6f\x74\x56\x61\x6c\x69\x64"
);NXShell::handle_command ("\x65\x78\x69\x74");}(my $date=(($year.sprintf (
"\x25\x30\x32\x64",$mon)).sprintf ("\x25\x30\x32\x64",$mday)));(my $date_timestamp
=Time::Local::timelocal ($sec,$min,$hour,$mday,($mon-(0x057c+ 6119-0x1d62)),
$year));($$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}=($expiry_timestamp-
$date_timestamp));($$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}=(
$$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}/86400));if ((($$ref_parameters{
"\x70\x65\x72\x69\x6f\x64"}eq (0x06c4+ 4109-0x1564))or ($$ref_parameters{
"\x70\x65\x72\x69\x6f\x64"}eq (0x0839+ 4840-0x19b3)))){($$ref_parameters{
"\x70\x65\x72\x69\x6f\x64"}="\x31\x20\x79\x65\x61\x72");}else{($$ref_parameters{
"\x70\x65\x72\x69\x6f\x64"}=(int ($$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}).
"\x20\x64\x61\x79\x73"));}}else{($$ref_parameters{"\x70\x65\x72\x69\x6f\x64"}=
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64");saveExpiryDate (
"\x55\x6e\x6c\x69\x6d\x69\x74\x65\x64");}(Common::NXCore::decodeDate (
$GLOBAL::BUILD_DAY)=~ /(\d{4})(\d{2})(\d{2})/ );(my $buildday_timestamp=
Time::Local::timelocal ((0x0641+ 2820-0x1145),(0x0a21+ 6492-0x237d),
(0x1c70+ 1366-0x21ba),$3,($2-(0x0a69+ 2742-0x151e)),$1));my ($wday,$yday,$isdst)
;(($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=
Common::NXTime::getLocalTimeFromTimestamp ($buildday_timestamp));($year+=
(0x11f0+ 4223-0x1b03));($sec=sprintf ("\x25\x30\x32\x64",$sec));($min=sprintf (
"\x25\x30\x32\x64",$min));($hour=sprintf ("\x25\x30\x32\x64",$hour));(my (
@mon_list)=("\x4a\x61\x6e","\x46\x65\x62","\x4d\x61\x72","\x41\x70\x72",
"\x4d\x61\x79","\x4a\x75\x6e","\x4a\x75\x6c","\x41\x75\x67","\x53\x65\x70",
"\x4f\x63\x74","\x4e\x6f\x76","\x44\x65\x63"));(my (@day_list)=("\x53\x75\x6e",
"\x4d\x6f\x6e","\x54\x75\x65","\x57\x65\x64","\x54\x68\x75","\x46\x72\x69",
"\x53\x61\x74"));($$ref_parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79\x5f\x66\x6f\x72\x6d\x61\x74\x65\x64"}=((((((((
(((($day_list[$wday]."\x20").$mon_list[$mon])."\x20").$mday)."\x20").$hour).
"\x3a").$min)."\x3a").$sec)."\x20\x43\x45\x54\x20").$year));($$ref_parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79"}=$year);($$ref_parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79"}=($$ref_parameters{
"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf ("\x25\x30\x32\x64",($mon+
(0x0042+ 902-0x03c7)))));($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}=(
$$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf ("\x25\x30\x32\x64"
,$mday)));($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}=(
$$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf ("\x25\x30\x32\x64"
,$hour)));($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}=(
$$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf ("\x25\x30\x32\x64"
,$min)));($$ref_parameters{"\x62\x75\x69\x6c\x64\x64\x61\x79"}=($$ref_parameters
{"\x62\x75\x69\x6c\x64\x64\x61\x79"}.sprintf ("\x25\x30\x32\x64",$sec)));}sub 
setMissedLicenseParameters{(my $content=shift (@_));(my $ref_parameters=shift (
@_));($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x74\x79\x70\x65"}=$content
);($$ref_parameters{
"\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x5f\x69\x64"}=
"\x4e\x6f\x6e\x65");($$ref_parameters{
"\x76\x69\x72\x74\x75\x61\x6c\x44\x65\x73\x6b\x74\x6f\x70\x73"}=
"\x4e\x6f\x6e\x65");($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}=uc (substr (
Common::NXInfo::getOsInfo (),(0x0aef+ 3889-0x1a20),(0x1076+ 4014-0x2023))));(
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=
libnxh::NXTransGetEnvironment ("\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"));if ((
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}eq (""))){(
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=$ENV{
"\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"});}($__acronymId=
libnxh::NXParseServerProductId ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($GLOBAL::PRODUCT_NAME=
libnxh::NXParseProductName ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($GLOBAL::PRODUCT_ID=(
$$ref_parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}.
$$ref_parameters{"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));(my ($sec,$min,
$hour,$mday,$mon,$year)=((0x1e84+ 240-0x1f74),(0x0426+ 5085-0x1803),
(0x0653+ 1960-0x0dfa),(0x06bb+ 1970-0x0e6d),(0x1573+ 4052-0x2547),
(0x166c+ 565-0x10ef)));($$ref_parameters{"\x65\x78\x70\x69\x72\x79"}=((((($year.
sprintf ("\x25\x30\x32\x64",$mon)).sprintf ("\x25\x30\x32\x64",$mday)).sprintf (
"\x25\x30\x32\x64",$hour)).sprintf ("\x25\x30\x32\x64",$min)).sprintf (
"\x25\x30\x32\x64",$sec)));saveExpiryDate ($$ref_parameters{
"\x65\x78\x70\x69\x72\x79"});(my $expiry_timestamp=(0x014f+ 3853-0x105c));
saveExpiryTimestamp ($expiry_timestamp);}sub checkNXProduct{(my $ref_parameters=
shift (@_));if (isWrongNXProductInLicense ()){($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}=getHardcodedNXProduct ());(
$$ref_parameters{"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}=uc (substr (
Common::NXInfo::getOsInfo (),(0x1360+ 2355-0x1c93),(0x1e73+ 1009-0x2263))));(
$GLOBAL::PRODUCT_ID=($$ref_parameters{
"\x70\x6c\x61\x74\x66\x6f\x72\x6d\x5f\x69\x64"}.$$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));($GLOBAL::PRODUCT_NAME=
libnxh::NXParseProductName ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));if (__isUsingNodeLicenseFile ()){(
$__acronymId=libnxh::NXParseNodeProductId ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}else{($__acronymId=
libnxh::NXParseServerProductId ($$ref_parameters{
"\x70\x72\x6f\x64\x75\x63\x74\x5f\x69\x64"}));}}else{(
$isNotSuitableLicenseForPackage=(0x03cd+ 8405-0x24a2));}}sub 
isWrongNXProductInLicense{(my $nxproduct=getHardcodedNXProduct ());if ((
$SubscriptionVersion<=(0x0081+ 7171-0x1c7d))){if ((libnxh::NXIsCloudServer (
$__acronymId)and ($nxproduct eq "\x45\x43\x53"))){return ((0x0227+ 7798-0x209d))
;}elsif ((libnxh::NXIsTerminalServerNode ($__acronymId)and ($nxproduct eq 
"\x45\x54\x53\x4e"))){return ((0x06f0+ 3115-0x131b));}elsif ((
libnxh::NXIsSmallBusinessServer ($__acronymId)and ($nxproduct eq 
"\x53\x42\x54\x53"))){return ((0x0f57+ 3272-0x1c1f));}}if ((
libnxh::NXIsNomachineFreeServer ($__acronymId)and ($nxproduct eq "\x53"))){
return ((0x0f36+ 389-0x10bb));}elsif ((libnxh::NXIsEnterpriseCloudServer (
$__acronymId)and ($nxproduct eq "\x45\x43\x53"))){return ((0x07ed+ 7583-0x258c))
;}elsif ((libnxh::NXIsEnterpriseCloudServerCluster ($__acronymId)and ($nxproduct
 eq "\x45\x43\x53\x43"))){return ((0x1089+ 5554-0x263b));}elsif ((
libnxh::NXIsCloudServer ($__acronymId)and ($nxproduct eq "\x43\x53"))){return (
(0x168b+ 3882-0x25b5));}elsif ((libnxh::NXIsSmallBusinessCloudServer (
$__acronymId)and ($nxproduct eq "\x53\x42\x43\x53"))){return (
(0x1965+ 2752-0x2425));}elsif ((libnxh::NXIsEnterpriseTerminalServer (
$__acronymId)and ($nxproduct eq "\x45\x54\x53"))){return ((0x1b0a+ 2819-0x260d))
;}elsif ((libnxh::NXIsEnterpriseTerminalServerCluster ($__acronymId)and (
$nxproduct eq "\x45\x54\x53\x43"))){return ((0x0e06+ 525-0x1013));}elsif ((
libnxh::NXIsTerminalServerNode ($__acronymId)and ($nxproduct eq "\x54\x53\x4e"))
){return ((0x1376+ 2703-0x1e05));}elsif ((
libnxh::NXIsEnterpriseTerminalServerNode ($__acronymId)and ($nxproduct eq 
"\x45\x54\x53\x4e"))){return ((0x0f4b+ 1526-0x1541));}elsif ((
libnxh::NXIsTerminalServer ($__acronymId)and ($nxproduct eq "\x54\x53"))){return
 ((0x0730+ 2666-0x119a));}elsif ((libnxh::NXIsSmallBusinessTerminalServer (
$__acronymId)and ($nxproduct eq "\x53\x42\x54\x53"))){return (
(0x04e6+ 6137-0x1cdf));}elsif ((libnxh::NXIsEnterpriseDesktop ($__acronymId)and 
($nxproduct eq "\x45\x44"))){return ((0x0032+ 1328-0x0562));}elsif ((
libnxh::NXIsWorkstation ($__acronymId)and ($nxproduct eq "\x57"))){return (
(0x0edd+ 3610-0x1cf7));}Logger::error (((((
"\x54\x68\x65\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x27".$GLOBAL::PRODUCT_ID).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x73\x75\x69\x74\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x73\x65\x72\x76\x65\x72\x20\x70\x72\x6f\x64\x75\x63\x74\x20\x27"
).$nxproduct)."\x27\x2e"));NXMsg::error (
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x72\x6f\x64\x75\x63\x74"
,"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",$nxproduct,$productIdInLicense);
setNotSuitableLicenseForPackage ();return ((0x09f4+ 3919-0x1942));}sub 
getHardcodedNXProduct{(my $nxproduct=libnxh::NXTransGetEnvironment (
"\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"));if (($nxproduct eq (""))){($nxproduct=
$ENV{"\x4e\x58\x50\x52\x4f\x44\x55\x43\x54"});}return ($nxproduct);}sub 
getNodeLicenseStatus{(my $uuid=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x6e\x6f\x64\x65\x73\x2e"
.$uuid).
"\x2c\x66\x69\x65\x6c\x64\x3d\x73\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x53\x74\x61\x74\x75\x73\x0a"
));(my $subscriptionStatus=main::urldecode (NXRedis::get ()));return (
$subscriptionStatus);}sub isLicenseSuspendsFurtherWork{if (((((
isEvaluationPeriodExpired ()or isLicenseExpired ())or isNoLicenseFile ())or 
isNotSuitableLicenseForPackage ())or isWrongPlatformLicenseForPackage ())){
return ((0x016f+ 9259-0x2599));}return ((0x1228+ 785-0x1539));}sub 
doesProductSupportGuestCreateVirtual{(my $productId=shift (@_));(my $acronym=
libnxh::NXParseServerProductId ($productId));if (((libnxh::NXIsTerminalServer (
$acronym)or libnxh::NXIsEnterpriseTerminalServer ($acronym))or 
libnxh::NXIsEnterpriseTerminalServerCluster ($acronym))){return (
(0x0c0f+ 4194-0x1c70));}return ((0x116f+ 4107-0x217a));}sub 
doesProductSupportGuestAccess{(my $productId=shift (@_));(my $acronym=
libnxh::NXParseServerProductId ($productId));if ((((libnxh::NXIsCloudServer (
$acronym)or libnxh::NXIsEnterpriseCloudServer ($acronym))or 
libnxh::NXIsSmallBusinessCloudServer ($acronym))or 
libnxh::NXIsEnterpriseCloudServerCluster ($acronym))){return (
(0x0d35+ 371-0x0ea7));}return ((0x0f46+ 240-0x1036));}NXMsg::register_response (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x70\x79\x54\x6f\x44\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"
,(0x1583+ 3156-0x1fe3));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x52\x65\x61\x64\x69\x6e\x67\x54\x68\x65\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4f\x6e\x54\x68\x65\x53\x65\x72\x76\x65\x72"
,(0x0ed8+ 1508-0x12c8));Common::NXMsg::register_response (
"\x69\x43\x6c\x75\x73\x74\x65\x72\x4e\x6f\x74\x53\x75\x70\x70\x6f\x72\x74\x65\x64"
,(0x0960+ 2605-0x1164));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x45\x76\x61\x6c\x75\x61\x74\x69\x6f\x6e\x45\x78\x70\x69\x72\x65\x64"
,(0x1890+ 1707-0x1cc5));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x45\x78\x70\x69\x72\x65\x64"
,(0x2306+ 1228-0x255c));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x46\x69\x6c\x65\x4e\x6f\x74\x45\x78\x69\x73\x74"
,(0x0d37+ 6741-0x2516));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x6c\x61\x74\x66\x6f\x72\x6d"
,(0x1633+ 4117-0x23d2));NXMsg::register_error (
"\x4e\x58\x4c\x69\x63\x65\x6e\x73\x65",
"\x65\x47\x55\x49\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4c\x69\x63\x65\x6e\x73\x65\x57\x72\x6f\x6e\x67\x50\x72\x6f\x64\x75\x63\x74"
,(0x050c+ 8162-0x2278));return ((0x0813+ 4202-0x187c));
