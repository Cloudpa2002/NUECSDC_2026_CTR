############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXAnywhereDefault::BEGIN{package NXAnywhereDefault;no warnings;require 
NXAnywhereClient;do{
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x43\x6c\x69\x65\x6e\x74"->import};}
package NXAnywhereDefault;no warnings;%anywhereConnection;($initialized=
(0x048d+ 1194-0x0937));($connectionLost=(0x144d+ 294-0x1573));(
$waitForLogoutForNewLogin=(0x0acf+ 7155-0x26c2));($status=
"\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64");($defaultAuth=
"\x73\x79\x73\x74\x65\x6d");($loginError=(0x0966+ 1938-0x10f8));($machineId=("")
);(my $__timeoutToNextLogin=(0x0a0f+ 4577-0x1bb4));(my $__defaultUser=
"\x64\x65\x66\x61\x75\x6c\x74");sub initialize{();}sub getStatusMessage{return (
((((((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ANYWHERE).
"\x20\x64\x65\x66\x61\x75\x6c\x74\x2c").$status)."\x2c").$loginError)."\x2c").
$machineId));}sub sendStatusToNode{(my $onlyLocal=shift (@_));if (
isNotInitialized ()){return;}if (($machineId eq (""))){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");(my $machineId=
NXAnywhereRedis::getMachineId ());if (($machineId eq (""))){Logger::debug2 ((
Server::getAnywhereName ().
"\x20\x4d\x69\x73\x73\x69\x6e\x67\x20\x6d\x61\x63\x68\x69\x6e\x65\x20\x49\x44\x2c\x20\x73\x6b\x69\x70\x20\x73\x65\x6e\x64\x69\x6e\x67\x20\x73\x74\x61\x74\x75\x73\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2e"
));return;}($NXAnywhereDefault::machineId=$machineId);}(my $message=
getStatusMessage ());(my $socket=NXLocalSession::getActiveLocalSessionNodeSocket
 ());if ((defined ($socket)and ($socket!=(-(0x07cb+ 954-0x0b84))))){(my $ret=
NXNodeExec::sendToNode ($message,$socket));if ((($ret==(-(0x03d3+ 5386-0x18dc)))
or ($ret==(0x008c+ 4370-0x119e)))){Logger::warning ((Server::getAnywhereName ().
((
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x73\x74\x61\x74\x75\x73\x20"
.$status).
"\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65\x2e"
)));}else{Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x73\x74\x61\x74\x75\x73\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x58\x4e\x6f\x64\x65\x2e"
));}}else{Logger::debug ((("\x53\x6b\x69\x70\x20\x73\x65\x6e\x64\x20".
Server::getAnywhereName ()).
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2c\x20\x77\x61\x69\x74\x20\x66\x6f\x72\x20\x61\x63\x74\x69\x76\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
));}if ($onlyLocal){return;}main::nxrequire (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72"
);NXDaemonSubscriptionManager::sendMessageToAnywhereSubscribers ($message);}sub 
sendNotificationToNode{(my $message=shift (@_));(my $socket=
NXLocalSession::getActiveLocalSessionNodeSocket ());($message=(((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_ANYWHERE).
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x2c").$message));if ((
defined ($socket)and ($socket!=(-(0x005c+ 7195-0x1c76))))){(my $ret=
NXNodeExec::sendToNode ($message,$socket));if ((($ret==(-(0x0b14+ 2795-0x15fe)))
or ($ret==(0x0f40+ 2826-0x1a4a)))){Logger::warning ((Server::getAnywhereName ().
(("\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x27".$message).
"\x27\x20\x63\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x6f\x64\x65\x2e"
)));}else{Logger::debug ((Server::getAnywhereName ().((
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x27".$message).
"\x27\x20\x73\x65\x6e\x64\x20\x74\x6f\x20\x4e\x58\x4e\x6f\x64\x65\x2e")));}}else
{Logger::debug ((("\x53\x6b\x69\x70\x20\x73\x65\x6e\x64\x20".
Server::getAnywhereName ()).
"\x20\x6e\x6f\x74\x69\x66\x69\x63\x61\x74\x69\x6f\x6e\x20\x74\x6f\x20\x6e\x6f\x64\x65\x2c\x20\x77\x61\x69\x74\x20\x66\x6f\x72\x20\x61\x63\x74\x69\x76\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
));}main::nxrequire (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72"
);NXDaemonSubscriptionManager::sendMessageToAnywhereSubscribers ($message);}sub 
__changeStatusToConnected{($status="\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64");
sendStatusToNode ();}sub __changeStatusToDisconnected{($status=
"\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64");sendStatusToNode ();}sub 
isStatusConnected{if (($status eq "\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64")){
return ((0x05f0+ 5205-0x1a44));}return ((0x12eb+ 878-0x1659));}sub 
isNotAllowedLoginDefaultUser{if (($GLOBAL::EnableNMNComputerPublishing==
(0x0467+ 4587-0x1652))){Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e"
));return ((0x00ca+ 3080-0x0cd1));}if ((not (
NXLicense::isDirectConnectionFeature ()))){Logger::debug ((
Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e\x20\x44\x69\x72\x65\x63\x74\x20\x61\x63\x63\x65\x73\x73\x20\x66\x65\x61\x74\x75\x72\x65\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"
));return ((0x070a+ 6978-0x224b));}main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if ((NXCluster::isInStandby ()==
(0x1269+ 2739-0x1d1b))){Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e\x20\x49\x73\x20\x43\x6c\x75\x73\x74\x65\x72\x20\x69\x6e\x20\x73\x74\x61\x6e\x64\x62\x79\x2e"
));return ((0x0f1d+ 1843-0x164f));}if (Server::isDirectAccessDisabled ()){
Logger::debug ((Server::getAnywhereName ().
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e\x20\x44\x69\x72\x65\x63\x74\x20\x61\x63\x63\x65\x73\x73\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
));return ((0x132f+ 4728-0x25a6));}if (Server::isAnywhereDisabled ()){
Logger::debug ((Server::getAnywhereName ().
"\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x6f\x6e\x20\x74\x68\x69\x73\x20\x6d\x61\x63\x68\x69\x6e\x65\x2e"
));return ((0x0876+ 118-0x08eb));}return ((0x0e88+ 3083-0x1a93));}sub 
isNotInitialized{if (($initialized==(0x1418+ 223-0x14f7))){return (
(0x1bd9+ 1237-0x20ad));}return ((0x0987+ 5128-0x1d8f));}sub handleClientMessage{
(my $message=shift (@_));(my $notifyNode=(shift (@_)||(0x0582+ 3543-0x1359)));
main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);(my $serverDaemonPid=NXClientSystemDaemons::getServerDaemonPid ());if ((
$serverDaemonPid!=$ $)) {
 return (
NXClientSystemDaemons::sendToServerDaemonAnywhereMessage ($message));}if ((
$message eq "\x72\x65\x6c\x6f\x61\x64\x2c\x64\x65\x66\x61\x75\x6c\x74")){
Logger::debug ((("\x52\x65\x6c\x6f\x61\x64\x20".Server::getAnywhereName ()).
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x2e"
));if (isNotAllowedLoginDefaultUser ()){return;}if (__isConnectionClosed ()){
initialize ();}else{logoutAllConnections ();($waitForLogoutForNewLogin=
(0x0728+ 7580-0x24c3));}if (($notifyNode==(0x0036+ 7876-0x1ef9))){
sendNotificationToNode ($message);}}elsif (($message=~ /broadcast,(.*)/ )){
Logger::debug ((Server::getAnywhereName ().((
"\x20\x73\x52\x65\x63\x65\x69\x76\x65\x64\x20\x62\x72\x6f\x61\x64\x63\x61\x73\x74\x20\x73\x74\x61\x74\x75\x73\x20\x63\x68\x61\x6e\x67\x65\x20\x74\x6f\x20"
.$1)."\x2e")));}elsif (($message=~ /default,(.*)/ )){if (($1 eq 
"\x64\x69\x73\x61\x62\x6c\x65\x64")){Logger::debug (((
"\x44\x69\x73\x61\x62\x6c\x65\x64\x20".Server::getAnywhereName ()).
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x2e"
));($GLOBAL::EnableNMNComputerPublishing=(0x0201+ 7309-0x1e8e));
logoutAllConnections ();if (($notifyNode==(0x0f4f+ 5631-0x254d))){
sendNotificationToNode ($message);}}elsif (($1 eq "\x65\x6e\x61\x62\x6c\x65\x64"
)){Logger::debug ((("\x45\x6e\x61\x62\x6c\x65\x64\x20".Server::getAnywhereName 
()).
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x2e"
));($GLOBAL::EnableNMNComputerPublishing=(0x16d3+ 301-0x17ff));
NXServerDaemon::setConnectionToLocalhostNumber ();if (__isConnectionOpen ()){
Logger::warning (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x65\x6e\x61\x62\x6c\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x77\x68\x65\x6e\x20"
.Server::getAnywhereName ()).
"\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x75\x73\x65\x72\x20\x69\x73\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x74\x2e"
));logoutAllConnections ();($waitForLogoutForNewLogin=(0x0e09+ 2428-0x1784));}
else{initialize ();}if (($notifyNode==(0x140f+ 892-0x178a))){
sendNotificationToNode ($message);}}else{Logger::warning (((
"\x4e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20".
Server::getAnywhereName ()).((
"\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x76\x61\x6c\x75\x65\x20"
.$1)."\x2e")));}}elsif (($message eq 
"\x72\x65\x6c\x6f\x61\x64\x2c\x61\x6c\x6c\x6f\x77\x65\x64")){if (
__isConnectionOpen ()){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");
NXAnywhereClient::sendAllowedCommandOnConnection (__getConnectionId (),
NXAnywhereRedis::getAllowed ());}if (($notifyNode==(0x06f0+ 6331-0x1faa))){
sendNotificationToNode ($message);}}elsif (($message=~ /hostname,(.*)/ )){(
$GLOBAL::NMNHostName=$1);Logger::debug ((("\x52\x65\x6c\x6f\x61\x64\x20".
Server::getAnywhereName ()).
"\x20\x63\x6f\x6d\x70\x75\x74\x65\x72\x20\x70\x75\x62\x6c\x69\x73\x68\x69\x6e\x67\x20\x6f\x6e\x20\x63\x68\x61\x6e\x67\x65\x20\x68\x6f\x73\x74\x6e\x61\x6d\x65\x2e"
));if (($notifyNode==(0x0b57+ 731-0x0e31))){sendNotificationToNode ($message);}
if (isNotAllowedLoginDefaultUser ()){return;}if (__isConnectionClosed ()){return
;}logoutAllConnections ();($waitForLogoutForNewLogin=(0x08df+ 3237-0x1583));}
else{Logger::warning (((
"\x4e\x6f\x74\x20\x72\x65\x63\x6f\x67\x6e\x69\x7a\x65\x64\x20".
Server::getAnywhereName ()).(("\x20\x6d\x65\x73\x73\x61\x67\x65\x20".$message).
"\x2e")));}return;}sub loginOnAnywhereServer{(my $id=
NXAnywhereClient::createConnectionAndRegularLogin ());if (defined ($id)){(my $fd
=NXAnywhereClient::getFdById ($id));($anywhereConnection{"\x69\x64"}=$id);
Logger::debug ((Server::getAnywhereName ().((((
"\x20\x41\x64\x64\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x27"
.$id)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$fd)."\x2e")));
Common::NXSelector::addToGlobalSelector ($fd,((
"\x41\x6e\x79\x77\x68\x65\x72\x65\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x27"
.$id)."\x27"),
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74\x3a\x3a\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x61\x72\x73\x65\x72"
);}return;}sub logoutAllConnections{if (isNotInitialized ()){return;}if (
__isConnectionOpen ()){NXAnywhereClient::sendLogoutOnConnection (
__getConnectionId ());}}sub terminate{if (isNotInitialized ()){return;}
__closeConnection ();Logger::debug ((Server::getAnywhereName ().
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x46\x72\x65\x65\x20\x73\x74\x61\x72\x74\x2e"
));libnxhs::NXAnywhereFree ();Logger::debug ((Server::getAnywhereName ().
"\x20\x6c\x69\x62\x6e\x78\x68\x73\x3a\x3a\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x46\x72\x65\x65\x20\x73\x74\x6f\x70\x2e"
));}sub __closeConnection{if (isNotInitialized ()){return;}
__changeStatusToDisconnected ();if (__isConnectionOpen ()){
NXAnywhereClient::closeAnywhereConnection (__getConnectionId ());
__cleanVariables ();}}sub __cleanVariables{($anywhereConnection{"\x69\x64"}=
undef);}sub __isConnectionClosed{if (defined ($anywhereConnection{"\x69\x64"})){
return ((0x0d10+ 2914-0x1872));}return ((0x0851+ 7834-0x26ea));}sub 
__isConnectionOpen{if (defined ($anywhereConnection{"\x69\x64"})){return (
(0x0d7f+ 2361-0x16b7));}return ((0x0286+ 3481-0x101f));}sub __getConnectionId{
Logger::debug ((Server::getAnywhereName ().((
"\x20\x67\x65\x74\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x69\x64\x3a\x20\x27"
.$anywhereConnection{"\x69\x64"})."\x27\x2e")));return ($anywhereConnection{
"\x69\x64"});}sub connectionParser{(my $fd=shift (@_));if ((
NXAnywhereClient::readToBuffer ($fd)==(0x1170+ 4300-0x223c))){__cleanVariables 
();return;}my (%command);while (NXAnywhereClient::getCommandResponse ((\%command
))){if (($command{"\x63\x6f\x6d\x6d\x61\x6e\x64"}eq "\x6c\x6f\x67\x69\x6e")){
__handleLoginCommad ($command{"\x65\x72\x72\x6f\x72"},$command{
"\x63\x6f\x6d\x6d\x61\x6e\x64\x44\x61\x74\x61"});}elsif (($command{
"\x63\x6f\x6d\x6d\x61\x6e\x64"}eq "\x6c\x6f\x67\x6f\x75\x74")){
__handleLogoutCommand ();}elsif (($command{"\x63\x6f\x6d\x6d\x61\x6e\x64"}eq 
"\x65\x76\x65\x6e\x74")){__handleEventCommand ($command{"\x65\x72\x72\x6f\x72"},
$command{"\x63\x6f\x6d\x6d\x61\x6e\x64\x44\x61\x74\x61"});}elsif (($command{
"\x63\x6f\x6d\x6d\x61\x6e\x64"}eq "\x74\x77\x6f\x66\x61\x63\x74\x6f\x72")){
main::nxrequire (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x44\x61\x65\x6d\x6f\x6e");
NXTwoFactorDaemon::handleResponse ((\%command));}elsif (($command{
"\x65\x72\x72\x6f\x72"}eq "\x32\x32")){Logger::warning ((Server::getAnywhereName
 ()."\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x20\x65\x72\x72\x6f\x72\x2e"));
__closeConnection ();}}}sub __handleEventCommand{(my $error=shift (@_));(my $data
=shift (@_));Logger::debug ((Server::getAnywhereName ().((
"\x20\x44\x65\x66\x61\x75\x6c\x74\x3a\x20\x47\x6f\x74\x20\x65\x76\x65\x6e\x74\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$__defaultUser)."\x27\x2e")));(my (%options)=NXAnywhereClient::parseLine ($data
));if (defined ($options{"\x65\x76\x65\x6e\x74"})){if (($options{
"\x65\x76\x65\x6e\x74"}eq "\x63\x6f\x6e\x6e\x65\x63\x74")){(my $type=$options{
"\x74\x79\x70\x65"});(my $host=$options{"\x69\x70"});(my $port=$options{
"\x70\x6f\x72\x74"});(my $iv=$options{"\x69\x76"});(my $key=$options{
"\x6b\x65\x79"});(my $trusted=$options{"\x74\x72\x75\x73\x74\x65\x64"});(my $rip
=$options{"\x72\x69\x70"});(my $rport=$options{"\x72\x70\x6f\x72\x74"});(my $rstunport
=$options{"\x72\x73\x74\x75\x6e\x70\x6f\x72\x74"});(my $code=$options{
"\x63\x6f\x64\x65"});(my $turn=(""));(my $display="\x64\x65\x66\x61\x75\x6c\x74"
);if (defined ($options{"\x74\x75\x72\x6e"})){($turn=((((((($options{
"\x74\x75\x72\x6e\x62\x69\x6e\x64"}."\x3b").$options{
"\x74\x75\x72\x6e\x63\x68\x61\x6e\x6e\x65\x6c"})."\x3b").$options{
"\x74\x75\x72\x6e\x70\x6f\x72\x74"})."\x3b").((((($options{
"\x74\x75\x72\x6e\x68\x61\x73\x68"}."\x3b").$options{"\x74\x75\x72\x6e\x69\x70"}
)."\x3b").$options{"\x74\x75\x72\x6e\x6e\x6f\x6e\x63\x65"})."\x3b")).(($options{
"\x74\x75\x72\x6e\x72\x65\x61\x6c\x6d"}."\x3b").$options{
"\x74\x75\x72\x6e\x75\x73\x65\x72"})));}if (defined ($options{
"\x74\x75\x72\x6e\x73\x74\x75\x6e"})){($turn.=("\x3b".$options{
"\x74\x75\x72\x6e\x73\x74\x75\x6e"}));}main::closeSocketAtFinish ($options{
"\x66\x64"});Logger::debug ((((Server::getAnywhereName ().((
"\x20\x44\x65\x66\x61\x75\x6c\x74\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$__defaultUser)."\x27\x20\x77\x69\x74\x68\x20")).((((((((((((
"\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x27".$options{"\x66\x64"}).
"\x27\x2c\x20\x27").$options{"\x74\x6f\x6b\x65\x6e"})."\x27\x2c\x20\x27").$type)
."\x27\x2c\x20\x27").$host)."\x27\x2c\x20\x27").$port)."\x27\x2c\x20\x27").$iv).
"\x27\x2c\x20")).(((((((((((((("\x20\x27".$key)."\x27\x2c\x20\x27").$trusted).
"\x27\x2c\x20\x27").$display)."\x27\x2c\x20\x27").$rport)."\x27\x2c\x20\x27").
$rstunport)."\x27\x2c\x20\x27").$rip)."\x27\x2c\x20\x27").$turn)."\x27\x2e")));
main::nxrequire ("\x53\x6c\x61\x76\x65\x53\x65\x72\x76\x65\x72");
SlaveServer::startServerProcessConnectedToPlayer ($options{"\x66\x64"},$options{
"\x74\x6f\x6b\x65\x6e"},$type,$host,$port,$iv,$key,$trusted,$display,$rport,
$rstunport,$rip,$code,$turn);}if (($options{"\x65\x76\x65\x6e\x74"}eq 
"\x74\x77\x6f\x66\x61\x63\x74\x6f\x72")){($options{"\x65\x72\x72\x6f\x72"}=
$error);main::nxrequire (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x44\x61\x65\x6d\x6f\x6e");
NXTwoFactorDaemon::handleEvent ((\%options));}if (($options{
"\x65\x76\x65\x6e\x74"}eq "\x6d\x61\x63\x68\x69\x6e\x65\x73")){if ((($options{
"\x74\x79\x70\x65"}eq "\x67\x65\x74\x69\x64")and ($options{
"\x6d\x61\x63\x68\x69\x6e\x65\x69\x64"}ne ("")))){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");
NXAnywhereRedis::setMachineId ($options{"\x6d\x61\x63\x68\x69\x6e\x65\x69\x64"})
;($machineId=$options{"\x6d\x61\x63\x68\x69\x6e\x65\x69\x64"});sendStatusToNode 
();}}}else{Logger::warning (((
"\x57\x72\x6f\x6e\x67\x20\x65\x76\x65\x6e\x74\x20\x66\x6f\x72\x20".
Server::getAnywhereName ()).(((("\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x27").$data)."\x27\x2e")));}}sub __handleLogoutCommand{Logger::debug (
(Server::getAnywhereName ().(("\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x6f\x75\x74\x2e")));__closeConnection ();
if (($waitForLogoutForNewLogin==(0x1531+ 1585-0x1b61))){(
$waitForLogoutForNewLogin=(0x0d1c+ 1410-0x129e));loginOnAnywhereServer ();}}sub 
__handleLoginCommad{(my $error=shift (@_));(my $data=shift (@_));($loginError=
$error);if (($error==(0x0a45+ 3286-0x171b))){(my (%options)=
NXAnywhereClient::parseLine ($data));($anywhereConnection{
"\x6e\x69\x63\x6b\x6e\x61\x6d\x65"}=$options{"\x6e\x69\x63\x6b\x6e\x61\x6d\x65"}
);Logger::debug ((Server::getAnywhereName ().(("\x20\x75\x73\x65\x72\x20\x27".
$__defaultUser)."\x27\x20\x6c\x6f\x67\x67\x65\x64\x20\x69\x6e\x2e")));
__changeStatusToConnected ();(my ($owner,$error)=NXSession2::getOwnerBySessionId
 (Server::getMySessionID ()));if ((defined ($owner)and ($owner ne ("")))){
NXAnywhereClient::sendUserOnConnection (__getConnectionId (),$owner);}if ((
$connectionLost==(0x0339+ 5338-0x1812))){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");
NXAnywhereClient::sendAllowedCommandOnConnection (__getConnectionId (),
NXAnywhereRedis::getAllowed ());}($connectionLost=(0x1560+ 3153-0x21b1));}elsif 
(($error==(-(0x15c1+ 3949-0x252c)))){Logger::warning ((Server::getAnywhereName 
().(("\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x66\x72\x6f\x6d\x20\x73\x65\x72\x76\x65\x72\x2e"
)));($connectionLost=(0x03c4+ 6346-0x1c8d));__changeStatusToDisconnected ();}
elsif (($error==(-(0x0f86+ 2539-0x1967)))){Logger::warning ((
Server::getAnywhereName ().(("\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x6c\x6f\x67\x69\x6e\x2e\x20\x54\x68\x65\x72\x65\x20\x77\x61\x73\x20\x6e\x6f\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x20\x66\x72\x6f\x6d\x20\x61\x6e\x79\x20\x64\x65\x76\x69\x63\x65\x20\x69\x6e\x20\x67\x69\x76\x65\x6e\x20\x74\x69\x6d\x65\x6f\x75\x74\x2e"
)));NXAnywhereClient::sendLogoutOnConnection (__getConnectionId ());
__closeConnection ();NXEvent::createEventOnTime (
"\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74",(
Common::NXTime::getSecondsSinceEpoch ()+$__timeoutToNextLogin));
NXEvent::subscribe (
"\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74",
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74\x3a\x3a\x6c\x6f\x67\x69\x6e\x4f\x6e\x41\x6e\x79\x77\x68\x65\x72\x65\x53\x65\x72\x76\x65\x72"
);($__timeoutToNextLogin=((0x14e4+ 225-0x15c3)*$__timeoutToNextLogin));if ((
$__timeoutToNextLogin>(0x0e10+ 7780-0x256c))){($__timeoutToNextLogin=1800);}}
else{Logger::warning (((Server::getAnywhereName ().((
"\x20\x75\x73\x65\x72\x20\x27".$__defaultUser).
"\x27\x20\x66\x61\x69\x6c\x65\x64\x20\x74\x6f\x20\x6c\x6f\x67\x69\x6e\x2e\x20"))
.__getConnectionErrorString ($error)));NXAnywhereClient::sendLogoutOnConnection 
(__getConnectionId ());__closeConnection ();}}sub sendDesktopOwner{(my $owner=
shift (@_));if ((defined ($owner)and ($owner ne ("")))){if (__isConnectionOpen 
()){return (NXAnywhereClient::sendUserOnConnection (__getConnectionId (),$owner)
);}}}sub sendConnections{(my $connections=shift (@_));if ((defined ($connections
)and ($connections ne ("")))){if (__isConnectionOpen ()){return (
NXAnywhereClient::sendConnectedOnConnection (__getConnectionId (),$connections))
;}}}sub __getConnectionErrorString{(my $error=shift (@_));return (((
"\x46\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x27".
$error)."\x27\x2e"));}sub getDefaultNickname{return ($anywhereConnection{
"\x6e\x69\x63\x6b\x6e\x61\x6d\x65"});}sub twoFactorRequest{(my $requestId=shift 
(@_));(my $username=shift (@_));(my $client=shift (@_));(my $ip=shift (@_));(my $local
=shift (@_));(my $hostname=shift (@_));(my $platform=shift (@_));(my $method=
shift (@_));if (__isConnectionOpen ()){return (
NXAnywhereClient::sendTwoFactorRequest (__getConnectionId (),$username,$client,
$ip,$requestId,$local,$hostname,$platform,$method));}Logger::warning ((
Server::getAnywhereName ().
"\x20\x44\x65\x66\x61\x75\x6c\x74\x3a\x20\x4e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x20\x61\x6e\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
));return ((0x0495+ 8249-0x24cd));}sub cancelTwoFactor{(my $requestId=shift (@_)
);if (__isConnectionOpen ()){return (NXAnywhereClient::sendCancelTwoFactor (
__getConnectionId (),$requestId));}Logger::warning ((Server::getAnywhereName ().
"\x20\x44\x65\x66\x61\x75\x6c\x74\x3a\x20\x4e\x6f\x74\x20\x64\x65\x66\x69\x6e\x65\x64\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
));return ((0x0b29+ 837-0x0e6d));}sub generateAccessKeyIfNeeded{(my $numberOfDigits
=(0x0cd2+  55-0x0d00));main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x52\x65\x64\x69\x73");(my $currentKey=
NXAnywhereRedis::getAccessKey ());unless ((length ($currentKey)==$numberOfDigits
)){(my $generateKey=(libnxh::NXGetRandomNumber ()%((0x1539+ 1344-0x1a6f)**
$numberOfDigits)));(my $len=length ($generateKey));if (($len<$numberOfDigits)){(
$generateKey=(("\x30" x ($numberOfDigits-$len)).$generateKey));}
NXAnywhereRedis::setAccessKey ($generateKey);}}sub generateAccessKey{(my $numberOfDigits
=(0x07b5+ 2956-0x1338));(my $generateKey=(libnxh::NXGetRandomNumber ()%(
(0x0ce1+ 3488-0x1a77)**$numberOfDigits)));(my $len=length ($generateKey));if ((
$len<$numberOfDigits)){($generateKey=(("\x30" x ($numberOfDigits-$len)).
$generateKey));}return ($generateKey);}sub getDefaultAuth{return ($defaultAuth);
}"\x3f\x3f\x3f";
