############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXLogrotate;no warnings;($__timeoutForFileReleasedCheck=
(0x151d+ 3100-0x212a));($__sleepTimeBetweenFileReleaseChecks=0.2);(
$__checkLogrotateDelay=(0x26e9+ 583-0x25ac));($__lastCheckLogrotate=
(0x0bdf+ 974-0x0fad));($__nxhtdErrorLogPath=(""));($__forcedRotate=
(0x0759+ 2575-0x1168));($__forcedRotateDateTime=(""));((
%__ref_forcedRotateParameters)=());((%threadHandles)=());sub 
__rotateTillOriginalFile{(my $type=shift (@_));(my $rotatedName=shift (@_));(my $rotationDir
=NXLogrotateDB::getDestination ($type));(my $maxRotation=
NXLogrotateDB::getRotate ($type));(my $prevRotatedFile=((($rotationDir.
$GLOBAL::DIRECTORY_SLASH).($rotatedName."\x2e")).($maxRotation+
(0x153b+ 1184-0x19da))));if (NXLogrotateDB::isCompressSet ($type)){(
$prevRotatedFile=($prevRotatedFile."\x2e\x67\x7a"));}for ((my $i=$maxRotation);(
$i>(0x1369+ 2501-0x1d2e));(--$i)){(my $curRotatedFile=((($rotationDir.
$GLOBAL::DIRECTORY_SLASH).($rotatedName."\x2e")).$i));if (
NXLogrotateDB::isCompressSet ($type)){($curRotatedFile=($curRotatedFile.
"\x2e\x67\x7a"));}if (Common::NXFile::fileExists ($curRotatedFile)){($result=
Common::NXFile::renameFile ($curRotatedFile,$prevRotatedFile));if (($result==
(0x0156+ 2271-0x0a35))){NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x52\x65\x6e\x61\x6d\x65\x46\x69\x6c\x65",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$curRotatedFile,$prevRotatedFile)
;return ((0x015a+ 9386-0x2604));}}($prevRotatedFile=$curRotatedFile);}return (
(0x0d83+ 1779-0x1475));}sub __copyTruncate{(my $type=shift (@_));(my $path=shift
 (@_));(my $rotatedName=shift (@_));(my $destFilePath=
__getRotatedLogFilePathByLogType ($type,$rotatedName));(my $result=__copyLogFile
 ($path,$destFilePath));if (($result==(0x0a17+ 1742-0x10e5))){return (
(0x1c98+ 1324-0x21c4));}return (__truncateFile ($path));}sub __removeExpiredLogs
{(my $type=shift (@_));(my $rotatedName=shift (@_));(my $rotationDir=
NXLogrotateDB::getDestination ($type));(my $maxRotation=NXLogrotateDB::getRotate
 ($type));(my $fileToRemove=((($rotationDir.$GLOBAL::DIRECTORY_SLASH).(
$rotatedName."\x2e")).($maxRotation+(0x0963+ 5120-0x1d62))));if (
NXLogrotateDB::isCompressSet ($type)){($fileToRemove=($fileToRemove.
"\x2e\x67\x7a"));}if (Common::NXFile::fileExists ($fileToRemove)){return (
Common::NXFile::removeFile ($fileToRemove));}return ((0x0ba6+ 6433-0x24c6));}sub
 forcedRotate{(my $ref_parameters=shift (@_));(my $result=
__handleForcedRotateParameters ($ref_parameters));if (($result==
(0x08fb+ 4008-0x18a3))){return ((0x1e57+ 505-0x2050));}if (($$ref_parameters{
"\x74\x79\x70\x65"}and (not (isLogTypeSupported ($$ref_parameters{
"\x74\x79\x70\x65"}))))){(my (@supportedTypes)=getAllSupportedLogrotateLogTypes 
());NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x54\x79\x70\x65\x4e\x6f\x74\x53\x75\x70\x70\x6f\x72\x74\x65\x64"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$$ref_parameters{
"\x74\x79\x70\x65"},join ($",@supportedTypes));return ((0x02b6+ 5935-0x19e5));}(my $dateTime
=Common::NXTime::getDateTimeForFileName ());__setForcedRotateDateTime ($dateTime
);__setForcedRotate ();return (rotate ($$ref_parameters{"\x74\x79\x70\x65"}));}
sub rotate{(my $type=(shift (@_)||("")));Logger::debug (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x6f\x67\x20\x72\x6f\x74\x61\x74\x65\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x2e"
);NXMsg::send_response (
"\x69\x43\x4d\x44\x53\x74\x61\x72\x74\x69\x6e\x67\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65");if (($type ne (""))){
__rotateByLogType ($type);}else{rotateAllLogFiles ();}Logger::debug (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x68\x61\x73\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x2e"
);}sub rotateAllLogFiles{main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42","\x69\x6e\x69\x74");(my (
@availableTypes)=());if (__isForcedRotate ()){(@availableTypes=
getAllSupportedLogrotateLogTypes ());}else{(@availableTypes=
NXLogrotateDB::getLogTypes ());}foreach my $availableType (@availableTypes){if (
__shouldSkipMultiTypeLogrotateForType ($availableType)){next;}__rotateByLogType 
($availableType);}}sub __rotateByLogType{(my $type=shift (@_));Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x6f\x67\x20\x72\x6f\x74\x61\x74\x65\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x2e"));if (__isNotForcedRotate ()){main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42","\x69\x6e\x69\x74");if (
NXLogrotateDB::isNotLogrotateExist ($type)){Logger::error ((((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x20\x68\x61\x73\x20\x66\x61\x69\x6c\x65\x64\x2e\x20").
"\x4c\x6f\x67\x20\x74\x79\x70\x65\x20\x69\x73\x20\x6e\x6f\x74\x20\x65\x6e\x61\x62\x6c\x65\x64\x20\x66\x6f\x72\x20\x6c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x2e"
));NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x6f\x65\x73\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42",$type);NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x61\x69\x6c\x65\x64",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$type);return (
(0x01c8+ 3011-0x0d8b));}}($result=__rotateFilesByLogType ($type));if (($result==
(0x0a80+ 2609-0x14b1))){Logger::error (((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x20\x68\x61\x73\x20\x66\x61\x69\x6c\x65\x64\x2e"));NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x61\x69\x6c\x65\x64",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$type);}else{Logger::debug (((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type).
"\x27\x20\x68\x61\x73\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x73\x75\x63\x63\x65\x73\x73\x66\x75\x6c\x6c\x79\x2e"
));NXMsg::send_response (
"\x69\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x69\x6e\x69\x73\x68\x65\x64"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$type);}return ($result);}sub 
__getUserLogFilePathsByType{(my $type=shift (@_));(my $ref_filePaths=shift (@_))
;(my (@filePaths)=());(my (%users)=
NXUsersManager::userListIncludingInternalDMUsers ());foreach my $user (keys (
%users)){if (NXUsersManager::isDMUser ($user)){($user=
NXUsersManager::getRealDMUsername ($user));}(my $fileName=__getFilenameByLogType
 ($type));(my $path=((Common::NXPaths::getNxDirectoryInUserHomeDirectory ($user)
.$GLOBAL::DIRECTORY_SLASH).$fileName));(my $rotatedName=($fileName.("\x2d".$user
)));($$ref_filePaths{$rotatedName}=$path);}}sub 
__getSpecialUserLogFilePathByType{(my $type=shift (@_));(my $ref_filePaths=shift
 (@_));(my $fileName=__getFilenameByLogType ($type));(my $path=((
Common::NXPaths::getSpecialUsersLogFolderPath ().$GLOBAL::DIRECTORY_SLASH).
$fileName));($$ref_filePaths{$fileName}=$path);}sub __getFilePathsByLogType{(my $type
=shift (@_));(my (%filePaths)=());if (($type eq 
Logger::getLogrotateLogTypeNxserverLog ())){if (($GLOBAL::CommonLogDirectory ne 
(""))){(my $fileName=__getFilenameByLogType ($type));(my $rotateFileName=(
$fileName."\x2d\x63\x6f\x6d\x6d\x6f\x6e"));($filePaths{$rotateFileName}=((
$GLOBAL::CommonLogDirectory.$GLOBAL::DIRECTORY_SLASH).$fileName));}else{
__getUserLogFilePathsByType ($type,(\%filePaths));
__getSpecialUserLogFilePathByType ($type,(\%filePaths));}}else{(my $fileName=
__getFilenameByLogType ($type));($filePaths{$fileName}=__getFilePathByLogType (
$type));}return (%filePaths);}sub __rotateFilesByLogType{(my $type=shift (@_));(my $ref_filePaths
=shift (@_));(my $silent=(shift (@_)||(0x128a+ 4425-0x23d3)));(my (%filePaths)=
());if (__isNotForcedRotate ()){((%filePaths)=%$ref_filePaths);}else{((
%filePaths)=__getFilePathsByLogType ($type));}(my $filesCount=
(0x0115+ 6718-0x1b53));(my $noExistPath=(""));(my $result=(0x0469+ 2069-0x0c7d))
;foreach my $rotatedName (keys (%filePaths)){(my $path=$filePaths{$rotatedName})
;if ((not (Common::NXFile::fileExists ($path)))){($noExistPath=$path);next;}(++
$filesCount);($result=__rotateWithCopytruncate ($type,$path,$rotatedName));if ((
$result!=(0x0059+ 3199-0x0cd8))){($result=__postRotate ($type,$rotatedName,
$silent));}}if (($filesCount==(0x07b0+ 1309-0x0ccd))){if ((scalar (@filePaths)>
(0x0ac0+ 651-0x0d4a))){Logger::error ((((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x20\x68\x61\x73\x20\x66\x61\x69\x6c\x65\x64\x2e\x20").
"\x4e\x6f\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x73\x20\x66\x6f\x75\x6e\x64\x2e"))
;}else{Logger::error ((((
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x4c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x70\x72\x6f\x63\x65\x64\x75\x72\x65\x20\x66\x6f\x72\x20\x27"
.$type)."\x27\x20\x68\x61\x73\x20\x66\x61\x69\x6c\x65\x64\x2e\x20").((
"\x4c\x6f\x67\x20\x66\x69\x6c\x65\x20\x27".$path).
"\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e")));if ((
$silent==(0x0d67+ 163-0x0e0a))){Common::NXMsg::error (
"\x65\x46\x69\x6c\x65\x4e\x6f\x74\x45\x78\x69\x73\x74",$noExistPath);}}if ((
$silent==(0x170b+ 676-0x19af))){NXMsg::error (
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x61\x69\x6c\x65\x64",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$noExistPath);}return (
(0x220d+ 1125-0x2672));}return ($result);}sub __postRotate{(my $type=shift (@_))
;(my $rotatedName=shift (@_));(my $silent=shift (@_));if (((__isForcedRotate ()
and __isForcedRotateCompress ())or ((not (__isForcedRotate ()))and 
NXLogrotateDB::isCompressSet ($type)))){(my $rotatedFile=
__getRotatedLogFilePathByLogType ($type,$rotatedName));($result=__compressFile (
$rotatedFile,$silent));if (($result==(0x1071+ 142-0x10ff))){return (
(0x1552+ 3352-0x226a));}Common::NXFile::removeFile ($rotatedFile);}return (
(0x0203+ 4184-0x125a));}sub __rotateWithCopytruncate{(my $type=shift (@_));(my $path
=shift (@_));(my $rotatedName=shift (@_));if (__isNotForcedRotate ()){(my $result
=__rotateTillOriginalFile ($type,$rotatedName));__removeExpiredLogs ($type,
$rotatedName);if (($result==(0x00bb+ 9072-0x242b))){return (
(0x02b4+ 4125-0x12d1));}}return (__copyTruncate ($type,$path,$rotatedName));}sub
 __getRotatedLogFilePathByLogType{(my $type=shift (@_));(my $rotatedName=shift (
@_));if (__isNotForcedRotate ()){(my $destination=NXLogrotateDB::getDestination 
($type));return ((($destination.$GLOBAL::DIRECTORY_SLASH).($rotatedName.
"\x2e\x31")));}else{(my $destination=__getForcedRotateDestination ());return (((
($destination.$GLOBAL::DIRECTORY_SLASH).($rotatedName."\x2d")).
__getForcedRotateDateTime ()));}}sub __compressFile{(my $logFilePath=shift (@_))
;(my $silent=shift (@_));(my $compressedFile=($logFilePath."\x2e\x67\x7a"));(my $result
=Common::NXFile::compressFile ($logFilePath,$compressedFile));if (($result!=
(0x2336+ 307-0x2468))){if (($silent==(0x0a9c+ 3145-0x16e5))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x6d\x70\x72\x65\x73\x73\x46\x69\x6c\x65"
,"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$logFilePath);}return (
(0x1903+ 1054-0x1d21));}else{if (($silent==(0x0934+ 988-0x0d10))){
NXMsg::send_response (
"\x69\x43\x4d\x44\x43\x6f\x6d\x70\x72\x65\x73\x73\x65\x64\x46\x69\x6c\x65",
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",$compressedFile);}
__correctRotatedFileOwnershipAndPermissions ($compressedFile);return (
(0x0317+ 6166-0x1b2c));}}sub isTimeForCheckLogrotate{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $delay=$__checkLogrotateDelay);if (
(($__lastCheckLogrotate+$delay)<$currentTime)){return ((0x070c+ 3049-0x12f4));}
return ((0x060c+ 5385-0x1b15));}sub checkLogrotateAndHandleIfNeeded{
Logger::debug (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x63\x68\x65\x64\x75\x6c\x65\x64\x20\x6c\x6f\x67\x20\x72\x6f\x74\x61\x74\x69\x6f\x6e\x20\x63\x68\x65\x63\x6b\x20\x66\x6f\x72\x20\x61\x6c\x6c\x20\x66\x69\x6c\x65\x73\x2e"
);($__lastCheckLogrotate=Common::NXTime::getSecondsSinceEpoch ());(my (
@typesToRotate)=());main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42");NXLogrotateDB::reload ()
;(my (@logTypes)=NXLogrotateDB::getLogTypes ());foreach my $type (@logTypes){(my $size
=NXLogrotateDB::getSizeInBytes ($type));(my $minsize=
NXLogrotateDB::getMinsizeInBytes ($type));(my $isTimeToRotate=
NXLogrotateDB::isTimeToRotate ($type));(my (%filePaths)=__getFilePathsByLogType 
($type));foreach my $fileName (keys (%filePaths)){(my $filePath=$filePaths{
$fileName});(my $fileSize=Common::NXCore::NXFileSize ($filePath));if (($size and
 ($size<=$fileSize))){return (__runLogrotateCommand ());}if ($isTimeToRotate){if
 (((not ($minsize))or ($minsize<$fileSize))){return (__runLogrotateCommand ());}
}}}}sub __runLogrotateCommand{(my (@command)=($GLOBAL::CommandNXexec,
$GLOBAL::SCRIPT_NXLOGROTATE));(my (@options)=
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");main::nxRunCommand ((\@command),(
\@options));Logger::debug (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x3a\x20\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x6c\x6f\x67\x72\x6f\x74\x61\x74\x65\x20\x68\x61\x73\x20\x62\x65\x65\x6e\x20\x72\x75\x6e\x2e"
);}sub automaticRotate{(my (%typesToRotate)=());main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42");NXLogrotateDB::reload ()
;(my (@logTypes)=NXLogrotateDB::getLogTypes ());foreach my $type (@logTypes){(my $size
=NXLogrotateDB::getSizeInBytes ($type));(my $minsize=
NXLogrotateDB::getMinsizeInBytes ($type));(my $isTimeToRotate=
NXLogrotateDB::isTimeToRotate ($type));(my (%filePaths)=__getFilePathsByLogType 
($type));(my (%pathsToRotate)=());if (__shouldSkipMultiTypeLogrotateForType (
$type)){next;}foreach my $fileName (keys (%filePaths)){(my $filePath=$filePaths{
$fileName});(my $fileSize=Common::NXCore::NXFileSize ($filePath));if (($size and
 ($size<=$fileSize))){($pathsToRotate{$fileName}=$filePath);($typesToRotate{
$type}=(\%pathsToRotate));next;}if ($isTimeToRotate){if (((not ($minsize))or (
$minsize<$fileSize))){($pathsToRotate{$fileName}=$filePath);($typesToRotate{
$type}=(\%pathsToRotate));next;}}}}(my $silent=(0x0a21+ 1762-0x1102));foreach my $type
 (keys (%typesToRotate)){__rotateFilesByLogType ($type,$typesToRotate{$type},
$silent);NXLogrotateDB::updateLastRotateTime ($type);}}sub 
__getFilePathByLogType{(my $type=shift (@_));if (($type eq 
Logger::getLogrotateLogTypeNxserverLog ())){return (
Common::NXPaths::getNXServerLogPath ());}elsif (($type eq 
Logger::getLogrotateLogTypeNxdLog ())){return (NXPaths::getNxdLog ());}elsif ((
$type eq Logger::getLogrotateLogTypeNwebclientLog ())){return (
NXPaths::getNxwebclientLog ());}elsif (($type eq 
Logger::getLogrotateLogTypeNxhtdErrorLog ())){if (($__nxhtdErrorLogPath eq (""))
){($__nxhtdErrorLogPath=NXTools::getNxhtdErrorLogPath ());}return (
$__nxhtdErrorLogPath);}elsif (($type eq Logger::getLogrotateLogTypeNxserviceLog 
())){return (NXPaths::getNxserviceLog ());}else{return ((""));}}sub 
__getFilenameByLogType{(my $type=shift (@_));if (($type eq 
Logger::getLogrotateLogTypeNxserverLog ())){return (
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67");}elsif (($type eq 
Logger::getLogrotateLogTypeNxdLog ())){return ("\x6e\x78\x64\x2e\x6c\x6f\x67");}
elsif (($type eq Logger::getLogrotateLogTypeNwebclientLog ())){return (
"\x6e\x78\x77\x65\x62\x72\x75\x6e\x6e\x65\x72\x2e\x6c\x6f\x67");}elsif (($type 
eq Logger::getLogrotateLogTypeNxhtdErrorLog ())){return (
"\x6e\x78\x68\x74\x64\x2e\x6c\x6f\x67");}elsif (($type eq 
Logger::getLogrotateLogTypeNxserviceLog ())){return (
"\x6e\x78\x73\x65\x72\x76\x69\x63\x65\x2e\x6c\x6f\x67");}else{return ((""));}}
sub isLogTypeSupported{(my $type=shift (@_));(my (@supportedTypes)=
getAllSupportedLogrotateLogTypes ());foreach my $supportedType (@supportedTypes)
{if (($supportedType eq $type)){return ((0x2167+ 1153-0x25e7));}}return (
(0x0acb+ 3735-0x1962));}sub getAllSupportedLogrotateLogTypes{(my (@types)=());
push (@types,Logger::getLogrotateLogTypeNxserverLog ());push (@types,
Logger::getLogrotateLogTypeNxdLog ());if (NXLicense::isHttpdSupportFeature ()){
push (@types,Logger::getLogrotateLogTypeNwebclientLog ());push (@types,
Logger::getLogrotateLogTypeNxhtdErrorLog ());}return (@types);}sub 
__isTypeNxserverLog{(my $type=shift (@_));if (($type eq 
Logger::getLogrotateLogTypeNxserverLog ())){return ((0x1e03+ 1940-0x2596));}
return ((0x107f+ 5294-0x252d));}sub __isTypeNxwebclientLog{(my $type=shift (@_))
;if (($type eq Logger::getLogrotateLogTypeNwebclientLog ())){return (
(0x1813+ 3122-0x2444));}return ((0x0328+ 3935-0x1287));}sub __truncateFile{(my $filePath
=shift (@_));(my $handle=main::nxopen ($filePath,($NXBits::O_WRONLY+
$NXBits::O_TRUNC)));if (defined ($handle)){main::nxclose ($handle);return (
(0x0ce2+ 4720-0x1f51));}return ((0x0316+ 2678-0x0d8c));}sub __copyLogFile{(my $filePath
=shift (@_));(my $destFilePath=shift (@_));(my ($return,$error)=
Common::NXCore::copyFile ($filePath,$destFilePath));if (($error ne (""))){return
 ((0x18a5+ 310-0x19db));}__correctRotatedFileOwnershipAndPermissions (
$destFilePath);return ((0x1500+ 2956-0x208b));}sub 
__correctRotatedFileOwnershipAndPermissions{(my $file=shift (@_));
Common::NXFile::setPermissionsReadWriteForNX ($file);if (
main::effectiveUserIsAdministrator ()){
Common::NXFile::setOwnershipForUserAndGroupNX ($file);}return (
(0x06e5+ 7932-0x25e0));}sub __setForcedRotateDateTime{($__forcedRotateDateTime=
shift (@_));}sub __getForcedRotateDateTime{return ($__forcedRotateDateTime);}sub
 __setForcedRotate{($__forcedRotate=(0x01b9+ 3300-0x0e9c));}sub __isForcedRotate
{return ($__forcedRotate);}sub __getForcedRotateDestination{return (
$$__ref_forcedRotateParameters{"\x64\x65\x73\x74\x69\x6e\x61\x74\x69\x6f\x6e"});
}sub __isForcedRotateCompress{if (($$__ref_forcedRotateParameters{
"\x63\x6f\x6d\x70\x72\x65\x73\x73"}eq "\x6e\x6f")){return ((0x15d3+ 269-0x16e0))
;}else{return ((0x08e9+ 4064-0x18c8));}}sub __isNotForcedRotate{return ((!
__isForcedRotate ()));}sub __handleForcedRotateParameters{(my $ref_parameters=
shift (@_));($__ref_forcedRotateParameters=$ref_parameters);main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x44\x42","\x69\x6e\x69\x74");(my $procedure
="\x66\x6f\x72\x63\x65\x64\x52\x6f\x74\x61\x74\x65");return (
NXLogrotateDB::handleDestinationAndCompressParameters ($ref_parameters,
$procedure));}sub __shouldSkipMultiTypeLogrotateForType{(my $type=shift (@_));
return ((0x0e80+ 4670-0x20be));}NXMsg::register_response (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x69\x43\x4d\x44\x53\x74\x61\x72\x74\x69\x6e\x67\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65"
,(0x0cd9+ 2476-0x1301));NXMsg::register_response (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x69\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x69\x6e\x69\x73\x68\x65\x64"
,(0x0dfc+ 6885-0x255d));NXMsg::register_response (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x69\x43\x4d\x44\x43\x6f\x6d\x70\x72\x65\x73\x73\x65\x64\x46\x69\x6c\x65",
(0x17a7+ 4024-0x23db));NXMsg::register_error (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x46\x61\x69\x6c\x65\x64",
(0x0695+ 3690-0x130b));NXMsg::register_error (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x65\x43\x4d\x44\x46\x69\x6c\x65\x49\x73\x42\x65\x69\x6e\x67\x55\x73\x65\x64",
(0x102a+ 1021-0x1233));NXMsg::register_error (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x6d\x70\x72\x65\x73\x73\x46\x69\x6c\x65"
,(0x169f+ 2740-0x1f5f));NXMsg::register_error (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65",
"\x65\x43\x4d\x44\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65\x54\x79\x70\x65\x4e\x6f\x74\x53\x75\x70\x70\x6f\x72\x74\x65\x64"
,(0x0912+ 3692-0x158a));"\x3f\x3f\x3f";
