############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package KeysManager;no warnings;(my $__maxRotatedFiles=(0x0664+ 3429-0x13c3));
sub __getBackupFileName{(my $name=shift (@_));($name.=
"\x2e\x62\x61\x63\x6b\x75\x70");if ((not (Common::NXFile::fileExists ($name)))){
return ($name);}(my $number=(0x0f28+ 3570-0x1d18));while (($number<=
$__maxRotatedFiles)){if ((not (Common::NXFile::fileExists (($name.$number))))){
return (($name.$number));}($number+=(0x0e68+ 2777-0x1940));}($number=
(0x1223+ 1521-0x1813));(my $oldestFile=$name);(my $oldestCTime=
Common::NXCore::NXFileCTime ($name));while (($number<=$__maxRotatedFiles)){(my $cTime
=Common::NXCore::NXFileCTime (($name.$number)));if (($oldestCTime>$cTime)){(
$oldestFile=($name.$number));($oldestCTime=$cTime);}($number+=
(0x0185+ 2640-0x0bd4));}return ($oldestFile);}sub __backupKey{(my $file=shift (
@_));(my $backup=__getBackupFileName ($file));if (Common::NXFile::fileExists (
$file)){(my ($ret,$error)=Common::NXCore::copyFile ($file,$backup));if (($error 
ne (""))){Logger::warning ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x62\x61\x63\x6b\x75\x70\x20\x66\x69\x6c\x65\x2e\x20"
.$error));return ((0x0c50+ 5428-0x2183));}else{
Common::NXFile::setOwnerShipAndPermissionsReadOnlyForNX ($backup);}}return (
(0x0080+ 9673-0x2649));}sub __createRestore{(my $file=shift (@_));if ((not (
Common::NXFile::isExists ($file)))){Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x72\x65\x73\x74\x6f\x72\x65\x20\x66\x69\x6c\x65\x2e\x20"
.$file)."\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));
return ((0x041f+ 7600-0x21cf));}(my $restore=($file.
"\x2e\x72\x65\x73\x74\x6f\x72\x65"));if (Common::NXFile::isExists ($restore)){
Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x72\x65\x73\x74\x6f\x72\x65\x20\x66\x69\x6c\x65\x2e\x20"
.$restore)."\x20\x65\x78\x69\x73\x74\x73\x2e"));return ((0x090b+ 3110-0x1531));}
if (Common::NXFile::fileExists ($file)){(my ($ret,$error)=
Common::NXCore::copyFile ($file,$restore));if (($error ne (""))){Logger::warning
 ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x72\x65\x73\x74\x6f\x72\x65\x20\x66\x69\x6c\x65\x2e\x20"
.$error));return ((0x153f+ 1305-0x1a57));}else{
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($restore);}}return
 ((0x1c32+ 1367-0x2189));}sub __createDefault{(my $file=shift (@_));(my $default
=shift (@_));if (Common::NXFile::fileExists ($default)){return (
(0x0fe8+ 1151-0x1467));}if (Common::NXFile::fileExists ($file)){(my ($ret,$error
)=Common::NXCore::copyFile ($file,$default));if (($error ne (""))){
Logger::warning ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x66\x61\x75\x6c\x74\x20\x66\x69\x6c\x65\x2e\x20"
.$error));return ((0x0669+ 5291-0x1b13));}else{
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($default);}}return
 ((0x1581+ 986-0x195b));}sub backup{if ((__backupKey (NXPaths::getNodePublicKeys
 ())==(0x045c+ 4012-0x1407))){return ((0x0526+ 3411-0x1278));}if ((__backupKey (
NXPaths::getUserDefaultRSAPublicKeyPath ())==(0x0711+ 3777-0x15d1))){return (
(0x039f+ 6754-0x1e00));}if ((__backupKey (NXPaths::getClientRSAPrivateKey ())==
(0x0264+ 4899-0x1586))){return ((0x1a8b+  10-0x1a94));}if ((__backupKey (
NXPaths::getClientRSADefaultPrivateKey ())==(0x0833+ 5183-0x1c71))){return (
(0x1e2c+ 682-0x20d5));}if ((__backupKey (NXPaths::getClientDSADefaultPrivateKey 
())==(0x0722+ 8112-0x26d1))){return ((0x021b+ 498-0x040c));}if ((__createRestore
 (NXPaths::getClientRSAPrivateKey ())==(0x010a+ 7199-0x1d28))){return (
(0x07d8+ 3232-0x1477));}return ((0x0746+ 5256-0x1bce));}sub __generateRSAKeys{(my $public
=NXPaths::getUserNewRSAPublicKey ());(my $private=
NXPaths::getUserNewRSAPrivateKey ());return (__generateKeys ($public,$private,
"\x72\x73\x61"));}sub __generateKeys{(my $publicKeyFileName=shift (@_));(my $privateKeyFileName
=shift (@_));(my $algorithm=shift (@_));(my (@command)=());(my (@options)=());(my $selinuxenabled
=NXTools::getUnixCommandPath (
"\x73\x65\x6c\x69\x6e\x75\x78\x65\x6e\x61\x62\x6c\x65\x64"));if (
Common::NXFile::isExists ($selinuxenabled)){(@command=$selinuxenabled);(my $runcon
=NXTools::getUnixCommandPath ("\x72\x75\x6e\x63\x6f\x6e"));(my ($cmd_err,
$cmd_out,$exit_value)=main::run_command ((\@command),(\@options)));if ((
$exit_value==(0x0a65+ 3382-0x179b))){if (Common::NXFile::isExists ($runcon)){
push (@command,$runcon,"\x2d\x75","\x72\x6f\x6f\x74","\x2d\x72",
"\x73\x79\x73\x74\x65\x6d\x5f\x72","\x2d\x74","\x69\x6e\x69\x74\x72\x63\x5f\x74"
,"\x2d\x2d");}}else{Logger::debug2 (
"\x53\x65\x6c\x69\x6e\x75\x78\x20\x69\x73\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x69\x6e\x20\x74\x68\x69\x73\x20\x73\x79\x73\x74\x65\x6d"
);}}(@command=());push (@command,$GLOBAL::COMMAND_NXKEYGEN);push (@command,
"\x2d\x6b",$privateKeyFileName,"\x2d\x74",$algorithm,"\x2d\x70",
$publicKeyFileName);push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(((
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".
$GLOBAL::NODE_ROOT).$GLOBAL::DIRECTORY_SLASH)."\x6c\x69\x62"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".
$GLOBAL::NODE_ROOT));push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x48\x4f\x4d\x45\x3d".NXPaths::getUserNXHomeDir ()));(my ($cmdErr,$cmdOut,
$exitValue)=main::nxRunCommand ((\@command),(\@options)));if (($exitValue!=
(0x0925+ 3259-0x15e0))){Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x6e\x65\x72\x61\x74\x65\x20".$algorithm).
"\x20\x6b\x65\x79\x20").$exitValue).
"\x2e\x20\x50\x6c\x65\x61\x73\x65\x20\x63\x68\x65\x63\x6b\x20\x74\x68\x65\x20\x27\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x6c\x6f\x67\x27\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x20\x69\x73\x73\x75\x65\x73\x2e"
));}return ($exitValue);}sub __getKeysFromFile{(my $keyFile=shift (@_));if ((not
 (Common::NXFile::isExists ($keyFile)))){return (undef);}(my (@keyLists)=());(my $fileFH
=Common::NXCore::nxopen ($keyFile,$NXBits::O_RDONLY,(0x1645+ 1938-0x1dd7)));if (
(not (defined ($fileFH)))){(my $error=libnxh::NXGetErrorName ());Logger::error (
((("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$keyFile)."\x27\x3a\x20").$error));return (undef);}while (
Common::NXCore::nxreadLine ($fileFH,(\$_))){($_=~ s/\r//g );chomp ($_);push (
@keyLists,$_);}Common::NXCore::nxclose ($fileFH);return (@keyLists);}sub 
__addPrefix{(my $file=shift (@_));(my (@keys)=__getKeysFromFile ($file));if ((
not (defined (@keys)))){return ((0x0047+ 4537-0x11ff));}(my $fh=
Common::NXCore::nxopen ($file,$NXBits::O_WRONLY,(0x0fb4+ 5050-0x236e)));if ((not
 (defined ($fh)))){(my $error=libnxh::NXGetErrorName ());Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".$file).
"\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x2e\x20").$error)."\x2e"));return (
(0x0b73+ 1519-0x1161));}foreach my $key (@keys){($key=__getKeyWithPrefix ($key))
;if ((Common::NXCore::nxwrite ($fh,$key)==(-(0x19eb+ 1029-0x1def)))){(my $error=
libnxh::NXGetErrorName ());Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20"
.$file)."\x3a\x20").$error)."\x2e"));Common::NXCore::nxclose ($fh);return (
(0x150b+ 1529-0x1b03));}}Common::NXCore::nxclose ($fh);return (
(0x0461+ 2331-0x0d7c));}sub __getKeyWithPrefix{(my $key=shift (@_));chomp ($key)
;chomp ($key);(my $keyWithPrefix.=
"\x6e\x6f\x2d\x70\x6f\x72\x74\x2d\x66\x6f\x72\x77\x61\x72\x64\x69\x6e\x67\x2c");
(my $path=NXPaths::getServerLaunchPath ());($keyWithPrefix.=((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x22".$path).
"\x20\x2d\x2d\x6c\x6f\x67\x69\x6e\x22\x20"));($keyWithPrefix.=$key);(
$keyWithPrefix.="\x0a");return ($keyWithPrefix);}sub generate{if (
isRSASuportedByServerConfig ()){if ((__generateRSAKeys ()>(0x0db3+ 1074-0x11e5))
){return ((0x0796+ 2348-0x10c1));}if ((__addPrefix (
NXPaths::getUserNewRSAPublicKey ())==(0x13d0+ 4894-0x26ed))){return (
(0x0952+ 6200-0x2189));}}return ((0x177f+ 3792-0x264f));}sub 
__changeRSAPublicKey{(my $file=NXPaths::getNodePublicKeys ());(my $oldKey=
NXPaths::getUserDefaultRSAPublicKeyPath ());if (Common::NXFile::isExists (
$oldKey)){if ((__removePublicKey ($file,$oldKey)==(0x016f+ 2066-0x0980))){return
 ((0x176a+ 1409-0x1cea));}}(my $newKey=NXPaths::getUserNewRSAPublicKey ());if ((
__addPublicKey ($file,$newKey)==(0x00a8+ 3211-0x0d32))){return (
(0x20a8+ 1231-0x2576));}if ((__moveKey ($newKey,$oldKey)==(0x0742+ 4183-0x1798))
){return ((0x0e79+ 3393-0x1bb9));}return ((0x0fef+ 1189-0x1494));}sub 
__removePublicKey{(my $file=shift (@_));(my $oldKeyFile=shift (@_));(my (
@oldKeys)=__getKeysFromFile ($oldKeyFile));if ((not (defined (@oldKeys)))){
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6f\x6c\x64\x20\x6b\x65\x79\x73\x20\x66\x6f\x72\x6d\x20\x66\x69\x6c\x65\x20"
.$oldKeyFile)."\x2e"));return ((0x1487+ 1236-0x195a));}(my (@oldKeys)=
__getKeysFromFile ($oldKeyFile));foreach my $key (@oldKeys){__removePrefix ((
\$key));}foreach my $key (@oldKeys){if ((removeKeyFromFile ($key,$file,
"\x53\x53\x48")==(0x0c54+ 6135-0x244a))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x6f\x6c\x64\x20\x6b\x65\x79\x20\x66\x6f\x72\x6d\x20\x66\x69\x6c\x65\x20"
.$file)."\x2e"));return ((0x1c60+ 1290-0x2169));}}return ((0x17bb+ 3847-0x26c2))
;}sub __removePrefix{(my $ref_key=shift (@_));if (($$ref_key=~ /(.*) (ssh-.*) (.*)/ )
){(my $type=$2);(my $value=$3);Logger::debug (((
"\x52\x65\x6d\x6f\x76\x65\x64\x20\x70\x72\x65\x66\x69\x78\x3a\x20".$1)."\x2e"));
($$ref_key=(($type."\x20").$value));}}sub __addPublicKey{(my $file=shift (@_));(my $newKeyFile
=shift (@_));(my (@newKeys)=__getKeysFromFile ($newKeyFile));if ((not (defined (
@newKeys)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x6e\x65\x77\x20\x6b\x65\x79\x73\x20\x66\x6f\x72\x6d\x20\x66\x69\x6c\x65\x20"
.$newKeyFile)."\x2e"));return ((0x0fa0+ 2041-0x1798));}(my $fh=
Common::NXCore::nxopen ($file,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+
$NXBits::O_APPEND),$NXBits::UserReadWrite));if ((not (defined ($fh)))){(my $error
=libnxh::NXGetErrorName ());Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20".$file).
"\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x2e\x20").$error)."\x2e"));return (
(0x0469+ 2818-0x0f6a));}foreach my $key (@newKeys){if ((Common::NXCore::nxwrite 
($fh,($key."\x0a"))==(-(0x0882+ 2684-0x12fd)))){(my $error=
libnxh::NXGetErrorName ());Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x20\x66\x69\x6c\x65\x20"
.$file)."\x3a\x20").$error)."\x2e"));Common::NXCore::nxclose ($fh);return (
(0x021d+ 5785-0x18b5));}}Common::NXCore::nxclose ($fh);if ((
Common::NXFile::setOwnerShipAndPermissionsReadOnlyForNX ($file)==(-
(0x0f73+ 5779-0x2605)))){return ((0x0076+ 9229-0x2482));}return (
(0x148c+ 2784-0x1f6c));}sub __changeRSAPrivateKey{(my $newFile=
NXPaths::getUserNewRSAPrivateKey ());(my $clientFile=
NXPaths::getClientRSAPrivateKey ());if ((__moveKey ($newFile,$clientFile)==
(0x085b+ 1573-0x0e7f))){return ((0x2348+ 891-0x26c2));}return (
(0x088a+ 7234-0x24cc));}sub __moveKey{(my $from=shift (@_));(my $to=shift (@_));
if (Common::NXFile::fileExists ($from)){if ((Common::NXCore::moveFile ($from,$to
)==(0x0e86+ 3108-0x1aaa))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6f\x76\x65\x20\x6b\x65\x79\x20\x66\x69\x6c\x65\x2e"
);return ((0x14bd+ 1030-0x18c2));}}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20".$from).
"\x2e\x20\x46\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"
));return ((0x0ef8+ 3016-0x1abf));}return ((0x15d4+ 367-0x1743));}sub __copyKey{
(my $from=shift (@_));(my $to=shift (@_));if (Common::NXFile::fileExists ($from)
){(my ($ret,$error)=Common::NXCore::copyFile ($from,$to));if (($error ne (""))){
Logger::warning ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x6f\x70\x79\x20\x73\x73\x68\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x66\x69\x6c\x65\x2e\x20"
.$error));return ((0x069b+ 635-0x0915));}else{if ((
Common::NXFile::setPermissionReadWriteForOwnerReadOnlyForAll ($to)==(-
(0x0753+ 3114-0x137c)))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73\x20\x66\x6f\x72\x20\x66\x69\x6c\x65\x20"
.$to)."\x2e"));return ((0x12c2+  74-0x130b));}}}else{Logger::warning (((
"\x53\x6f\x75\x72\x63\x65\x20\x6b\x65\x79\x20\x66\x69\x6c\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x20"
.$from)."\x2e"));return ((0x0406+ 4200-0x146d));}return ((0x0227+ 5725-0x1884));
}sub change{if (isRSASuportedByServerConfig ()){if ((__changeRSAPublicKey ()==
(0x0740+ 5571-0x1d02))){return ((0x093a+ 4402-0x1a6b));}if ((
__changeRSAPrivateKey ()==(0x0f4c+ 4207-0x1fba))){return ((0x0e0a+  54-0x0e3f));
}}return ((0x0061+ 7705-0x1e7a));}sub __restoreRSAPublicKey{(my $file=
NXPaths::getNodePublicKeys ());(my $oldKey=
NXPaths::getUserDefaultRSAPublicKeyPath ());if (Common::NXFile::isExists (
$oldKey)){if ((__removePublicKey ($file,$oldKey)==(0x097f+ 6084-0x2142))){return
 ((0x2223+ 208-0x22f2));}}(my $newKey=NXPaths::getRestoreRSAPublicKey ());if ((
__addPublicKey ($file,$newKey)==(0x097f+ 3343-0x168d))){return (
(0x09b7+ 714-0x0c80));}if ((__copyKey ($newKey,$oldKey)==(0x0e73+ 3729-0x1d03)))
{return ((0x03bd+ 946-0x076e));}return ((0x127d+ 4645-0x24a2));}sub 
__restoreRSAPrivateKey{(my $restoreKey=NXPaths::getClientRSARestorePrivateKey ()
);(my $clientKey=NXPaths::getClientRSAPrivateKey ());if ((__copyKey ($restoreKey
,$clientKey)==(0x185b+ 2392-0x21b2))){return ((0x132b+ 3117-0x1f57));}return (
(0x0422+ 3418-0x117c));}sub restore{if (isRSASuportedByServerConfig ()){if ((
__restoreRSAPublicKey ()==(0x00c4+ 2701-0x0b50))){return ((0x1024+ 2870-0x1b59))
;}if ((__restoreRSAPrivateKey ()==(0x022b+ 7523-0x1f8d))){return (
(0x0c02+ 3096-0x1819));}}return ((0x0d6c+ 1435-0x1307));}sub __isKeyInLine{(my $key
=shift (@_));(my $line=shift (@_));(my $protocol=shift (@_));($key=~ s/\r//g );(
$key=~ s/\n//g );chomp ($key);(my ($keyType,$keyValue)=split ( / / ,$key,
(0x01c5+  37-0x01e7)));($line=~ s/\r//g );($line=~ s/\n//g );chomp ($line);(my (
@lineFields)=split ( / / ,$line,(0x0032+ 4087-0x1029)));if (($protocol eq 
"\x53\x53\x48")){if ((($keyType eq $lineFields[(0x093d+ 4203-0x19a6)])and (
$keyValue eq $lineFields[(0x0700+ 6541-0x208a)]))){Logger::debug (((
"\x4b\x65\x79\x20\x27".$key).
"\x27\x20\x6b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e"
));return ((0x00d4+ 5825-0x1794));}if ((($keyType eq $lineFields[
(0x0959+ 1972-0x110c)])and ($keyValue eq $lineFields[(0x03f9+ 8277-0x244c)]))){
Logger::debug ((("\x4b\x65\x79\x20\x27".$key).
"\x27\x20\x6b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e"
));return ((0x0fc4+ 5755-0x263e));}}else{if ((($keyType eq $lineFields[
(0x0976+ 5267-0x1e09)])and ($keyValue eq $lineFields[(0x0f04+ 1484-0x14cf)]))){
Logger::debug ((("\x4b\x65\x79\x20\x27".$key).
"\x27\x20\x6b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e"
));return ((0x03b9+ 1865-0x0b01));}}return ((0x1761+ 3570-0x2553));}sub 
__isAnyKeyInLine{(my $line=shift (@_));(my $protocol=shift (@_));($line=~ s/\r//g )
;($line=~ s/\n//g );chomp ($line);(my (@lineFields)=split ( / / ,$line,
(0x1500+ 2160-0x1d70)));if (($protocol eq "\x53\x53\x48")){if ((($lineFields[
(0x1608+ 3854-0x2514)]ne (""))and ($lineFields[(0x06a8+ 5787-0x1d40)]ne ("")))){
Logger::debug (
"\x4b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e");
return ((0x2396+  79-0x23e4));}if ((($lineFields[(0x14d2+ 1318-0x19f7)]ne (""))
and ($lineFields[(0x216a+ 1224-0x2630)]ne ("")))){Logger::debug (
"\x4b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e");
return ((0x08ec+ 3444-0x165f));}}else{if ((($lineFields[(0x0564+ 218-0x063e)]ne 
(""))and ($lineFields[(0x05e5+ 4684-0x1830)]ne ("")))){Logger::debug (
"\x4b\x65\x79\x20\x6b\x65\x79\x20\x66\x6f\x75\x6e\x64\x20\x69\x6e\x20\x6c\x69\x6e\x65\x2e"
);return ((0x043a+ 6391-0x1d30));}}return ((0x0fea+ 2786-0x1acc));}sub 
removeKeyFromFile{(my $keyToRemove=shift (@_));(my $filePath=shift (@_));(my $protocol
=shift (@_));(my $tempFilePath=(($filePath."\x2e\x74\x6d\x70\x2e").$ $));
 (my $fileFH
=Common::NXCore::nxopen ($filePath,$NXBits::O_RDONLY,(0x215a+ 371-0x22cd)));if (
(not (defined ($fileFH)))){(my $error=libnxh::NXGetErrorName ());Logger::error (
((("\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$filePath)."\x27\x3a\x20").$error));return ((0x0c53+ 741-0x0f37));}(my $tempFileFH
=Common::NXCore::nxopen ($tempFilePath,(($NXBits::O_CREAT+$NXBits::O_WRONLY)+
$NXBits::O_APPEND),$NXBits::UserReadWrite));if ((not (defined ($tempFileFH)))){(my $error
=libnxh::NXGetErrorName ());Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x74\x65\x6d\x70\x6f\x72\x61\x72\x79\x20\x66\x69\x6c\x65\x20\x27"
.$tempFilePath)."\x27\x3a\x20").$error));return ((0x1aa7+ 1231-0x1f75));}while (
Common::NXCore::nxreadLine ($fileFH,(\$_))){(my $line=$_);if (__isKeyInLine (
$keyToRemove,$line,$protocol)){Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x6b\x65\x79\x20\x27".$line)."\x27\x2e"));}
else{Common::NXCore::nxwrite ($tempFileFH,$line);}}Common::NXCore::nxclose (
$tempFileFH);Common::NXCore::nxclose ($fileFH);if ((Common::NXFile::renameFile (
$tempFilePath,$filePath)==(0x15dd+ 1581-0x1c0a))){return ((0x0778+ 2173-0x0ff4))
;}if ((Common::NXFile::setOwnerShipAndPermissionsForNX ($filePath)==(-
(0x0f4b+ 2135-0x17a1)))){return ((0x045a+ 4783-0x1708));}return (
(0x0846+ 2999-0x13fd));}sub isKeyInFile{(my $key=shift (@_));(my $keyFile=shift 
(@_));(my $protocol=shift (@_));(my (@listSupportedKeys)=__getKeysFromFile (
$keyFile));foreach my $line (@listSupportedKeys){if (__isKeyInLine ($key,$line,
$protocol)){Logger::debug (
"\x4b\x65\x79\x20\x69\x73\x20\x69\x6e\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x2e");
return ((0x06d1+ 7509-0x2425));}}Logger::debug (
"\x4b\x65\x79\x20\x69\x73\x20\x75\x6e\x69\x71\x75\x65\x2e");return (
(0x0743+ 6039-0x1eda));}sub restorePrivateKey{(my $privateKey=
NXPaths::getClientPrivateKey ());(my $defaultPrivateKey=
NXPaths::getClientDefaultPrivateKey ());(my $restore=($privateKey.
"\x2e\x72\x65\x73\x74\x6f\x72\x65"));if (Common::NXFile::fileExists ($restore)){
copyKeyFile ($restore,$privateKey);copyKeyFile ($restore,$defaultPrivateKey);}}
sub isNotExistNodePublicKey{if (((not (Common::NXFile::isExists (
NXPaths::getNodePublicKeys ())))and (not (Common::NXFile::isExists (
NXPaths::getNXAuthorizedKeysPath ("\x6e\x78")))))){return ((0x06a9+ 1033-0x0ab1)
);}if (Common::NXFile::isExists (NXPaths::getNXAuthorizedKeysPath ("\x6e\x78")))
{(my (@listSupportedKeys)=__getKeysFromFile (NXPaths::getNXAuthorizedKeysPath (
"\x6e\x78")));foreach my $line (@listSupportedKeys){if (__isAnyKeyInLine ($line,
"\x4e\x58")){Logger::debug (
"\x46\x6f\x75\x6e\x64\x20\x4e\x58\x20\x6b\x65\x79\x2e");return (
(0x08c6+ 1911-0x103d));}}}if (Common::NXFile::isExists (
NXPaths::getNodePublicKeys ())){(my (@listSupportedKeys)=__getKeysFromFile (
NXPaths::getNodePublicKeys ()));foreach my $line (@listSupportedKeys){if (
__isAnyKeyInLine ($line,"\x53\x53\x48")){Logger::debug (
"\x46\x6f\x75\x6e\x64\x20\x53\x53\x48\x20\x6b\x65\x79\x2e");return (
(0x2267+ 690-0x2519));}}}return ((0x05db+ 6066-0x1d8c));}sub 
getSupportedSSHDKeyExchangeAlgorithm{if ((
$GLOBAL::SupportedSSHDKeyExchangeAlgorithm=~ /DSA|RSA|all|DSA,RSA|RSA,DSA/ )){
return ($GLOBAL::SupportedSSHDKeyExchangeAlgorithm);}else{Logger::warning (((
"\x57\x72\x6f\x6e\x67\x20\x76\x61\x6c\x75\x65\x20\x66\x6f\x72\x20\x6b\x65\x79\x3a\x20\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x53\x53\x48\x44\x4b\x65\x79\x45\x78\x63\x68\x61\x6e\x67\x65\x41\x6c\x67\x6f\x72\x69\x74\x68\x6d\x3a\x20"
.$GLOBAL::SupportedSSHDKeyExchangeAlgorithm).
"\x20\x75\x73\x65\x20\x61\x6c\x6c\x2e"));return ("\x61\x6c\x6c");}}sub 
isDSASuportedByServerConfig{(my $supportedKeyList=
getSupportedSSHDKeyExchangeAlgorithm ());if (($supportedKeyList=~ /DSA/ )){
return ((0x0967+ 3491-0x1709));}if (($supportedKeyList eq "\x61\x6c\x6c")){
return ((0x0368+ 2054-0x0b6d));}return ((0x1090+ 5543-0x2637));}sub 
isRSASuportedByServerConfig{(my $supportedKeyList=
getSupportedSSHDKeyExchangeAlgorithm ());if (($supportedKeyList=~ /RSA/ )){
return ((0x015a+ 4606-0x1357));}if (($supportedKeyList eq "\x61\x6c\x6c")){
return ((0x14bf+ 2582-0x1ed4));}return ((0x0936+ 828-0x0c72));}sub add{(my $ref_parameters
=shift (@_));($$ref_parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}=uc (
$$ref_parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}));if (($$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}eq (""))){($$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}="\x4e\x58");}unless (__getKey (
$ref_parameters)){return ((0x03c2+ 1715-0x0a75));}unless (prepareKey (
$ref_parameters)){return ((0x1a48+ 461-0x1c15));}unless (setKey ($ref_parameters
)){return ((0x1a9d+ 1714-0x214f));}NXMsg::send_response (
"\x69\x43\x4d\x44\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x41\x64\x64\x65\x64\x4f\x6b"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$$ref_parameters{
"\x61\x75\x74\x68\x46\x69\x6c\x65"});return ((0x12cd+ 2469-0x1c71));}sub 
__getKey{(my $ref_parameters=shift (@_));if (($$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"}ne (""))){unless (__getKeyFromFile (
$ref_parameters)){return ((0x043f+ 2276-0x0d23));}return ((0x0f75+ 1331-0x14a7))
;}unless (__getKeyFromSTDIN ($ref_parameters)){return ((0x0171+ 1603-0x07b4));}
return ((0x0722+ 5553-0x1cd2));}sub __getKeyFromFile{(my $ref_parameters=shift (
@_));unless (Common::NXFile::isExists ($$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"})){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x4e\x6f\x74\x45\x78\x69\x73\x74"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"});return ((0x0501+ 5051-0x18bc));}(my $INFILE=
Common::NXCore::nxopen ($$ref_parameters{"\x6b\x65\x79\x46\x69\x6c\x65"},
$NXBits::O_RDONLY));unless (defined ($INFILE)){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x52\x65\x61\x64"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"});return ((0x0458+ 6097-0x1c29));}if ((
Common::NXCore::nxread ($INFILE,(\$$ref_parameters{"\x6b\x65\x79"}))==
(0x0390+ 1782-0x0a86))){NXMsg::error (
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x45\x6d\x70\x74\x79\x46\x69\x6c\x65"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x6b\x65\x79\x46\x69\x6c\x65"});Common::NXCore::nxclose ($INFILE);return (
(0x1089+ 4208-0x20f9));}Logger::debug ((((("\x4b\x65\x79\x20\x27".
$$ref_parameters{"\x6b\x65\x79"}).
"\x27\x20\x72\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x66\x69\x6c\x65\x20\x27").
$$ref_parameters{"\x6b\x65\x79\x46\x69\x6c\x65"})."\x27\x2e"));
Common::NXCore::nxclose ($INFILE);return ((0x01b8+ 7314-0x1e49));}sub 
__getKeyFromSTDIN{(my $ref_parameters=shift (@_));(my $message=
"\x4e\x58\x3e\x20\x39\x32\x33\x20\x50\x6c\x65\x61\x73\x65\x20\x65\x6e\x74\x65\x72\x20\x74\x68\x65\x20\x73\x73\x68\x2d\x64\x73\x73\x20\x6b\x65\x79\x3a"
);(my $bytes=main::nxwrite (main::nxgetSTDOUT (),$message));unless (($bytes>
(0x06b5+ 768-0x09b5))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x6b\x65\x79\x20\x72\x65\x71\x75\x65\x73\x74\x20\x6f\x6e\x20\x53\x54\x44\x4f\x55\x54\x2e"
);return ((0x0032+ 4090-0x102c));}(($$ref_parameters{"\x6b\x65\x79"},
$$ref_parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$$ref_parameters{
"\x75\x75\x69\x64"})=__retrieveKey ());if (($$ref_parameters{"\x6b\x65\x79"}eq 
(""))){Logger::error (
"\x50\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x6e\x6f\x74\x20\x70\x72\x6f\x76\x69\x64\x65\x64\x2e"
);return ((0x1542+ 2682-0x1fbc));}($$ref_parameters{"\x6b\x65\x79"}.="\x0a");
return ((0x0bf8+ 1149-0x1074));}sub prepareKey{(my $ref_parameters=shift (@_));(my $proto
=$$ref_parameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"});if (($proto eq "\x4e\x58"
)){(my $authFile=NXPaths::getNXAuthorizedKeysPath ("\x6e\x78"));(my $authDir=
Common::NXFile::dirname ($authFile));Logger::debug (((
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x41\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x6b\x65\x79\x73\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20\x27"
.$authDir)."\x27\x2e"));if ((not (Common::NXFile::directoryExists ($authDir)))){my (
$error);unless (Common::NXPaths::createAccessibleForNXDirectory ((\$error),
$authDir)){NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x44\x69\x72"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$proto,$authDir);return ((0x0a81+ 1017-0x0e7a));
}}($$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"}=$authFile);Logger::debug
 (((
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72\x3a\x20\x41\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x6b\x65\x79\x73\x20\x66\x69\x6c\x65\x20\x27"
.$$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"})."\x27\x2e"));}elsif ((
$proto eq "\x53\x53\x48")){($$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"}
=NXPaths::getNodePublicKeys ());if (isKeyInFile ($$ref_parameters{"\x6b\x65\x79"
},$$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"},$proto)){
removeKeyFromFile ($$ref_parameters{"\x6b\x65\x79"},$$ref_parameters{
"\x61\x75\x74\x68\x46\x69\x6c\x65"},$proto);}}else{NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x55\x6e\x6b\x6e\x6f\x77\x6e\x50\x72\x6f\x74\x6f"
,"\x4e\x58\x53\x68\x65\x6c\x6c");return ((0x11c5+ 1366-0x171b));}if (
Common::NXFile::isExists ($$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"}))
{if ((Common::NXFile::setPermissionsReadWriteForNX ($$ref_parameters{
"\x61\x75\x74\x68\x46\x69\x6c\x65"})==(-(0x033b+  43-0x0365)))){NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$proto,$$ref_parameters{
"\x61\x75\x74\x68\x46\x69\x6c\x65"});return ((0x13ff+ 1857-0x1b40));}}return (
(0x0d45+ 575-0x0f83));}sub setKey{(my $ref_parameters=shift (@_));(my $filepath=
$$ref_parameters{"\x61\x75\x74\x68\x46\x69\x6c\x65"});(my $mode=((
$NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND));(my $permissions=
$NXBits::UserReadWrite);(my $OUTFILE=Common::NXCore::nxopen ($filepath,$mode,
$permissions));unless (defined ($OUTFILE)){(my $errorString=
libnxh::NXGetErrorName ());NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x4f\x70\x65\x6e\x54\x6f\x57\x72\x69\x74\x65"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$filepath);return ((0x2063+ 961-0x2424));}(my $keyToSave
=$$ref_parameters{"\x6b\x65\x79"});if (($$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"}eq "\x53\x53\x48")){($keyToSave=
NXNodeExec::addPrefixForSSHKey ($$ref_parameters{"\x6b\x65\x79"}));}if ((
Common::NXCore::nxwrite ($OUTFILE,$keyToSave)==(-(0x04b0+ 2457-0x0e48)))){
NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x57\x72\x69\x74\x65"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$filepath);Common::NXCore::nxclose ($OUTFILE
);return ((0x12d2+ 4856-0x25ca));}Common::NXCore::nxclose ($OUTFILE);if ((
Common::NXFile::setOwnerShipAndPermissionsForNX ($filepath)==(-
(0x1024+ 192-0x10e3)))){NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x53\x65\x74\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x73"
,"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",$$ref_parameters{
"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"},$filepath);return ((0x1462+ 1109-0x18b7));}
if (($$ref_parameters{"\x75\x75\x69\x64"}ne (""))){NXNodes::setAccessKey (
$$ref_parameters{"\x75\x75\x69\x64"},$$ref_parameters{"\x6b\x65\x79"});}return (
(0x1084+ 2614-0x1ab9));}sub __retrieveKey{(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;(my $signalFd=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});($$NXBegin::parser
{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x49\x4e\x54"}=sub{Common::NXCore::nxexit ();}
);$selector->add ($signalFd);$selector->add (main::nxgetSTDIN ());(my $key=(""))
;(my $protocol=(""));(my $finish=(0x0aff+ 7164-0x26fb));while (($finish==
(0x0503+ 6733-0x1f50))){(my (@ready)=$selector->can_read (5000));if ((scalar (
@ready)==(0x0d1f+ 3369-0x1a48))){Logger::debug (
"\x4e\x6f\x74\x68\x69\x6e\x67\x20\x74\x6f\x20\x72\x65\x61\x64\x2e");($finish=
(0x065b+ 3222-0x12f0));}foreach my $fh (@ready){Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x46\x44\x23".$fh)."\x2e"));if (($fh==
main::nxgetSTDIN ())){my ($read_buf);(my $bytes_read=main::nxread ($fh,(
\$read_buf),(0x1bbb+ 1948-0x1357)));Logger::debug (((
"\x52\x65\x61\x64\x20\x66\x72\x6f\x6d\x20\x53\x54\x44\x49\x4e\x20\x27".$read_buf
)."\x27\x2e"));if (($read_buf=~ /NX> params=(.*) / )){(my (%hashParameters)=
NXShell::urlParameter2Hash ($1));($key=$hashParameters{"\x6b\x65\x79"});(
$protocol=$hashParameters{"\x70\x72\x6f\x74\x6f\x63\x6f\x6c"});($uuid=
$hashParameters{"\x75\x75\x69\x64"});$selector->remove (main::nxgetSTDIN ());
$selector->remove ($signalFd);($finish=(0x121d+ 3831-0x2113));}elsif ((
$bytes_read==(0x1811+ 2419-0x2184))){$selector->remove (main::nxgetSTDIN ());
$selector->remove ($signalFd);($finish=(0x0da6+ 111-0x0e14));}}}}return ($key,
$protocol,$uuid);}NXMsg::register_response (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x69\x43\x4d\x44\x41\x64\x64\x69\x6e\x67\x4b\x65\x79",(0x05f1+ 5312-0x1a17));
NXMsg::register_response ("\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x69\x43\x4d\x44\x50\x75\x62\x6c\x69\x63\x4b\x65\x79\x41\x64\x64\x65\x64\x4f\x6b"
,(0x019b+ 1030-0x0506));NXMsg::register_error (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x4e\x6f\x74\x45\x78\x69\x73\x74"
,(0x121c+ 5093-0x23bd));NXMsg::register_error (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x43\x61\x6e\x6e\x6f\x74\x52\x65\x61\x64"
,580);NXMsg::register_error ("\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x65\x43\x4d\x44\x43\x61\x6e\x6e\x6f\x74\x41\x64\x64\x4b\x65\x79\x45\x6d\x70\x74\x79\x46\x69\x6c\x65"
,(0x2154+ 1013-0x2305));return ((0x1bc2+ 397-0x1d4e));
