############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXRunCommand::BEGIN{package Common::NXRunCommand;no warnings;require
 strict;do{"\x73\x74\x72\x69\x63\x74"->unimport ("\x72\x65\x66\x73")};}sub 
Common::NXRunCommand::BEGIN{package Common::NXRunCommand;no warnings;require 
Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub 
Common::NXRunCommand::BEGIN{package Common::NXRunCommand;no warnings;require 
Exception::Log;do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->
import};}package Common::NXRunCommand;no warnings;(@NXRunCommand::command=());(
@NXRunCommand::environment=());($NXRunCommand::filename=(""));(
@NXRunCommand::commandrest=());($NXRunCommand::priority=(0x1520+ 942-0x1869));(
$NXRunCommand::childpid=(0x0920+ 2406-0x1286));($NXRunCommand::flag_typeNX=
(0x0df1+ 5237-0x2266));($NXRunCommand::flag_runInBg=(0x0cd6+ 2285-0x15c3));(
$NXRunCommand::flag_closeCMDIN=(0x077d+ 4429-0x18c9));(
$NXRunCommand::flag_noLogStdout=(0x1891+ 2544-0x2280));(
$NXRunCommand::flag_stdin_redirect=(0x0aec+ 7022-0x265a));(
$NXRunCommand::flag_stdout_redirect=(0x1987+ 802-0x1ca9));(
$NXRunCommand::flag_stderr_redirect=(0x1588+ 1680-0x1c18));(
$NXRunCommand::flag_stdinfd_redirect=(0x07d5+ 2707-0x1268));(
$NXRunCommand::flag_stdoutfd_redirect=(0x01b2+ 3915-0x10fd));(
$NXRunCommand::saveStdinTo=(""));($NXRunCommand::flag_saveStdin=
(0x025a+ 5083-0x1635));($NXRunCommand::saveStdoutTo=(""));(
$NXRunCommand::flag_saveStdout=(0x1239+ 184-0x12f1));(
$NXRunCommand::saveStderrTo=(""));($NXRunCommand::flag_saveStderr=
(0x12a4+  92-0x1300));($NXRunCommand::flag_setStderrAsPipe=(0x0214+ 5114-0x160e)
);($NXRunCommand::flag_ERRinOUT=(0x0657+ 6076-0x1e13));(
$NXRunCommand::flag_runFunction=(0x0634+ 4076-0x1620));(
$NXRunCommand::functionToRun=(""));(@NXRunCommand::functionToRunParameters=());(
$NXRunCommand::flag_callFunctionAfterRun=(0x252d+ 292-0x2651));(
$NXRunCommand::flag_callFunctionAfterExit=(0x0808+ 2354-0x113a));(
$NXRunCommand::flag_callFunctionAfterError=(0x155a+ 1350-0x1aa0));(
$NXRunCommand::flag_closeAfterRun=(0x219b+ 167-0x2242));(
@NXRunCommand::handlesToCloseAfterRun=());($NXRunCommand::flag_nxexecSTD=
(0x0f15+  22-0x0f2b));($NXRunCommand::FunctionAfterExit=(""));(
$NXRunCommand::FunctionAfterError=(""));($NXRunCommand::timeoutForOperation=
(0x02fc+ 3817-0x11c7));($NXRunCommand::useScriptToKill=(0x0c9a+ 5305-0x2153));(
$NXRunCommand::finishOnSigchld=(0x182d+ 2072-0x2045));(
$NXRunCommand::stdinLogEnabled=(0x1c06+ 2443-0x2590));(
$NXRunCommand::flag_execCommand=(0x2476+ 193-0x2537));(my $__stderrBuffer=(""));
sub new{(my $class=shift (@_));(my $self=bless ({},$class));(
@NXRunCommand::command=());(@NXRunCommand::environment=());(
$NXRunCommand::filename=(""));(@NXRunCommand::commandrest=());(
$NXRunCommand::priority=(0x0708+ 4190-0x1701));($NXRunCommand::childpid=
(0x0a1d+ 2364-0x1359));($NXRunCommand::flag_typeNX=(0x1831+ 530-0x1a43));(
$NXRunCommand::flag_runInBg=(0x1010+ 4123-0x202b));(
$NXRunCommand::flag_closeCMDIN=(0x1319+ 4231-0x239f));(
$NXRunCommand::flag_stdin_redirect=(0x0117+ 594-0x0369));(
$NXRunCommand::flag_stdout_redirect=(0x0506+ 898-0x0888));(
$NXRunCommand::flag_stderr_redirect=(0x22fd+  29-0x231a));(
$NXRunCommand::flag_stdinfd_redirect=(0x0ad0+ 2056-0x12d8));(
$NXRunCommand::flag_stdoutfd_redirect=(0x114f+ 3765-0x2004));(
$NXRunCommand::saveStdinTo=undef);($NXRunCommand::flag_saveStdin=
(0x0193+ 8796-0x23ef));($NXRunCommand::saveStdoutTo=undef);(
$NXRunCommand::flag_saveStdout=(0x1a66+ 2958-0x25f4));(
$NXRunCommand::saveStderrTo=undef);($NXRunCommand::flag_saveStderr=
(0x074d+ 1248-0x0c2d));($NXRunCommand::flag_setStderrAsPipe=
(0x0036+ 3082-0x0c40));($NXRunCommand::flag_ERRinOUT=(0x0089+ 1915-0x0804));(
$NXRunCommand::stdin_redirect=undef);($NXRunCommand::stdout_redirect=undef);(
$NXRunCommand::stderr_redirect=undef);($NXRunCommand::stdin_redirected=undef);(
$NXRunCommand::stdout_redirected=undef);($NXRunCommand::stderr_redirected=undef)
;($NXRunCommand::savepid=undef);($NXRunCommand::savePidToFile=undef);(
$NXRunCommand::parentStdin=undef);($NXRunCommand::parentStdout=undef);(
$NXRunCommand::parentStderr=undef);($NXRunCommand::childStdin=undef);(
$NXRunCommand::childStdout=undef);($NXRunCommand::childStderr=undef);(
$NXRunCommand::childStdinInt=undef);($NXRunCommand::childStdoutInt=undef);(
$NXRunCommand::parentStdinInt=undef);($NXRunCommand::parentStdoutInt=undef);(
$NXRunCommand::childStderrInt=undef);($NXRunCommand::parentStderrInt=undef);(
$NXRunCommand::flag_runFunction=(0x00dc+ 3639-0x0f13));(
$NXRunCommand::functionToRun=(""));(@NXRunCommand::functionToRunParameters=());(
$NXRunCommand::flag_callFunctionAfterRun=(0x1c74+ 223-0x1d53));(
$NXRunCommand::flag_noLogStdout=(0x045d+ 5781-0x1af1));(
$NXRunCommand::flag_nxexecSTD=(0x0445+ 4352-0x1545));(
$NXRunCommand::flag_closeAfterRun=(0x0555+ 6244-0x1db9));(
@NXRunCommand::handlesToCloseAfterRun=());($NXRunCommand::FunctionAfterExit=("")
);($NXRunCommand::FunctionAfterError=(""));($NXRunCommand::timeoutForOperation=
(0x0cf2+ 198-0x0d9a));($NXRunCommand::useScriptToKill=(0x1b6f+ 204-0x1c3b));(
$NXRunCommand::finishOnSigchld=(0x08f6+ 5076-0x1cca));(
$NXRunCommand::stdinLogEnabled=(0x05ac+ 3086-0x11b9));(
$NXRunCommand::flag_callFunctionAfterExit=(0x2375+ 496-0x2565));(
$NXRunCommand::flag_callFunctionAfterError=(0x15e2+ 413-0x177f));
cleanFileNameForSetPid ();return ($self);}sub __setupParentChildStdin{
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x5f\x5f\x73\x65\x74\x75\x70\x50\x61\x72\x65\x6e\x74\x43\x68\x69\x6c\x64\x53\x74\x64\x69\x6e\x20\x73\x74\x61\x72\x74\x65\x64"
);if (stdinFD_redirect ()){($NXRunCommand::childStdinInt=getStdin_redirect ());
unless (libnxh::NXDescriptorInheritable ($NXRunCommand::childStdinInt,
(0x07db+ 3043-0x13bd))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStdinInt));main::nxexit ();}Logger::debug2 ((
"\x43\x68\x69\x6c\x64\x20\x73\x74\x64\x69\x6e\x46\x44\x20\x73\x65\x74\x20\x74\x6f\x3a\x20"
.$NXRunCommand::childStdinInt));return;}else{Logger::debug2 (
"\x43\x68\x69\x6c\x64\x20\x73\x74\x64\x69\x6e\x46\x44\x20\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x2e"
);}unless (main::nxPipeCreateMono ((\$NXRunCommand::childStdinInt),(
\$NXRunCommand::parentStdinInt))){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6d\x6f\x6e\x6f\x20\x70\x69\x70\x65\x20\x66\x6f\x72\x20\x63\x68\x69\x6c\x64\x20\x73\x74\x64\x69\x6e\x2e"
);Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString));main::nxexit ();}libnxh::NXDescriptorInheritable (
$NXRunCommand::childStdinInt,(0x1953+ 1396-0x1ec6));
libnxh::NXDescriptorInheritable ($NXRunCommand::parentStdinInt,
(0x093a+ 6899-0x242d));if (saveStdin ()){($$NXRunCommand::saveStdinTo=
getParentStdinInt ());Logger::debug2 (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x61\x76\x65\x20\x70\x61\x72\x65\x6e\x74\x20\x73\x74\x64\x69\x6e\x20\x61\x73\x20\x46\x44\x23"
.$$NXRunCommand::saveStdinTo).("\x20\x69\x6e\x20".$NXRunCommand::saveStdinTo)));
}}sub __setupParentChildStdout{Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x5f\x5f\x73\x65\x74\x75\x70\x50\x61\x72\x65\x6e\x74\x43\x68\x69\x6c\x64\x53\x74\x64\x6f\x75\x74\x20\x73\x74\x61\x72\x74\x65\x64"
);if (stdoutFD_redirect ()){($NXRunCommand::childStdoutInt=getStdout_redirect ()
);unless (libnxh::NXDescriptorInheritable ($NXRunCommand::childStdoutInt,
(0x07f2+ 321-0x0932))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStdoutInt));main::nxexit ();}Logger::debug2 ((
"\x43\x68\x69\x6c\x64\x20\x73\x74\x64\x6f\x75\x74\x46\x44\x20\x73\x65\x74\x20\x74\x6f\x3a\x20"
.$NXRunCommand::childStdoutInt));return;}elsif (stdout_redirect ()){
Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x74\x64\x6f\x75\x74\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x66\x69\x6c\x65\x20"
.getStdout_redirect ()));($NXRunCommand::childStdoutInt=main::nxopen (
getStdout_redirect (),(($NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND),
$NXBits::UserReadWrite));if ((not (defined ($NXRunCommand::childStdoutInt)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x6f\x75\x74\x20\x66\x6f\x72\x20\x73\x75\x62\x70\x72\x6f\x63\x65\x73\x2e"
);Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString)."\x2e"));main::nxexit ();}unless (
libnxh::NXDescriptorInheritable ($NXRunCommand::childStdoutInt,
(0x1f6a+ 1311-0x2488))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStdoutInt));main::nxexit ();}Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x73\x74\x64\x6f\x75\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x46\x44\x23"
.$NXRunCommand::childStdoutInt));}else{unless (main::nxPipeCreateMono ((
\$NXRunCommand::parentStdoutInt),(\$NXRunCommand::childStdoutInt))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6d\x6f\x6e\x6f\x20\x70\x69\x70\x65\x20\x66\x6f\x72\x20\x63\x68\x69\x6c\x64\x20\x73\x74\x64\x6f\x75\x74\x2e"
);Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString)."\x2e"));main::nxexit ();}
libnxh::NXDescriptorInheritable ($NXRunCommand::parentStdoutInt,
(0x126f+ 1216-0x172f));libnxh::NXDescriptorInheritable (
$NXRunCommand::childStdoutInt,(0x0a38+ 2417-0x13a8));if (saveStdout ()){(
$$NXRunCommand::saveStdoutTo=getParentStdoutInt ());Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6f\x70\x65\x6e\x20\x46\x44\x23"
.$$NXRunCommand::saveStdoutTo).("\x20\x69\x6e\x20".$NXRunCommand::saveStdoutTo))
);}}}sub __setupParentChildStderr{if (ERRinOUT ()){(
$NXRunCommand::childStderrInt=$NXRunCommand::childStdoutInt);}elsif (
stderr_redirect ()){Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x74\x64\x65\x72\x72\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x3a\x20"
.getStderr_redirect ()));($NXRunCommand::childStderrInt=main::nxopen (
getStderr_redirect (),(($NXBits::O_WRONLY+$NXBits::O_CREAT)+$NXBits::O_APPEND),
$NXBits::UserReadWrite));if ((not (defined ($NXRunCommand::childStderrInt)))){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x65\x72\x72\x20\x66\x6f\x72\x20\x73\x75\x62\x70\x72\x6f\x63\x65\x73\x2e"
);Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString));main::nxexit ();}unless (
libnxh::NXDescriptorInheritable ($NXRunCommand::childStderrInt,
(0x0615+ 7747-0x2457))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStderrInt));main::nxexit ();}Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x73\x74\x64\x65\x72\x72\x20\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x46\x44\x23"
.getChildStderrInt ()));}elsif (isSetStderrAsPipe ()){unless (
main::nxPipeCreateMono ((\$NXRunCommand::parentStderrInt),(
\$NXRunCommand::childStderrInt))){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6d\x6f\x6e\x6f\x20\x70\x69\x70\x65\x20\x66\x6f\x72\x20\x63\x68\x69\x6c\x64\x20\x73\x74\x64\x65\x72\x72\x2e"
);Logger::error (((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber).
"\x2c\x20").$errorString));main::nxexit ();}libnxh::NXDescriptorInheritable (
$NXRunCommand::parentStderrInt,(0x1880+ 119-0x18f7));
libnxh::NXDescriptorInheritable ($NXRunCommand::childStderrInt,
(0x0015+ 5379-0x1517));}else{(my $errorLogFile=
Common::NXPaths::getNXServerLogPath ());Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x6f\x69\x6e\x67\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x65\x72\x72\x20\x74\x6f\x20\x66\x69\x6c\x65\x3a\x20"
.$errorLogFile));(my $needToFixPermissions=(0x0821+ 961-0x0be2));(
$NXRunCommand::childStderrInt=main::nxopen ($errorLogFile,(($NXBits::O_WRONLY+
$NXBits::O_CREAT)+$NXBits::O_APPEND),(($NXBits::UserReadWrite+
$NXBits::GroupReadWrite)+$NXBits::OthersWrite)));unless (
$NXRunCommand::childStderrInt){(my $errorNumber=libnxh::NXGetError ());(my $errorString
=libnxh::NXGetErrorString ());Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x73\x74\x64\x65\x72\x72\x20\x74\x6f\x20"
.Common::NXPaths::getNXServerLogPath ())."\x2e"));Logger::error (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorString)."\x2e"));main::nxexit ();}if ($needToFixPermissions){
Common::NXFile::setServerLogFilePermissions ();}unless (
libnxh::NXDescriptorInheritable ($NXRunCommand::childStderrInt,
(0x1c58+ 1270-0x214d))){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x70\x72\x6f\x70\x65\x72\x74\x79\x20\x69\x6e\x68\x65\x72\x69\x74\x61\x62\x6c\x65\x20\x6f\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStderrInt));main::nxexit ();}Logger::debug2 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x20\x73\x74\x64\x65\x72\x72\x5f\x72\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x69\x6e\x20\x46\x44\x23"
.getChildStderrInt ()));}}sub setChildDescriptors{my ($parentSocket);my (
$childSocket);my ($stderr_in);Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x43\x68\x69\x6c\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x73\x74\x61\x72\x74\x65\x64"
);if (isTypeNX ()){Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x43\x68\x69\x6c\x64\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x66\x6f\x72\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x6f\x66\x20\x74\x79\x70\x65\x20\x4e\x58"
);main::nxPipeCreateBi ((\$parentSocket),(\$childSocket));(
$NXRunCommand::childStdin=$childSocket);($NXRunCommand::childStdout=$childSocket
);main::nxPipeCreateMono ((\$stderr_in),(\$NXRunCommand::childStderr));(
$NXRunCommand::parentStdin=$parentSocket);($NXRunCommand::parentStdout=
$parentSocket);($NXRunCommand::parentStderr=$stderr_in);}else{
__setupParentChildStdin ();__setupParentChildStdout ();__setupParentChildStderr 
();Logger::debug (((((((((((
"\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x73\x65\x74\x2e\x20\x43\x68\x69\x6c\x64\x3a\x20\x46\x44\x23"
.getChildStdinInt ())."\x2c\x20\x46\x44\x23").getChildStdoutInt ()).
"\x2c\x20\x46\x44\x23").getChildStderrInt ()).
"\x2e\x20\x50\x61\x72\x65\x6e\x74\x3a\x20\x46\x44\x23").getParentStdinInt ()).
"\x2c\x20\x46\x44\x23").getParentStdoutInt ())."\x2e"));}}sub 
closeChildDescriptors{if (isTypeNX ()){main::nxclose (getChildStdinInt ());
main::nxclose (getChildStderrInt ());}else{if ((not (stdinFD_redirect ()))){
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x43\x68\x69\x6c\x64\x53\x74\x64\x69\x6e"
);main::nxclose (getChildStdinInt ());}if ((getChildStdoutInt ()==
getChildStderrInt ())){Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x43\x68\x69\x6c\x64\x53\x74\x64\x6f\x75\x74\x2f\x43\x68\x69\x6c\x64\x53\x74\x64\x65\x72\x72"
);main::nxclose (getChildStderrInt ());}else{if ((not (stdoutFD_redirect ()))){
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x43\x68\x69\x6c\x64\x53\x74\x64\x6f\x75\x74"
);main::nxclose (getChildStdoutInt ());}Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x43\x6c\x6f\x73\x69\x6e\x67\x20\x43\x68\x69\x6c\x64\x53\x74\x64\x65\x72\x72"
);main::nxclose (getChildStderrInt ());}}Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x68\x69\x6c\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);}sub getChildStderr{if (defined ($NXRunCommand::childStderrInt)){return (
$NXRunCommand::childStderrInt);}return ($NXRunCommand::childStderr);}sub 
setOptions{(my $self=shift (@_));(my (@options)=@_);(my $getpriority=
(0x0cd4+ 5500-0x2250));(my $getstdin=(0x0b90+ 1725-0x124d));(my $getstdout=
(0x13a8+ 3137-0x1fe9));(my $getstderr=(0x08a5+ 3086-0x14b3));(my $getsavepid=
(0x1205+ 791-0x151c));(my $getVarForStdin=(0x1378+ 3319-0x206f));(my $getVarForStdout
=(0x003b+ 827-0x0376));(my $getVarForStderr=(0x14e7+ 4226-0x2569));(my $getenv=
(0x1790+ 1084-0x1bcc));(my $getfunction=(0x0362+ 1515-0x094d));(my $getfunctionParameters
=(0x170c+ 3434-0x2476));(my $getStdinDescriptor=(0x09f9+ 3967-0x1978));(my $getStdoutDescriptor
=(0x013f+ 6685-0x1b5c));(my $getfunctionafterexit=(0x134d+ 2329-0x1c66));(my $getfunctionaftererror
=(0x08ef+ 6369-0x21d0));(my $getFileNameForSavePid=(0x06df+ 8026-0x2639));(my (
@environment)=());(my $getTimeout=(0x14b3+ 2996-0x2067));(my $getFileNameToSavePid
=(0x046d+ 353-0x05ce));(my $getStdoutFD=(0x04dd+ 5830-0x1ba3));(my $getStdinFD=
(0x164f+ 3973-0x25d4));(my $getHandleToClose=(0x10ab+ 3487-0x1e4a));foreach my $key
 (@options){if ($getTimeout){($getTimeout=(0x0001+ 7741-0x1e3e));setTimeout (
$key);next;}if ($getfunction){($getfunction=(0x0b0b+ 235-0x0bf6));(
$getfunctionParameters=(0x1984+ 1940-0x2117));setFunctionToCall ($key);next;}if 
($getfunctionafterexit){($getfunction=(0x1082+ 5586-0x2654));(
$NXRunCommand::FunctionAfterExit=$key);next;}if ($getfunctionaftererror){(
$getfunction=(0x0190+ 3758-0x103e));($NXRunCommand::FunctionAfterError=$key);
next;}if ($getFileNameToSavePid){($getFileNameToSavePid=(0x16c3+ 738-0x19a5));
setFileNameForSetPid ($key);next;}if ($getfunctionParameters){Logger::debug (
"\x6e\x78\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x54\x68\x65\x20\x72\x65\x73\x74\x20\x6f\x66\x20\x74\x68\x65\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x61\x72\x65\x20\x61\x72\x67\x75\x6d\x65\x6e\x74\x73\x20\x66\x6f\x72\x20\x74\x68\x65\x20\x63\x61\x6c\x6c\x65\x64\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x2e"
);addToFunctionParameters ($key);next;}if ($getpriority){($getpriority=
(0x04a9+ 6543-0x1e38));setPriority ($key);next;}if ($getstdin){($getstdin=
(0x03a5+ 5820-0x1a61));setStdin_redirect ($key);next;}if ($getstdout){(
$getstdout=(0x0340+ 6713-0x1d79));setStdout_redirect ($key);next;}if ($getstderr
){($getstderr=(0x049a+ 1871-0x0be9));setStderr_redirect ($key);next;}if (
$getVarForStdin){($getVarForStdin=(0x1e53+  45-0x1e80));$self->setSaveStdinTo (
$key);next;}if ($getVarForStdout){($getVarForStdout=(0x0b2f+ 1271-0x1026));$self
->setSaveStdoutTo ($key);next;}if ($getVarForStderr){($getVarForStderr=
(0x11a7+ 2912-0x1d07));$self->setSaveStderrTo ($key);next;}if ($getsavepid){
setVarToSavePid ($key);Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x70\x69\x64\x20\x74\x6f\x20\x27"
.$NXRunCommand::savepid)."\x27\x2e"));($getsavepid=(0x1732+ 924-0x1ace));next;}
if ($getenv){push (@environment,$key);($getenv=(0x01ff+ 1452-0x07ab));next;}if (
$getStdoutFD){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x61\x6c\x6c\x3a\x20\x73\x65\x74\x53\x74\x64\x6f\x75\x74\x46\x44\x5f\x72\x65\x64\x69\x72\x65\x63\x74\x28"
.$key)."\x29"));setStdoutFD_redirect ($key);($getStdoutFD=(0x07b3+ 7894-0x2689))
;next;}if ($getStdinFD){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x61\x6c\x6c\x3a\x20\x73\x65\x74\x53\x74\x64\x69\x6e\x46\x44\x5f\x72\x65\x64\x69\x72\x65\x63\x74\x28"
.$key)."\x29"));setStdinFD_redirect ($key);($getStdinFD=(0x1577+ 445-0x1734));
next;}if ($getHandleToClose){addHandleToClose ($key);($getHandleToClose=
(0x0006+ 8354-0x20a8));next;}if (($key eq "\x74\x69\x6d\x65\x6f\x75\x74")){(
$getTimeout=(0x112d+ 4300-0x21f8));next;}if (($key eq 
"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e")){($getHandleToClose=
(0x049f+ 6753-0x1eff));next;}if (($key eq "\x6e\x78\x65\x78\x65\x63\x53\x54\x44"
)){setNxexecSTD ();next;}if (($key eq "\x74\x79\x70\x65\x4e\x58")){setTypeNX ();
next;}if (($key eq "\x73\x65\x74\x5f\x70\x72\x69\x6f\x72\x69\x74\x79")){(
$getpriority=(0x0f88+ 1203-0x143a));next;}if (($key eq 
"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67")){setRunCommandInBG ();next;}if (($key eq
 "\x73\x74\x64\x69\x6e")){($getstdin=(0x21d1+ 1098-0x261a));next;}if (($key eq 
"\x73\x74\x64\x6f\x75\x74")){($getstdout=(0x1b7d+ 1174-0x2012));next;}if (($key 
eq "\x73\x74\x64\x65\x72\x72")){($getstderr=(0x07ef+ 4398-0x191c));next;}if ((
$key eq "\x73\x65\x74\x20\x73\x74\x64\x69\x6e\x20\x61\x73\x20\x76\x61\x72")){(
$getVarForStdin=(0x1454+ 2411-0x1dbe));next;}if (($key eq 
"\x73\x65\x74\x20\x73\x74\x64\x6f\x75\x74\x20\x61\x73\x20\x76\x61\x72")){(
$getVarForStdout=(0x0360+ 1109-0x07b4));next;}if (($key eq 
"\x73\x65\x74\x20\x73\x74\x64\x65\x72\x72\x20\x61\x73\x20\x76\x61\x72")){(
$getVarForStderr=(0x1602+  87-0x1658));next;}if (($key eq 
"\x73\x65\x74\x20\x73\x74\x64\x65\x72\x72\x20\x61\x73\x20\x70\x69\x70\x65")){
$self->setStderrAsPipe;next;}if (($key eq "\x67\x65\x74\x20\x70\x69\x64")){(
$getsavepid=(0x0aec+ 3131-0x1726));next;}if (($key eq 
"\x73\x61\x76\x65\x50\x69\x64\x54\x6f\x46\x69\x6c\x65")){($getFileNameToSavePid=
(0x02c9+ 1173-0x075d));next;}if (($key eq "\x73\x65\x74\x20\x65\x6e\x76")){(
$getenv=(0x0439+ 6502-0x1d9e));next;}if (($key eq 
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e")){
setNotCloseCMDIN ();next;}if (($key eq 
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x6f\x75\x74\x20\x6f\x70\x65\x6e")){
setNotCloseCMDOUT ();next;}if (($key eq "\x45\x52\x52\x69\x6e\x4f\x55\x54")){
Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key).
"\x27\x20\x73\x74\x64\x6f\x75\x74\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x75\x73\x65\x64\x20\x61\x73\x20\x73\x74\x64\x65\x72\x72\x2e"
));setERRinOUT ();next;}if (($key eq 
"\x66\x75\x6c\x6c\x20\x65\x6e\x76\x69\x72\x6f\x6e\x6d\x65\x6e\x74")){
Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key)."\x27\x20\x73\x65\x74"));setFullEnv ();next;}if (($key eq 
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e")){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key)."\x27\x20\x73\x65\x74\x20\x67\x65\x74\x53\x74\x64\x69\x6e\x46\x44"));(
$getStdinFD=(0x02ca+ 4109-0x12d6));next;}if (($key eq 
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74")){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key)."\x27\x20\x73\x65\x74\x20\x67\x65\x74\x53\x74\x64\x4f\x75\x74\x46\x44"));(
$getStdoutFD=(0x06b3+ 4587-0x189d));next;}if (($key eq 
"\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e")){setCallFunction ();(
$getfunction=(0x0c56+ 2683-0x16d0));next;}if (($key eq 
"\x6e\x6f\x20\x6c\x6f\x67\x20\x73\x74\x64\x6f\x75\x74")){setNoLogStdout ();next;
}if (($key eq "\x73\x74\x64\x69\x6e\x6e\x6f\x72\x65\x64\x69\x72\x65\x63\x74")){
setCloseCMDIN ();next;}if (($key eq 
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e")){
setCallFunctionAfterRun ();($getfunction=(0x056a+ 3934-0x14c7));next;}if (($key 
eq 
"\x63\x61\x6c\x6c\x20\x61\x66\x74\x65\x72\x20\x6e\x6f\x72\x6d\x61\x6c\x20\x65\x78\x69\x74"
)){setCallFunctionAfterExit ();($getfunctionafterexit=(0x0d9c+ 4010-0x1d45));
next;}if (($key eq 
"\x63\x61\x6c\x6c\x20\x61\x66\x74\x65\x72\x20\x65\x72\x72\x6f\x72\x20\x65\x78\x69\x74"
)){setCallFunctionAfterError ();($getfunctionaftererror=(0x04b1+ 8599-0x2647));
next;}if (($key eq 
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c")){
setUseScriptToKill ();next;}if (($key eq 
"\x66\x69\x6e\x69\x73\x68\x20\x6f\x6e\x20\x73\x69\x67\x63\x68\x6c\x64")){
setFinishOnSigchld ();next;}if (($key eq 
"\x6e\x6f\x20\x6c\x6f\x67\x20\x73\x74\x64\x69\x6e")){setNoLogStdin ();next;}
Logger::warning (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6b\x65\x79\x20\x27".
$key).
"\x27\x20\x73\x74\x69\x6c\x6c\x20\x6e\x65\x65\x64\x73\x20\x74\x6f\x20\x62\x65\x20\x68\x61\x6e\x64\x6c\x65\x64\x2e"
));next;}$self->setEnvironment (@environment);}sub setEnvironment{(my $self=
shift (@_));(my (@environment)=@_);if (($NXRunCommand::flag_fullENV==
(0x11bb+ 4814-0x2488))){(@NXRunCommand::environment=sort (@environment));return;
}if ((scalar (@environment)==(0x0886+ 1953-0x1027))){(@NXRunCommand::environment
=(""));return;}(@NXRunCommand::environment=sort (@environment));}sub setCommand{
(my $self=shift (@_));(my (@command)=@_);Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x27"
.join ($",@command))."\x27\x2e"));($NXRunCommand::filename=$command[
(0x0f16+ 2325-0x182b)]);unshift (@command,$NXRunCommand::filename);(
@NXRunCommand::command=@command);}sub setCommandForExec{(my $self=shift (@_));(my (
@command)=@_);Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x65\x78\x65\x63\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x27"
.join ($",@command))."\x27\x2e"));($NXRunCommand::filename=$command[
(0x0f9a+ 1898-0x1704)]);(@NXRunCommand::command=@command);}sub handleParentStdin
{if ((stdin_redirect ()and ($NXRunCommand::stdin_redirect ne ("")))){if (
isStdinLogEnabled ()){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x54\x72\x79\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6f\x6e\x20\x73\x74\x64\x69\x6e\x3a\x20\x5b"
.$NXRunCommand::stdin_redirect)."\x5d"));}else{Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x54\x72\x79\x20\x74\x6f\x20\x77\x72\x69\x74\x65\x20\x6f\x6e\x20\x73\x74\x64\x69\x6e\x2e"
);}(my $write=main::nxwrite (getParentStdinInt (),$NXRunCommand::stdin_redirect)
);if (isStdinLogEnabled ()){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x77\x72\x69\x74\x65\x20\x5b"
.$write)."\x5d"));}}if (closeCMDINonStart ()){main::nxclose (getParentStdinInt 
());undef ($NXRunCommand::parentStdinInt);}}sub handleParentStdout{if ((not (
defined (getParentStdoutInt ())))){return;}if (((not (stdout_redirect ()))and (
not (saveStdout ())))){Logger::debug (
"\x68\x61\x6e\x64\x6c\x65\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x6f\x75\x74\x20\x63\x6c\x6f\x73\x69\x6e\x67\x20\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x6f\x75\x74"
);main::nxclose (getParentStdoutInt ());undef ($NXRunCommand::parentStdoutInt);}
}sub handleParentStderr{if ((not (defined (getParentStderrInt ())))){return;}if 
((not (stderr_redirect ()))){main::nxclose (getParentStderrInt ());undef (
$NXRunCommand::parentStderrInt);}}sub handlePid{(my $pid=shift (@_));(
$NXRunCommand::childpid=$pid);savePidToVar ();savePidToFile ();if (
callFunctionAfterExit ()){Common::NXProcess::setExitCallback ($pid,
$NXRunCommand::FunctionAfterExit);}if (callFunctionAfterError ()){
Common::NXProcess::setErrorCallback ($pid,$NXRunCommand::FunctionAfterError);}}
sub __callbackStdout{(my $self=shift (@_));(my $handleHash=shift (@_));(my $buffer
=shift (@_));(my $bytesRead=shift (@_));if (($bytesRead<=(0x1d33+ 2124-0x257f)))
{$self->removeAndCloseHandle ($$handleHash{"\x48\x61\x6e\x64\x6c\x65"});$self->
setExit ($handleHash,(0x055f+ 149-0x05f4),$buffer);}else{($$handleHash{
"\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"}{"\x63\x6d\x64\x5f\x6f\x75\x74"}.=
$buffer);($$handleHash{"\x45\x78\x69\x74\x52\x65\x73\x75\x6c\x74"}.=$buffer);(
$buffer=(""));}}sub __callbackStderr{(my $self=shift (@_));(my $handleHash=shift
 (@_));(my $buffer=shift (@_));(my $bytesRead=shift (@_));if (($bytesRead<=
(0x03c1+ 6059-0x1b6c))){$self->removeAndCloseHandle ($$handleHash{
"\x48\x61\x6e\x64\x6c\x65"});}else{($__stderrBuffer.=$buffer);($buffer=(""));}}
sub run{(my $buf_stdout=(""));(my $exit_value=(-(0x0787+ 3000-0x133e)));(my $timeout
=getTimeout ());my ($child_pid);my ($code);if (callFunction ()){($exit_value=
&$NXRunCommand::functionToRun (@NXRunCommand::functionToRunParameters));
Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$exit_value)."\x2e"));return ((""),(""),$exit_value);}if (nxexecSTD ()){
libnxh::NXDescriptorInheritable (main::nxgetSTDIN (),(0x1275+ 2927-0x1de3));
libnxh::NXDescriptorInheritable (main::nxgetSTDOUT (),(0x1b60+ 1323-0x208a));
libnxh::NXDescriptorInheritable (main::nxgetSTDERR (),(0x18e9+ 1910-0x205e));(
$NXRunCommand::childStdinInt=main::nxgetSTDIN ());($NXRunCommand::childStdoutInt
=main::nxgetSTDOUT ());($NXRunCommand::childStderrInt=main::nxgetSTDERR ());}
else{setChildDescriptors ();}if (isExecCommand ()){(my $error=(""));
Common::NXProcess::nxProcessExec ($NXRunCommand::filename,(
\@NXRunCommand::command),(\@NXRunCommand::environment),(\$error));return ($error
);}($child_pid=Common::NXProcess::nxProcessCreate ($NXRunCommand::filename,(
\@NXRunCommand::command),(\@NXRunCommand::environment),getChildStdinInt (),
getChildStdoutInt (),getChildStderrInt (),getPriority ()));(my $error=
libnxh::NXGetErrorName ());(my $errorNumber=libnxh::NXGetError ());(my $errorstring
=libnxh::NXGetErrorString ());if (closeAfterRun ()){foreach my $handle (
@NXRunCommand::handlesToCloseAfterRun){Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x6c\x6f\x73\x65\x20\x61\x66\x74\x65\x72\x20\x72\x75\x6e\x20\x2d\x20\x63\x6c\x6f\x73\x65\x20\x46\x44\x23"
.$handle)."\x2e"));main::nxclose ($handle);}}if (nxexecSTD ()){
libnxh::NXDescriptorInheritable (main::nxgetSTDIN (),(0x0ab8+ 3298-0x179a));
libnxh::NXDescriptorInheritable (main::nxgetSTDOUT (),(0x0ae2+ 5950-0x2220));
libnxh::NXDescriptorInheritable (main::nxgetSTDERR (),(0x06d8+ 6257-0x1f49));}
else{closeChildDescriptors ();}if (($child_pid<=(0x01bf+ 6083-0x1982))){(my $processName
=NXBegin::getProcessName ());Logger::error (((((
"\x43\x61\x6e\x27\x74\x20\x63\x72\x65\x61\x74\x65\x20\x6e\x65\x77\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.join ($",@NXRunCommand::command))."\x27\x20\x66\x72\x6f\x6d\x20").$processName)
."\x2e"));Logger::error ((((("\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".
$errorNumber)."\x2c\x20\x27").$errorstring)."\x27\x2e"));if ((((not (
stdin_redirect ()))and defined (getParentStdinInt ()))and (not (saveStdin ()))))
{main::nxclose (getParentStdinInt ());}if ((((not (stdout_redirect ()))and 
defined (getParentStdoutInt ()))and (not (saveStdout ())))){main::nxclose (
getParentStdoutInt ());}if ((((not (stderr_redirect ()))and defined (
getParentStderrInt ()))and (not (saveStderr ())))){main::nxclose (
getParentStderrInt ());}main::nxexit ((0x01ca+ 4428-0x1315));return ((""),(""),(
-(0x05a7+ 7317-0x223b)));}handlePid ($child_pid);handleParentStdin ();if (
runCommandInBg ()){handleParentStdout ();handleParentStderr ();Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x69\x6e\x20\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2e"
);($exit_value=(0x1400+ 1654-0x1a76));if (callFunctionAfterRun ()){push (
@NXRunCommand::functionToRunParameters,getChildPid ());($exit_value=
&$NXRunCommand::functionToRun (@NXRunCommand::functionToRunParameters));
Logger::debug (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x20\x72\x65\x74\x75\x72\x6e\x65\x64\x20"
.$exit_value)."\x2e"));}return ((""),(""),$exit_value);}($__stderrBuffer=(""));(my $flag_closed_stdout
=(0x057c+ 751-0x086a));(my $parentStdout=getParentStdoutInt ());(my $parentStderr
=getParentStderrInt ());(my $parser=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x50\x61\x72\x73\x65\x72"->new);(my $params
={"\x63\x6d\x64\x4f\x75\x74",("")});(my $signalFd=$$NXBegin::parser{
"\x53\x69\x67\x6e\x61\x6c"});$parser->add ($signalFd);$parser->setTimeout (
$timeout);if (finishOnSigchld ()){$parser->setFinishOnSigchld ($child_pid);}if (
(not (stdout_redirect ()))){if ((not ($parser->add ($parentStdout,(
\&__callbackStdout),
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x53\x74\x64\x6f\x75\x74"
,$params)))){Logger::warning (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x46\x44\x23"
.$parentStdout).
"\x20\x74\x6f\x20\x74\x68\x65\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"));}else{
$parser->setAsStdout ($parentStdout);Logger::debug2 (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x61\x64\x64\x65\x64\x20\x46\x44\x23"
.$parentStdout).
"\x20\x74\x6f\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x20\x73\x65\x74"
));($flag_closed_stdout=(0x07e9+ 4162-0x182b));}}if (isSetStderrAsPipe ()){if ((
not ($parser->add ($parentStderr,(\&__callbackStderr),
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x3a\x5f\x5f\x63\x61\x6c\x6c\x62\x61\x63\x6b\x53\x74\x64\x65\x72\x72"
,$params)))){Logger::warning (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x46\x44\x23"
.$parentStderr).
"\x20\x74\x6f\x20\x74\x68\x65\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"));}else{
$parser->setHandleStdoutStderr;Logger::debug2 (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x61\x64\x64\x65\x64\x20\x46\x44\x23"
.$parentStderr).
"\x20\x74\x6f\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x20\x73\x65\x74"
));}}(my $timedout=(0x0dff+ 1621-0x1454));if ((not ($flag_closed_stdout))){&try 
(sub{(($code,$buf_stdout)=$parser->run);},
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->catch (&with (sub{
Logger::warning (((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x54\x69\x6d\x65\x6f\x75\x74\x20\x77\x68\x69\x6c\x65\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x27"
.join ($",@NXRunCommand::command)).
"\x27\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x2e"));($timedout=(0x058d+ 397-0x0719)
);if ((not ($flag_closed_stdout))){main::nxclose ($parentStdout);}})));}(my $res
=(0x0381+ 3589-0x1186));if ((not ($timedout))){($res=
Common::NXProcess::nxwaitpid ($child_pid,$NXBits::WAIT_UNTRACED,$timeout));if ((
$res==(0x1567+ 2361-0x1ea0))){Logger::debug2 (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x77\x65\x20\x64\x69\x64\x6e\x27\x74\x20\x72\x65\x63\x65\x69\x76\x65\x20\x53\x49\x47\x43\x48\x4c\x44\x20\x69\x6e\x20\x74\x69\x6d\x65\x2e"
);killProcess ($child_pid);return ($__stderrBuffer,$buf_stdout,
(0x10cd+ 1292-0x15d8));}}else{($res=Common::NXProcess::nxwaitpid ($child_pid,
$NXBits::WAIT_NOHANG));if (($res==(0x06f3+ 2471-0x109a))){killProcess (
$child_pid);($res=Common::NXProcess::nxwaitpid ($child_pid,
$NXBits::WAIT_UNTRACED,$timeout));}}Logger::debug2 ((((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x6e\x78\x77\x61\x69\x74\x70\x69\x64\x20"
.$child_pid)."\x20\x72\x65\x74\x75\x72\x6e\x20").$res));($exit_value=
Common::NXProcess::getExitValue ($child_pid));Logger::debug (((((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$child_pid).
"\x27\x20\x65\x78\x69\x74\x20\x73\x74\x61\x74\x75\x73\x20\x77\x61\x73\x20\x27").
$exit_value)."\x27"));if (logStdout ()){Logger::debug (((((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$child_pid)."\x27\x20\x73\x74\x64\x6f\x75\x74\x20\x77\x61\x73\x20\x27").
$buf_stdout)."\x27"));}Logger::debug (((((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x27"
.$child_pid)."\x27\x20\x73\x74\x64\x65\x72\x72\x20\x77\x61\x73\x20\x27").
$__stderrBuffer)."\x27"));Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x72\x65\x74\x75\x72\x6e\x3a\x20"
.$exit_value));return ($__stderrBuffer,$buf_stdout,$exit_value);}sub 
setRunCommandInBG{($NXRunCommand::flag_runInBg=(0x0d79+ 2077-0x1595));}sub 
runCommandInBg{return ($NXRunCommand::flag_runInBg);}sub setPriority{(my $priority
=shift (@_));($NXRunCommand::priority=$priority);}sub getPriority{return (
$NXRunCommand::priority);}sub savePidToVar{if (defined ($NXRunCommand::savepid))
{(my $var=getVarToSavePid ());Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x61\x76\x69\x6e\x67\x20\x70\x69\x64\x20\x69\x6e\x20"
.$var));($$var=$NXRunCommand::childpid);}}sub getVarToSavePid{return (
$NXRunCommand::savepid);}sub setVarToSavePid{(my $var=shift (@_));(
$NXRunCommand::savepid=$var);}sub setStdin_redirect{(my $fh=shift (@_));(
$NXRunCommand::stdin_redirect=$fh);($NXRunCommand::flag_stdin_redirect=
(0x0f85+ 400-0x1114));}sub setStdinFD_redirect{(my $fh=shift (@_));Logger::debug
 ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x20\x73\x74\x64\x69\x6e\x46\x44\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x61\x73\x3a\x20"
.$fh));($NXRunCommand::stdin_redirect=$fh);($NXRunCommand::flag_stdinfd_redirect
=(0x13d3+ 3938-0x2334));}sub setStdoutFD_redirect{(my $fh=shift (@_));
Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x20\x73\x74\x64\x6f\x75\x74\x46\x44\x20\x72\x65\x64\x69\x72\x65\x63\x74\x20\x61\x73\x3a\x20"
.$fh));($NXRunCommand::stdout_redirect=$fh);(
$NXRunCommand::flag_stdoutfd_redirect=(0x1d57+ 520-0x1f5e));}sub 
setStdout_redirect{(my $fh=shift (@_));($NXRunCommand::stdout_redirect=$fh);(
$NXRunCommand::flag_stdout_redirect=(0x0553+ 3024-0x1122));}sub 
setStderr_redirect{(my $fh=shift (@_));($NXRunCommand::stderr_redirect=$fh);(
$NXRunCommand::flag_stderr_redirect=(0x1d58+   6-0x1d5d));}sub getStdin_redirect
{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x53\x74\x64\x69\x6e\x5f\x72\x65\x64\x69\x72\x65\x63\x74\x20\x72\x65\x74\x75\x72\x6e\x20"
.$NXRunCommand::stdin_redirect));return ($NXRunCommand::stdin_redirect);}sub 
getStdout_redirect{return ($NXRunCommand::stdout_redirect);}sub 
getStderr_redirect{return ($NXRunCommand::stderr_redirect);}sub stdinFD_redirect
{return ($NXRunCommand::flag_stdinfd_redirect);}sub stdin_redirect{return (
$NXRunCommand::flag_stdin_redirect);}sub stdoutFD_redirect{return (
$NXRunCommand::flag_stdoutfd_redirect);}sub stdout_redirect{return (
$NXRunCommand::flag_stdout_redirect);}sub stderr_redirect{return (
$NXRunCommand::flag_stderr_redirect);}sub setTypeNX{($NXRunCommand::flag_typeNX=
(0x1654+ 2793-0x213c));}sub isTypeNX{return ($NXRunCommand::flag_typeNX);}sub 
getChildPid{return ($NXRunCommand::childpid);}sub setSaveStdinTo{(my $self=shift
 (@_));(my $fh=shift (@_));($NXRunCommand::saveStdinTo=$fh);(
$NXRunCommand::flag_saveStdin=(0x01d9+ 6315-0x1a83));}sub setSaveStdoutTo{(my $self
=shift (@_));(my $fh=shift (@_));($NXRunCommand::saveStdoutTo=$fh);(
$NXRunCommand::flag_saveStdout=(0x0108+ 396-0x0293));}sub setSaveStderrTo{(my $self
=shift (@_));(my $fh=shift (@_));($NXRunCommand::saveStderrTo=$fh);(
$NXRunCommand::flag_saveStderr=(0x01e9+ 2553-0x0be1));}sub setStderrAsPipe{(my $self
=shift (@_));($NXRunCommand::flag_setStderrAsPipe=(0x0289+ 7345-0x1f39));}sub 
saveStdin{return ($NXRunCommand::flag_saveStdin);}sub saveStdout{return (
$NXRunCommand::flag_saveStdout);}sub saveStderr{return (
$NXRunCommand::flag_saveStderr);}sub isSetStderrAsPipe{return (
$NXRunCommand::flag_setStderrAsPipe);}sub getParentStderrInt{return (
$NXRunCommand::parentStderrInt);}sub closeCMDINonStart{return (
$NXRunCommand::flag_closeCMDIN);}sub closeCMDOUTonStart{return (
$NXRunCommand::flag_closeCMDOUT);}sub setCloseCMDIN{Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x43\x4d\x44\x5f\x49\x4e\x20\x74\x6f\x20\x62\x65\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);($NXRunCommand::flag_closeCMDIN=(0x128a+ 2129-0x1ada));}sub setNotCloseCMDIN{
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x43\x4d\x44\x5f\x49\x4e\x20\x6e\x6f\x74\x20\x74\x6f\x20\x62\x65\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);($NXRunCommand::flag_closeCMDIN=(0x09fb+ 5529-0x1f94));}sub setNotCloseCMDOUT{
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x43\x4d\x44\x5f\x4f\x55\x54\x20\x6e\x6f\x74\x20\x74\x6f\x20\x62\x65\x20\x63\x6c\x6f\x73\x65\x64\x2e"
);($NXRunCommand::flag_closeCMDOUT=(0x0a02+ 6943-0x2521));}sub setERRinOUT{(
$NXRunCommand::flag_ERRinOUT=(0x0931+ 399-0x0abf));}sub ERRinOUT{return (
$NXRunCommand::flag_ERRinOUT);}sub setFullEnv{($NXRunCommand::flag_fullENV=
(0x05a5+ 166-0x064a));}sub getParentStdin{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x69\x6e\x20\x72\x65\x74\x75\x72\x6e\x20"
.$NXRunCommand::parentStdin));return ($NXRunCommand::parentStdin);}sub 
getParentStdout{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x6f\x75\x74\x20\x72\x65\x74\x75\x72\x6e\x20"
.$NXRunCommand::parentStdout));return ($NXRunCommand::parentStdout);}sub 
getParentStderr{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x50\x61\x72\x65\x6e\x74\x53\x74\x64\x65\x72\x72\x20\x72\x65\x74\x75\x72\x6e\x20"
.$NXRunCommand::parentStderr));return ($NXRunCommand::parentStderr);}sub 
getChildStdinInt{Logger::debug ((
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x67\x65\x74\x43\x68\x69\x6c\x64\x53\x74\x64\x69\x6e\x20\x72\x65\x74\x75\x72\x6e\x20\x46\x44\x23"
.$NXRunCommand::childStdinInt));return ($NXRunCommand::childStdinInt);}sub 
getChildStdoutInt{return ($NXRunCommand::childStdoutInt);}sub getChildStderrInt{
return ($NXRunCommand::childStderrInt);}sub getParentStdinInt{return (
$NXRunCommand::parentStdinInt);}sub getParentStdoutInt{return (
$NXRunCommand::parentStdoutInt);}sub callFunction{return (
$NXRunCommand::flag_runFunction);}sub setCallFunction{(
$NXRunCommand::flag_runFunction=(0x0ff9+ 2025-0x17e1));}sub 
addToFunctionParameters{(my $parameters=shift (@_));push (
@NXRunCommand::functionToRunParameters,$parameters);}sub setNoLogStdout{
Logger::debug (
"\x4e\x58\x52\x75\x6e\x43\x6f\x6d\x6d\x61\x6e\x64\x3a\x20\x73\x65\x74\x74\x69\x6e\x67\x20\x6e\x6f\x74\x20\x74\x6f\x20\x6c\x6f\x67\x20\x73\x74\x64\x6f\x75\x74\x2e"
);($NXRunCommand::flag_noLogStdout=(0x0039+ 9087-0x23b7));}sub logStdout{return 
((!$NXRunCommand::flag_noLogStdout));}sub setFunctionToCall{(my $function=shift 
(@_));($NXRunCommand::functionToRun=("\x3a\x3a".$function));(
@NXRunCommand::functionToRunParameters=());}sub setCallFunctionAfterRun{(
$NXRunCommand::flag_callFunctionAfterRun=(0x06cf+ 3831-0x15c5));}sub 
setCallFunctionAfterExit{($NXRunCommand::flag_callFunctionAfterExit=
(0x10c1+ 5361-0x25b1));}sub setCallFunctionAfterError{(
$NXRunCommand::flag_callFunctionAfterError=(0x1e71+ 1557-0x2485));}sub 
callFunctionAfterRun{return ($NXRunCommand::flag_callFunctionAfterRun);}sub 
callFunctionAfterExit{return ($NXRunCommand::flag_callFunctionAfterExit);}sub 
callFunctionAfterError{return ($NXRunCommand::flag_callFunctionAfterError);}sub 
setFileNameForSetPid{(my $fileName=shift (@_));Logger::debug2 ((
"\x73\x65\x74\x46\x69\x6c\x65\x4e\x61\x6d\x65\x46\x6f\x72\x53\x65\x74\x50\x69\x64\x20\x69\x6e\x20\x66\x69\x6c\x65\x3a\x20"
.$fileName));($NXRunCommand::fileNameForSetPid=$fileName);}sub 
cleanFileNameForSetPid{Logger::debug2 (
"\x63\x6c\x65\x61\x6e\x46\x69\x6c\x65\x4e\x61\x6d\x65\x46\x6f\x72\x53\x65\x74\x50\x69\x64"
);if (defined ($NXRunCommand::fileNameForSetPid)){undef (
$NXRunCommand::fileNameForSetPid);}}sub savePidToFile{if (defined (
$NXRunCommand::fileNameForSetPid)){Logger::debug2 ((((
"\x47\x6f\x69\x6e\x67\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x70\x69\x64\x20".
$NXRunCommand::childpid)."\x20\x69\x6e\x20\x66\x69\x6c\x65\x20").
$NXRunCommand::fileNameForSetPid));(my $file=main::nxopen (
$NXRunCommand::fileNameForSetPid,(($NXBits::O_WRONLY+$NXBits::O_CREAT)+
$NXBits::O_TRUNC),(($NXBits::UserReadWrite+$NXBits::GroupRead)+
$NXBits::OthersRead)));if ((not (defined ($file)))){Common::NXCore::assertExit 
();return ((0x16dc+ 1332-0x1c10));}main::nxwrite ($file,($NXRunCommand::childpid
."\x0a"));main::nxclose ($file);}else{Logger::debug2 (((
"\x4e\x6f\x74\x20\x73\x61\x76\x65\x20\x70\x69\x64\x20".$NXRunCommand::childpid).
"\x20\x69\x6e\x20\x61\x6e\x79\x20\x66\x69\x6c\x65\x2e"));}}sub killProcess{(my $child_pid
=shift (@_));if (useScriptToKill ()){
Common::NXProcess::signalProcessByRestrictedScript ($child_pid,
Common::NXProcess::getSignalKill ());}else{if (Common::NXProcess::sigkill (
$child_pid)){Logger::debug ((
"\x53\x49\x47\x4b\x49\x4c\x4c\x20\x73\x65\x6e\x74\x20\x74\x6f\x20\x72\x75\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$child_pid));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x53\x49\x47\x4b\x49\x4c\x4c\x20\x74\x6f\x20\x72\x75\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20"
.$child_pid)."\x2e"));}}}sub closeAfterRun{return (
$NXRunCommand::flag_closeAfterRun);}sub addHandleToClose{(my $handle=shift (@_))
;($NXRunCommand::flag_closeAfterRun=(0x015a+ 111-0x01c8));push (
@NXRunCommand::handlesToCloseAfterRun,$handle);}sub setNxexecSTD{(
$NXRunCommand::flag_nxexecSTD=(0x0787+ 5306-0x1c40));}sub nxexecSTD{return (
$NXRunCommand::flag_nxexecSTD);}sub setTimeout{(my $timeout=shift (@_));(
$NXRunCommand::timeoutForOperation=$timeout);}sub getTimeout{return (
$NXRunCommand::timeoutForOperation);}sub setUseScriptToKill{(
$NXRunCommand::useScriptToKill=(0x21b0+ 1297-0x26c0));}sub useScriptToKill{
return ($NXRunCommand::useScriptToKill);}sub finishOnSigchld{return (
$NXRunCommand::finishOnSigchld);}sub setFinishOnSigchld{(
$NXRunCommand::finishOnSigchld=(0x094b+ 1316-0x0e6e));}sub setNoLogStdin{return 
(($NXRunCommand::stdinLogEnabled=(0x1481+  27-0x149c)));}sub isStdinLogEnabled{
return ($NXRunCommand::stdinLogEnabled);}sub setExecCommand{(
$NXRunCommand::flag_execCommand=(0x141d+ 2269-0x1cf9));}sub isExecCommand{if ((
$NXRunCommand::flag_execCommand==(0x0468+ 6121-0x1c50))){return (
(0x0632+ 2773-0x1106));}return ((0x036a+ 2396-0x0cc6));}return (
(0x0a5c+ 927-0x0dfa));
