############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::MaximumGuestsNumber::BEGIN{package Exception::MaximumGuestsNumber
;no warnings;require base;do{"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::MaximumGuestsNumber::BEGIN{package Exception::MaximumGuestsNumber;no 
warnings;require overload;do{"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import (
"\x22\x22","\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::MaximumGuestsNumber::notify{package Exception::MaximumGuestsNumber;no
 warnings;(my $self=shift (@_));NXMsg::error (
"\x65\x4d\x61\x78\x69\x6d\x75\x6d\x47\x75\x65\x73\x74\x73\x4e\x75\x6d\x62\x65\x72"
,"\x4e\x58\x53\x68\x65\x6c\x6c");}package Exception::MaximumGuestsNumber;no 
warnings;return ((0x0179+ 3018-0x0d42));
