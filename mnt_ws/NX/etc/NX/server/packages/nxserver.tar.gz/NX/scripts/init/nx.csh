#!/bin/csh

#
#  Expanding PATH
#
if ( -x /usr/xpg4/bin/grep ) then
  set GREPCOMMAND = /usr/xpg4/bin/grep
else if ( -x /usr/bin/grep ) then
  set GREPCOMMAND = /usr/bin/grep
else if ( -x /bin/grep ) then
  set GREPCOMMAND = /bin/grep
else
  set GREPCOMMAND = grep
endif

set FOUND = `echo $PATH | $GREPCOMMAND INSTALL_PATH`

if ( $FOUND == "" ) then
  setenv PATH INSTALL_PATH/bin:${PATH}
endif


