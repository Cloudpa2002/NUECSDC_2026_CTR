############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXUsb::BEGIN{package NXUsb;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}package NXUsb;no warnings;
%usbDB;sub list{(my $extended=(shift (@_)||(0x04e7+ 6533-0x1e6c)));(my $username
=(shift (@_)||("")));(my (%usbList)=());(my $result=getUsbList ((\%usbList),
$username));if (($result!=(0x0271+ 8957-0x256e))){printUsbList ((\%usbList),
$extended);}else{Common::NXMsg::error (
"\x65\x43\x4d\x44\x55\x73\x62\x4c\x69\x73\x74\x46\x61\x69\x6c\x65\x64");}}sub 
add{(my $encodedLine=shift (@_));(my $line=main::urldecode ($encodedLine));(my $usb
=__parseUsbCommandLine ($line));(my $sessionId=Server::getMySessionID ());(my $record
=__createRecord ($sessionId,NXLogin::getCurrentUser (),$usb));(my $result=__add 
($record));(my $hubPort=$$usb{"\x48\x75\x62\x2d\x50\x6f\x72\x74"});if (($result
==(0x1cdb+ 296-0x1e03))){Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x48\x75\x62\x2d\x50\x6f\x72\x74\x3a\x20")
.$hubPort)."\x2e"));}else{Logger::debug (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x41\x64\x64\x65\x64\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x48\x75\x62\x2d\x50\x6f\x72\x74\x3a\x20")
.$hubPort)."\x2e"));}}sub __createRecord{(my $sessionId=shift (@_));(my $username
=shift (@_));(my $ref_usb=shift (@_));(my $record=(""));($record.=($username.
"\x3a"));($record.=($sessionId."\x3a"));($record.=($$ref_usb{
"\x44\x65\x76\x69\x63\x65\x20\x6e\x61\x6d\x65"}."\x3a"));($record.=($$ref_usb{
"\x48\x75\x62\x2d\x50\x6f\x72\x74"}."\x3a"));($record.=($$ref_usb{
"\x53\x74\x61\x74\x75\x73"}."\x3a"));($record.=($$ref_usb{"\x4e\x6f\x64\x65\x73"
}."\x3a"));($record.="\x0a");return ($record);}sub delete{(my $encodedLine=shift
 (@_));(my $line=main::urldecode ($encodedLine));(my $usb=__parseUsbCommandLine 
($line));(my $sessionId=Server::getMySessionID ());(my $hubPort=$$usb{
"\x48\x75\x62\x2d\x50\x6f\x72\x74"});(my $result=__del ($sessionId,$hubPort));if
 (($result==(0x0565+ 7954-0x2477))){Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x48\x75\x62\x2d\x50\x6f\x72\x74\x3a\x20")
.$hubPort)."\x2e"));}else{Logger::debug (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x44\x65\x6c\x65\x74\x65\x64\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x20\x77\x69\x74\x68\x20\x48\x75\x62\x2d\x50\x6f\x72\x74\x3a\x20")
.$hubPort)."\x2e"));}}sub deleteBySessionId{(my $sessionId=shift (@_));(my $result
=__del ($sessionId));if (($result==(0x04eb+ 2868-0x101f))){Logger::warning (((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x2e"));}else{Logger::debug (((
"\x4e\x58\x55\x73\x62\x3a\x20\x44\x65\x6c\x65\x74\x65\x64\x20\x75\x73\x62\x20\x65\x6e\x74\x72\x79\x20\x66\x6f\x72\x3a\x20"
.$sessionId)."\x2e"));}}sub deleteMySession{return (deleteBySessionId (
Server::getMySessionID ()));}sub __parseUsbCommandLine{(my $lineToParse=shift (
@_));($lineToParse=~ s/[\r\n]//g );(my (@line)=split ( /,/ ,$lineToParse,
(0x08e8+ 7287-0x255f)));(my (%usb)=());($usb{
"\x44\x65\x76\x69\x63\x65\x20\x6e\x61\x6d\x65"}=$line[(0x0a26+ 7231-0x2665)]);(
$usb{"\x48\x75\x62\x2d\x50\x6f\x72\x74"}=$line[(0x01a1+ 849-0x04f1)]);($usb{
"\x53\x74\x61\x74\x75\x73"}=$line[(0x01b3+ 1975-0x0968)]);($usb{
"\x4e\x6f\x64\x65\x73"}=$line[(0x10db+ 204-0x11a4)]);return ((\%usb));}sub 
getUsbList{(my $ref_usbList=shift (@_));(my $username=shift (@_));(my $dbFilePath
=NXPaths::getUsbDBPath ());(my $handle=main::nxopen ($dbFilePath,
$NXBits::O_RDONLY));if (defined ($handle)){my ($line);while (main::nxreadLine (
$handle,(\$line))){(my $usb=__parseDBLine ($line));if ($username){if (($username
 eq $$usb{"\x55\x73\x65\x72\x6e\x61\x6d\x65"})){($$ref_usbList{$i++}=$usb);}}
else{($$ref_usbList{$i++}=$usb);}}main::nxclose ($handle);}else{return (
(0x082a+ 5760-0x1eaa));}return ((0x1078+ 1690-0x1711));}sub printUsbList{(my $ref_usbList
=shift (@_));(my $extended=(shift (@_)||(0x13e1+ 4674-0x2623)));(my (@labels)=(
"\x55\x73\x65\x72\x6e\x61\x6d\x65","\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44",
"\x44\x65\x76\x69\x63\x65\x20\x6e\x61\x6d\x65",
"\x48\x75\x62\x2d\x50\x6f\x72\x74","\x53\x74\x61\x74\x75\x73"));if ($extended){
push (@labels,"\x4e\x6f\x64\x65\x73");}Common::NXMsg::info (
"\x69\x43\x4d\x44\x55\x73\x62\x4c\x69\x73\x74");return (NXTools::printTable ((
\@labels),$ref_usbList));}sub __add{(my $record=shift (@_));(my $dbFilePath=
NXPaths::getUsbDBPath ());(my $lockHandle=main::lockFileDirect ($dbFilePath,
$NXBits::LOCK_EX));(my $dbHandle=main::nxopen ($dbFilePath,(($NXBits::O_WRONLY+
$NXBits::O_CREAT)+$NXBits::O_APPEND),$NXBits::UserReadWrite));if ((not (defined 
($dbHandle)))){main::unLockFileDirect ($lockHandle);(my $errorString=
libnxh::NXGetErrorString ());Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20"
.$dbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorString).
"\x27"));return ((0x054a+ 7111-0x2111));}(my $bytes=main::nxwrite ($dbHandle,
$record));if (($bytes==(-(0x00d3+ 8412-0x21ae)))){(my $errorString=
libnxh::NXGetErrorString ());main::nxclose ($dbHandle);main::unLockFileDirect (
$lockHandle);Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x3a\x20"
.$dbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorString).
"\x27"));return ((0x00e3+ 363-0x024e));}main::nxclose ($dbHandle);
main::unLockFileDirect ($lockHandle);return ((0x0c3f+ 868-0x0fa2));}sub __del{(my $sessionId
=shift (@_));(my $hubPort=shift (@_));(my $dbFilePath=NXPaths::getUsbDBPath ());
(my $flag_del=(0x17d6+ 1498-0x1db0));(my $lockHandle=main::lockFileDirect (
$dbFilePath,$NXBits::LOCK_EX));(my $dbHandle=main::nxopen ($dbFilePath,
$NXBits::O_RDONLY,(0x185b+ 1904-0x1fcb)));if ((not (defined ($dbHandle)))){(my $errorString
=libnxh::NXGetErrorString ());main::unLockFileDirect ($lockHandle);
Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x3a\x20"
.$dbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorString).
"\x27"));return ((0x0d46+ 6350-0x2614));}(my $tempdbFilePath=(($dbFilePath.
"\x2e\x74\x6d\x70\x2e").$ $));
 if (Common::NXFile::isExists ($tempdbFilePath)){
unlink ($tempdbFilePath);}(my $tmpHandle=main::nxopen ($tempdbFilePath,((
$NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND),$NXBits::UserReadWrite));
if ((not (defined ($tmpHandle)))){(my $errorString=libnxh::NXGetErrorString ());
main::nxclose ($dbHandle);main::unLockFileDirect ($lockHandle);Logger::warning (
((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x3a\x20"
.$tempdbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").
$errorString)."\x27"));return ((0x0172+ 4725-0x13e7));}&try (sub{my ($line);
while (main::nxreadLine ($dbHandle,(\$line))){(my $usb=__parseDBLine ($line));(
$usbDB{$$usb{"\x55\x73\x65\x72\x6e\x61\x6d\x65"}}=$usb);if ((($sessionId ne 
$$usb{"\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44"})or ($hubPort and ($hubPort ne 
$$usb{"\x48\x75\x62\x2d\x50\x6f\x72\x74"})))){
Common::NXCore::nxwriteOrThrowException ($tmpHandle,$line);}}},&otherwise (sub{(my $error
=shift (@_));main::nxclose ($tmpHandle);main::nxclose ($dbHandle);
main::unLockFileDirect ($lockHandle);Logger::warning (((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x74\x6f\x3a\x20"
.$tempdbFilePath)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$error).
"\x27"));return ((0x0248+ 9206-0x263e));}));main::nxclose ($tmpHandle);
main::nxclose ($dbHandle);if ((not (Common::NXFile::renameFile ($tempdbFilePath,
$dbFilePath)))){(my $errorString=libnxh::NXGetErrorString ());
main::unLockFileDirect ($lockHandle);Logger::warning (((((((
"\x4e\x58\x55\x73\x62\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x3a\x3a\x20"
.$tempdbFilePath)."\x20\x74\x6f\x3a\x20").$dbFilePath).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27").$errorString)."\x27"));
return ((0x0ecf+ 4030-0x1e8d));}main::unLockFileDirect ($lockHandle);return (
(0x0934+  36-0x0957));}sub __parseDBLine{(my $lineToParse=shift (@_));(
$lineToParse=~ s/[\r\n]//g );(my (@line)=split ( /:/ ,$lineToParse,
(0x1181+ 2073-0x199a)));(my (%usb)=());($usb{"\x55\x73\x65\x72\x6e\x61\x6d\x65"}
=$line[(0x096f+ 4722-0x1be1)]);($usb{"\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44"}
=$line[(0x097b+ 2928-0x14ea)]);($usb{
"\x44\x65\x76\x69\x63\x65\x20\x6e\x61\x6d\x65"}=$line[(0x0ee9+ 1497-0x14c0)]);(
$usb{"\x48\x75\x62\x2d\x50\x6f\x72\x74"}=$line[(0x0ccb+ 1136-0x1138)]);($usb{
"\x53\x74\x61\x74\x75\x73"}=$line[(0x0473+ 6627-0x1e52)]);($usb{
"\x4e\x6f\x64\x65\x73"}=$line[(0x0357+ 4715-0x15bd)]);return ((\%usb));}
"\x3f\x3f\x3f";
