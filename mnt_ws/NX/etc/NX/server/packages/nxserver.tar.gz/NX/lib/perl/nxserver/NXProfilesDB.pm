############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXProfilesDB;no warnings;require NXPaths;sub BEGIN{require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub BEGIN{require 
Exception::Log;do{"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->
import};}(my $__databaseInitialized=(0x1197+ 3911-0x20de));(my $__userSidsInitialized
=(0x033b+ 4331-0x1426));(my (%__profiles)=());(my (%__loadedProfiles)=());(my $__fields_in_record
=(0x1cdb+ 2118-0x2507));sub save{Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42\x3a\x20\x53\x61\x76\x69\x6e\x67\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e"
);if ((not (%__profiles))){NXRedis::sendToDbAndSave (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x0a"
);}else{my ($command);foreach my $key (keys (%__profiles)){(my $line=join (
"\x3a",@{$__profiles{$key};}));(my $record=main::urlencode ($line));($key=
main::urlencode ($key));if (($record ne $__loadedProfiles{$key})){(my $newRule=(
(("\x2c\x66\x69\x65\x6c\x64\x3d".$key)."\x2c\x76\x61\x6c\x75\x65\x3d").$record))
;if ((length ($newRule)>(0x10a6+ 918-0x0ed5))){NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73"
.$newRule)."\x0a"));delete ($__loadedProfiles{$key});next;}($command.=$newRule);
}delete ($__loadedProfiles{$key});(my $length=length ($command));if (($length>
15000)){NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73"
.$command)."\x0a"));($command=(""));}}if (($command ne (""))){
NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73"
.$command)."\x0a"));}if (%__loadedProfiles){my ($commandDel);foreach my $key (
keys (%__loadedProfiles)){($commandDel.=("\x2c\x66\x69\x65\x6c\x64\x3d".$key));}
if (($commandDel ne (""))){NXRedis::sendToDbAndSave (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73"
.$commandDel)."\x0a"));}}resetDB ();}return ((0x0067+ 5874-0x1759));}sub __load{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x67\x65\x74\x61\x6c\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x0a"
);((%__loadedProfiles)=split ( / / ,NXRedis::get (),(0x00ab+ 6403-0x19ae)));
foreach my $key (keys (%__loadedProfiles)){(my $record=main::urldecode (
$__loadedProfiles{$key}));($key=main::urldecode ($key));(my (@recordArray)=split
 ( /:/ ,$record,(0x0413+ 2589-0x0e30)));($__profiles{$key}=(\@recordArray));}
__convertUsernamesInKeysToAbsoluteUsername ();($__databaseInitialized=
(0x0620+ 6210-0x1e61));}sub getDatabaseInString{__load ();(my $string=
NXShell::hashParameters2Url (%__loadedProfiles));return ($string);}sub 
setDatabaseByString{(my $string=shift (@_));if (($string eq (""))){return (
(0x095d+ 3394-0x169f));}(my (%tmpProfiles)=NXShell::urlParameter2Hash ($string))
;foreach my $key (keys (%tmpProfiles)){(my (@recordArray)=split ( /:/ ,
main::urldecode ($tmpProfiles{$key}),(0x014f+ 7491-0x1e92)));($__profiles{$key}=
(\@recordArray));}save ();return ((0x1384+ 2958-0x1f12));}sub 
getProfileServerSetInString{NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x73\x65\x72\x76\x65\x72\x73\x54\x6f\x43\x68\x65\x63\x6b\x0a"
);return (main::urlencode (NXRedis::get ()));}sub getProfileGroupSetInString{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x67\x72\x6f\x75\x70\x73\x54\x6f\x43\x68\x65\x63\x6b\x0a"
);return (main::urlencode (NXRedis::get ()));}sub saveProfileServerSetByString{(my $string
=shift (@_));(my (@servers)=split ( / / ,main::urldecode ($string),
(0x0d37+ 5095-0x211e)));if ((scalar (@servers)==(0x0817+ 5157-0x1c3c))){
Logger::debug (
"\x4e\x6f\x20\x73\x65\x72\x76\x65\x72\x73\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x69\x6e\x20\x70\x72\x6f\x66\x69\x6c\x65\x20\x73\x65\x74\x2e\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x2e"
);return ((0x0380+ 1515-0x096b));}(my $command=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x73\x65\x72\x76\x65\x72\x73\x54\x6f\x43\x68\x65\x63\x6b"
);foreach my $serverToAdd (@servers){($command.=("\x2c\x66\x69\x65\x6c\x64\x3d".
$serverToAdd));}($command.="\x0a");NXRedis::sendToDbAndSave ($command);return (
(0x04c2+ 357-0x0627));}sub saveProfileGroupSetByString{(my $string=shift (@_));(my (
@groups)=split ( / / ,main::urldecode ($string),(0x0ac8+ 1167-0x0f57)));if ((
scalar (@groups)==(0x033b+ 2805-0x0e30))){Logger::debug (
"\x4e\x6f\x20\x67\x72\x6f\x75\x70\x73\x20\x74\x6f\x20\x73\x61\x76\x65\x20\x69\x6e\x20\x70\x72\x6f\x66\x69\x6c\x65\x20\x73\x65\x74\x2e\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x2e"
);return ((0x19a2+ 2684-0x241e));}(my $command=
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e\x67\x72\x6f\x75\x70\x73\x54\x6f\x43\x68\x65\x63\x6b"
);foreach my $groupToAdd (@groups){($command.=("\x2c\x66\x69\x65\x6c\x64\x3d".
$groupToAdd));}($command.="\x0a");NXRedis::sendToDbAndSave ($command);return (
(0x208a+ 1198-0x2538));}sub cleanDb{NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x70\x72\x6f\x66\x69\x6c\x65\x73\x0a"
);resetDB ();((%__loadedProfiles)=());}sub getDatabaseReference{if ((
$__databaseInitialized==(0x0280+ 4577-0x1461))){__load ();}return ((\%__profiles
));}sub getEmptyProfile{return ((((""))x $__fields_in_record));}sub resetDB{
Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42\x3a\x20\x52\x65\x73\x65\x74\x69\x6e\x67\x20\x70\x72\x6f\x66\x69\x6c\x65\x73\x2e"
);($__databaseInitialized=(0x1ee9+ 718-0x21b7));foreach my $key (keys (
%__profiles)){delete ($__profiles{$key});}}sub 
__convertUsernamesInKeysToAbsoluteUsername{if ((($__userSidsInitialized==
(0x059a+ 2547-0x0f8c))or ($GLOBAL::DisableUsernameConversion==
(0x0496+ 4210-0x1507)))){return;}Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x44\x42\x3a\x20\x43\x6f\x6e\x76\x65\x72\x74\x69\x6e\x67\x20\x75\x73\x65\x72\x6e\x61\x6d\x65\x73\x20\x74\x6f\x20\x53\x49\x44\x73\x2e"
);foreach my $key (keys (%__profiles)){(my $convertedKey=$key);
convertUsernameInKeyToAbsoluteUsername ((\$convertedKey));if (($convertedKey ne 
$key)){($__profiles{$convertedKey}=$__profiles{$key});delete ($__profiles{$key})
;}}($__userSidsInitialized=(0x0401+ 1341-0x093d));}sub 
convertUsernameInKeyToAbsoluteUsername{if (($GLOBAL::DisableUsernameConversion==
(0x0e5a+ 782-0x1167))){return;}(my $ref_key=shift (@_));if ((
__convertUsernameInNodeAndUserProfileKeyToAbsoluteUsername ($ref_key)==
(0x0072+ 9231-0x2480))){return;}if ((
__convertUsernameInUserProfileKeyToAbsoluteUsername ($ref_key)==
(0x1386+ 4385-0x24a6))){return;}}sub 
__convertUsernameInNodeAndUserProfileKeyToAbsoluteUsername{(my $ref_key=shift (
@_));if (($$ref_key=~ /(.*),(.*)/ )){(my $node=$1);(my $user=$2);if (($node=~ /\// )
){if ((__convertUsernameInUserProfileKeyToAbsoluteUsername ((\$user))==
(0x0b50+ 3646-0x198d))){($$ref_key=(($node."\x2c").$user));}}return (
(0x0014+ 1516-0x05ff));}return ((0x1835+ 2280-0x211d));}sub 
__convertUsernameInUserProfileKeyToAbsoluteUsername{(my $ref_key=shift (@_));if 
(NXProfiles::isInternalKey ($$ref_key)){return ((0x096b+ 3397-0x16b0));}if ((
$$ref_key eq (""))){Logger::debug (
"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x63\x68\x65\x63\x6b\x20\x65\x6d\x70\x74\x79\x20\x6b\x65\x79\x2e"
);return ((0x00e4+ 4568-0x12bc));}if (NXNodes::isUUID ($$ref_key)){return (
(0x0f05+ 3078-0x1b0b));}if (($$ref_key=~ /__group__/ )){return (
(0x0847+ 3843-0x174a));}if (($$ref_key=~ /\// )){return ((0x1d83+ 135-0x1e0a));}
if (($$ref_key=~ /__nodegroup__/ )){return ((0x2184+   4-0x2188));}if ((
$$ref_key=~ /__servergroup__/ )){return ((0x1e1d+ 1723-0x24d8));}if (($$ref_key
=~ /__address__/ )){return ((0x0976+ 4418-0x1ab8));}(my $username=
NXLogin::getAbsoluteNameForUsername ($$ref_key));($$ref_key=$username);return (
(0x0151+ 2881-0x0c91));}sub reloadProfilesDB{($__databaseInitialized=
(0x0c7b+ 1412-0x11ff));($__userSidsInitialized=(0x2592+  90-0x25ec));((
%__profiles)=());__load ();if (NXProfiles::isPropagatedRuleToOverwrite ()){
NXProfiles::overwritePropagatedRules ();}}"\x3f\x3f\x3f";
