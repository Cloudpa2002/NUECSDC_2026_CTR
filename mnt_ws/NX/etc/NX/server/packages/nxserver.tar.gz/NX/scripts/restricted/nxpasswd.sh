#!/bin/bash
######################################################################
#                                                                    #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.     #
#                                                                    #
#  All rights reserved.                                              #
#                                                                    #
######################################################################

RunDir=${0%nxpasswd.sh}
RestrictedDir=$(cd "${RunDir}" && pwd)

PARAMS_COUNT=4

. "${RestrictedDir}"/nxfunct.sh

isRunByServer

if test "x$3" = "x"; then
  $3=0
fi

COMMAND_CHPASSWD="${NX_ROOT}/bin/nxserver"

exec "${COMMAND_CHPASSWD}" --passwd $3 --system $4

exit $?
