############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXNODE, NX protocol compression and NX extensions to this software      #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Common::NXImage::import{package Common::NXImage;no warnings;(my $source=
shift (@_));(my $destination=shift (@_));(my $tempDestination=($destination.
"\x2e\x70\x61\x72\x74"));if ((__import ($source,$tempDestination)<
(0x05ac+ 5949-0x1ce9))){return ((0x0785+ 5973-0x1eda));}if ((not (rename (
$tempDestination,$destination)))){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$tempDestination)."\x27\x20\x74\x6f\x20\x27").$destination).
"\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x20").$!)."\x2e"));if ((not (
unlink ($tempDestination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$tempDestination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));}
return ((0x091f+ 4318-0x19fd));}return ((0x079b+ 4301-0x1867));}sub 
Common::NXImage::delete{package Common::NXImage;no warnings;(my $path=shift (@_)
);Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x44\x65\x6c\x65\x74\x65\x28"
.$path)."\x29"));(my $return=libnxhc::NXImageDelete ($path));Logger::debug ((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x44\x65\x6c\x65\x74\x65\x28"
.$path)."\x29\x20\x72\x65\x74\x75\x72\x6e\x20").$return));if (($return<
(0x1b7a+ 854-0x1ed0))){(my $errorNumber=libnxh::NXShellGetError ());(my $errorString
=libnxh::NXGetSystemErrorString ($errorNumber));Logger::warning (((((
"\x43\x6f\x75\x6c\x64\x6e\x27\x74\x20\x64\x65\x6c\x65\x74\x65\x20\x69\x6d\x61\x67\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));}return ($return);}sub 
Common::NXImage::list{package Common::NXImage;no warnings;(my $path=shift (@_));
Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x4c\x69\x73\x74\x28"
.$path)."\x29"));(my $buffer=libnxhc::NXImageList ($path));Logger::debug ((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x4c\x69\x73\x74\x28"
.$path)."\x29\x20\x72\x65\x74\x75\x72\x6e\x20").$buffer));(my (@files)=());if (
defined ($buffer)){(@files=split ( /\n/ ,$buffer,(0x05b9+ 6472-0x1f01)));}return
 (@files);}sub Common::NXImage::isoCreate{package Common::NXImage;no warnings;(my $output
=shift (@_));(my $input=shift (@_));(my $label=shift (@_));(my $joliet=shift (@_
));Logger::debug (((((((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x73\x6f\x43\x72\x65\x61\x74\x65\x28"
.$output)."\x2c\x20").$input)."\x2c\x20").$label)."\x2c\x20").$joliet)."\x29"));
(my $return=libnxhc::NXIsoCreate ($output,$input,$label,$joliet));Logger::debug 
(((((((((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x73\x6f\x43\x72\x65\x61\x74\x65\x28"
.$output)."\x2c\x20").$input)."\x2c\x20").$label)."\x2c\x20").$joliet).
"\x29\x20\x72\x65\x74\x75\x72\x6e\x20").$return)."\x2e"));if (($return==
(0x1bc4+ 2092-0x23f0))){(my $errorNumber=NXPL::NXShellGetError ());(my $errorString
=NXPL::NXGetSystemErrorString ($errorNumber));Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x49\x53\x4f\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));}return ($return);}sub 
Common::NXImage::replace{package Common::NXImage;no warnings;(my $source=shift (
@_));(my $destination=shift (@_));(my $tempDestination=($destination.
"\x2e\x70\x61\x72\x74"));if ((__import ($source,$tempDestination)<
(0x1436+ 1241-0x190f))){return ((0x20db+ 780-0x23e7));}if ((not (unlink (
$destination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$destination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));if ((
not (unlink ($tempDestination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$tempDestination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));}
return ((0x11c1+ 533-0x13d6));}if ((not (rename ($tempDestination,$destination))
)){Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$tempDestination)."\x27\x20\x74\x6f\x20\x27").$destination).
"\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x20").$!)."\x2e"));if ((not (
unlink ($tempDestination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$tempDestination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));}
return ((0x0bb5+ 4305-0x1c86));}return ((0x16a0+ 1829-0x1dc4));}sub 
Common::NXImage::__import{package Common::NXImage;no warnings;(my $source=shift 
(@_));(my $destination=shift (@_));Logger::debug (((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x49\x6d\x70\x6f\x72\x74\x28"
.$source)."\x2c\x20").$destination)."\x29"));(my $return=libnxhc::NXImageImport 
($source,$destination));Logger::debug ((((((
"\x6c\x69\x62\x6e\x78\x68\x63\x3a\x3a\x4e\x58\x49\x6d\x61\x67\x65\x49\x6d\x70\x6f\x72\x74\x28"
.$source)."\x2c\x20").$destination)."\x29\x20\x72\x65\x74\x75\x72\x6e\x20").
$return));if (($return<(0x12d2+ 1157-0x1757))){(my $errorNumber=
libnxh::NXShellGetError ());(my $errorString=libnxh::NXGetSystemErrorString (
$errorNumber));Logger::warning (((((
"\x43\x6f\x75\x6c\x64\x6e\x27\x74\x20\x69\x6d\x70\x6f\x72\x74\x20\x69\x6d\x61\x67\x65\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20"
.$errorNumber)."\x2c\x20").$errorString)."\x2e"));if (Common::NXFile::isExists (
$destination)){if ((not (unlink ($destination)))){Logger::warning (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$destination)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$!)."\x2e"));}}}
return ($return);}package Common::NXImage;no warnings;"\x3f\x3f\x3f";
