############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub BEGIN{no warnings;require NXMsg;do{"\x4e\x58\x4d\x73\x67"->import};}sub 
NXHostsManager::put{package NXHostsManager;no warnings;return (__put (@_));}sub 
NXHostsManager::del{package NXHostsManager;no warnings;return (__del (@_));}sub 
NXHostsManager::list{package NXHostsManager;no warnings;return (show (@_));}sub 
NXHostsManager::edit{package NXHostsManager;no warnings;return (__edit (@_));}
sub NXHostsManager::show{package NXHostsManager;no warnings;(my (@hosts)=__list 
(@_));main::nxwrite (main::nxgetSTDOUT (),"\x0a");main::nxwrite (
main::nxgetSTDOUT (),
"\x43\x6c\x69\x65\x6e\x74\x20\x49\x50\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x52\x65\x64\x69\x72\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x4d\x6f\x64\x65\x0a"
);main::nxwrite (main::nxgetSTDOUT (),("\x2d" x (0x0263+ 621-0x04b2)),"\x20",(
"\x2d" x (0x091a+ 6372-0x21e0)),"\x20",("\x2d" x (0x05ba+ 2270-0x0e83)),"\x0a");
foreach my $host (@hosts){chomp ($host);($host=~ s/\r//g );(my ($client,
$redirect,$auth)=split ( /,/ ,$host,(0x007b+ 2780-0x0b53)));($client=sprintf (
"\x25\x2d\x33\x30\x73",$client));($redirect=sprintf ("\x25\x2d\x33\x30\x73",
$redirect));($auth=sprintf ("\x25\x2d\x32\x31\x73",($auth.
"\x20\x61\x75\x74\x68\x65\x6e\x74\x69\x63\x61\x74\x69\x6f\x6e")));main::nxwrite 
(main::nxgetSTDOUT (),((((($client."\x20").$redirect)."\x20").$auth)."\x0a"));}
main::nxwrite (main::nxgetSTDOUT (),"\x0a");}sub NXHostsManager::__put{package 
NXHostsManager;no warnings;(my (@fields)=@_);NXRedis::sendToDb (((((((((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$fields[(0x1564+ 3957-0x24d9)]).
"\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x69\x65\x6e\x74\x2c\x76\x61\x6c\x75\x65\x3d"
).$fields[(0x0372+ 8210-0x2384)]).
"\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x64\x69\x72\x65\x63\x74\x2c\x76\x61\x6c\x75\x65\x3d"
).$fields[(0x0499+ 8720-0x26a8)])."\x3a").$fields[(0x080b+ 429-0x09b6)]).
"\x2c\x66\x69\x65\x6c\x64\x3d\x61\x75\x74\x68\x2c\x76\x61\x6c\x75\x65\x3d").
$fields[(0x10da+ 2168-0x194f)])."\x0a"));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x61\x64\x64\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2c\x76\x61\x6c\x75\x65\x3d"
.$fields[(0x1f22+   2-0x1f24)])."\x0a"));return ((0x0724+ 2367-0x1062));}sub 
NXHostsManager::__del{package NXHostsManager;no warnings;(my $clientIpToDelete=
shift (@_));if (checkClientRedirectExist ($clientIpToDelete)){NXRedis::sendToDb 
(((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x72\x65\x6d\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2c\x76\x61\x6c\x75\x65\x3d"
.$clientIpToDelete)."\x0a"));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x64\x65\x6c\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$clientIpToDelete)."\x0a"));return ((0x1bb0+ 1285-0x20b4));}else{return (
(0x0c8d+ 6772-0x2701));}}sub NXHostsManager::__list{package NXHostsManager;no 
warnings;(my $clientIpToFind=shift (@_));(my (@hosts)=());if ($clientIpToFind){
NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$clientIpToFind).
"\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x69\x65\x6e\x74\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x64\x69\x72\x65\x63\x74\x2c\x66\x69\x65\x6c\x64\x3d\x61\x75\x74\x68\x0a"
));(my $line=NXRedis::get ());($line=~ s/ /,/g );push (@hosts,$line);}else{
NXRedis::sendToDb (
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x6d\x65\x6d\x62\x65\x72\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x0a"
);(my (@hostList)=split ( / / ,NXRedis::get (),(0x06d3+ 1207-0x0b8a)));foreach 
$host (@hostList){NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x6d\x67\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$host).
"\x2c\x66\x69\x65\x6c\x64\x3d\x63\x6c\x69\x65\x6e\x74\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x64\x69\x72\x65\x63\x74\x2c\x66\x69\x65\x6c\x64\x3d\x61\x75\x74\x68\x0a"
));(my $line=NXRedis::get ());($line=~ s/ /,/g );push (@hosts,$line);}}return (
@hosts);}sub NXHostsManager::__edit{package NXHostsManager;no warnings;(my $client
=shift (@_));(my $host=shift (@_));(my $port=shift (@_));(my $switch=shift (@_))
;if (checkClientRedirectExist ($client)){if ((defined ($host)and defined ($port)
)){NXRedis::sendToDbAndSave (((((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$client).
"\x2c\x66\x69\x65\x6c\x64\x3d\x72\x65\x64\x69\x72\x65\x63\x74\x2c\x76\x61\x6c\x75\x65\x3d"
).$host)."\x3a").$port)."\x0a"));}if (defined ($switch)){
NXRedis::sendToDbAndSave (((((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x68\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$client).
"\x2c\x66\x69\x65\x6c\x64\x3d\x61\x75\x74\x68\x2c\x76\x61\x6c\x75\x65\x3d").
$switch)."\x0a"));}}NXMsg::send_response (
"\x69\x48\x6f\x73\x74\x45\x64\x69\x74\x65\x64",
"\x4e\x58\x48\x6f\x73\x74\x73\x4d\x61\x6e\x61\x67\x65\x72",$client);return (
(0x0c27+ 4759-0x1ebd));}sub NXHostsManager::checkClientRedirectExist{package 
NXHostsManager;no warnings;(my $client=shift (@_));NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x65\x78\x69\x73\x74\x73\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x68\x6f\x73\x74\x73\x2e"
.$client)."\x0a"));(my $result=NXRedis::get ());if (($result==
(0x196b+ 1094-0x1db0))){Logger::debug ((("\x48\x6f\x73\x74\x3a\x20\x27".$client)
."\x27\x20\x65\x78\x69\x73\x74\x73\x2e"));}return ($result);}sub 
NXHostsManager::getClientRedirectBeforeAuth{package NXHostsManager;no warnings;(my $client
=shift (@_));return (__getClientRedirect ($client,(0x1438+ 1184-0x18d7)));}sub 
NXHostsManager::getClientRedirectAfterAuth{package NXHostsManager;no warnings;(my $client
=shift (@_));return (__getClientRedirect ($client,(0x09f7+ 1987-0x11ba)));}sub 
NXHostsManager::__getClientRedirect{package NXHostsManager;no warnings;(my $client
=shift (@_));(my $authbeforelogin=shift (@_));my (@hostTab);my (@ipTab);(my $all
=(0x0592+ 3439-0x1301));if (NXLicense::isNotRedirectFeature ()){return (
(0x1511+ 3898-0x244b));}(my (@hostlist)=__list ());foreach my $hostline (
@hostlist){($hostline=~ s/\n//g );(my (@line)=split ( /,/ ,$hostline,
(0x11d1+ 1395-0x1744)));if ((($line[(0x0fe8+ 1749-0x16bd)]eq "\x2a")or ($line[
(0x02bd+ 9197-0x26aa)]eq "\x2a\x2e\x2a\x2e\x2a\x2e\x2a"))){if (((
$authbeforelogin and ($line[(0x1e51+ 588-0x209b)]eq "\x62\x65\x66\x6f\x72\x65"))
or ((not ($authbeforelogin))and ($line[(0x0088+ 1698-0x0728)]eq 
"\x61\x66\x74\x65\x72")))){($all=$line[(0x036a+ 3795-0x123c)]);}}elsif (($line[
(0x0ba0+ 3315-0x1893)]=~ /^[0-9\*\.]{1,15}$/ )){if ((($authbeforelogin and (
$line[(0x0661+ 6055-0x1e06)]eq "\x62\x65\x66\x6f\x72\x65"))or ((not (
$authbeforelogin))and ($line[(0x073a+ 5512-0x1cc0)]eq "\x61\x66\x74\x65\x72"))))
{push (@ipTab,[$line[(0x0a29+ 2598-0x144f)],$line[(0x16a8+ 382-0x1825)],$line[
(0x0c8f+ 1720-0x1345)]]);}}else{if ((($authbeforelogin and ($line[
(0x0c8b+ 5750-0x22ff)]eq "\x62\x65\x66\x6f\x72\x65"))or ((not ($authbeforelogin)
)and ($line[(0x1b30+ 475-0x1d09)]eq "\x61\x66\x74\x65\x72")))){push (@hostTab,[
$line[(0x04f3+ 198-0x05b9)],$line[(0x0acc+ 341-0x0c20)],$line[
(0x1bc4+ 1470-0x2180)]]);}}}(my $regEx=(""));foreach my $ipLine (@ipTab){(my (
@pieces)=split ( /\./ ,@{$ipLine;}[(0x02f8+ 1397-0x086d)],(-(0x0ab1+ 271-0x0bbf)
)));(my $piecesCount=scalar (@pieces));($regEx=@{$ipLine;}[(0x0a12+ 3450-0x178c)
]);if (($piecesCount<(0x15c0+ 3712-0x243c))){if (($pieces[(0x175c+ 1960-0x1f04)]
=~ /^\*/ )){($regEx=("\x2e\x7b\x30\x2c\x7d".$regEx));}if (($pieces[$piecesCount-
(0x2019+ 1701-0x26bd)]=~ /\*$/ )){($regEx.="\x2e\x7b\x30\x2c\x7d");}}($regEx=~ s/\*/(|[0-9]|[0-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])/g )
;if (($client=~ /^($regEx)$/ )){return (@{$ipLine;}[(0x0857+ 3292-0x1532)]);}}
foreach my $hostLine (@hostTab){(my (@ipdata)=split ( /\./ ,$client,
(0x0376+ 7617-0x2137)));(my $ippacked=pack ("\x43\x34",@ipdata));(my $host=
gethostbyaddr ($ippacked,(0x0560+ 1450-0x0b08)));if ((@{$hostLine;}[
(0x05a7+ 1372-0x0b03)]=~ /^\*/ )){(@{$hostLine;}[(0x18b7+ 2075-0x20d2)]=~ s/^\*// )
;}else{(@{$hostLine;}[(0x1a41+ 788-0x1d55)]=("\x5e".@{$hostLine;}[
(0x199c+ 1468-0x1f58)]));}if ((@{$hostLine;}[(0x0659+ 4430-0x17a7)]=~ /\*$/ )){(
@{$hostLine;}[(0x072c+ 7762-0x257e)]=~ s/\*$// );}else{(@{$hostLine;}[
(0x1717+ 3232-0x23b7)]=(@{$hostLine;}[(0x103c+ 1182-0x14da)]."\x24"));}if ((
$host=~ @{$hostLine;}[0] )){return (@{$hostLine;}[(0x007a+ 4200-0x10e1)]);}}if (
$all){return ($all);}Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x62\x65\x20\x66\x6f\x75\x6e\x64\x20\x63\x6c\x69\x65\x6e\x74\x20\x49\x50\x3a\x20\x27"
.$client)."\x27\x20\x69\x6e\x20\x68\x6f\x73\x74\x73\x2e\x64\x62\x2e"));return (
(0x0417+ 3263-0x10d6));}package NXHostsManager;no warnings;
NXMsg::register_response (
"\x4e\x58\x48\x6f\x73\x74\x73\x4d\x61\x6e\x61\x67\x65\x72",
"\x69\x48\x6f\x73\x74\x45\x64\x69\x74\x65\x64",(0x1fe0+ 851-0x22a4));
"\x3f\x3f\x3f";
