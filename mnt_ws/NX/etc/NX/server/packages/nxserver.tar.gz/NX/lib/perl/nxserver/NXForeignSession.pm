############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXForeignSession::BEGIN{package NXForeignSession;no warnings;require Error;
do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}package 
NXForeignSession;no warnings;($maximumRestartCounterForFailedSession=
(0x1c39+ 687-0x1ee4));($sessionIsForeignAttach=(0x050c+ 2680-0x0f84));(
$lastCheckForeignNodes=(0x07fc+ 7055-0x238b));sub createSessionFile{(my $refParameters
=shift (@_));(my $node=shift (@_));($$refParameters{
"\x6e\x6f\x64\x65\x48\x6f\x73\x74"}=$$node->getHost);($$refParameters{
"\x6e\x6f\x64\x65\x50\x6f\x72\x74"}=$$node->getPort);($$refParameters{
"\x6e\x6f\x64\x65\x55\x55\x49\x44"}=$$node->getUuid);($$refParameters{
"\x70\x6f\x72\x74"}=NXServerDaemon::getPort ());if (((not (defined (
$$refParameters{"\x70\x6f\x72\x74"})))or ($$refParameters{"\x70\x6f\x72\x74"}==(
-(0x0118+ 8350-0x21b5))))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x73\x73\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x70\x6f\x72\x74\x20\x77\x68\x65\x6e\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x6f\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);main::nxexit ();}Logger::debug (((((
"\x43\x72\x65\x61\x74\x69\x6e\x67\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$$refParameters{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}).
"\x20\x77\x69\x74\x68\x20\x70\x6f\x72\x74\x20").$$refParameters{
"\x70\x6f\x72\x74"})."\x2e"));($$refParameters{"\x63\x6f\x6f\x6b\x69\x65"}=
NXServerDaemon::getCookie ());if (($$refParameters{"\x63\x6f\x6f\x6b\x69\x65"}eq
 (""))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x63\x65\x73\x73\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x63\x6f\x6f\x6b\x69\x65\x20\x77\x68\x65\x6e\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x6f\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);main::nxexit ();}($$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x4e\x61\x6d\x65"}=
"\x46\x6f\x72\x65\x69\x67\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e");($$refParameters
{"\x75\x73\x65\x72\x4e\x61\x6d\x65"}=NXNodes::getForeignUserName ($$node->
getUuid));($$refParameters{"\x73\x74\x61\x74\x75\x73"}=
NXSession2::getStatusNotActive ());($$refParameters{
"\x63\x72\x65\x61\x74\x69\x6f\x6e\x54\x69\x6d\x65"}=time);return (
NXSession2::createForeignSession ($refParameters));}sub startForeignNodeProcess{
(my $foreignNodeHost=shift (@_));(my $foreignNodePort=shift (@_));(my $foreignNodeUuid
=shift (@_));if (foreignNodesNotAvailable ()){Logger::warning (((((
"\x46\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x20".$foreignNodeHost)."\x3a")
.$foreignNodePort).
"\x20\x69\x73\x20\x70\x72\x65\x73\x65\x6e\x74\x20\x69\x6e\x20\x6e\x6f\x64\x65\x73\x2e\x64\x62\x2c\x20\x62\x75\x74\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x73\x20\x61\x72\x65\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x2e"
));return ((0x0b6f+ 3174-0x17d5));}Logger::debug (((((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20"
.$foreignNodeHost)."\x3a").$foreignNodePort)."\x2e"));if (
NXNodes::nodeDoesntExist (NXNodes::getUuid ($foreignNodeHost,$foreignNodePort)))
{Logger::debug (((((
"\x53\x6b\x69\x70\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x20"
.$foreignNodeHost)."\x3a").$foreignNodePort).
"\x3a\x20\x6e\x6f\x64\x65\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x20\x69\x6e\x20\x64\x61\x74\x61\x62\x61\x73\x65\x2e"
));return ((0x03e1+ 4552-0x15a9));}if (
NXLocalSession::isForeignSessionAlreadyRuning ($foreignNodeHost,$foreignNodePort
)){Logger::debug (((((
"\x53\x6b\x69\x70\x20\x73\x74\x61\x72\x74\x69\x6e\x67\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x20"
.$foreignNodeHost)."\x3a").$foreignNodePort).
"\x3a\x20\x6e\x6f\x64\x65\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
));return ((0x0395+ 3683-0x11f8));}initializeCheckForeignNodes ();(my $node=
NXLocalSessionNode::createForeign ($foreignNodeHost,$foreignNodePort,
$foreignNodeUuid));(my $sessionId=$node->getSessionId);
NXLocalSession::addLocalNode ($node,$sessionId);(my $parameters=$node->
getForeignParametersString);(my ($uuid,$host,$port)=NXNodes::findLocalNode ());(my $userName
="\x6e\x78");Server::setInheritConnectionDescriptor ("\x6e\x6f");$node->
setShellMode;NXNodes::setStatusNegotiating ($foreignNodeUuid);eval{(my (
$nodeOutput,$pid)=NXNodeExec::askNode (
"\x67\x65\x74\x46\x6f\x72\x65\x69\x67\x6e\x43\x6f\x6f\x6b\x69\x65",$parameters,
$uuid,$userName,NXNodeExec::getPublicKeyAuthMethod ()));};if (($@or ($@ne ("")))
){Logger::error ((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x2e\x20"
.$@));return ((0x0f17+ 1897-0x167f));}$node->setNodeStartedByDaemon;$node->
setRunning;(my $stdin=NXNodeExec::getstdin ());(my $stdout=NXNodeExec::getstdout
 ());$node->setStdin ($stdin);$node->setStdout ($stdout);
NXLocalSession::assignSocketToNode ($stdin,$node);
NXLocalSession::assignSocketToNode ($stdout,$node);
NXServerDaemon::addAcceptedFdToSystemSelector ($stdout);
NXServerDaemon::authorizeConnectionOnFD ($stdout);
NXConnectionMonitor::propagateMap ();}sub __setParametersFromMessage{(my $refParameters
=shift (@_));(my $message=shift (@_));if (($message=~ /Retrieved cookie=(.*) display=(.*) for foreign session=(.*) / )
){($$refParameters{"\x6c\x6f\x63\x61\x6c\x43\x6f\x6f\x6b\x69\x65"}=$1);(
$$refParameters{"\x64\x69\x73\x70\x6c\x61\x79"}=$2);($$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}=$3);}else{return ((0x1e29+ 1546-0x2433))
;}($$refParameters{"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"}=
Common::NXSessionType::getForeignDesktop ());return ((0x0593+ 3033-0x116b));}sub
 __setNodeParameters{(my $refParameters=shift (@_));(my $refNode=shift (@_));(my $socket
=shift (@_));(my $sessionParameters=(""));$$refNode->setSocket ($socket);
$$refNode->setCookie ($$refParameters{
"\x6c\x6f\x63\x61\x6c\x43\x6f\x6f\x6b\x69\x65"});$$refNode->setDisplay (
$$refParameters{"\x64\x69\x73\x70\x6c\x61\x79"});$$refNode->setSessionId (
$$refParameters{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"});$$refNode->
setParameters ($sessionParameters);$$refNode->setRestartCounter (
$maximumRestartCounterForFailedSession);}sub 
__createMessageStringForStartLocalSession{(my $refParameters=shift (@_));(my $refNode
=shift (@_));(my $foreignNodeHost=$$refNode->getHost);(my $foreignNodePort=
$$refNode->getPort);(my $login=$$$refNode{
"\x66\x6f\x72\x65\x69\x67\x6e\x55\x73\x65\x72\x4e\x61\x6d\x65"});(my $service=
"\x73\x74\x61\x72\x74\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");(my $parameters
=(("\x6c\x6f\x63\x61\x6c\x5f\x64\x69\x73\x70\x6c\x61\x79\x3d".$$refNode->getHost
).("\x3a".$$refParameters{"\x64\x69\x73\x70\x6c\x61\x79"})));($parameters.=(
"\x26\x6c\x6f\x63\x61\x6c\x43\x6f\x6f\x6b\x69\x65\x3d".$$refParameters{
"\x6c\x6f\x63\x61\x6c\x43\x6f\x6f\x6b\x69\x65"}));($parameters.=(
"\x26\x73\x65\x73\x73\x69\x6f\x6e\x49\x64\x3d".$$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}));($parameters.=(
"\x26\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x3d".$$refParameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"}));($parameters.=
"\x26\x73\x65\x73\x73\x69\x6f\x6e\x50\x69\x64\x3d\x31");($parameters.=(
"\x26\x70\x72\x69\x6f\x72\x69\x74\x79\x3d".
main::getNodePriorityBasedOnSessionType (
Common::NXSessionType::getPhysicalDesktop ())));($parameters.=
"\x26\x4e\x58\x57\x6d\x52\x75\x6e\x6e\x69\x6e\x67\x3d\x31");(my $msg=(($service.
"\x0a").$parameters));}sub handleCookieAndDisplayRetrieved{(my $socket=shift (@_
));(my $message=shift (@_));Logger::debug (((((
"\x68\x61\x6e\x64\x6c\x65\x43\x6f\x6f\x6b\x69\x65\x41\x6e\x64\x44\x69\x73\x70\x6c\x61\x79\x52\x65\x74\x72\x69\x65\x76\x65\x64\x20\x66\x6f\x72\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$message).
"\x27\x20\x72\x65\x74\x72\x65\x69\x76\x65\x64\x20\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x20\x46\x44\x23"
).$socket)."\x2e"));my (%parameters);if (__setParametersFromMessage ((
\%parameters),$message)){Logger::debug (
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x73\x65\x74\x20\x66\x6f\x72\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x2e"
);}else{Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x68\x61\x6e\x64\x6c\x65\x20\x63\x6f\x6f\x6b\x69\x65\x20\x61\x6e\x64\x20\x64\x69\x70\x6c\x61\x79\x20\x66\x6f\x72\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x2e\x20\x42\x61\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x72\x65\x63\x65\x69\x76\x65\x64\x2e"
);return;}(my $node=NXLocalSession::getNodeBySessionID ($parameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}));if ((not (defined ($node)))){
Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x68\x61\x6e\x64\x6c\x65\x20\x63\x6f\x6f\x6b\x69\x65\x20\x61\x6e\x64\x20\x64\x69\x73\x70\x6c\x61\x79\x20\x66\x6f\x72\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x2e\x20\x4e\x6f\x64\x65\x20\x66\x6f\x72\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
.$session{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}).
"\x20\x77\x61\x73\x20\x6e\x6f\x74\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x2e"
));return;}__setNodeParameters ((\%parameters),(\$node),$socket);
createSessionFile ((\%parameters),(\$node));NXLocalSession::addLocalNode ($node,
$parameters{"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"},$parameters{
"\x64\x69\x73\x70\x6c\x61\x79"},$socket);NXNodeExec::setNodeAsMaster ();(my $msg
=__createMessageStringForStartLocalSession ((\%parameters),(\$node)));(my $bytes
=NXNodeExec::sendToNodeBySessionId ($msg,$parameters{
"\x73\x65\x73\x73\x69\x6f\x6e\x49\x64"}));$node->setShellModeFinished;if ((
$bytes==(-(0x0246+ 5487-0x17b4)))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x2e"
);return;}$node->setRunning;}sub isSessionForeign{(my $sesionId=shift (@_));if (
foreignNodesAvailable ()){(my $sessionType=NXSession2::getTypeBySessionId (
$sesionId));if (($sessionType eq (""))){return ((0x0579+ 7931-0x2474));}if (
Common::NXSessionType::isForeignMaster ($sessionType)){return (
(0x03d7+ 306-0x0508));}}return ((0x1daf+ 1909-0x2524));}sub 
setSessionIsForeignAttach{($sessionIsForeignAttach=(0x06e6+ 234-0x07cf));}sub 
isSessionForeignAttach{return ($sessionIsForeignAttach);}sub 
foreignNodesAvailable{if (NXLicense::isNotMultiServerFeature ()){return (
(0x00a1+ 5807-0x1750));}if ((not (isForeignDesktopAvailableInConfig ()))){return
 ((0x0b7a+ 1111-0x0fd1));}return ((0x0707+ 5787-0x1da1));}sub 
foreignNodesNotAvailable{return ((!foreignNodesAvailable ()));}sub 
setIsForeignDesktopAvailableInConfig{Logger::debug (((
"\x53\x65\x72\x76\x65\x72\x20\x63\x6f\x6e\x66\x69\x67\x20\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x73\x3a\x20"
.$GLOBAL::AvailableSessionTypes)."\x2e"));(my (@availableSessionsTypeArray)=
split ( /,/ ,$GLOBAL::AvailableSessionTypes,(0x1367+ 3358-0x2085)));foreach my $sessionType
 (@availableSessionsTypeArray){if (Common::NXSessionType::isForeignDesktop (
Common::NXSessionType::convertToInternal ($sessionType))){(
$foreignDesktopAvailableInConfig=(0x0f9d+ 1727-0x165b));return;}}(
$foreignDesktopAvailableInConfig=(0x246f+ 132-0x24f3));}sub 
isForeignDesktopAvailableInConfig{if ((not (defined (
$foreignDesktopAvailableInConfig)))){setIsForeignDesktopAvailableInConfig ();}
return ($foreignDesktopAvailableInConfig);}sub initializeCheckForeignNodes{if ((
$lastCheckForeignNodes==(0x0a01+ 1346-0x0f43))){($lastCheckForeignNodes=
Common::NXTime::getSecondsSinceEpoch ());}}sub getForeignNodesCheckDelay{return 
($GLOBAL::foreignNodesCheckDelay);}sub isTimeForCheckForeignNodes{if ((
foreignNodesAvailable ()==(0x01a6+ 3219-0x0e39))){return ((0x0506+ 5994-0x1c70))
;}(my $currentTime=Common::NXTime::getSecondsSinceEpoch ());(my $delay=
getForeignNodesCheckDelay ());if ((($lastCheckForeignNodes+$delay)<$currentTime)
){($lastCheckForeignNodes=$currentTime);return ((0x16af+ 983-0x1a85));}return (
(0x0301+ 453-0x04c6));}sub checkForeignNodes{(my (@foreignNodes)=
NXNodes::getForeignNodes ());if ((scalar (@foreignNodes)==(0x13cc+ 554-0x15f6)))
{return ((0x0365+ 868-0x06c9));}(my $ref_workingForeignSessions=
NXLocalSession::getWorkingForeigNodeHash ());foreach my $node (@foreignNodes){if
 (($$ref_workingForeignSessions{$$node{"\x6e\x61\x6d\x65"}}ne (""))){
Logger::debug ((((("\x4e\x6f\x64\x65\x20".$$node{"\x6e\x61\x6d\x65"}).
"\x20\x69\x73\x20\x77\x6f\x72\x6b\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x73\x65\x73\x73\x69\x6f\x6e\x20"
).$$ref_workingForeignSessions{$$node{"\x6e\x61\x6d\x65"}})."\x2e"));}else{
startForeignNodeProcess ($$node{"\x68\x6f\x73\x74"},$$node{"\x70\x6f\x72\x74"},
$$node{"\x75\x75\x69\x64"});}}}return ((0x052c+ 4794-0x17e5));
