############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXTools::BEGIN{package NXTools;no warnings;require Error;do{
"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub NXTools::__getTimeMs{
package NXTools;no warnings;(my ($sec,$microsec)=
Common::NXTime::getSecondsAndMicrosecondsSinceEpoch ());(my (@time)=
Common::NXTime::getLocalTimeFromTimestamp ($sec));(my $milisec=sprintf (
"\x25\x30\x36\x64",$microsec));($milisec=(substr ($milisec,(0x02ec+ 698-0x05a6),
(0x003d+ 3538-0x0e0c)).substr ($milisec,(0x0b9b+ 5952-0x22d8))));return (
$milisec,@time);}sub NXTools::getTimeMs{package NXTools;no warnings;(my (
$milisec,@time)=__getTimeMs ());(my $TimeMs=((((sprintf ("\x25\x30\x32\x64",
$time[(0x05f0+ 4923-0x1929)]).sprintf ("\x25\x30\x32\x64",$time[
(0x00f0+ 5406-0x160d)])).sprintf ("\x25\x30\x32\x64",$time[(0x0ad9+ 3897-0x1a12)
]))."\x2e").sprintf ($milisec)));return ($TimeMs);}sub NXTools::getTimestamp{
package NXTools;no warnings;(my ($milisec,@time)=__getTimeMs ());($milisec=((
substr ($milisec,(0x1441+  52-0x1475),(0x0012+ 4138-0x1039))."\x2e").substr (
$milisec,(0x0080+ 6234-0x18d7))));(my $Timestamp=(sprintf (
"\x25\x30\x34\x64\x2d\x25\x30\x32\x64\x2d\x25\x30\x32\x64\x20\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x3a\x25\x30\x32\x64\x20"
,((0x1ab6+ 2013-0x1b27)+$time[(0x13ea+ 810-0x170f)]),((0x1489+ 4275-0x253b)+
$time[(0x0881+ 4258-0x191f)]),$time[(0x0f9a+ 3167-0x1bf6)],$time[
(0x1f4b+ 1582-0x2577)],$time[(0x11d7+  57-0x120f)],$time[(0x1152+ 4147-0x2185)])
.$milisec));return ($Timestamp);}sub NXTools::getTimestampOnlyMicroseconds{
package NXTools;no warnings;(my ($milisec,@time)=__getTimeMs ());($milisec=((
substr ($milisec,(0x1802+ 1534-0x1e00),(0x01fb+ 4220-0x1274))."\x2e").substr (
$milisec,(0x00d9+ 8415-0x21b5))));(my $Timestamp=sprintf ($milisec));return (
$Timestamp);}sub NXTools::getSharedLibraryExtension{package NXTools;no warnings;my (
$extension);($extension="\x2e\x73\x6f");return ($extension);}sub 
NXTools::cleanLdLibraryPath{package NXTools;no warnings;(my $libnx=(
"\x6c\x69\x62\x6e\x78".getSharedLibraryExtension ()));(my $ldLibraryPath=
libnxh::NXTransGetEnvironment (
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48"));(my (@elements)
=split ( /:/ ,$ldLibraryPath,(0x0595+ 3177-0x11fe)));my (@newLdLibraryPathArray)
;foreach my $element (@elements){(my $testLibry=(($element.
$GLOBAL::DIRECTORY_SLASH).$libnx));if ((Common::NXFile::isExists ($testLibry)or 
(not (-d ($element))))){next;}push (@newLdLibraryPathArray,$element);}(
$ldLibraryPath=join ("\x3a",@newLdLibraryPathArray));
libnxh::NXTransSetEnvironment (
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48",$ldLibraryPath);}
sub NXTools::getWindowsSystemPath{package NXTools;no warnings;(my $systemPath=
(""));(my $envSystemDirectory=libnxh::NXTransGetEnvironment (
"\x53\x79\x73\x74\x65\x6d\x44\x69\x72\x65\x63\x74\x6f\x72\x79"));(my $envWinDir=
libnxh::NXTransGetEnvironment ("\x57\x69\x6e\x44\x69\x72"));(my $envSystemRoot=
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74"));(my $envSystemDrive
=libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x44\x72\x69\x76\x65"))
;(my $envHOMEDRIVE=libnxh::NXTransGetEnvironment (
"\x48\x4f\x4d\x45\x44\x52\x49\x56\x45"));if (((undef ne $envSystemDirectory)and 
(length ($envSystemDirectory)>(0x0821+ 6882-0x2303)))){($systemPath=
$envSystemDirectory);}elsif (((undef ne $envWinDir)and (length ($envWinDir)>
(0x0608+ 401-0x0799)))){($systemPath=(($envWinDir.$GLOBAL::DIRECTORY_SLASH).
"\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif (((undef ne $envSystemRoot)and (
length ($envSystemRoot)>(0x0606+ 5283-0x1aa9)))){($systemPath=(($envSystemRoot.
$GLOBAL::DIRECTORY_SLASH)."\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif (((undef 
ne $envSystemDrive)and (length ($envSystemDrive)>(0x044c+ 8788-0x26a0)))){(
$systemPath=(((($envSystemDrive.$GLOBAL::DIRECTORY_SLASH).
"\x57\x69\x6e\x64\x6f\x77\x73").$GLOBAL::DIRECTORY_SLASH).
"\x53\x79\x73\x74\x65\x6d\x33\x32"));}elsif (((undef ne $envHOMEDRIVE)and (
length ($envHOMEDRIVE)>(0x1c50+ 841-0x1f99)))){($systemPath=(((($envHOMEDRIVE.
$GLOBAL::DIRECTORY_SLASH)."\x57\x69\x6e\x64\x6f\x77\x73").
$GLOBAL::DIRECTORY_SLASH)."\x53\x79\x73\x74\x65\x6d\x33\x32"));}else{
Logger::warning (
"\x67\x65\x74\x57\x69\x6e\x64\x6f\x77\x73\x53\x79\x73\x74\x65\x6d\x50\x61\x74\x68\x28\x29\x3a\x20\x75\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x73\x65\x74\x20\x70\x61\x74\x68"
);return ((""));}Logger::debug (((
"\x67\x65\x74\x57\x69\x6e\x64\x6f\x77\x73\x53\x79\x73\x74\x65\x6d\x50\x61\x74\x68\x28\x29\x3a\x20\x73\x65\x74\x20\x70\x61\x74\x68\x20\x74\x6f\x20\x5b"
.$systemPath)."\x5d"));return ($systemPath);}sub NXTools::getUnixCommandPath{
package NXTools;no warnings;(my $command=shift (@_));if (-x ((
"\x2f\x62\x69\x6e\x2f".$command))){return (("\x2f\x62\x69\x6e\x2f".$command));}
elsif (-x (("\x2f\x73\x62\x69\x6e\x2f".$command))){return ((
"\x2f\x73\x62\x69\x6e\x2f".$command));}elsif (-x ((
"\x2f\x75\x73\x72\x2f\x62\x69\x6e\x2f".$command))){return ((
"\x2f\x75\x73\x72\x2f\x62\x69\x6e\x2f".$command));}elsif (-x ((
"\x2f\x75\x73\x72\x2f\x6c\x6f\x63\x61\x6c\x2f\x62\x69\x6e\x2f".$command))){
return (("\x2f\x75\x73\x72\x2f\x6c\x6f\x63\x61\x6c\x2f\x62\x69\x6e\x2f".$command
));}elsif (-x (("\x2f\x75\x73\x72\x2f\x73\x62\x69\x6e\x2f".$command))){return ((
"\x2f\x75\x73\x72\x2f\x73\x62\x69\x6e\x2f".$command));}return ($command);}sub 
NXTools::getCommandUserAppPid{package NXTools;no warnings;(my $user=shift (@_));
(my (@command)=());(@command=($GLOBAL::COMMAND_PS,"\x2d\x55",$user,"\x2d\x75",
$user,"\x68","\x2d\x6f","\x70\x69\x64\x2c\x61\x72\x67\x73"));return (@command);}
sub NXTools::getUserAppPid{package NXTools;no warnings;(my $user=shift (@_));(my $app
=shift (@_));if (((((not (defined ($user)))or ($user eq ("")))or (not (defined (
$app))))or ($app eq ("")))){Logger::debug (((((
"\x57\x72\x6f\x6e\x67\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x73\x20\x70\x72\x6f\x76\x69\x64\x65\x64\x3a\x20\x75\x73\x65\x72\x5b"
.$user)."\x5d\x2c\x20\x61\x70\x70\x5b").$app)."\x5d\x2e"));return (
(0x09a5+ 4777-0x1c4e));}(my (@command)=getCommandUserAppPid ($user));(my (
@parameters)=());(my ($cmd_err,$cmd_out,$exit_value)=main::run_command ((
\@command),(\@parameters)));if ($exit_value){Logger::debug (((
"\x45\x72\x72\x6f\x72\x20\x72\x65\x74\x72\x69\x65\x76\x69\x6e\x67\x20\x74\x68\x65\x20\x6c\x69\x73\x74\x20\x6f\x66\x20\x70\x72\x6f\x63\x65\x73\x73\x65\x73\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x3a\x20"
.$user)."\x2e"));return ((0x15fd+ 3760-0x24ad));}(my (@userProcesses)=split ( /\n/ ,
$cmd_out,(0x0d39+ 5542-0x22df)));foreach my $item (@userProcesses){($item=~ s/ start$// )
;($item=~ /(\d+) (.*)/ );(my $val1=$1);(my $val2=$2);if ((($app eq $val2)or ((
$app."\x20\x73\x74\x61\x72\x74")eq $val2))){return ($val1);}if ((($app eq $2)or 
(($app."\x20\x73\x74\x61\x72\x74")eq $2))){return ($1);}}return (
(0x0f55+ 5696-0x2595));}sub NXTools::__getFromNxhtdCfg{package NXTools;no 
warnings;(my $ref_keys=shift (@_));unless (defined ($GLOBAL::configFileNXHtd)){(
$GLOBAL::configFileNXHtd=(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x65\x74\x63").$GLOBAL::DIRECTORY_SLASH)."\x77\x65\x62\x2e\x63\x66\x67"));}(my $FH
=main::nxopen ($GLOBAL::configFileNXHtd,$NXBits::O_RDONLY,(0x0921+ 6587-0x22dc))
);if ((not (defined ($FH)))){if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27".
$GLOBAL::configFileNXHtd)."\x27\x2e"));Logger::warning (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".$errorNumber)."\x27\x2c\x20\x27").
$errorstring)."\x27\x2e"));}return ((0x0744+ 8026-0x269e));}(my $line=(""));
while (main::nxreadLine ($FH,(\$line))){chomp ($line);($line=~ s/^ *// );($line
=~ s/ *$// );foreach my $key (keys (%$ref_keys)){if (((($key eq 
"\x4c\x69\x73\x74\x65\x6e")and ($line=~ /^Listen.+:(\d+)\s+https/i ))or ($line=~ /^Listen\s+(\d+)\s+https/i )
)){(my $nxhtdPort=$1);if (($nxhtdPort ne (""))){if (($nxhtdPort=~ /:/ )){(
$nxhtdPort=(split ( /:/ ,$nxhtdPort,(0x1125+ 1548-0x1731)))[(0x1f68+ 526-0x2175)
]);}if ((($nxhtdPort>=(0x003f+  43-0x0069))and ($nxhtdPort<=65535))){($$ref_keys
{$key}=$nxhtdPort);}else{Logger::debug ((("\x50\x6f\x72\x74\x3a\x20".$nxhtdPort)
."\x20\x69\x73\x20\x6e\x6f\x74\x20\x76\x61\x6c\x69\x64\x2e"));}}}elsif (($key eq
 "\x43\x75\x73\x74\x6f\x6d\x4c\x6f\x67")){if (($line=~ /^CustomLog ("|)([^ "]*)("|) common$/ )
){($$ref_keys{$key}=$2);}}elsif (($line=~ /^$key ("|)([^"]*)("|)$/ )){(
$$ref_keys{$key}=$2);}}}main::nxclose ($FH);return ((0x0290+ 7926-0x2185));}sub 
NXTools::getNxhtdErrorLogPath{package NXTools;no warnings;(my $cfgKey=
"\x45\x72\x72\x6f\x72\x4c\x6f\x67");(my $result=__getNxhtdLogFilePath ($cfgKey))
;if (($result eq (""))){return (NXPaths::getDefaultNxhtdErrorLog ());}return (
$result);}sub NXTools::getNxhtdAccessLogPath{package NXTools;no warnings;(my $cfgKey
="\x43\x75\x73\x74\x6f\x6d\x4c\x6f\x67");(my $result=__getNxhtdLogFilePath (
$cfgKey));if (($result eq (""))){return (NXPaths::getDefaultNxhtdErrorLog ());}
return ($result);}sub NXTools::__getNxhtdLogFilePath{package NXTools;no warnings
;(my $key=shift (@_));(my (%keys)=());($keys{$key}=(""));($keys{
"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}=(""));(my $result=__getFromNxhtdCfg 
((\%keys)));if (($result==(0x16e4+ 944-0x1a94))){return ((""));}if (($keys{$key}
=~ /^\// )){return ($keys{$key});}else{if (($keys{$key}ne (""))){return ((($keys
{"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}.$GLOBAL::DIRECTORY_SLASH).$keys{
$key}));}else{return ((""));}}}sub NXTools::getNXHtdUser{package NXTools;no 
warnings;(my (%keys)=());($keys{"\x55\x73\x65\x72"}="\x6e\x78\x68\x74\x64");(
$keys{"\x47\x72\x6f\x75\x70"}="\x6e\x78\x68\x74\x64");__getFromNxhtdCfg ((\%keys
));return ($keys{"\x55\x73\x65\x72"},$keys{"\x47\x72\x6f\x75\x70"});}sub 
NXTools::getNXHtdPort{package NXTools;no warnings;(my (%keys)=());($keys{
"\x4c\x69\x73\x74\x65\x6e"}="\x34\x34\x34\x33");__getFromNxhtdCfg ((\%keys));
return ($keys{"\x4c\x69\x73\x74\x65\x6e"});}sub NXTools::getNXExecCommand{
package NXTools;no warnings;return ((((($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x62\x69\x6e").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x65\x78\x65\x63"));}sub NXTools::getNXNodeCommand{package NXTools;no 
warnings;return ($GLOBAL::CommandNXNode);}sub NXTools::getNXSshCommand{package 
NXTools;no warnings;return ($GLOBAL::SSHClient);}sub 
NXTools::findFreePortAndOpen{package NXTools;no warnings;(my $from=shift (@_));(my $silent
=(shift (@_)||(0x1081+ 5315-0x2544)));(my $to=(shift (@_)||($from+
$GLOBAL::ServerSlaveLimit)));Logger::debug (((((((
"\x4e\x58\x54\x6f\x6f\x6c\x73\x3a\x20\x46\x69\x6e\x64\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x20\x66\x72\x6f\x6d\x20\x27"
.$from)."\x27\x20\x74\x6f\x20\x27").$to).
"\x27\x20\x73\x69\x6c\x65\x6e\x74\x20\x27").$silent)."\x27\x2e"));(my $i=$from);
(my $port=(0x1b1f+ 1105-0x1f70));(my $handler=(0x009f+ 1848-0x07d7));while (((
$port==(0x02d2+ 5896-0x19da))and ($i<$to))){($handler=main::nxListenOnSocket ($i
,$silent));if (($handler==(-(0x1457+ 1639-0x1abd)))){(++$i);}elsif (($handler==(
-(0x1426+ 457-0x15ed)))){Logger::debug (
"\x4e\x58\x54\x6f\x6f\x6c\x73\x3a\x20\x55\x6e\x65\x78\x70\x65\x63\x74\x65\x64\x20\x65\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x73\x65\x61\x72\x63\x68\x69\x6e\x67\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x2e"
);last;}else{($port=$i);}}if (($handler<(0x1c70+ 677-0x1f15))){Logger::debug (
"\x4e\x58\x54\x6f\x6f\x6c\x73\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x66\x69\x6e\x64\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x72\x61\x6e\x67\x65\x2e"
);return (undef,$port);}Logger::debug (((
"\x4e\x58\x54\x6f\x6f\x6c\x73\x3a\x20\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x69\x73\x74\x65\x6e\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20\x27"
.$port)."\x27\x2e"));return ($handler,$port);}sub NXTools::openNXServerPort{
package NXTools;no warnings;my ($port);my ($handler);if ((Server::getMySessionID
 ()ne (""))){if (NXSession2::existSession (Server::getMySessionID ())){((
$handler,$port)=findFreePortAndOpen ($GLOBAL::ServerSlaveBase,
"\x73\x69\x6c\x65\x6e\x74"));NXSession2::setPortBySessionId (
Server::getMySessionID (),$port);}Logger::debug (((((
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6c\x69\x73\x74\x65\x6e\x20\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x3a\x20"
.$port)."\x20\x2d\x20").Server::getMySessionID ()).("")));}else{Logger::debug (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x73\x6f\x63\x6b\x65\x74\x20\x66\x6f\x72\x20\x4e\x58\x53\x65\x72\x76\x65\x72\x20\x2d\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x64"
);}return ($handler);}sub NXTools::getMainSessionID{package NXTools;no warnings;my (
$mainSessionId);if (defined (NXNodeExec::getMainSessionId ())){($mainSessionId=
NXNodeExec::getMainSessionId ());}else{(my (@sessions)=NXSession2::listSessions 
());foreach my $session (@sessions){($mainSessionId=
NXSession2::getMainSessionBySessionId ($session));if ((not (defined (
$mainSessionId)))){(my $localSessiontType=
NXSession2::getLocalSessionTypeBySessionId ($session));if (
NXLocalSession::isLocalSessionTypeDesktop ($localSessionType)){($mainSessionId=
$session);}elsif (NXLocalSession::isLocalSessionTypeLoginwindow (
$localSessionType)){($mainSessionId=$session);}}if (defined ($mainSessionId)){
last;}}NXNodeExec::setMainSessionId ($mainSessionId);}return ($mainSessionId);}
sub NXTools::getParentPid{package NXTools;no warnings;(my $parentPid=
(0x0566+ 1441-0x0b07));($parentPid=getppid);return ($parentPid);}sub 
NXTools::getNXSshdPidWindows{package NXTools;no warnings;(my $forwardServerParentPid
=(0x03d8+ 4729-0x1651));(my $sshdPid=(0x083b+ 3258-0x14f5));return (
(0x0354+ 6074-0x1b0e));}sub NXTools::getSshdPidUnix{package NXTools;no warnings;
(my $sshdPid=(0x0722+ 6115-0x1f05));if (NXAuth::isSystem ()){($sshdPid=
Common::NXCore::getParentPidByPid (getParentPid ()));}if (NXAuth::isNomachine ()
){($sshdPid=getppid);}return ($sshdPid);}sub NXTools::getSshdPid{package NXTools
;no warnings;(my $sshdPid=(0x1fb1+ 1464-0x2569));($sshdPid=getSshdPidUnix ());if
 (Common::NXCore::isProcessRunnningAndExpectedNameMatch ($sshdPid,
"\x73\x73\x68\x64")){return ($sshdPid);}Logger::warning (((
"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x67\x65\x74\x20\x53\x53\x48\x44\x20\x50\x49\x44\x3a\x20\x50\x72\x6f\x63\x65\x73\x73\x20"
.$sshdPid).
"\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x68\x61\x76\x65\x20\x65\x78\x70\x65\x63\x74\x65\x64\x20\x6e\x61\x6d\x65\x2e"
));}sub NXTools::getNXSshdPidOnWindowsOnSystemSshSession{package NXTools;no 
warnings;(my $parentPid=(0x012c+ 1763-0x080f));return ($parentPid);}sub 
NXTools::getGIDByGroupOnApple{package NXTools;no warnings;(my $group=shift (@_))
;(my $groupId=getgrnam ($group));if (defined ($groupId)){return ($groupId);}(my (
$name,$passwd,$gid,$members)=getgrgid ($group));if (($name and ($gid eq $group))
){return ($gid);}return ((""));}sub NXTools::getArrayOfListWrappedByLineLength{
package NXTools;no warnings;(my $list=shift (@_));(my (@wrappedArray)=());while 
((libnxh::NXStringLength ($list)>(0x052a+ 5054-0x18c0))){(my $line=
libnxh::NXSubstring ($list,(0x0503+ 7646-0x22e1),(0x0a67+ 6115-0x2222)));(my $commaPosition
=libnxh::NXStringRightIndex ($line,"\x2c"));(++$commaPosition);($line=
libnxh::NXSubstring ($line,(0x16e0+ 3284-0x23b4),$commaPosition));push (
@wrappedArray,$line);($list=libnxh::NXSubstring ($list,$commaPosition,
(0x08da+ 6852-0x1f9e)));($list=~ s/^ // );}push (@wrappedArray,$list);return (
@wrappedArray);}sub NXTools::setWidth{package NXTools;no warnings;(my $refTable=
shift (@_));(my $name=shift (@_));(my $value=shift (@_));if (($$refTable{$name}<
libnxh::NXStringLength ($value))){($$refTable{$name}=libnxh::NXStringLength (
$value));}}sub NXTools::printWidth{package NXTools;no warnings;(my $refTable=
shift (@_));(my $name=shift (@_));(my $value=shift (@_));(my $width=($$refTable{
$name}+(0x1388+ 2088-0x1baf)));(my $message=
Common::NXCore::leftJustifyOrTrimString ($value,$width));if ((main::nxwrite (
main::nxgetSTDOUT (),$message)==(-(0x0177+ 7591-0x1f1d)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x0735+ 5382-0x1c3a)));}}sub NXTools::printMark{package NXTools;no warnings;(my $refTable
=shift (@_));(my $name=shift (@_));(my $value=shift (@_));(my $width=($$refTable
{$name}+(0x0306+ 7366-0x1fcb)));(my $message=
Common::NXCore::leftJustifyOrTrimString (("\x2d" x $$refTable{$name}),$width));
if ((main::nxwrite (main::nxgetSTDOUT (),$message)==(-(0x1ada+ 2138-0x2333)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x1152+ 2751-0x1c10)));}}sub NXTools::printTable{package NXTools;no warnings;(my $ref_labels
=shift (@_));(my $ref_values=shift (@_));(my (%table)=());for ((my $i=
(0x101c+ 2926-0x1b8a));($i<@$ref_labels);(++$i)){setWidth ((\%table),$i,
@$ref_labels[$i]);}foreach my $value (values (%$ref_values)){for ((my $i=
(0x0c59+ 4523-0x1e04));($i<@$ref_labels);(++$i)){(my $name=@$ref_labels[$i]);
setWidth ((\%table),$i,$$value{$name});}}for ((my $i=(0x02f0+ 8642-0x24b2));($i<
@$ref_labels);(++$i)){printWidth ((\%table),$i,@$ref_labels[$i]);}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x0f90+ 5415-0x24b6)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x1092+ 4754-0x2323)));}for ((my $i=(0x1a7d+ 634-0x1cf7));($i<@$ref_labels);(++
$i)){if (printMark ((\%table),$i)){return ((-(0x06d7+ 1111-0x0b2d)));}}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x1d30+ 1435-0x22ca)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x0059+ 2437-0x09dd)));}foreach my $key (sort (keys (%$ref_values))){(my $value
=$$ref_values{$key});for ((my $i=(0x0aaa+ 4613-0x1caf));($i<@$ref_labels);(++$i)
){(my $name=@$ref_labels[$i]);if (printWidth ((\%table),$i,$$value{$name})){
return ((-(0x02b2+ 2386-0x0c03)));}}if ((main::nxwrite (main::nxgetSTDOUT (),
"\x0a")==(-(0x0a43+ 4932-0x1d86)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x157c+ 2480-0x1f2b)));}}if ((
main::nxwrite (main::nxgetSTDOUT (),"\x0a")==(-(0x098d+ 3573-0x1781)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x06d1+ 6423-0x1fe7)));}return ((0x0adb+ 2758-0x15a1));}sub NXTools::getLoadAvg
{package NXTools;no warnings;(my $file=
"\x2f\x70\x72\x6f\x63\x2f\x6c\x6f\x61\x64\x61\x76\x67");main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x54\x6f\x6f\x6c\x73");(my $loadAvg=
Common::NXFile::getFileContent ($file));if (($loadAvg=~ /(\d+\.\d+) (\d+\.\d+) (\d+\.\d+)/ )
){Logger::debug ((("\x4c\x6f\x61\x64\x20\x61\x76\x65\x72\x61\x67\x65\x3a\x20".$1
)."\x2e"));return ($1);}Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x62\x74\x61\x69\x6e\x20\x6c\x6f\x61\x64\x20\x61\x76\x65\x72\x61\x67\x65\x2e"
);return (0.5);}sub NXTools::getSystemLoad{package NXTools;no warnings;(my $file
=NXPaths::getSystemLoadFile ());(my $load=Common::NXFile::getFileContent ($file)
);if (($load=~ /^(\d+)/ )){Logger::debug (((
"\x53\x79\x73\x74\x65\x6d\x20\x6c\x6f\x61\x64\x3a\x20".$1)."\x2e"));return ($1);
}return ((-(0x0c25+ 1411-0x11a7)));}sub NXTools::getAvailableMemory{package 
NXTools;no warnings;(my $file=NXPaths::getMemInfoFile ());(my $fh=main::nxopen (
$file,$NXBits::O_RDONLY,(0x107f+ 1140-0x14f3)));if ((not (defined ($fh)))){
Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x6d\x65\x6d\x6f\x72\x79\x2e"
);return ((-(0x12da+ 2090-0x1b03)));}my ($line);(my $availableMemory=(-
(0x098c+ 2062-0x1199)));while ((main::nxreadLine ($fh,(\$line))>
(0x19cc+ 1979-0x2187))){chomp ($line);if (($line=~ /^MemFree:\s+(\d+)/ )){(
$availableMemory=$1);}if (($line=~ /^MemAvailable:\s+(\d+)/ )){($availableMemory
=$1);}if (($line=~ /^SwapFree:\s+(\d+)/ )){($availableMemory+=$1);}}
main::nxclose ($fh);return ($availableMemory);return ((-(0x08d8+ 2138-0x1131)));
}sub NXTools::stringLengthClientDependent{package NXTools;no warnings;(my $string
=shift (@_));if (Server::isClientSupportsCorrectlyFormattedUnicodeInListCommands
 ()){return (libnxh::NXStringLength ($string));}else{return (length ($string));}
}sub NXTools::subStringClientDependent{package NXTools;no warnings;(my $string=
shift (@_));(my $offset=shift (@_));(my $length=shift (@_));if (
Server::isClientSupportsCorrectlyFormattedUnicodeInListCommands ()){return (
libnxh::NXSubstring ($string,$offset,$length));}else{($string=~ s/^(.{$offset,$length}).*/$1/ )
;return ($string);}}sub NXTools::leftJustifyStringClientDependent{package 
NXTools;no warnings;(my $string=shift (@_));(my $maxLength=shift (@_));(my $character
=(shift (@_)||"\x20"));if (
Server::isClientSupportsCorrectlyFormattedUnicodeInListCommands ()){return (
Common::NXCore::leftJustifyString ($string,$maxLength,$character));}else{return 
(sprintf ((("\x25\x2d".$maxLength)."\x73"),$string));}}sub 
NXTools::leftJustifyOrTrimStringClientDependent{package NXTools;no warnings;(my $string
=shift (@_));(my $maxLength=shift (@_));(my $character=(shift (@_)||"\x20"));if 
(Server::isClientSupportsCorrectlyFormattedUnicodeInListCommands ()){return (
Common::NXCore::leftJustifyOrTrimString ($string,$maxLength,$character));}else{
return (sprintf ((((("\x25\x2d".$maxLength)."\x2e").$maxLength)."\x73"),$string)
);}}sub NXTools::leftJustifyOrTrimStringRawFormat{package NXTools;no warnings;(my $string
=shift (@_));(my $maxLength=shift (@_));return (sprintf ((((("\x25\x2d".
$maxLength)."\x2e").$maxLength)."\x73"),$string));}sub 
NXTools::getNxhtdPidFileFromCfg{package NXTools;no warnings;(my (%keys)=());(
$keys{"\x50\x69\x64\x46\x69\x6c\x65"}=(""));($keys{
"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}=(""));__getFromNxhtdCfg ((\%keys));
if (($keys{"\x50\x69\x64\x46\x69\x6c\x65"}=~ /^\// )){return ($keys{
"\x50\x69\x64\x46\x69\x6c\x65"});}if (($keys{
"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}ne (""))){return ((($keys{
"\x53\x65\x72\x76\x65\x72\x52\x6f\x6f\x74"}.$GLOBAL::DIRECTORY_SLASH).$keys{
"\x50\x69\x64\x46\x69\x6c\x65"}));}else{return ((($GLOBAL::NODE_ROOT.
$GLOBAL::DIRECTORY_SLASH).$keys{"\x50\x69\x64\x46\x69\x6c\x65"}));}}sub 
NXTools::getUniquePort{package NXTools;no warnings;(my $a=(
Common::NXTime::getSecondsSinceEpoch ()%(0x13a8+ 3111-0x0c47)));(my $port=(
$GLOBAL::ServerSlaveBase+$a));(my $end=($GLOBAL::ServerSlaveBase+
$GLOBAL::ServerSlaveLimit));while (($port<$end)){Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x54\x72\x79\x42\x69\x6e\x64\x4c\x6f\x63\x61\x6c\x28\x31\x2c\x20"
.$port)."\x29"));(my $return=libnxh::NXTryBindLocal ((0x1652+ 1755-0x1d2c),$port
));Logger::debug (((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x54\x72\x79\x42\x69\x6e\x64\x4c\x6f\x63\x61\x6c\x20\x72\x65\x74\x75\x72\x6e\x73\x20\x27"
.$return)."\x27\x2e"));if (($return eq "\x31")){return ($port);}if (($return eq 
"\x2d\x31")){(my $errorName=libnxh::NXGetErrorName ());if (($errorName ne 
"\x45\x41\x44\x44\x52\x49\x4e\x55\x53\x45")){(my $errorString=
libnxh::NXGetErrorString ());Logger::error (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x62\x69\x6e\x64\x20\x70\x6f\x72\x74\x20\x27".$port
)."\x27\x3a\x20").$errorName)."\x2c\x20").$errorString)."\x2e"));return ((-
(0x13e6+ 541-0x1602)));}}(++$port);}Logger::error (((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x66\x72\x65\x65\x20\x70\x6f\x72\x74\x20\x69\x6e\x20\x72\x61\x6e\x67\x65\x20\x27"
.$port)."\x20\x2d\x20").$end)."\x27\x2e"));return ((-(0x1911+ 1242-0x1dea)));}
sub NXTools::isNotCorrectPort{package NXTools;no warnings;(my $port=shift (@_));
return ((!isCorrectPort ($port)));}sub NXTools::isCorrectPort{package NXTools;no
 warnings;(my $port=shift (@_));if ((((defined ($port)and ($port=~ /^\d+$/ ))and
 ($port>=(0x0086+ 4062-0x1064)))and ($port<=65535))){return (
(0x1ef9+ 1847-0x262f));}return ((0x0142+ 2711-0x0bd9));}package NXTools;no 
warnings;return ((0x01c9+ 415-0x0367));
