############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package SlaveServer;no warnings;require NXServerDaemon;sub handleGetCommand{(my $socket
=shift (@_));(my $read_buf=shift (@_));Logger::debug (
"\x48\x61\x6e\x64\x6c\x65\x20\x67\x65\x74\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2e");
if (($read_buf=~ /cookie=(.*),command=get,target=local,option=(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*) / )
){(my $cookie=$1);(my $pid=$2);(my $fd=$3);(my $path=$4);(my $magic=$5);(my $token
=$6);(my $type=$7);(my $host=$8);(my $port=$9);(my $iv=$10);(my $key=$11);(my $invited
=$12);(my $display=$13);(my $local=$14);(my $stun=$15);(my $remote=$16);(my $code
=$17);(my $turn=$18);if ((lc ($cookie)ne lc (NXServerDaemon::getCookie ()))){
Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$socket)."\x2e"));}else{libnxh::NXProcessUnpurgeArg ($path);(my $descriptor=
__acquireDescriptor ($pid,$fd,$path,$magic));if (($descriptor!=(-
(0x104a+ 5149-0x2466)))){startServerProcessConnectedToPlayer ($descriptor,$token
,$type,$host,$port,$iv,$key,$invited,$display,$local,$stun,$remote,$code,$turn);
}}}elsif (($read_buf=~ /cookie=(.*),command=get,target=local,option=(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*) / )
){(my $cookie=$1);(my $pid=$2);(my $fd=$3);(my $path=$4);(my $magic=$5);(my $token
=$6);(my $type=$7);(my $host=$8);(my $port=$9);(my $iv=$10);(my $key=$11);(my $invited
=$12);(my $display=$13);(my $local=$14);(my $stun=$15);(my $remote=$16);(my $code
=$17);if ((lc ($cookie)ne lc (NXServerDaemon::getCookie ()))){Logger::warning ((
(
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$socket)."\x2e"));}else{libnxh::NXProcessUnpurgeArg ($path);(my $descriptor=
__acquireDescriptor ($pid,$fd,$path,$magic));if (($descriptor!=(-
(0x0b9b+ 6107-0x2375)))){startServerProcessConnectedToPlayer ($descriptor,$token
,$type,$host,$port,$iv,$key,$invited,$display,$local,$stun,$remote,$code);}}}
elsif (($read_buf=~ /cookie=(.*),command=get,target=local,option=(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*):(.*) / )
){(my $cookie=$1);(my $pid=$2);(my $fd=$3);(my $path=$4);(my $magic=$5);(my $token
=$6);(my $type=$7);(my $host=$8);(my $port=$9);(my $iv=$10);(my $key=$11);(my $invited
=$12);(my $display=$13);(my $local=$14);(my $stun=$15);(my $remote=$16);if ((lc 
($cookie)ne lc (NXServerDaemon::getCookie ()))){Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$socket)."\x2e"));}else{libnxh::NXProcessUnpurgeArg ($path);(my $descriptor=
__acquireDescriptor ($pid,$fd,$path,$magic));if (($descriptor!=(-
(0x0c1a+ 1003-0x1004)))){startServerProcessConnectedToPlayer ($descriptor,$token
,$type,$host,$port,$iv,$key,$invited,$display,$local,$stun,$remote);}}}
NXServerDaemon::removeClientFDFromSelector ($socket);main::nxclose ($socket);}
sub __acquireDescriptor{(my $pid=shift (@_));(my $fd=shift (@_));(my $path=shift
 (@_));(my $magic=shift (@_));Logger::debug (((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x63\x71\x75\x69\x72\x65\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28"
.$pid)."\x2c\x20").$fd)."\x2c\x20").$path)."\x2c\x20\x2a\x2a\x2a\x29"));(my $descriptor
=libnxh::NXAcquireDescriptor ($pid,$fd,$path,$magic));Logger::debug ((((((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x63\x71\x75\x69\x72\x65\x44\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x28"
.$pid)."\x2c\x20").$fd)."\x2c\x20").$path)."\x2c\x20\x2a\x2a\x2a\x29\x20").
$descriptor));if (($descriptor==(-(0x1982+ 2929-0x24f2)))){(my $errorInt=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());(my $errorName
=libnxh::NXGetErrorName ());Logger::error ((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x63\x71\x75\x69\x72\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x20\x66\x72\x6f\x6d\x20\x70\x69\x64\x20"
.$pid)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").$errorInt)."\x20").
$errorName)."\x20").$errorString));}else{main::closeSocketAtFinish ($descriptor)
;}return ($descriptor);}sub startServerProcessConnectedToPlayer{(my $descriptor=
shift (@_));(my $token=shift (@_));(my $type=shift (@_));(my $host=shift (@_));(my $port
=shift (@_));(my $iv=shift (@_));(my $key=shift (@_));(my $invited=shift (@_));(my $display
=shift (@_));(my $local=shift (@_));(my $stun=shift (@_));(my $remote=shift (@_)
);(my $code=shift (@_));(my $turn=shift (@_));Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x2e");my (
@command);(my $path=NXPaths::getServerLaunchPath ());($path=~ s/\\\\/\\/g );push
 (@command,$path);push (@command,"\x2d\x63");push (@command,($path.
"\x20\x2d\x2d\x6c\x6f\x67\x69\x6e"));push (@command,"\x2d\x48");push (@command,
$descriptor);libnxh::NXDescriptorInheritable ($descriptor,(0x0ae1+ 1831-0x1207))
;my (@options);push (@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");push (
@options,"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",$descriptor);(my $connection
=((($host."\x20").$port)."\x20\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x20\x30"));if
 (defined ($turn)){(my (@tmp)=split ( /;/ ,$turn,(0x0647+ 6539-0x1fd2)));if (
defined ($tmp[(0x0950+  83-0x099b)])){($connection=((($tmp[(0x1e0f+ 933-0x21ac)]
."\x20").$port)."\x20\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x20\x30"));splice (
@tmp,(0x0474+ 3845-0x1371),(0x09d0+  21-0x09e4));($turn=join ("\x3b",@tmp));}}
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e\x3d".$connection));if ((
$type<(0x063a+ 1310-0x0b54))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",((((
((("\x4e\x58\x5f\x52\x54\x3d".$host)."\x3a").$port)."\x3a").$iv)."\x3a").$key));
}if (($local ne (""))){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(((((
"\x4e\x58\x5f\x55\x44\x50\x3d".$remote)."\x3a").$local)."\x3a").$stun));}if ((
$invited ne "\x30")){push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x49\x4e\x56\x49\x54\x45\x44\x3d".$invited));}push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x54\x4f\x4b\x45\x4e\x3d".$token));
push (@options,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x43\x4f\x44\x45\x3d".$code));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x54\x41\x52\x47\x45\x54\x3d".
$display));if ((defined ($turn)and ($turn ne ("")))){push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x54\x55\x52\x4e\x5f\x44\x41\x54\x41\x3d".$turn));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76","\x4e\x58\x5f\x54\x55\x52\x4e\x3d\x31");}push (
@options,"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x48\x4f\x4d\x45\x3d".
Common::NXPaths::getEffectiveUserHomeDirectory ()));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x52\x4f\x4f\x54\x3d".
Common::NXPaths::getNxDirectoryInEffectiveUserHomeDirectory ()));
main::nxRunCommand ((\@command),(\@options));}return ((0x0887+ 5342-0x1d64));
