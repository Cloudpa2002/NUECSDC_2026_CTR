############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXWebInfoFilesControl;no warnings;($serviceMonitoringDelay=
(0x1248+ 1361-0x0989));($serviceStatus=(0x0ecf+ 4385-0x1ff0));($lastCheckTime=
(0x0c3b+ 5079-0x2012));($infoFilesDirectory=(((((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x74\x6d\x70").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x77\x65\x62\x70\x6c\x61\x79\x65\x72").$GLOBAL::DIRECTORY_SLASH).
"\x69\x6e\x66\x6f"));sub BEGIN{require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub enableService{if ((
isServiceEnabled ()!=(0x0bc5+  50-0x0bf6))){init ();}($serviceStatus=
(0x0436+ 7549-0x21b2));return;}sub disableService{if ((isServiceEnabled ()==
(0x0032+ 6369-0x1912))){deleteAllInfoFiles ();}($serviceStatus=
(0x0f42+ 379-0x10bd));return;}sub isServiceEnabled{return ($serviceStatus);}sub 
init{($lastCheckTime=Common::NXTime::getSecondsSinceEpoch ());return;}sub 
__checkIsTimeForRemoveInfoFiles{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $delay=$serviceMonitoringDelay);if 
((($lastCheckTime+$delay)<=$currentTime)){($lastCheckTime=$currentTime);return (
(0x0be7+ 1960-0x138e));}return ((0x0d05+ 2633-0x174e));}sub checkService{if ((
isServiceEnabled ()!=(0x0f3a+ 2737-0x19ea))){return ((0x0466+ 4265-0x150e));}if 
((__checkIsTimeForRemoveInfoFiles ()==(0x0cf0+ 5308-0x21ac))){return (
(0x0078+ 1563-0x0692));}if ((not (Common::NXFile::directoryExists (
$infoFilesDirectory)))){(my $errorString=libnxh::NXGetErrorString ());(my $errorNumber
=libnxh::NXGetError ());Logger::debug (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x63\x68\x65\x63\x6b\x53\x65\x72\x76\x69\x63\x65\x20\x4d\x69\x73\x73\x69\x6e\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20\x27"
.$infoFilesDirectory)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").
$errorNumber)."\x2c\x20").$errorString)."\x2e"));return;}(my $list=
libnxhs::NXGetFilesList ($infoFilesDirectory));if (($list eq (""))){
Logger::debug (((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x63\x68\x65\x63\x6b\x53\x65\x72\x76\x69\x63\x65\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20\x27"
.$infoFilesDirectory)."\x27\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"));return;}
foreach my $name (split ( /\n/ ,$list,(0x02ed+ 2690-0x0d6f))){if (($name=~ /^[\d\w]{32}\.info$/ )
){(my $path=(($infoFilesDirectory.$GLOBAL::DIRECTORY_SLASH).$name));(my $fileCTime
=Common::NXCore::NXFileCTime ($path));if ((checkAndRemoveInfoFile ($fileCTime)==
(0x0283+ 6030-0x1a10))){deleteInfoFile ($name);}}}return;}sub 
checkAndRemoveInfoFile{(my $cTime=(shift (@_)||(0x094d+ 2214-0x11f3)));if ((
$cTime<=(0x18d3+ 2890-0x241d))){return;}if ((($cTime+$serviceMonitoringDelay)<
Common::NXTime::getSecondsSinceEpoch ())){return ((0x18aa+ 1377-0x1e0a));}
Logger::debug2 (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x63\x68\x65\x63\x6b\x41\x6e\x64\x52\x65\x6d\x6f\x76\x65\x49\x6e\x66\x6f\x46\x69\x6c\x65\x20\x46\x69\x6c\x65\x20\x6e\x6f\x74\x20\x72\x65\x61\x64\x79\x20\x74\x6f\x20\x72\x65\x6d\x6f\x76\x65\x2e"
);return ((0x0e83+ 480-0x1063));}sub deleteAllInfoFiles{Logger::debug2 (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x64\x65\x6c\x65\x74\x65\x41\x6c\x6c\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"
);if ((not (Common::NXFile::directoryExists ($infoFilesDirectory)))){(my $errorString
=libnxh::NXGetErrorString ());(my $errorNumber=libnxh::NXGetError ());
Logger::debug (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x64\x65\x6c\x65\x74\x65\x41\x6c\x6c\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x3a\x20\x4d\x69\x73\x73\x69\x6e\x67\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20\x27"
.$infoFilesDirectory)."\x27\x2e\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").
$errorNumber)."\x2c\x20").$errorString)."\x2e"));return;}(my $list=
libnxhs::NXGetFilesList ($infoFilesDirectory));if (($list eq (""))){
Logger::debug (((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x64\x65\x6c\x65\x74\x65\x41\x6c\x6c\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x3a\x20\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x3a\x20\x27"
.$infoFilesDirectory)."\x27\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e"));}foreach my $name
 (split ( /\n/ ,$list,(0x0083+ 5106-0x1475))){deleteInfoFile ($name);}return;}
sub deleteInfoFile{(my $filename=(shift (@_)||("")));Logger::debug2 (((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x64\x65\x6c\x65\x74\x65\x49\x6e\x66\x6f\x46\x69\x6c\x65\x28"
.$filename)."\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"));if (($filename=~ /^[\d\w]{32}\.info$/ )
){(my $path=(($infoFilesDirectory.$GLOBAL::DIRECTORY_SLASH).$filename));if ((
libnxh::NXFileExists ($path)==(0x180b+ 1545-0x1e13))){if ((libnxh::NXFileRemove 
($path)!=(0x01c6+ 3562-0x0fb0))){(my $errorString=libnxh::NXGetErrorString ());(my $errorNumber
=libnxh::NXGetError ());Logger::warning (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6d\x6f\x76\x65\x20\x66\x69\x6c\x65\x20\x27"
.$path)."\x27\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20").$errorNumber).
"\x2c\x20").$errorString)."\x2e"));}else{Logger::debug (((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$path)."\x27\x20\x72\x65\x6d\x6f\x76\x65\x64\x2e"));}}else{(my $errorString=
libnxh::NXGetErrorString ());(my $errorNumber=libnxh::NXGetError ());
Logger::debug2 (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$path).
"\x27\x20\x64\x6f\x65\x73\x6e\x74\x20\x65\x78\x69\x73\x74\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20"
).$errorNumber)."\x2c\x20").$errorString)."\x2e"));}}return;}sub 
setInfoDirectoryPermissionByAdmin{Logger::debug (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x73\x65\x74\x49\x6e\x66\x6f\x44\x69\x72\x65\x63\x74\x6f\x72\x79\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x42\x79\x41\x64\x6d\x69\x6e\x28\x29\x20\x63\x61\x6c\x6c\x65\x64\x2e"
);main::nxrequire (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");if ((not (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()))){return;}if ((not (
main::effectiveUserIsAdministrator ()))){return;}if ((not (
Common::NXFile::directoryExists ($infoFilesDirectory)))){my ($errorMsg);if ((not
 (Common::NXPaths::makePath ((\$errorMsg),$infoFilesDirectory)))){
Logger::warning (((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x64\x69\x72\x65\x63\x74\x6f\x72\x79\x20"
.$infoFilesDirectory)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errorMsg)
."\x2e"));return ((0x0222+ 7330-0x1ec3));}}my ($errorNumber);my ($errorString);(my $silent
=(0x0218+ 5916-0x1933));(my $permissions=((($NXBits::UserReadWrite+
$NXBits::UserExecute)+$NXBits::GroupReadWrite)+$NXBits::GroupExecute));if ((
Common::NXFile::setPermissions_unix ($infoFilesDirectory,$permissions,(
\$errorNumber),(\$errorString),$silent)==(-(0x0a05+ 3884-0x1930)))){
Logger::debug (((((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$infoFilesDirectory)."\x20\x74\x6f\x20").$permissions).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errorNumber)."\x2c\x20").
$errorString)."\x2e"));}(my $ApacheUname=(""));if (($GLOBAL::ApacheUname ne ("")
)){($ApacheUname=$GLOBAL::ApacheUname);}else{(my (@htdUsers)=
NXTools::getNXHtdUser ());($ApacheUname=$htdUsers[(0x0022+ 6161-0x1833)]);}(my $uid
=Common::NXCore::userInfoGetUidByUsername ($ApacheUname));(my $gid=
Common::NXCore::userInfoGetGidByUsername ("\x6e\x78"));if ((
Common::NXFile::setOwnershipForUser_unix ($infoFilesDirectory,$uid,$gid,(
\$errorString),(\$errorNumber),$silen)==(-(0x17df+ 1709-0x1e8b)))){Logger::debug
 (((((((
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x6f\x77\x6e\x65\x72\x20\x6f\x66\x20"
.$infoFilesDirectory)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").
$errorNumber)."\x2c\x20").$errorString)."\x2e"));}return;}"\x3f\x3f\x3f";
