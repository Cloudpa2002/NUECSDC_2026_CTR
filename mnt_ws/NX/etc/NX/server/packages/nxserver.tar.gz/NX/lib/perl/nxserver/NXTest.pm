############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXTest::BEGIN{package NXTest;no warnings;require NXMsg;do{
"\x4e\x58\x4d\x73\x67"->import};}sub NXTest::run_test{package NXTest;no warnings
;Common::NXMsg::send_response (
"\x69\x52\x75\x6e\x6e\x69\x6e\x67\x54\x65\x73\x74\x50\x72\x6f\x63\x65\x64\x75\x72\x65"
);(my $test_dir=((((((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x73\x63\x72\x69\x70\x74\x73").$GLOBAL::DIRECTORY_SLASH)."\x74\x65\x73\x74").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72").
$GLOBAL::DIRECTORY_SLASH));(my $log_dir=(((((((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").$GLOBAL::DIRECTORY_SLASH).
"\x74\x65\x73\x74").$GLOBAL::DIRECTORY_SLASH).
"\x6e\x78\x73\x65\x72\x76\x65\x72\x2d").$ $) . $GLOBAL::DIRECTORY_SLASH));
 (my $log_test_dir
=((((($GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x74\x65\x73\x74").$GLOBAL::DIRECTORY_SLASH));(my $dir_created
=(0x062f+  64-0x066f));(my $prevUmask=umask);opendir (my $TESTDIR,$test_dir);(my (
@test_files)=sort (grep ({ /^[^\.]/ ;}readdir ($TESTDIR))));closedir ($TESTDIR);
foreach my $file (@test_files){if (((($file=~ /^\d{2}-(\w+)/ )and (not (($file=~ /^\d{2}-.*-.*/ )
)))or ($file=~ /^\d{2}-\d{2}-\w+/ ))){($file=($test_dir.$file));if (-x ($file)){
($prevUmask=umask ((0x0da1+ 1731-0x1464)));if ((not (-d ($log_test_dir)))){if ((
not (mkdir ($log_test_dir)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20".$log_test_dir).
"\x20\x66\x6f\x6c\x64\x65\x72\x2e"),(0x0646+ 3697-0x14b7));}}if ((not (-d (
$log_dir)))){if ((not (mkdir ($log_dir)))){Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20".$log_dir).
"\x20\x66\x6f\x6c\x64\x65\x72\x2e"),(0x0257+ 7803-0x20d2));}else{($dir_created=
(0x0c50+ 377-0x0dc8));}}Common::NXMsg::send_response (
"\x69\x52\x75\x6e\x6e\x69\x6e\x67\x53\x63\x72\x69\x70\x74",$file);(my (@command)
=(("\x22".$file)."\x22"));(my (@options)=("\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x54\x45\x53\x54\x4c\x4f\x47\x3d".$log_dir),
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x54\x45\x53\x54\x44\x49\x52\x3d".
$test_dir)));(my ($cmd_err,$cmd_out,$exit_value)=main::run_command ((\@command),
(\@options)));if (($exit_value==(0x0a44+ 4358-0x1b4a))){NXMsg::send_response (
"\x69\x53\x63\x72\x69\x70\x74\x46\x69\x6e\x69\x73\x68\x4f\x6b",
"\x4e\x58\x54\x65\x73\x74");}else{NXMsg::send_response (
"\x65\x53\x63\x72\x69\x70\x74\x46\x69\x6e\x69\x73\x68\x4b\x6f",
"\x4e\x58\x54\x65\x73\x74");}Common::NXMsg::send_response (
"\x69\x53\x63\x72\x69\x70\x74\x4f\x75\x74\x70\x75\x74");main::nxwrite (
main::nxgetSTDOUT (),$cmd_out);if (($cmd_err ne (""))){main::nxwrite (
main::nxgetSTDOUT (),$cmd_err);}}else{Common::NXMsg::send_response (
"\x65\x43\x61\x6e\x6e\x6f\x74\x52\x75\x6e\x53\x63\x72\x69\x70\x74",$file);
NXMsg::send_response (
"\x65\x4e\x6f\x74\x45\x78\x65\x63\x75\x74\x61\x62\x6c\x65\x46\x69\x6c\x65",
"\x4e\x58\x54\x65\x73\x74");}}else{unless (($file eq 
"\x66\x75\x6e\x63\x74\x69\x6f\x6e\x73")){Common::NXMsg::send_response (
"\x65\x49\x6e\x63\x6f\x72\x72\x65\x63\x74\x46\x69\x6c\x65\x6e\x61\x6d\x65",$file
);}}}Common::NXMsg::send_response (
"\x69\x46\x69\x6e\x69\x73\x68\x65\x64\x54\x65\x73\x74\x50\x72\x6f\x63\x65\x64\x75\x72\x65"
);if ($dir_created){Common::NXMsg::send_response (
"\x69\x4f\x75\x74\x70\x75\x74\x41\x76\x61\x69\x6c\x61\x62\x6c\x65",$log_dir);}
umask ($prevUmask);}package NXTest;no warnings;NXMsg::register_response (
"\x4e\x58\x54\x65\x73\x74",
"\x69\x53\x63\x72\x69\x70\x74\x46\x69\x6e\x69\x73\x68\x4f\x6b",
(0x1044+ 1424-0x12b3));NXMsg::register_response ("\x4e\x58\x54\x65\x73\x74",
"\x65\x53\x63\x72\x69\x70\x74\x46\x69\x6e\x69\x73\x68\x4b\x6f",
(0x1810+ 3957-0x2464));NXMsg::register_response ("\x4e\x58\x54\x65\x73\x74",
"\x65\x4e\x6f\x74\x45\x78\x65\x63\x75\x74\x61\x62\x6c\x65\x46\x69\x6c\x65",
(0x1096+ 4609-0x1f74));"\x3f\x3f\x3f";
