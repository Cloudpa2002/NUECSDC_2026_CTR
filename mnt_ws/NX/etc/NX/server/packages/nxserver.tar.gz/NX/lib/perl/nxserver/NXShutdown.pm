############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXShutdown;no warnings;my (%__wasDisabled);sub handleShutdown{(my (
%parameters)=@_);if (defined ($parameters{"\x6d\x6f\x6e\x69\x74\x6f\x72"})){
Server::setClientConnectionClosed ();($parameters{"\x73\x69\x6c\x65\x6e\x63\x65"
}=(0x03c9+ 6527-0x1d47));}if (((not (main::effectiveUserIsAdministrator ()))and 
(Common::NXCore::getEffectiveUsername ()eq "\x6e\x78"))){return (
shutdownForUserNx ());}setServiceStatuses ();NXSystemDaemons::stop (
"\x6e\x78\x64");main::nxrequire (
"\x4e\x58\x43\x6c\x69\x65\x6e\x74\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73"
);NXClientSystemDaemons::requestDaemonPreshutdown ();Server::setServerIsShutdown
 ();main::nxrequire (
"\x4e\x58\x52\x65\x64\x69\x73\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e");
NXRedisSubscription::publishToSubscribers (($GLOBAL::MSG_SHUTDOWN_TERMINATE.
"\x20\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x72\x65\x61\x73\x6f\x6e\x3d\x73\x68\x75\x74\x64\x6f\x77\x6e\x20"
));NXSystemDaemons::setShutdownFlag ();main::nxrequire (
"\x53\x65\x72\x76\x69\x63\x65");(my $error=Service::setStopFlag ());if (((not (
defined ($parameters{"\x73\x69\x6c\x65\x6e\x63\x65"})))or ($parameters{
"\x73\x69\x6c\x65\x6e\x63\x65"}eq (0x0dcc+ 2700-0x1858)))){if (($error==
(0x1f10+ 1168-0x23a0))){if (serviceWasDisabled (
"\x6e\x78\x73\x65\x72\x76\x65\x72")){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}else{NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}}else{(my $errorString=
libnxh::NXGetErrorString ());Common::NXMsg::error (
"\x65\x47\x55\x49\x43\x61\x6e\x6e\x6f\x74\x43\x72\x65\x61\x74\x65\x46\x69\x6c\x65"
,$GLOBAL::ServerStopStatusFlagLink,$errorString);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",
"\x6e\x78\x73\x65\x72\x76\x65\x72");}}main::setSSHStatusShutdown ();
main::nxrequire ("\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c");
NXFirewall::delFirewallRules ();NXSystemDaemons::stop (
"\x6e\x78\x73\x65\x72\x76\x65\x72");NXSystemDaemons::printStatus (
"\x6e\x78\x6e\x6f\x64\x65");if (NXSystemDaemons::isServiceEnabled (
"\x6e\x78\x68\x74\x64")){NXSystemDaemons::stop ("\x6e\x78\x68\x74\x64");}
NXUpdate::killUpdate ();NXTerminate::terminateAll ((0x15bf+ 3060-0x21b2));
main::nxrequire ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72");if (
NXCluster::isEnabled ()){NXCluster::standby ();}main::nxrequire (
"\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::handleLeftoverSystemLoadScriptCleanup ();__resetWasDisabled ();return
 ((0x0fd1+ 3621-0x1df6));}sub setServiceStatuses{(my $servicesToCheck=
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x6e\x78\x6e\x6f\x64\x65\x20\x6e\x78\x64");
if (NXLicense::isHttpdSupportFeature ()){($servicesToCheck.=
"\x20\x6e\x78\x68\x74\x64");}($response=
NXSystemDaemons::askServerDaemonForServiceStatus ($servicesToCheck));if (defined
 ($response)){(my (@services)=split ( /, / ,$response,(0x1306+ 2927-0x1e75)));
foreach my $service (@services){if (($service=~ /(.*) Disabled/ )){(
$__wasDisabled{$1}=(0x01bf+ 7639-0x1f95));}}}else{($__wasDisabled{
"\x6e\x78\x6e\x6f\x64\x65"}=(0x09e1+ 5961-0x2129));(my (@services)=(
"\x6e\x78\x73\x65\x72\x76\x65\x72","\x6e\x78\x64"));if (
NXLicense::isHttpdSupportFeature ()){push (@services,"\x6e\x78\x68\x74\x64");}
foreach my $serviceName (@services){if ((not (NXSystemDaemons::isRunning (
$serviceName)))){($__wasDisabled{$serviceName}=(0x0493+ 5631-0x1a91));}}}}sub 
serviceWasDisabled{(my $service=shift (@_));if ((defined ($__wasDisabled{
$service})and ($__wasDisabled{$service}==(0x18fa+ 2880-0x2439)))){return (
(0x0b61+ 6207-0x239f));}return ((0x171d+ 846-0x1a6b));}sub __resetWasDisabled{(my (
@services)=("\x6e\x78\x73\x65\x72\x76\x65\x72","\x6e\x78\x64",
"\x6e\x78\x6e\x6f\x64\x65"));if (NXLicense::isHttpdSupportFeature ()){push (
@services,"\x6e\x78\x68\x74\x64");}foreach my $serviceName (@services){(
$__wasDisabled{$serviceName}=undef);}}sub shutdownForUserNx{Logger::debug (
"\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x6e\x78\x2e"
);(my (@command)=());push (@command,$GLOBAL::CommandNXexec,
"\x6e\x78\x73\x68\x75\x74\x64\x6f\x77\x6e\x2e\x73\x68");(my (@parameters)=());
main::run_command ((\@command),(\@parameters));return ((0x0437+ 7770-0x2291));}
return ((0x04bf+ 8307-0x2531));
