############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXServerDaemon::BEGIN{package NXServerDaemon;no warnings;require warnings;do
{"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXServerDaemon::BEGIN{package 
NXServerDaemon;no warnings;require NXPaths;do{"\x4e\x58\x50\x61\x74\x68\x73"->
import};}package NXServerDaemon;no warnings;require SlaveServer;sub BEGIN{
require Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}((
%listenSocket)=());(@checkLocalSessionLoopDelay=((0x12ab+ 1971-0x1a40),
(0x0375+ 2146-0x0bb9),(0x0e96+ 4295-0x1f21),(0x1459+ 821-0x1662),
(0x1225+ 761-0x12c6),(0x0c5c+ 4548-0x1718),(0x116d+ 348-0x04b9)));(
$servicesMonitoringDelay=(0x0210+ 6162-0x1a04));(
$currentCheckLocalSessionLoopDelay=(0x0495+ 6879-0x1f74));(
$lastCheckLocalSessionTime=(0x0ac7+ 4242-0x1b59));($terminateMode=
(0x1425+ 4026-0x23df));(@servicesToMonitoring=());($terminateReceivedTime=
(0x173b+ 3688-0x25a3));($checkLocalSessionScheduled=(0x1fcd+ 1543-0x25d4));(
$checkLocalSessionDelayed=(0x1218+ 4434-0x236a));($selector=undef);(
$ServerDaemonLockFileHandle=(-(0x0263+ 6353-0x1b33)));($ServerDaemonDBusName=
"\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65\x2e\x6e\x78\x73\x65\x72\x76\x65\x72\x2e\x64\x61\x65\x6d\x6f\x6e"
);($clientDescriptorsWaitingForStatusReport={});((%serversInAdminMode)=());(
$adminModeFlag=((((((NXPaths::getNodeRoot ().$GLOBAL::DIRECTORY_SLASH).
"\x76\x61\x72").$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e").
$GLOBAL::DIRECTORY_SLASH)."\x61\x64\x6d\x69\x6e\x4d\x6f\x64\x65"));(
$connectedToRemoteNodes=(0x0447+ 2428-0x0dc3));($connectedToLocalhost=
(0x0d29+ 3242-0x19d3));($initializing=(-(0x0448+ 4751-0x16d6)));($errorToAdmin=
(""));sub __startupInfo{(my $nodes=NXNodes::remoteNodesSize ());(my $message=
"\x53\x79\x73\x74\x65\x6d\x20\x69\x6e\x66\x6f\x72\x6d\x61\x74\x69\x6f\x6e\x3a\x20"
);($message.=Common::NXInfo::getDistroInfo ());main::nxrequire (
"\x4b\x65\x79\x73\x4d\x61\x6e\x61\x67\x65\x72");if (
KeysManager::isNotExistNodePublicKey ()){($message.=
"\x2c\x20\x73\x74\x61\x6e\x64\x61\x6c\x6f\x6e\x65");}if (($nodes>
(0x07bd+ 4029-0x177a))){($message.=("\x2c\x20\x4e".$nodes));}($message.="\x2e");
Logger::info ((((("\x53\x74\x61\x72\x74\x69\x6e\x67\x20".$GLOBAL::PRODUCT_ID).
"\x20").$GLOBAL::SOFTWARE_RELEASE).
"\x20\x61\x6e\x64\x20\x73\x65\x72\x76\x69\x63\x65\x73\x2e"));Logger::info (
$message);}sub runDaemon{__startupInfo ();__setDaemonInitializing ();
Server::setPassErrorsToUserDisabled ();if ((not (
NXRedis::isDbRunningInCurrentProcess ()))){NXRedis::initRedisServer ();}
main::nxrequire ("\x4e\x58\x44\x62\x75\x73");main::nxrequire (
"\x4e\x58\x44\x62\x75\x73\x4d\x6f\x6e\x69\x74\x6f\x72");if (
checkLocalSessionIsEnabled ()){main::nxrequire (
"\x50\x68\x79\x73\x69\x63\x53\x65\x73\x73\x69\x6f\x6e\x73");PhysicSessions::init
 ($ServerDaemonDBusName);NXDbusMonitor::startMonitor ();}main::nxrequire (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");
NXUdpControl::cleanLocalUdpChannels ();NXNodes::findLocalNode ();
saveServerDaemonLangEnvInDb ();NXLocalSession::startSessionServers ();
NXLocate::setServerStartup ();__startServices ();if (NXLocate::isNXLocateEnabled
 ()){NXLocate::run ();}NXSystemDaemons::initUPnPServices ();
NXSystemDaemons::initNXNetworkChangeService ();if (
NXLicense::isAutomaticRecordingFeature ()){if (($GLOBAL::AutomaticRecordingClean
>(0x0f1d+ 5984-0x267d))){NXEvent::createPeriodicEventAndSubscribe (
NXEvent::getAutomaticRecordingCleanEventName (),(
$GLOBAL::AutomaticRecordingClean/(0x0516+ 3523-0x12d7)),
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x3a\x3a\x72\x65\x6d\x6f\x76\x65\x4f\x6c\x64\x52\x65\x63\x6f\x72\x64\x73"
);}}__setDaemonInitialized ();NXEvent::afterDaemonStart ();runMonitor ();
NXSystemDaemons::stopNXNetworkChangeService ();NXSystemDaemons::stopUPnPServices
 ();NXSystemDaemons::stop ("\x6e\x78\x64");if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){NXSystemDaemons::stop (
"\x6e\x78\x68\x74\x64");}stopServerDaemonListen ();removeServerDaemonPidFile ();
NXRedis::closeDb ();main::nxrequire (
"\x50\x68\x79\x73\x69\x63\x53\x65\x73\x73\x69\x6f\x6e\x73");
NXDbusMonitor::stopMonitor ();PhysicSessions::destroy ();
NXClusterDaemon::destroy ();NXEvent::afterDaemonStop ();}sub initializeDaemon{
Server::initConnectionSTD ();if ((checkAndSetServerDaemonFlock ()==
(0x0547+ 8303-0x25b6))){Logger::error (
"\x41\x6e\x6f\x74\x68\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x69\x6e\x73\x74\x61\x6e\x63\x65\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);main::nxexit ();}NXEvent::beforeDaemonStart ();if (NXSystemDaemons::savePid (
"\x6e\x78\x73\x65\x72\x76\x65\x72",$ $)) {
 Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x61\x76\x65\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x70\x69\x64\x2e"
);main::nxexit ();}__initializeDaemonSelector ();if ((not (
__startServerDaemonListen ()))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x74\x61\x72\x74\x20\x6c\x69\x73\x74\x65\x6e\x69\x6e\x67\x20\x6f\x6e\x20\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x2e"
);main::nxexit ();}return ((0x1b03+ 2249-0x23cb));}sub __startServices{
Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x62\x79\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);Server::redirectClientConnectionToNull ();NXSystemDaemons::start (
"\x6e\x78\x64");NXSystemDaemons::start ("\x6e\x78\x68\x74\x64");}sub 
__initializeDaemonSelector{($selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;($$NXBegin::parser{"\x73\x69\x67\x62\x61\x63\x6b"}{"\x54\x45\x52\x4d"}=sub{if (
(not (NXSystemDaemons::isPreshutdown ()))){preShutdown ();}(
$GLOBAL::REQUEST_TERMINATE=(0x1798+ 1246-0x1c75));
NXSystemDaemons::setShutdownFlag ();Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x27\x53\x49\x47\x54\x45\x52\x4d\x27\x20\x69\x6e\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x3a\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x69\x6f\x6e\x2e"
);});}sub checkAndSetServerDaemonFlock{unless (($ServerDaemonLockFileHandle==(-
(0x0742+ 4030-0x16ff)))){return ((0x11b1+ 1894-0x1916));}if ((not (
checkDaemonFlock ()))){return ((0x00df+ 2293-0x09d4));}else{main::nxrequire (
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73\x3a\x3a\x4e\x58\x44\x61\x65\x6d\x6f\x6e"
);(my $fh=NXServices::NXDaemon::lockFile ());if (($fh==(-(0x0f40+ 1335-0x1476)))
){return ((0x0942+ 5383-0x1e49));}setServerDaemonLockFileHandle ($fh);return (
(0x0107+ 1241-0x05df));}}sub checkDaemonFlock{(my $file=
$GLOBAL::ServerDaemonLockFilePath);Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x66\x69\x6c\x65\x20\x6c\x6f\x63\x6b\x3a\x20"
.$file)."\x2e"));if (((defined ($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"})and (
length ($ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"})>(0x183c+ 2471-0x21e3)))and (
$ENV{"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq "\x31"))){(my $dir=((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x72\x75\x6e"));if ((not (-d ($dir)
))){my ($errorMessage);Common::NXPaths::makePath ((\$errorMessage),$dir);}}if ((
not (Common::NXFile::fileExists ($file)))){Logger::debug (((
"\x46\x69\x6c\x65\x20".$file).
"\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"));return (
(0x10b2+ 4594-0x22a3));}(my $SERVER_FH=main::nxopen ($file,$NXBits::O_RDONLY,
(0x1c53+ 2126-0x24a1)));if ((not (defined ($SERVER_FH)))){Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20".$file
)."\x2e"));return ((0x157d+ 1369-0x1ad6));}if ((not (Common::NXCore::nxTryLock (
$SERVER_FH,$NXBits::LOCK_EX)))){Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6c\x6f\x63\x6b\x20\x66\x69\x6c\x65\x3a\x20".$file
)."\x2e"));main::nxclose ($SERVER_FH);return ((0x0607+ 2740-0x10bb));}
main::nxclose ($SERVER_FH);return ((0x17ec+ 3003-0x23a6));}sub runMonitor{
Logger::debug (
"\x53\x74\x61\x72\x74\x20\x6d\x61\x69\x6e\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x6c\x6f\x6f\x70\x2e"
);main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x61\x65\x6d\x6f\x6e");
NXNodeExec::setSessionType (Common::NXSessionType::getPhysicalDesktop ());(my $signalFd
=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});addFdToSelector ($signalFd);
main::nxrequire ("\x4e\x58\x46\x72\x61\x6d\x65\x42\x75\x66\x66\x65\x72");
addDBusIfEnabled ();main::nxrequire ("\x4e\x58\x55\x70\x64\x61\x74\x65");
NXUpdate::init ();if (NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){
main::nxrequire (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c"
);NXWebInfoFilesControl::enableService ();}(my $terminateFinished=
(0x12e8+ 261-0x13ed));my ($exception);while ((($GLOBAL::REQUEST_TERMINATE!=
(0x1a7d+ 1814-0x2192))or ($terminateFinished!=(0x0a37+ 5636-0x203a)))){my (
@ready);if ((not (isTerminateMode ()))){if ((isSendErrorToAdminMode ()==
(0x0de7+ 1781-0x14db))){NXLocalSession::sendErrorToAdmin (getErrorToAdmin ());}
handleServicesMonitoring ();NXClusterDaemon::create ();(my $delay=
getNewTimeoutForRead ());(@ready=$selector->can_read ($delay));}else{if (
NXLocalSession::localSessionsRunning ()){(my $timeout=getNewTimeoutForRead ());
Common::NXCore::exitFromSelectOnFirstSignal ();&try (sub{(@ready=$selector->
can_read ($timeout));},&otherwise (sub{($exception=shift (@_));}));if (
$exception){last;}}else{($terminateFinished=(0x0638+ 5192-0x1a7f));}}foreach my $f
 (@ready){if (NXSystemDaemons::isDefinedUPnPFD ($f)){main::nxrequire (
"\x4e\x58\x55\x70\x6e\x70");NXUpnp::handleMessageOnDescriptor ($f);}elsif (($f==
$NXSystemDaemons::NetworkChangeFD_Read)){main::nxrequire (
"\x4e\x58\x4e\x65\x74\x77\x6f\x72\x6b\x43\x68\x61\x6e\x67\x65");
NXNetworkChange::handleMessageOnDescriptor ($f);}elsif (($f==
NXDbusMonitor::getStdout ())){(my $read_buf=(""));(my $bytes_read=main::nxread (
$f,(\$read_buf),8192));if (((not (defined ($bytes_read)))or ($bytes_read==
(0x1fe2+ 1007-0x23d1)))){Logger::debug (((
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x74\x6f\x20\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6f\x6e\x20\x46\x44\x23"
.$f)."\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"));removeFdFromSelector (
$f);main::nxclose ($f);}else{Logger::debug (((
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x72\x65\x63\x65\x69\x76\x65\x64\x3a\x20"
.$read_buf)."\x2e"));NXDbusMonitor::parseDbusMonitorBuffer ($read_buf);}}}if ((
not (NXSystemDaemons::isShutdownFlag ()))){if (((not (defined ($ENV{
"\x4e\x58\x5f\x51\x55\x49\x43\x4b"})))or ($ENV{
"\x4e\x58\x5f\x51\x55\x49\x43\x4b"}eq ("")))){if (checkIsTimeForNewSessionList 
()){if ((((((not (NXLicense::isEvaluationPeriodExpired ()))and (not (
NXLicense::isLicenseExpired ())))and (not (NXLicense::isNoLicenseFile ())))and (
not (NXLicense::isNotSuitableLicenseForPackage ())))and (not (
NXLicense::isWrongPlatformLicenseForPackage ())))){
NXLocalSession::checkForRestartingXservers ();}if (
NXLocalSession::thereIsNoXserverFound ()){increaseCheckLocalSessionLoopDelay ();
}}if (((not (NXLocalSession::anyXserverFound ()))and 
NXFrameBuffer::shouldStartNewXserver ())){
NXFrameBuffer::handleStartNxFrameBufferAutomatically ();}}if (
NXForeignSession::isTimeForCheckForeignNodes ()){
NXForeignSession::checkForeignNodes ();}NXServers::checkInverseNodesConnection 
();NXConnectionMonitor::checkCMConnection ();main::nxrequire (
"\x4e\x58\x4c\x6f\x67\x72\x6f\x74\x61\x74\x65");if (((not (
__isWaitingForLocalNodeRun ()))and NXLogrotate::isTimeForCheckLogrotate ())){
NXLogrotate::checkLogrotateAndHandleIfNeeded ();}if (
NXLicense::isTimeForCheckProcessorsCount ()){NXLicense::checkProcessorsCount ();
}main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");if (
NXScripts::shouldRerunNXReportSystemLoadScript ()){
NXScripts::rerunNXReportSystemLoadScript ();}}if (
NXLicense::isAutomaticRecordingFeature ()){main::nxrequire (
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x4e\x6f\x64\x65"
);NXAutomaticRecordingNode::checkAndHandleIfNeeded ();}if ((
Server::terminateCommandReceived ()and (not (isTerminateMode ())))){
setTerminateMode ();Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x53\x65\x6e\x64\x69\x6e\x67\x20\x73\x68\x75\x74\x64\x6f\x77\x6e\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);main::nxrequire (
"\x4e\x58\x52\x65\x64\x69\x73\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e");
NXRedisSubscription::publishToSubscribers (($GLOBAL::MSG_SHUTDOWN_TERMINATE.
"\x20\x53\x68\x75\x74\x64\x6f\x77\x6e\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x72\x65\x61\x73\x6f\x6e\x3d\x64\x61\x65\x6d\x6f\x6e\x20"
));main::nxrequire ("\x50\x68\x79\x73\x69\x63\x53\x65\x73\x73\x69\x6f\x6e\x73");
PhysicSessions::terminate ();NXLocalSession::terminateAllLocalSessions ();}
NXLocalSession::checkNodesToRemove ();
NXLocalSession::checkNodesToKillAfterTerminateSent ();
checkWaitingToLocalNodeRunWithSendStatus ();}Logger::debug (
"\x41\x66\x74\x65\x72\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x6d\x61\x69\x6e\x20\x6c\x6f\x6f\x70\x2e"
);NXEvent::beforeDaemonStop ();NXUpdate::shutdown ();main::nxrequire (
"\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c");NXFirewall::delFirewallRules ();if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){main::nxrequire (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c"
);NXWebInfoFilesControl::deleteAllInfoFiles ();}main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x43\x6c\x65\x61\x6e\x65\x72");NXNodeCleaner::collect 
();NXTerminate::waitForRunningSession ();NXTerminate::terminateLeftoverServers 
();if ($exception){$exception->notify;}}sub handleServicesMonitoring{
NXUpdate::checkUpdate ();main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");if ((
NXUpnp::isUPnPMapEnabled ()and NXUpnp::isUPnPEnabled ())){
NXUpnp::checkIfAddPortMapping ();}if ((NXLocate::isNXLocateEnabled ()and 
NXLocate::wasStarted ())){NXLocate::checkUpdate ();}if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){main::nxrequire (
"\x4e\x58\x57\x65\x62\x49\x6e\x66\x6f\x46\x69\x6c\x65\x73\x43\x6f\x6e\x74\x72\x6f\x6c"
);NXWebInfoFilesControl::checkService ();}foreach my $service (
@servicesToMonitoring){checkServiceAndRestartIfNecessary ($service);}}sub 
checkServiceAndRestartIfNecessary{(my $service=shift (@_));Logger::debug (((
"\x43\x68\x65\x63\x6b\x20\x73\x65\x72\x76\x69\x63\x65\x20\x61\x6e\x64\x20\x72\x65\x73\x74\x61\x72\x74\x20\x69\x66\x20\x6e\x65\x63\x65\x73\x73\x61\x72\x79\x3a\x20"
.$service)."\x2e"));if (NXSystemDaemons::isDisabled ($service)){return (
(0x0fd2+ 2717-0x1a6f));}if (NXSystemDaemons::isRunning ($service)){return (
(0x00c2+ 5434-0x15fc));}return (NXSystemDaemons::start ($service));}sub 
parseLocalNodeSocket{(my $socket=shift (@_));(my $read_buf=shift (@_));if (
isAcceptFDParsing ($socket)){addToAcceptFDBuffer ($socket,$read_buf);
Logger::debug (((
"\x70\x61\x72\x73\x65\x4c\x6f\x63\x61\x6c\x4e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74\x3a\x20\x53\x6b\x69\x70\x20\x70\x61\x72\x73\x69\x6e\x67\x20\x66\x6f\x72\x20\x46\x44\x23"
.$socket).
"\x20\x61\x6e\x6f\x74\x68\x65\x72\x20\x70\x61\x72\x73\x69\x6e\x67\x20\x69\x6e\x20\x70\x72\x6f\x67\x72\x65\x73\x73\x2e"
));return;}else{setAcceptFDParsing ($socket);}Logger::debug (((((
"\x50\x61\x72\x73\x65\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$read_buf)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$socket)."\x2e"));(my (@lines)=
split ( /\n/ ,$read_buf,(0x08e7+ 3459-0x166a)));foreach my $line (@lines){if ((
$line eq (""))){next;}if (($line=~ /NX> (\d+).*/ )){(my $messageNum=$1);if (
NXNodeExec::isMessageWithCodeHandledByNode ($messageNum)){Logger::debug (
"\x48\x61\x6e\x64\x6c\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x74\x6f\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x62\x79\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x2e"
);(my $currentNodeStdin=NXNodeExec::getstdin ());if (defined ($currentNodeStdin)
){Logger::debug (((
"\x53\x61\x76\x69\x6e\x67\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x20\x6e\x6f\x64\x65\x20\x73\x74\x64\x69\x6e\x3a\x20\x46\x44\x23"
.$currentNodeStdin)."\x2e"));}else{Logger::debug (
"\x53\x61\x76\x69\x6e\x67\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x20\x6e\x6f\x64\x65\x20\x73\x74\x64\x69\x6e\x3a\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x2e"
);}(my $stdin=NXLocalSession::getStdinForLocalNodeBasedOnSocket ($socket));if ((
$stdin==(-(0x1860+ 1636-0x1ec3)))){Logger::debug (((
"\x4e\x6f\x64\x65\x20\x6f\x62\x6a\x65\x63\x74\x20\x77\x61\x73\x20\x63\x6c\x65\x61\x6e\x65\x64\x20\x62\x65\x66\x6f\x72\x65\x20\x68\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$line)."\x27\x2e"));next;}NXNodeExec::setstdin ($stdin);(my $function=
NXNodeExec::getHandlerFunctionForMessageCodeFromNode ($messageNum));
Logger::debug (((("\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x3a\x20"
.$messageNum)."\x20\x77\x69\x74\x68\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x3a\x20"
).$function));&$function ($socket,$line);Logger::debug (
"\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x68\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x62\x79\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x2e"
);if (defined ($currentNodeStdin)){Logger::debug (((
"\x52\x65\x73\x74\x6f\x72\x69\x6e\x67\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x20\x6e\x6f\x64\x65\x20\x73\x74\x64\x69\x6e\x3a\x20\x46\x44\x23"
.$currentNodeStdin)."\x2e"));}else{Logger::debug (
"\x52\x65\x73\x74\x6f\x72\x69\x6e\x67\x20\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x20\x6e\x6f\x64\x65\x20\x73\x74\x64\x69\x6e\x3a\x20\x75\x6e\x64\x65\x66\x69\x6e\x65\x64\x2e"
);}NXNodeExec::setstdin ($currentNodeStdin);}else{if (
Common::NXMsg::isPackedMessageNumber ($messageNum)){(my ($indexString,
$rawMessage,@parameters)=Common::NXMsg::unpackResponse ($line));($messageNum=
Common::NXMsg::getNumber ($indexString));if (((not ($messageNum))and (
$rawMessage=~ /NX> (\d+).*/ ))){($messageNum=$1);}}if (
Common::NXMsg::isErrorMessageNumber ($messageNum)){NXNodeExec::setLastErrorLine 
($line);}}}}Logger::debug (((
"\x70\x61\x72\x73\x65\x4c\x6f\x63\x61\x6c\x4e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74\x3a\x20\x46\x69\x6e\x69\x73\x68\x65\x64\x20\x70\x61\x72\x73\x69\x6e\x67\x20\x66\x6f\x72\x20\x46\x44\x23"
.$socket)."\x2e"));clearAcceptFDParsing ($socket);(my $FDBuffer=
getAcceptFDBuffer ($socket));if (($FDBuffer ne (""))){clearAcceptFDBuffer (
$socket);Logger::debug (((
"\x70\x61\x72\x73\x65\x4c\x6f\x63\x61\x6c\x4e\x6f\x64\x65\x53\x6f\x63\x6b\x65\x74\x3a\x20\x52\x65\x73\x75\x6d\x65\x20\x70\x61\x72\x73\x69\x6e\x67\x20\x66\x6f\x72\x20\x46\x44\x23"
.$socket)."\x2e"));parseLocalNodeSocket ($socket,$FDBuffer);}}sub 
parseServerMonitor{(my $socket_fn=shift (@_));my ($line);(my $code=(-
(0x031f+ 1873-0x0a6f)));(my $body=(""));(my $clientSocket=(""));if ((
getAcceptFDBuffer ($socket_fn)=~ /^(.*?)\n(.*)$/s )){($line=$1);
setAcceptFDBuffer ($socket_fn,$2);}(my $logstr=main::hideOutput ($line));(my $logsbuff
=main::hideOutput (getAcceptFDBuffer ($socket_fn)));Logger::debug (((((
"\x50\x61\x72\x73\x65\x20\x64\x61\x65\x6d\x6f\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$logstr).
"\x27\x20\x69\x6e\x20\x62\x75\x66\x66\x65\x72\x20\x6c\x65\x66\x74\x20\x27").
$logsbuff)."\x27\x2e"));if (($line=~ /NX> (\d+) (.*)$/ )){($code=$1);($body=$2);
(my $logBody=($body||("")));(my $logCode=($code||("")));Logger::debug ((((((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x5b".
$logCode)."\x5d\x5b").$logBody)."\x5d\x20\x66\x72\x6f\x6d\x20\x46\x44\x23").
$socket_fn));if ((defined ($code)and ($code==(0x1612+ 200-0x12f3)))){return (
(0x03af+ 558-0x05dd));}elsif (($code==$GLOBAL::MSG_UPNP_DELETE)){main::nxrequire
 ("\x4e\x58\x55\x70\x6e\x70");return (NXUpnp::handleCodeDeleteUPnPMap (
$socket_fn,$body));}elsif (($code==$GLOBAL::MSG_UPNP_START)){main::nxrequire (
"\x4e\x58\x55\x70\x6e\x70");return (NXUpnp::handleCodeStartUPnPMap ($socket_fn,
$body));}elsif (($code==$GLOBAL::MSG_UPNP_STOP)){main::nxrequire (
"\x4e\x58\x55\x70\x6e\x70");return (NXUpnp::handleCodeStopUPnPMap ($socket_fn));
}elsif (($code==$GLOBAL::MSG_UPNP_STATUS_REQUEST)){main::nxrequire (
"\x4e\x58\x55\x70\x6e\x70");return (NXUpnp::handleCodeStatusUPnPMap ($socket_fn)
);}elsif (($code==$GLOBAL::MSG_UPNP_MAPPING_SERVICE)){main::nxrequire (
"\x4e\x58\x55\x70\x6e\x70");return (NXUpnp::handleUPnPSingleServiceMessage (
$socket_fn,$body));}elsif (($code==$GLOBAL::MSG_MCM_START)){
NXNodes::reloadNodesDB ();if (($body=~ /uuid=(\S+) / )){(my $uuid=$1);
NXLocalSession::startLocalSession ($uuid);}}elsif (($code==$GLOBAL::MSG_MCM_STOP
)){if (($body=~ /uuid=(\S+) / )){(my $uuid=$1);NXLocalSession::stopMonitoring (
$uuid);NXTerminate::terminateConnectionMonitor ($uuid);}}elsif (($code==
$GLOBAL::MSG_MCM_STANDBY)){NXTerminate::terminateConnectionMonitors ();}elsif ((
$code==$GLOBAL::MSG_MCM_FAILOVER)){NXNodes::reloadNodesDB ();
NXLocalSession::startConnectionMonitors ();}elsif (($code==
$GLOBAL::MSG_MCM_SESSION)){Logger::debug (((((
"\x52\x65\x63\x65\x69\x76\x65\x64\x3a\x20".$body).
"\x2e\x20\x43\x75\x72\x72\x65\x6e\x74\x6c\x79\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20"
).$connected)."\x2e"));if (($body=~ /disconnected (\d*)/ )){(
$connectedToRemoteNodes=($connectedToRemoteNodes-$1));}elsif (($body=~ /connected (\d*)/ )
){($connectedToRemoteNodes=($connectedToRemoteNodes+$1));}}elsif (($code==
$GLOBAL::MSG_ASK_FOR_SERVICES_STATUS)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x2e\x20\x42\x6f\x64\x79\x20\x69\x73\x20\x27"
.$body)."\x27"));(my $answer=prepareAnswerWithServicesStatus ($body));if (
clientIsWaitingForReply ($socket_fn)){Logger::debug (((
"\x41\x6e\x73\x77\x65\x72\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x20\x69\x73\x20\x27"
.$answer)."\x27"));main::nxwrite ($socket_fn,$answer);}return (
(0x087a+ 3589-0x167f));}elsif (($code==
$GLOBAL::MSG_ASK_FOR_SERVICES_STATUS_AND_RUN_IF_NEEDED)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x61\x6e\x64\x20\x72\x75\x6e\x20\x69\x66\x20\x6e\x65\x65\x64\x65\x64\x3a\x20"
.$body)."\x2e"));NXSystemDaemons::setEnabled ("\x6e\x78\x68\x74\x64");
NXSystemDaemons::setHandlingManualStart ("\x6e\x78\x68\x74\x64");
NXSystemDaemons::setEnabled ("\x6e\x78\x64");
NXSystemDaemons::setHandlingManualStart ("\x6e\x78\x64");if (
shouldNotWaitLocalSessionForStatusResponse ()){__runServicesIfNeeded ($body);}
else{Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x62\x65\x66\x6f\x72\x65\x20\x61\x6e\x79\x20\x6c\x6f\x63\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x69\x73\x20\x73\x74\x61\x72\x74\x65\x64\x2e\x20\x57\x61\x69\x74\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x2e"
);waitWithStatusResponseToNodeRun ($socket_fn,(0x01d6+ 2935-0x0d39),$body);
return ((0x109d+ 2705-0x1b2d));}(my $answer=
__prepareAnswerWithServicesStatusForStartupDontWaitForLocalNode ($body));if (
clientIsWaitingForReply ($socket_fn)){Logger::debug (((
"\x41\x6e\x73\x77\x65\x72\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x20\x61\x6e\x64\x20\x72\x75\x6e\x20\x69\x66\x20\x6e\x65\x65\x64\x65\x64\x3a\x20"
.$answer)."\x2e"));main::nxwrite ($socket_fn,$answer);}return (
(0x1952+ 992-0x1d32));}elsif (($code==$GLOBAL::MSG_ASK_FOR_DESKTOP_OWNER)){
Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x71\x75\x65\x72\x79\x20\x27"
.$body)."\x27\x2e"));if (clientIsWaitingForReply ($socket_fn)){(my $desktopOwner
=NXLocalSession::getActiveSessionOwner ());Logger::debug (((
"\x41\x6e\x73\x77\x65\x72\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x20\x69\x73\x20\x27"
.$desktopOwner)."\x27\x2e"));(my $message=(((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ASK_FOR_DESKTOP_OWNER).
"\x20\x44\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x20\x69\x73\x20").
main::urlencode ($desktopOwner))."\x20"));(my $bytes=main::nxwrite ($socket_fn,
$message));if (($bytes==(-(0x041f+ 6423-0x1d35)))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x61\x6e\x73\x77\x65\x72\x2e"
);}}else{Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x6e\x64\x20\x64\x65\x73\x6b\x74\x6f\x70\x20\x6f\x77\x6e\x65\x72\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x72\x65\x74\x72\x69\x65\x76\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x73\x6f\x63\x6b\x65\x74\x2e"
);}return ((0x037a+ 5394-0x188c));}elsif (($code==$GLOBAL::MSG_NXLOCATE_STOP)){
if (NXLocate::isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x77\x69\x6c\x6c\x20\x63\x6c\x6f\x73\x65\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65\x2e"
);if (($body eq "\x73\x74\x6f\x70")){NXLocate::close ();}else{
NXLocate::removeService ($body);}}}elsif (($code==$GLOBAL::MSG_NXLOCATE_START)){
if (NXLocate::isNXLocateEnabled ()){Logger::debug (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65\x20\x77\x69\x6c\x6c\x20\x72\x75\x6e\x20\x6e\x78\x6c\x6f\x63\x61\x74\x65\x2e"
);if (($body eq "\x73\x74\x61\x72\x74")){NXLocate::run ();}else{
NXLocate::addService ($body);}}}elsif (($code==
$GLOBAL::MSG_NXD_COMMAND_TO_SERVER_STARTUP_MONITOR)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x4e\x58\x44\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));return (handleNXDCommand ($body,$socket_fn));}elsif (($code==
$GLOBAL::MSG_ADMIN_MODE)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x41\x64\x6d\x69\x6e\x20\x4d\x6f\x64\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));return (handleAdminModeCommand ($body,$socket_fn));}elsif ((
$code==$GLOBAL::MSG_UPDATE_IGNORE_TO_SERVER_STARTUP_MONITOR)){if (($body ne ("")
)){NXUpdate::setUpdateIgnoreMessage ($body);notifyClientIfStillAvailable (
$socket_fn,$GLOBAL::NXUPDATE_IGNORE_COMMAND_SUCCESS);return (
(0x1e74+ 606-0x20d2));}else{Logger::debug (
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x4e\x58\x75\x70\x64\x61\x74\x65\x20\x69\x67\x6e\x6f\x72\x65\x2e"
);return ((0x150c+ 1061-0x1931));}}elsif (($code==
$GLOBAL::MSG_NXHTD_COMMAND_TO_SERVER_STARTUP_MONITOR)){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x4e\x58\x48\x54\x44\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);return (handleNXHTDCommand ($body,$socket_fn));}elsif (($code==
$GLOBAL::MSG_REGISTER_LOCAL_NODE_IN_SERVER_STARTUP_MONITOR)){(my $logBody=($body
||("")));Logger::debug (((
"\x4e\x65\x77\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x77\x69\x74\x68\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$logBody)."\x2e"));NXLocalSession::handleRegisterLocalSession ($socket_fn,
NXNodes::findLocalNode (),$body,getServerSocketPort (),getServerSocketCookie ())
;}elsif (($code==
$GLOBAL::MSG_REGISTER_LOCAL_NODE_IN_SERVER_STARTUP_MONITOR_AFTER_SERVER_CRASH)){
(my $logBody=($body||("")));Logger::debug (((
"\x4c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x72\x65\x67\x69\x73\x74\x65\x72\x65\x64\x20\x61\x66\x74\x65\x72\x20\x70\x72\x65\x76\x69\x6f\x75\x73\x20\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x20\x63\x72\x61\x73\x68\x65\x64\x20\x77\x69\x74\x68\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20"
.$logBody)."\x2e"));
NXLocalSession::handleRegisterLocalSessionAfterServerDaemonCrash ($socket_fn,
$body);}elsif (($code==$GLOBAL::MSG_FOREIGN_NODE_COOKIE_DISPLAY)){Logger::debug 
(
"\x4e\x65\x77\x20\x66\x6f\x72\x65\x69\x67\x6e\x20\x6e\x6f\x64\x65\x20\x72\x65\x67\x69\x73\x74\x65\x72\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x63\x6f\x6f\x6b\x69\x65\x20\x61\x6e\x64\x20\x64\x69\x73\x70\x6c\x61\x79\x2e"
);NXForeignSession::handleCookieAndDisplayRetrieved ($socket_fn,$body);}elsif ((
$code==$GLOBAL::MSG_START_VIRTUAL_SESSION_NODE)){Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x66\x6f\x72\x20\x63\x72\x65\x61\x74\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6e\x6f\x64\x65\x20\x70\x72\x6f\x63\x65\x73\x73\x2e"
);return (NXVirtualSession::createSessionNode ($socket_fn,$body));}elsif (($code
==$GLOBAL::MSG_ASK_ATTACH_ANSWER)){Logger::debug (
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e\x20\x72\x65\x73\x70\x6f\x6e\x73\x65\x2e"
);NXAsk4Attach::parseAuthorizationResponse ($body);}elsif (($code==
$GLOBAL::MSG_START_FRAME_BUFFER)){Logger::debug (
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x72\x65\x71\x75\x65\x73\x74\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x76\x69\x72\x74\x75\x61\x6c\x20\x66\x72\x61\x6d\x65\x20\x62\x75\x66\x66\x65\x72\x2e"
);main::nxrequire ("\x4e\x58\x46\x72\x61\x6d\x65\x42\x75\x66\x66\x65\x72");
NXFrameBuffer::handleRequestToStartNxFrameBuffer ($socket_fn,$body);}elsif ((
$code==$GLOBAL::MSG_DESKTOP_SHARING)){Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x70\x68\x79\x73\x69\x63\x61\x6c\x20\x73\x68\x61\x72\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));return (
NXUsersManager::sendSharingPhysicalToPhysicalSessionIfNeeded ($body,$socket_fn))
;}elsif (($code==$GLOBAL::MSG_ANYWHERE)){main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74");
Logger::debug ((("\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20".Server::getAnywhereName 
()).((
"\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e")));NXAnywhereDefault::handleClientMessage ($body,
(0x1a23+ 2480-0x23d2));return ((0x0792+ 105-0x07fb));}elsif (($code==
$GLOBAL::MSG_USER_CONNECTION_TO_MACHINE)){if (($body eq 
"\x55\x73\x65\x72\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64")){
handleDisconnectedFromMachine ();}elsif (($body eq 
"\x55\x73\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64")){
handleConnectedToMachine ();}else{Logger::warning (((
"\x52\x65\x63\x65\x69\x76\x65\x64\x20\x77\x72\x6f\x6e\x67\x20\x75\x73\x65\x72\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20\x27"
.$body)."\x27"));}return ((0x07bf+ 2594-0x11e0));}elsif (($code==
$GLOBAL::MSG_EMULATE_SYSTEM_EVENTS)){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x65\x6d\x75\x6c\x61\x74\x65\x20\x73\x79\x73\x74\x65\x6d\x20\x65\x76\x65\x6e\x74\x73\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);NXLocalSession::sendToActiveLocalNode ((("\x4e\x58\x3e\x20".
$GLOBAL::MSG_EMULATE_SYSTEM_EVENTS).
"\x20\x45\x6d\x75\x6c\x61\x74\x65\x20\x73\x79\x73\x74\x65\x6d\x20\x65\x76\x65\x6e\x74\x73\x20"
));return ((0x03b8+ 6648-0x1db0));}elsif (($code==
$GLOBAL::MSG_START_AUTOMATIC_RECORDING)){main::nxrequire (
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x4e\x6f\x64\x65"
);Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x72\x65\x63\x6f\x72\x64\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));NXAutomaticRecordingNode::startRecordSessionById ($body);return
 ((0x1562+ 1038-0x1970));}elsif (($code==$GLOBAL::MSG_STOP_AUTOMATIC_RECORDING))
{main::nxrequire (
"\x4e\x58\x41\x75\x74\x6f\x6d\x61\x74\x69\x63\x52\x65\x63\x6f\x72\x64\x69\x6e\x67\x4e\x6f\x64\x65"
);Logger::debug (((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x61\x75\x74\x6f\x6d\x61\x74\x69\x63\x20\x72\x65\x63\x6f\x72\x64\x69\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x74\x6f\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20"
.$body)."\x2e"));NXAutomaticRecordingNode::stopRecordSessionById ($body);return 
((0x1e59+ 1871-0x25a8));}elsif (
NXNodeExec::isMessageWithCodeHandledByServerSocket ($code)){Logger::debug (
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x6f\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x2e"
);(my $function=NXNodeExec::getHandlerFunctionForMessageCodeFromServerSocket (
$code));Logger::debug ((((
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x3a\x20".$code).
"\x20\x77\x69\x74\x68\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e\x3a\x20").$function));
&$function ($socket_fn,$line);Logger::debug (((
"\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x3a\x20\x66\x69\x6e\x69\x73\x68\x65\x64\x20\x68\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x64\x65\x3a\x20"
.$code).
"\x20\x6f\x6e\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x73\x6f\x63\x6b\x65\x74\x2e"))
;if ((((NXAsk4Attach::isAttachCandidate ($socket_fn)or 
NXAsk4Disconnect::isDisconnectCandidate ($socket_fn))or 
NXNodeConnectionMonitor::isNodeConnectionMonitorSocket ($socket_fn))or 
NXReconnect::isDisconnectSocket ($socket_fn))){return ((0x0ef6+ 107-0x0f60));}
return ((0x0590+ 3591-0x1397));}elsif (($code==$GLOBAL::MSG_CLUSTER_YIELD)){
Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6c\x75\x73\x74\x65\x72\x20\x79\x69\x65\x6c\x64\x2e"
);main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x61\x65\x6d\x6f\x6e");return (
NXClusterDaemon::acquire ($body,$socket_fn));}elsif (($code==
$GLOBAL::MSG_REDIS_YIELD)){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x72\x65\x64\x69\x73\x20\x79\x69\x65\x6c\x64\x2e"
);return (NXRedis::daemonAcquire ($body,$socket_fn));}elsif ((($code==
$GLOBAL::MSG_OTP_CREATE)or ($code==$GLOBAL::MSG_OTP_AUTH))){if (
NXLicense::isServerAvailableAsRemoteServer ()){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x6f\x6e\x65\x2d\x74\x69\x6d\x65\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);main::nxrequire (
"\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64");return (
NXOneTimePassword::parseMessage ($socket_fn,$body));}else{Logger::error (
"\x53\x65\x72\x76\x65\x72\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x20\x74\x6f\x6b\x65\x6e\x20\x72\x65\x6d\x6f\x74\x65\x20\x73\x65\x72\x76\x65\x72\x2e"
);return ((0x052f+ 5104-0x191f));}}elsif (($code==
$GLOBAL::MSG_PROPAGATION_RULES_AND_SESSION_ID)){if (
NXLicense::isServerAvailableAsRemoteServer ()){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x70\x72\x6f\x70\x61\x67\x61\x74\x69\x6f\x6e\x20\x72\x75\x6c\x65\x73\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);main::nxrequire (
"\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64");return (
NXOneTimePassword::parsePropagationRulesAndSessionIDRequest ($socket_fn,$body));
}}elsif (($code==$GLOBAL::MSG_NCM_NAME)){if (
NXLicense::isServerAvailableAsRemoteServer ()){Logger::debug (
"\x48\x61\x6e\x64\x6c\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x66\x6f\x72\x20\x74\x6f\x6b\x65\x6e\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);main::nxrequire (
"\x4e\x58\x4f\x6e\x65\x54\x69\x6d\x65\x50\x61\x73\x73\x77\x6f\x72\x64");return (
NXOneTimePassword::parseNCMNameRequest ($socket_fn,$body));}}elsif (($code==
$GLOBAL::MSG_2FA_REQUEST)){main::nxrequire (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x44\x61\x65\x6d\x6f\x6e");return (
NXTwoFactorDaemon::parseMessage ($socket_fn,$body));}elsif (($code==
$GLOBAL::MSG_SUBSCRIBE_TO_DAEMON)){main::nxrequire (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72"
);return (NXDaemonSubscriptionManager::addSubscription ($socket_fn,$body));}
elsif (($code==$GLOBAL::MSG_CM_REVERSE_RUNNING)){main::nxrequire (
"\x4e\x58\x52\x65\x76\x65\x72\x73\x65\x43\x6c\x69\x65\x6e\x74\x44\x61\x65\x6d\x6f\x6e"
);return (NXReverseClientDaemon::handleConnection ($socket_fn,$body));}elsif ((
$code==$GLOBAL::MSG_DEBUG_LOG_LEVEL)){main::nxrequire (
"\x4e\x58\x44\x65\x62\x75\x67\x4d\x61\x6e\x61\x67\x65\x72");return (
NXDebugManager::handleDebugLogLevelMessage ($body));}elsif (($code==
$GLOBAL::MSG_MCM_START_SYSTEM_LOAD_SCRIPT)){saveReportSystemLoadReceivedFd (
$socket_fn);main::nxrequire ("\x4e\x58\x53\x63\x72\x69\x70\x74\x73");
NXScripts::runNXReportSystemLoadScript ();return ((0x2264+ 152-0x22fb));}elsif (
($code==$GLOBAL::MSG_LICENSE_CHANGE)){NXLicense::handleLicenseChanged ();return 
((0x0896+ 2388-0x11ea));}elsif (($code==$GLOBAL::MSG_UPDATE_UUID)){if (($body=~ /newuuid=(\S+) olduuid=(\S+)/ )
){(my $uuid=$1);(my $oldUuid=$2);if ((($uuid ne (""))and ($oldUuid ne ("")))){
main::nxrequire ("\x4e\x58\x53\x65\x72\x76\x65\x72\x73");NXServers::setNewUuid (
$uuid,$oldUuid);NXConnectionMonitor::propagateMap ();}}return (
(0x01c0+ 9054-0x251e));}elsif (($code==$GLOBAL::MSG_UPDATE_PARENT_UUID)){if ((
$body=~ /parent uuid change newuuid=(\S+) olduuid=(\S+)/ )){(my $uuid=$1);(my $oldUuid
=$2);if ((($uuid ne (""))and ($oldUuid ne ("")))){
NXLocalSession::updateConnectionMonitorUUIDs ($oldUuid,$uuid);
NXNodes::reloadNodesDB ();}return ((0x1319+ 895-0x1698));}return (
(0x0a18+ 6471-0x235f));}elsif (($code==$GLOBAL::MSG_ASK_FOR_NODEDEL_ON_PARENT)){
if (($body=~ /Delete node nodeuuid=(\S+) / )){(my $uuid=$1);if (($uuid ne ("")))
{NXNodes::runNodeDelForNodeRequest ($uuid);NXNodes::reloadNodesDB ();}}return (
(0x05e3+ 6837-0x2098));}elsif (($code==$GLOBAL::MSG_TERMINATE_SESSION)){if ((
$body=~ /sessionID=(\S+) / )){(my $sessionID=$1);if (($sessionID ne (""))){
NXLocalSession::terminateLocalSession ($sessionID);}else{Logger::debug (((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x49\x44\x20\x65\x6d\x70\x74\x79\x20\x69\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x27"
.$body)."\x27\x2e"));}}return ((0x1909+ 1013-0x1cfe));}elsif (($code==
$GLOBAL::MSG_SOFTWARE_UPDATE)){main::nxrequire (
"\x4e\x58\x53\x6f\x66\x74\x77\x61\x72\x65\x55\x70\x64\x61\x74\x65\x44\x61\x65\x6d\x6f\x6e"
);if (NXSoftwareUpdateDaemon::handleRequest ($socket_fn,$body)){return (
(0x0e31+ 3548-0x1c0d));}removeFdFromSelector ($socket_fn);return (
(0x0ccb+ 2891-0x1815));}elsif (($code==$GLOBAL::MSG_DAEMON_RESTART)){
NXSystemDaemons::handleRestartRequest ($socket_fn,$body);removeFdFromSelector (
$socket_fn);return ((0x094a+ 5564-0x1f05));}elsif (($code==
$GLOBAL::MSG_CHECK_GUESTS_EXPIRY_DATE)){checkGuestsExpiryDate ();}elsif (($code
==$GLOBAL::MSG_DAEMON_RUN_COMMAND_REQUEST)){return (runCommandAsDaemon (
$socket_fn,$body));}elsif (($code==$GLOBAL::MSG_CLUSTER_STATUS)){main::nxrequire
 ("\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x61\x65\x6d\x6f\x6e");
NXClusterDaemon::handleStatusRequest ($socket_fn);return ((0x0527+ 5300-0x19db))
;}elsif (($code==$GLOBAL::UDP_COMMUNICATION)){main::nxrequire (
"\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");if (
NXUdpControl::handleDaemonCommunicationRequest ($socket_fn,$body)){return (
(0x1217+ 2907-0x1d72));}removeFdFromSelector ($socket_fn);return (
(0x1c0d+ 1087-0x204b));}elsif (($code==$GLOBAL::UDP_FORWARDER)){main::nxrequire 
("\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");
NXUdpControl::handleDaemonForwarderRequest ($socket_fn,$body);return (
(0x0bb9+ 5665-0x21da));}elsif (($code==$GLOBAL::UDP_COMMUNICATION_CLOSE)){
main::nxrequire ("\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");
NXUdpControl::handleDaemonCommunicationCloseRequest ($socket_fn,$body);return (
(0x07bb+  15-0x07ca));}elsif (($code==$GLOBAL::MSG_DAEMON_PRESHUTDOWN)){
preShutdown ();return ((0x1611+ 4220-0x268d));}else{(my $logBody=($body||("")));
($logBody=main::hideOutput ($logBody));Logger::debug (((((
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x6d\x65\x73\x73\x61\x67\x65\x3a\x20\x27".
$logBody)."\x27\x20\x6f\x6e\x20\x46\x44\x23").$socket_fn)."\x2e"));return (
(0x0c29+ 3824-0x1b19));}}else{Logger::warning (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x72\x65\x71\x75\x65\x73\x74\x20\x27"
.$logstr)."\x27\x2e"));}return ((0x0f94+ 483-0x1176));}sub preShutdown{
Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x50\x72\x65\x73\x68\x75\x74\x64\x6f\x77\x6e\x2e"
);main::nxrequire (
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73");
NXSystemDaemons::setPreshutdown ();main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x6c\x53\x65\x73\x73\x69\x6f\x6e");
NXLocalSession::terminateAllLocalSessions ();main::nxrequire (
"\x4e\x58\x43\x6c\x75\x73\x74\x65\x72\x44\x61\x65\x6d\x6f\x6e");
NXClusterDaemon::destroy ();if (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()){NXSystemDaemons::stop (
"\x6e\x78\x68\x74\x64");}NXSystemDaemons::resetPreshutdown ();}sub 
handleNXDCommand{(my $body=shift (@_));(my $socket_fn=shift (@_));if (($body eq 
$GLOBAL::NXD_COMMAND_START)){if (NXSystemDaemons::isRunning ("\x6e\x78\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXD_COMMAND_ALREADY_DONE);
return ((0x03a5+ 3973-0x132a));}Server::updateMyCfg ();
NXSystemDaemons::setEnabled ("\x6e\x78\x64");
NXSystemDaemons::setHandlingManualStart ("\x6e\x78\x64");NXSystemDaemons::start 
("\x6e\x78\x64");if (NXSystemDaemons::isRunning ("\x6e\x78\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXD_COMMAND_SUCCESS);if (
NXLocate::isNXLocateEnabled ()){NXLocate::addService ("\x6e\x78\x64");}return (
(0x1f64+ 1382-0x24ca));}else{notifyClientIfStillAvailable ($socket_fn,
$GLOBAL::NXD_COMMAND_FAILURE);return ((0x02e3+ 9050-0x263d));}}elsif (($body eq 
$GLOBAL::NXD_COMMAND_STOP)){if ((not (NXSystemDaemons::isRunning ("\x6e\x78\x64"
)))){notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXD_COMMAND_ALREADY_DONE)
;return ((0x1c4a+ 2628-0x268e));}NXSystemDaemons::stop ("\x6e\x78\x64");if (
NXSystemDaemons::isRunning ("\x6e\x78\x64")){notifyClientIfStillAvailable (
$socket_fn,$GLOBAL::NXD_COMMAND_FAILURE);return ((0x213f+ 1408-0x26bf));}else{
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXD_COMMAND_SUCCESS);if (
NXLocate::isNXLocateEnabled ()){NXLocate::removeService ("\x6e\x78\x64");}return
 ((0x009a+ 5445-0x15df));}}else{Logger::debug (
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x4e\x58\x44\x2e"
);return ((0x00c1+ 4479-0x1240));}}sub handleAdminModeCommand{(my $body=shift (
@_));(my $socket=shift (@_));Logger::debug (((((
"\x68\x61\x6e\x64\x6c\x65\x20\x41\x64\x6d\x69\x6e\x20\x4d\x6f\x64\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20"
.$body)."\x20\x6f\x6e\x20\x46\x44\x23").$socket)."\x2e"));if (($body=~ /^enable (.*)/ )
){__handleEnableAdminMode ($1,$socket);}elsif (($body=~ /^disable (.*)/ )){
__handleDisableAdminMode ($1,$socket);}elsif (($body=~ /^connected (.*)/ )){
__handleConnectedSessionInAdminMode ($1,$socket);}elsif (($body=~ /^disconnected (.*)/ )
){handleDisconnectedSessionInAdminMode ($1,$socket);}else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x70\x61\x72\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x2c\x20\x72\x65\x63\x65\x69\x76\x65\x64\x20\x77\x72\x6f\x6e\x67\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x3a\x20"
.$body)."\x2e"));}return ((0x0d23+ 2882-0x1865));}sub __handleEnableAdminMode{(my $sessionId
=shift (@_));(my $socket=shift (@_));NXSession2::setAdminModeBySessionId (
$sessionId,(0x0aa9+ 4861-0x1da5));if (($sessionId eq Server::getMySessionID ()))
{($serversInAdminMode{$sessionId}=(-(0x0217+ 3326-0x0f14)));main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXConnectedUsersManager::sendAllAddedUserToClient ();}else{(my $fh=
main::send_command_to_server ($sessionId,($GLOBAL::MSG_ENABLE_ADMIN."\x20"),
"\x6e\x6f\x74\x63\x6c\x6f\x73\x65"));if (($fh==(-(0x043a+ 4820-0x170d)))){
main::nxwrite ($socket,"\x66\x61\x69\x6c\x65\x64");return;}else{(
$serversInAdminMode{$sessionId}=$fh);}}(my $fd=main::nxopen ($adminModeFlag,(
$NXBits::O_WRONLY+$NXBits::O_CREAT),(($NXBits::UserReadWrite+$NXBits::GroupRead)
+$NXBits::OthersRead)));if ((not (defined ($fd)))){main::nxwrite ($socket,
"\x66\x61\x69\x6c\x65\x64");}else{main::nxclose ($fd);main::nxwrite ($socket,
"\x64\x6f\x6e\x65");}}sub __handleDisableAdminMode{(my $sessionId=shift (@_));(my $socket
=shift (@_));if ((not (defined ($serversInAdminMode{$sessionId})))){
main::nxwrite ($socket,"\x6e\x6f\x74\x20\x65\x78\x69\x73\x74");}else{
NXSession2::setAdminModeBySessionId ($sessionId,(0x0cdb+ 3266-0x199d));if ((
$serversInAdminMode{$sessionId}!=(-(0x18bb+ 2156-0x2126)))){main::nxclose (
$serversInAdminMode{$sessionId});}($serversInAdminMode{$sessionId}=undef);delete
 ($serversInAdminMode{$sessionId});if ((not (%$serversInAdminMode))){unlink (
$adminModeFlag);}main::nxwrite ($socket,"\x64\x6f\x6e\x65");}}sub 
__handleConnectedSessionInAdminMode{(my $sessionId=shift (@_));(my $socket=shift
 (@_));foreach my $fh (values (%serversInAdminMode)){Logger::debug ((
"\x73\x65\x6e\x64\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20\x74\x6f\x20\x41\x64\x6d\x69\x6e\x20\x4d\x6f\x64\x65\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$fh));if (($fh==(-(0x0043+ 7676-0x1e3e)))){(my ($username,$ip,$createTime,
$display,$cookie,$client,$shadowMode,$nodeName,$type,$shadowModeCfg)=
NXSession2::getClientMonitorParameters ($sessionId));(my (%session)=(
"\x75\x73\x65\x72\x6e\x61\x6d\x65",$username,"\x49\x50",$ip,
"\x63\x72\x65\x61\x74\x69\x6f\x6e\x54\x69\x6d\x65",$createTime,
"\x64\x69\x73\x70\x6c\x61\x79",$display,"\x63\x6f\x6f\x6b\x69\x65",$cookie,
"\x63\x6c\x69\x65\x6e\x74",$client,"\x73\x68\x61\x64\x6f\x77\x4d\x6f\x64\x65",
$shadowMode,"\x6e\x6f\x64\x65",$nodeName,
"\x73\x68\x61\x64\x6f\x77\x4d\x6f\x64\x65\x43\x66\x67",$shadowModeCfg));
main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXConnectedUsersManager::sendAddUserToClient ((\%session));}else{if ((
main::nxwrite ($fh,(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ADMIN_MODE).
"\x20\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20").$sessionId)."\x0a"))==(-
(0x0cc9+ 6653-0x26c5)))){main::nxwrite ($socket,"\x66\x61\x69\x6c\x65\x64");}}}
main::nxwrite ($socket,"\x64\x6f\x6e\x65");}sub 
handleDisconnectedSessionInAdminMode{(my $message=shift (@_));(my $socket=shift 
(@_));foreach my $fh (values (%serversInAdminMode)){if (($fh==(-
(0x07c2+ 6083-0x1f84)))){main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x65\x64\x55\x73\x65\x72\x73\x4d\x61\x6e\x61\x67\x65\x72"
);NXConnectedUsersManager::sendDelUserToClient ($message);}else{if ((
main::nxwrite ($fh,(((("\x4e\x58\x3e\x20".$GLOBAL::MSG_ADMIN_MODE).
"\x20\x64\x69\x73\x63\x6f\x6e\x6e\x65\x63\x74\x65\x64\x20").$message)."\x0a"))==
(-(0x0ca3+ 4739-0x1f25)))){if (defined ($socket)){main::nxwrite ($socket,
"\x66\x61\x69\x6c\x65\x64");}}}}if (defined ($socket)){main::nxwrite ($socket,
"\x64\x6f\x6e\x65");}}sub handleNXHTDCommand{(my $body=shift (@_));(my $socket_fn
=shift (@_));if (($body eq $GLOBAL::NXHTD_COMMAND_START)){if (
NXSystemDaemons::isRunning ("\x6e\x78\x68\x74\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_ALREADY_DONE);
return ((0x0850+ 481-0x0a31));}NXSystemDaemons::setEnabled (
"\x6e\x78\x68\x74\x64");NXSystemDaemons::setHandlingManualStart (
"\x6e\x78\x68\x74\x64");NXSystemDaemons::start ("\x6e\x78\x68\x74\x64");if (
NXSystemDaemons::isRunning ("\x6e\x78\x68\x74\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_SUCCESS);if (
NXLocate::isNXLocateEnabled ()){NXLocate::addService ("\x6e\x78\x68\x74\x64");}}
else{notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_FAILURE);}
return ((0x213f+ 807-0x2466));}elsif (($body eq $GLOBAL::NXHTD_COMMAND_STOP)){if
 ((not (NXSystemDaemons::isRunning ("\x6e\x78\x68\x74\x64")))){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_ALREADY_DONE);
return ((0x1778+ 1631-0x1dd7));}NXSystemDaemons::stop ("\x6e\x78\x68\x74\x64");
if (NXSystemDaemons::isRunning ("\x6e\x78\x68\x74\x64")){
notifyClientIfStillAvailable ($socket_fn,$GLOBAL::NXHTD_COMMAND_FAILURE);}else{
if (NXLocate::isNXLocateEnabled ()){NXLocate::removeService (
"\x6e\x78\x68\x74\x64");}notifyClientIfStillAvailable ($socket_fn,
$GLOBAL::NXHTD_COMMAND_SUCCESS);}return ((0x01a8+ 1088-0x05e8));}elsif (($body 
eq $GLOBAL::NXHTD_COMMAND_STATUS)){if (NXSystemDaemons::isRunning (
"\x6e\x78\x68\x74\x64")){notifyClientIfStillAvailable ($socket_fn,
$GLOBAL::NXHTD_COMMAND_SUCCESS);}else{notifyClientIfStillAvailable ($socket_fn,
$GLOBAL::NXHTD_COMMAND_FAILURE);}return ((0x0925+ 174-0x09d3));}else{
Logger::debug (
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x66\x6f\x72\x20\x4e\x58\x48\x54\x44\x2e"
);return ((0x0a03+ 5836-0x20cf));}}sub checkLocalSessionIsEnabled{if ((
NXNodes::isLocalNodeInDatabase ()and 
NXLocalSession::isPhysicalDesktopAvailableInConfig ())){return (
(0x0f43+ 4539-0x20fd));}return ((0x132f+ 2868-0x1e63));}sub 
__prepareAnswerWithServicesStatusForStartupDontWaitForLocalNode{(my $list=shift 
(@_));return (__prepareAnswerWithServicesStatusForStartup ($list,
(0x1921+ 3005-0x24dd)));}sub 
__prepareAnswerWithServicesStatusForStartupOrWaitForLocalNode{(my $list=shift (
@_));return (__prepareAnswerWithServicesStatusForStartup ($list,
(0x0172+ 7461-0x1e97)));}sub __prepareAnswerWithServicesStatusForStartup{(my $list
=shift (@_));(my $dontWait=shift (@_));if ((not (defined ($dontWait)))){(
$dontWait=(0x030b+ 3698-0x117d));}(my (@services)=split ( / / ,$list,
(0x08af+ 7481-0x25e8)));(my $answer=("\x4e\x58\x3e\x20".
$GLOBAL::MSG_ASK_FOR_SERVICES_STATUS_AND_RUN_IF_NEEDED));foreach my $service (
@services){($answer.=(("\x20".$service)."\x20"));if (($service eq 
"\x6e\x78\x6e\x6f\x64\x65")){(my $nodeShouldBeRunning=checkLocalSessionIsEnabled
 ());if ($nodeShouldBeRunning){if (NXLocalSession::localSessionsRunning ()){(
$answer.="\x45\x6e\x61\x62\x6c\x65\x64");}else{if ($dontWait){if (
NXLocalSession::localSessionsRunning ()){($answer.=
"\x45\x6e\x61\x62\x6c\x65\x64");}else{($answer.=
"\x4e\x6f\x74\x52\x75\x6e\x6e\x69\x6e\x67");}}else{return (undef);}}}else{(
$answer.="\x44\x69\x73\x61\x62\x6c\x65\x64");}}else{if (
NXSystemDaemons::isServiceEnabled ($service)){if (NXSystemDaemons::isRunning (
$service,(0x05bc+ 3158-0x1211))){($answer.="\x45\x6e\x61\x62\x6c\x65\x64");}else
{($answer.="\x4e\x6f\x74\x52\x75\x6e\x6e\x69\x6e\x67");}}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}($answer.="\x2c");}($answer=~ s/,$// );(
$answer.="\x0a");return ($answer);}sub __runServicesIfNeededExceptNode{(my $list
=shift (@_));($list=~ s/ nxnode// );($list=~ s/nxnode // );($list=~ s/nxnode// )
;return (__runServicesIfNeeded ($list));}sub __runServicesIfNeeded{(my $list=
shift (@_));(my (@services)=split ( / / ,$list,(0x0883+ 1998-0x1051)));foreach my $service
 (@services){if (($service eq "\x6e\x78\x6e\x6f\x64\x65")){(my $nodeShouldBeRunning
=checkLocalSessionIsEnabled ());if ($nodeShouldBeRunning){
NXLocalSession::enableRestartNode ();if ((NXLocalSession::localSessionsRunning 
()==(0x0300+ 7647-0x20df))){
NXLocalSession::findFirstAvailableXserverAndRunSession ();}}}else{if (
NXSystemDaemons::isServiceEnabled ($service)){NXSystemDaemons::setSilentMode (
$service);checkServiceAndRestartIfNecessary ($service);}}}return (
(0x0921+ 1514-0x0f0a));}sub prepareAnswerWithServicesStatus{(my $list=shift (@_)
);(my $answer=("\x4e\x58\x3e\x20".$GLOBAL::MSG_ASK_FOR_SERVICES_STATUS));(my (
@services)=split ( / / ,$list,(0x1062+ 873-0x13cb)));foreach my $service (
@services){($answer.=(("\x20".$service)."\x20"));if (($service eq 
"\x6e\x78\x6e\x6f\x64\x65")){(my $nodeShouldBeRunning=checkLocalSessionIsEnabled
 ());if ($nodeShouldBeRunning){if (NXLocalSession::localSessionsRunning ()){(
$answer.="\x45\x6e\x61\x62\x6c\x65\x64");}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}else{if (NXSystemDaemons::isServiceEnabled
 ($service)){if (NXSystemDaemons::isRunning ($service,(0x1502+ 1614-0x1b4f))){(
$answer.="\x45\x6e\x61\x62\x6c\x65\x64");}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}else{($answer.=
"\x44\x69\x73\x61\x62\x6c\x65\x64");}}($answer.="\x2c");}($answer=~ s/,$// );(
$answer.="\x0a");return ($answer);}sub getPort{return (getServerSocketPort ());}
sub getCookie{return (getServerSocketCookie ());}sub delaySessionList{
Logger::debug (
"\x53\x63\x68\x65\x64\x75\x6c\x69\x6e\x67\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x6c\x69\x73\x74\x20\x61\x73\x20\x73\x6f\x6f\x6e\x20\x61\x73\x20\x70\x6f\x73\x73\x69\x62\x6c\x65\x2e"
);($checkLocalSessionDelayed=(0x1545+ 466-0x1716));}sub 
checkIsTimeForNewSessionList{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());(my $delay=
getCheckLocalSessionLoopDelay ());if ($checkLocalSessionScheduled){(
$lastCheckLocalSessionTime=$currentTime);($checkLocalSessionScheduled=
(0x01a2+ 5190-0x15e8));return ((0x0499+ 6389-0x1d8d));}if (((
$lastCheckLocalSessionTime+$delay)<$currentTime)){if ($checkLocalSessionDelayed)
{($checkLocalSessionDelayed=(0x0666+ 4957-0x19c3));}($lastCheckLocalSessionTime=
$currentTime);return ((0x0c3c+ 300-0x0d67));}else{return ((0x06b3+ 459-0x087e));
}}sub initializeCheckLocalSessionTime{(my $currentTime=
Common::NXTime::getSecondsSinceEpoch ());($lastCheckLocalSessionTime=
$currentTime);}sub getCheckLocalSessionLoopDelay{(my $delay=
$checkLocalSessionLoopDelay[$currentCheckLocalSessionLoopDelay]);if (
$checkLocalSessionDelayed){($delay=$GLOBAL::checkLocalSessionDelay);}return (
$delay);}sub increaseCheckLocalSessionLoopDelay{if (((
$currentCheckLocalSessionLoopDelay+(0x07eb+ 4317-0x18c7))<scalar (
@checkLocalSessionLoopDelay))){($currentCheckLocalSessionLoopDelay+=
(0x21e3+ 446-0x23a0));}}sub restartCheckLocalSessionDelayCounter{(
$currentCheckLocalSessionLoopDelay=(0x0e88+ 630-0x10fe));}sub 
isAnyLocalSessionFound{if (($currentCheckLocalSessionLoopDelay==
(0x0e14+ 2108-0x1650))){return ((0x0b42+ 1177-0x0fda));}else{return (
(0x1408+ 1229-0x18d5));}}sub isTerminateMode{return ($terminateMode);}sub 
setTerminateMode{($terminateMode=(0x0e0a+ 5220-0x226d));($terminateReceivedTime=
Common::NXTime::getSecondsSinceEpoch ());Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x53\x65\x74\x74\x69\x6e\x67\x20\x74\x65\x72\x6d\x69\x6e\x61\x74\x65\x20\x6d\x6f\x64\x65\x2e"
);}sub getNewTimeoutForRead{(my $time=Common::NXTime::getSecondsSinceEpoch ());my (
$newTimeout);if (isTerminateMode ()){($newTimeout=((($terminateReceivedTime+
$GLOBAL::timeoutForLocalSessionTerminate)-$time)*(0x1332+ 5592-0x2522)));}else{(
$newTimeout=($servicesMonitoringDelay *(0x1e14+ 1856-0x216c)));Logger::debug (((
"\x4e\x65\x78\x74\x20\x73\x65\x72\x76\x69\x63\x65\x73\x20\x63\x68\x65\x63\x6b\x20\x69\x6e\x20"
.$newTimeout)."\x20\x6d\x73\x2e"));if (NXClusterDaemon::isStartupInProgress ()){
(my $clusterDelay=NXClusterDaemon::getTimeoutForStartup ());if (($newTimeout>
$clusterDelay)){($newTimeout=$clusterDelay);}}if (
NXUpnp::isRepeatMappingInProgress ()){(my $upnpDelay=
NXUpnp::getTimeoutForRepeatMapping ());if (($newTimeout>$upnpDelay)){(
$newTimeout=$upnpDelay);}}}if (($newTimeout<(0x1371+ 2665-0x1dd9))){($newTimeout
=(0x0924+ 536-0x0ad8));}Logger::debug (((
"\x4e\x65\x77\x20\x74\x69\x6d\x65\x6f\x75\x74\x3a\x20".$newTimeout).
"\x20\x6d\x73\x2e"));return ($newTimeout);}sub serverSocket_parser{(my $socket=
getServerSocket ());if (defined ($socket)){(my $new_sock=main::nxAcceptSocket (
$socket));addAcceptedFdToSystemSelector ($new_sock);}}sub 
serverSocketAccepted_parser{(my $f=shift (@_));(my $auth=
"\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64");if ((isAuthorizedConnectionOnFD ($f)
==(0x0295+ 8404-0x2369))){($auth=
"\x75\x6e\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64");}Logger::debug (((((((
"\x53\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x20\x70\x61\x72\x73\x65\x72\x20\x66\x6f\x72\x20"
.$auth)."\x20\x46\x44\x23").$f)."\x20\x27").$listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$f}{
"\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e"})."\x27\x2e"));if (
isDefinedClientHandlerOnSocket ($f)){(my $readBuffer=(""));(my $bufferSize=
(0x1459+ 5974-0x1baf));(my $readSize=$bufferSize);while (($readSize==$bufferSize
)){(my $read=(""));($readSize=main::nxread ($f,(\$read),$bufferSize));(
$readBuffer.=$read);}if (((not (defined ($readSize)))or ($readSize==
(0x0536+ 4048-0x1506)))){main::nxrequire ("\x4e\x58\x55\x70\x6e\x70");
main::nxrequire ("\x4e\x58\x55\x64\x70\x43\x6f\x6e\x74\x72\x6f\x6c");
main::nxrequire (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x44\x61\x65\x6d\x6f\x6e");
main::nxrequire (
"\x4e\x58\x44\x61\x65\x6d\x6f\x6e\x53\x75\x62\x73\x63\x72\x69\x70\x74\x69\x6f\x6e\x4d\x61\x6e\x61\x67\x65\x72"
);Logger::debug (((
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23".$f).
"\x20\x77\x61\x73\x20\x63\x6c\x6f\x73\x65\x64\x2e"));removeClientFDFromSelector 
($f);if (NXLocalSession::isLocalNodeSocket ($f)){
NXLocalSession::handleLocalNodeClosedSocket ($f);}elsif (
isSocketWaitingForLocalNodeStatus ($f)){
handleSocketWaitingForLocalNodeStatusClosed ($f);}elsif (
NXNodeConnectionMonitor::isNodeConnectionMonitorSocket ($f)){
NXNodeConnectionMonitor::handleConnectionToNCMLost ($f);}elsif (
NXTwoFactorDaemon::isRequestSocket ($f)){NXTwoFactorDaemon::handleSocketClosed (
$f);}elsif (NXDaemonSubscriptionManager::isSubscriptionSocket ($f)){
NXDaemonSubscriptionManager::handleCloseSubscription ($f);}elsif (
NXUpnp::isUPnPSocket ($f)){NXUpnp::handleUPnPSocketOnClose ($f);}elsif (
isReportSystemLoadFD ($f)){removeReportSystemLoadFD ($f);}elsif (
NXUdpControl::isRequestSocket ($f)){NXUdpControl::handleRequestSocketOnClose ($f
);}main::nxclose ($f);}else{(my $logLine=main::hideOutput ($readBuffer));
Logger::debug ((((((("\x52\x65\x61\x64\x20\x27".$logLine)."\x27\x2c\x20").
$readSize)."\x20\x62\x79\x74\x65\x73\x20\x66\x72\x6f\x6d\x20\x46\x44\x23").$f).
"\x2e"));if ((isAuthorizedConnectionOnFD ($f)==(0x07f2+ 702-0x0ab0))){
Logger::debug ((("\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x46\x44\x23".$f).
"\x20\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x2c\x20\x79\x65\x74\x2e"
));if ((handleSlaveMessage ($readBuffer,$f)==(0x0012+ 6751-0x1a70))){return;}if 
((handleUnauthorizedConnection ((\$readBuffer),$f)==(0x0c0d+ 588-0x0e59))){
return;}}if (NXLocalSession::isLocalNodeSocket ($f)){addToAcceptFDBuffer ($f,
$readBuffer);(my $FDBuffer=getAcceptFDBuffer ($f));clearAcceptFDBuffer ($f);
parseLocalNodeSocket ($f,$FDBuffer);return;}else{addToAcceptFDBuffer ($f,
$readBuffer);}while (isCommandToParseInFDBuffer ($f)){if ((parseServerMonitor (
$f)==(0x12b8+ 1019-0x16b3))){removeClientFDFromSelector ($f);clearAcceptFDBuffer
 ($f);main::nxclose ($f);next;}if (NXLocalSession::isLocalNodeSocket ($f)){(my $FDBuffer
=getAcceptFDBuffer ($f));clearAcceptFDBuffer ($f);parseLocalNodeSocket ($f,
$FDBuffer);}}}return;}else{Logger::warning (((
"\x73\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x41\x63\x63\x65\x70\x74\x65\x64\x5f\x70\x61\x72\x73\x65\x72\x3a\x20\x74\x72\x79\x69\x6e\x67\x20\x74\x6f\x20\x70\x61\x72\x73\x65\x20\x6d\x65\x73\x73\x61\x67\x65\x20\x66\x72\x6f\x6d\x20\x61\x6e\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x61\x63\x63\x65\x70\x74\x65\x64\x20\x68\x61\x6e\x64\x6c\x65\x3a\x20\x27"
.$f)."\x27\x2e"));}}sub handleUnauthorizedConnection{(my $bufferRef=shift (@_));
(my $f=shift (@_));Logger::debug (((
"\x41\x75\x74\x68\x6f\x72\x69\x7a\x69\x6e\x67\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$f)."\x2e"));(my $cookie=substr ($$bufferRef,(0x0bfc+ 5374-0x20fa),length ((
"\x4e\x58\x3e\x20".getServerSocketCookie ()))));($$bufferRef=substr ($$bufferRef
,length (("\x4e\x58\x3e\x20".getServerSocketCookie ()))));($cookie=~ s/NX> // );
if (isServerSocketCookie ($cookie)){Logger::debug (((
"\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x64\x20\x6f\x6e\x20\x46\x44\x23"
.getClientHandler ($f))."\x2e"));authorizeConnectionOnFD ($f);($$bufferRef=~ s/NX> $cookie// )
;if (((not (defined ($$bufferRef)))or ($$bufferRef eq ("")))){return (
(0x13ef+ 3533-0x21bc));}($$bufferRef=~ s/^\n// );if ((not (($$bufferRef=~ /^NX>/ )
))){($$bufferRef=("\x4e\x58\x3e".$$bufferRef));}return ((0x080d+ 2962-0x139e));}
else{Logger::warning (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x63\x6c\x69\x65\x6e\x74\x20\x6f\x6e\x20\x46\x44\x23"
.$f)."\x2e"));removeClientFDFromSelector ($f);main::nxclose ($f);return (
(0x0065+ 7992-0x1f9d));}}sub handleSlaveMessage{(my $buffer=shift (@_));(my $f=
shift (@_));if (($buffer=~ /^NXCLIENT-(.*) cookie=(.*),command=get,target=local,option=(.*)/ )
){Logger::debug (
"\x53\x6c\x61\x76\x65\x20\x66\x72\x6f\x6d\x20\x6e\x78\x72\x75\x6e\x6e\x65\x72\x2e"
);SlaveServer::handleGetCommand ($f,$buffer);return ((0x13b8+ 3887-0x22e6));}}
sub stopServerDaemonListen{if (defined ($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"})){
Common::NXSelector::removeFromGlobalSelector ($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"});main::nxclose ($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"});}if ((defined ($listenSocket{
"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"})and ($listenSocket{
"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}ne ("")))){(my $fileName=((
$listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}.
$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6f\x6b\x69\x65"));unlink ($fileName);
Logger::debug ((("\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20".$fileName).
"\x20\x66\x69\x6c\x65"));($fileName=(($listenSocket{
"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}.$GLOBAL::DIRECTORY_SLASH).
"\x70\x6f\x72\x74"));unlink ($fileName);Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20".$fileName)."\x20\x66\x69\x6c\x65"));(
$listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}=(""));}(my $path=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x64\x62").$GLOBAL::DIRECTORY_SLASH
)."\x73\x65\x72\x76\x65\x72"));(my $redisPortFile=main::get_redis_port ($path));
unlink ($redisPortFile);libnxhs::NXRedisServerListenerDestroy ();}sub 
removeServerDaemonPidFile{if (($ServerDaemonLockFileHandle!=(-
(0x1274+ 2272-0x1b53)))){main::nxclose ($ServerDaemonLockFileHandle);(
$ServerDaemonLockFileHandle=(-(0x01e0+ 558-0x040d)));}(my $filename=
$GLOBAL::ServerDaemonLockFilePath);if ((Common::NXFile::isExists ($filename)and 
(not (unlink ($filename))))){Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x75\x6e\x6c\x69\x6e\x6b\x20\x66\x69\x6c\x65\x20".
$filename)."\x3a\x20").$!));}else{Logger::debug (((
"\x55\x6e\x6c\x69\x6e\x6b\x65\x64\x20\x66\x69\x6c\x65\x20".$filename)."\x2e"));}
}sub setServerDaemonLockFileHandle{($ServerDaemonLockFileHandle=shift (@_));}sub
 __startServerDaemonListen{if (((not (defined ($listenSocket{"\x70\x6f\x72\x74"}
)))or ($listenSocket{"\x70\x6f\x72\x74"}eq ("")))){($listenSocket{
"\x70\x6f\x72\x74"}=NXTools::getUniquePort ());if (($listenSocket{
"\x70\x6f\x72\x74"}<(0x0340+ 8864-0x25e0))){Logger::error (
"\x43\x61\x6e\x6e\x6f\x74\x20\x67\x65\x74\x20\x70\x6f\x72\x74\x20\x66\x6f\x72\x20\x6c\x69\x73\x74\x65\x6e\x69\x6e\x67\x2e"
);return ((0x1121+ 1646-0x178f));}}if (((not (defined ($listenSocket{
"\x63\x6f\x6f\x6b\x69\x65"})))or ($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"}eq 
("")))){($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"}=main::get_unique_id ());}if (
((not (defined ($listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"})))or (
$listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}eq ("")))){(
$listenSocket{"\x6f\x70\x74\x69\x6f\x6e\x73\x44\x69\x72"}=
__saveServerDaemonOptionsFile ());}($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"}=main::nxListenOnSocket ($listenSocket{
"\x70\x6f\x72\x74"}));if (($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"}<
(0x112d+ 3107-0x1d50))){($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"}=undef
);return ((0x0a50+ 6421-0x2365));}addServerSocketToSelector ();Logger::debug (((
"\x53\x74\x61\x72\x74\x65\x64\x20\x6c\x69\x73\x74\x65\x6e\x69\x6e\x67\x20\x6f\x6e\x20\x70\x6f\x72\x74\x20"
.$listenSocket{"\x70\x6f\x72\x74"})."\x2e"));
libnxhs::NXRedisServerListenerCreate (Logger::setLogFile (),
$GLOBAL::SessionLogLevel,NXTools::getUniquePort (),$listenSocket{
"\x63\x6f\x6f\x6b\x69\x65"});return ((0x049d+ 2128-0x0cec));}sub 
__saveServerDaemonOptionsFile{(my $path=(((($GLOBAL::VAR_ROOT.
$GLOBAL::DIRECTORY_SLASH)."\x64\x62").$GLOBAL::DIRECTORY_SLASH).
"\x73\x65\x72\x76\x65\x72"));(my $serverDaemonCookieFile=(($path.
$GLOBAL::DIRECTORY_SLASH)."\x63\x6f\x6f\x6b\x69\x65"));(my $serverDaemonPortFile
=(($path.$GLOBAL::DIRECTORY_SLASH)."\x70\x6f\x72\x74"));(my $OPF=main::nxopen (
$serverDaemonCookieFile,($NXBits::O_WRONLY+$NXBits::O_CREAT),
$NXBits::UserReadWrite));if ((not (defined ($OPF)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20".
$serverDaemonCookieFile)."\x2e"));Logger::debug (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));return;}main::nxwrite ($OPF,$listenSocket{
"\x63\x6f\x6f\x6b\x69\x65"});main::nxclose ($OPF);($OPF=main::nxopen (
$serverDaemonPortFile,($NXBits::O_WRONLY+$NXBits::O_CREAT),
$NXBits::UserReadWrite));if ((not (defined ($OPF)))){(my $errorNumber=
libnxh::NXGetError ());(my $errorstring=libnxh::NXGetErrorString ());
Logger::debug (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x3a\x20".
$serverDaemonPortFile)."\x2e"));Logger::debug (((((
"\x45\x72\x72\x6f\x72\x20\x69\x73\x3a\x20".$errorNumber)."\x2c\x20").
$errorstring)."\x2e"));return;}main::nxwrite ($OPF,$listenSocket{
"\x70\x6f\x72\x74"});main::nxclose ($OPF);return ($path);}sub getServerSocket{
return ($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"});}sub 
removeSocketFromMonitoring{(my $socket=shift (@_));Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x46\x44\x23".$socket).
"\x20\x66\x72\x6f\x6d\x20\x64\x61\x65\x6d\x6f\x6e\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"
));$selector->remove ($socket);Logger::debug (((
"\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x46\x44\x23".$socket).
"\x20\x66\x72\x6f\x6d\x20\x67\x6c\x6f\x62\x61\x6c\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"
));Common::NXSelector::removeFromGlobalSelector ($socket);delete ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$socket});}sub 
removeSocketFromMonitoringIfExist{(my $socket=shift (@_));if (defined ($selector
)){if ($selector->exists ($socket)){removeSocketFromMonitoring ($socket);return 
((0x12e9+ 4591-0x24d7));}}return ((0x0d27+ 4933-0x206c));}sub addFdToSelector{(my $new_sock
=shift (@_));if ((defined ($new_sock)and ($new_sock ne ("")))){if (defined (
$listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"})){$selector->add ($new_sock);}
}}sub isClientFDInSelector{(my $socket=shift (@_));if ((defined ($selector)and (
$socket ne ("")))){if ($selector->exists ($socket)){return (
(0x036f+ 7118-0x1f3c));}}return ((0x18b7+ 424-0x1a5f));}sub 
removeClientFDFromSelector{(my $socket=shift (@_));if ((defined ($socket)and (
$socket ne ("")))){if (defined ($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"
})){$selector->remove ($socket);Common::NXSelector::removeFromGlobalSelector (
$socket);delete ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$socket});}}}sub 
removeFdFromSelector{(my $socket=shift (@_));if ((defined ($socket)and ($socket 
ne ("")))){if (defined ($listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"})){
$selector->remove ($socket);}}}sub addServerSocketToSelector{if (defined (
$listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"})){$selector->add (
$listenSocket{"\x73\x6f\x63\x6b\x65\x74\x46\x44"});
Common::NXSelector::addToGlobalSelector ($listenSocket{
"\x73\x6f\x63\x6b\x65\x74\x46\x44"},
"\x73\x65\x72\x76\x65\x72\x20\x64\x61\x65\x6d\x6f\x6e\x27\x73\x20\x73\x6f\x63\x6b\x65\x74"
,
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x3a\x73\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x5f\x70\x61\x72\x73\x65\x72"
);}}sub addAcceptedFdToSystemSelector{(my $new_sock=shift (@_));(my $description
=(shift (@_)||"\x72\x65\x67\x75\x6c\x61\x72\x20\x68\x61\x6e\x64\x6c\x65"));if ((
defined ($new_sock)and ($new_sock ne ("")))){Logger::debug (((
"\x41\x63\x63\x65\x70\x74\x65\x64\x20\x6e\x65\x77\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6f\x6e\x20\x46\x44\x23"
.$new_sock)."\x2e"));Logger::debug (((
"\x41\x64\x64\x69\x6e\x67\x20\x63\x75\x73\x74\x6f\x6d\x20\x68\x61\x6e\x64\x6c\x65\x20\x66\x6f\x72\x20\x46\x44\x23"
.$new_sock).
"\x20\x74\x6f\x20\x6d\x6f\x6e\x69\x74\x6f\x72\x69\x6e\x67\x20\x68\x61\x73\x68\x2e"
));($listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{
$new_sock}={"\x66\x68",$new_sock,"\x61\x63\x63\x65\x70\x74\x65\x64",
(0x1654+ 1727-0x1d13),"\x62\x75\x66\x66\x65\x72",(""),
"\x64\x65\x73\x63\x72\x69\x70\x74\x69\x6f\x6e",$description,
"\x70\x61\x72\x73\x69\x6e\x67",(0x0310+ 3429-0x1075)});$selector->add ($new_sock
);Common::NXSelector::addToGlobalSelector ($new_sock,
"\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x27\x73\x20\x73\x6f\x63\x6b\x65\x74\x20\x61\x63\x63\x65\x70\x74\x65\x64\x20\x68\x61\x6e\x64\x6c\x65"
,
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x3a\x73\x65\x72\x76\x65\x72\x53\x6f\x63\x6b\x65\x74\x41\x63\x63\x65\x70\x74\x65\x64\x5f\x70\x61\x72\x73\x65\x72"
);}}sub authorizeConnectionOnFD{(my $socketToAuthorize=shift (@_));(
$listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{
$socketToAuthorize}{"\x61\x63\x63\x65\x70\x74\x65\x64"}=(0x0af8+ 3410-0x1849));}
sub isAuthorizedConnectionOnFD{(my $socketToAuthorize=shift (@_));return (
$listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{
$socketToAuthorize}{"\x61\x63\x63\x65\x70\x74\x65\x64"});}sub 
isDefinedClientHandlerOnSocket{(my $socket=shift (@_));if (defined (
$listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{
$socket})){return ((0x02fc+ 3574-0x10f1));}return ((0x011a+ 6792-0x1ba2));}sub 
clientIsWaitingForReply{(my $clientSocket=shift (@_));(my $socket=$listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$clientSocket});if (
(defined ($socket)and ($socket ne ("")))){return ((0x0481+ 6476-0x1dcc));}return
 ((0x13cd+ 2228-0x1c81));}sub notifyClientIfStillAvailable{(my $socket=shift (@_
));(my $msg=shift (@_));if (clientIsWaitingForReply ($socket)){main::nxwrite (
$socket,$msg);}}sub addDBusIfEnabled{if (NXDbusMonitor::isRunning ()){
addFdToSelector (NXDbusMonitor::getStdout ());Logger::debug (
"\x41\x64\x64\x65\x64\x20\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x68\x61\x6e\x64\x6c\x65\x20\x74\x6f\x20\x73\x65\x6c\x65\x63\x74\x6f\x72\x2e"
);}else{Logger::debug (
"\x44\x42\x75\x73\x2d\x6d\x6f\x6e\x69\x74\x6f\x72\x20\x6e\x6f\x74\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);}}sub getServerSocketPort{return ($listenSocket{"\x70\x6f\x72\x74"});}sub 
getServerSocketCookie{if (((not (defined ($listenSocket{
"\x63\x6f\x6f\x6b\x69\x65"})))or ($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"}eq 
("")))){($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"}=main::get_unique_id ());}
return ($listenSocket{"\x63\x6f\x6f\x6b\x69\x65"});}sub isServerSocketCookie{(my $cookie
=shift (@_));if (($cookie eq $listenSocket{"\x63\x6f\x6f\x6b\x69\x65"})){return 
((0x0e03+ 4889-0x211b));}return ((0x15f9+ 3902-0x2537));}sub isAcceptFDParsing{(my $fd
=shift (@_));if (defined ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x70\x61\x72\x73\x69\x6e\x67"})){return ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x70\x61\x72\x73\x69\x6e\x67"});}else{return ((0x2221+ 1066-0x264b));}}sub 
setAcceptFDParsing{(my $fd=shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x70\x61\x72\x73\x69\x6e\x67"}=(0x0856+ 2310-0x115b));}sub clearAcceptFDParsing
{(my $fd=shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x70\x61\x72\x73\x69\x6e\x67"}=(0x07b2+ 1944-0x0f4a));}sub clearAcceptFDBuffer{
(my $fd=shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}=(""));}sub getAcceptFDBuffer{(my $fd=shift (@_));
return ($listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"
}{$fd}{"\x62\x75\x66\x66\x65\x72"});}sub isCommandToParseInFDBuffer{(my $fd=
shift (@_));if (((defined ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"})and ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}ne ("")))and ($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}=~ /\n/ ))){return ((0x00a8+ 6635-0x1a92));}return (
(0x053f+ 8604-0x26db));}sub addToAcceptFDBuffer{(my $fd=shift (@_));(my $buffer=
shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}.=$buffer);}sub setAcceptFDBuffer{(my $fd=shift (@_))
;(my $buffer=shift (@_));($listenSocket{
"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"}{$fd}{
"\x62\x75\x66\x66\x65\x72"}=$buffer);}sub getClientHandler{(my $f=shift (@_));
return ($listenSocket{"\x63\x6c\x69\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72\x73"
}{$f}{"\x66\x68"});}sub waitWithStatusResponseToNodeRun{(my $socket_fn=shift (@_
));(my $timeout=shift (@_));(my $serviceName=shift (@_));Logger::debug (((
"\x77\x61\x69\x74\x57\x69\x74\x68\x53\x74\x61\x74\x75\x73\x52\x65\x73\x70\x6f\x6e\x73\x65\x54\x6f\x4e\x6f\x64\x65\x52\x75\x6e\x3a\x20\x57\x61\x69\x74\x20\x74\x6f\x20\x72\x65\x67\x69\x73\x74\x65\x72\x20\x6c\x6f\x63\x61\x6c\x20\x6e\x6f\x64\x65\x20\x77\x69\x74\x68\x20\x74\x69\x6d\x65\x6f\x75\x74\x20"
.$timeout)."\x2e"));__addClientDescriptorWaitingForLocalNodeStatus ($socket_fn,
$timeout,$serviceName);}sub checkWaitingToLocalNodeRunWithSendStatus{(my $currectTime
=Common::NXTime::getSecondsSinceEpoch ());foreach my $socket (keys (
%$clientDescriptorsWaitingForStatusReport)){(my $timestamp=
__getTimestampForSocketWaitingForLocalNodeStatus ($socket));if (($currectTime>
$timestamp)){__raportServicesStatusAndCloseConnection ($socket);}}}sub 
handleSocketWaitingForLocalNodeStatusClosed{(my $socket=shift (@_));if (((
$socket ne (""))and ($socket!=(-(0x186a+ 1772-0x1f55))))){
__removeSocketWaitingForLocalNodeStatus ($socket);}}sub 
__raportServicesStatusAndCloseConnection{(my $socket=shift (@_));(my $services=
__getServicesWaitingForLocalNodeStatus ($socket));
__removeSocketWaitingForLocalNodeStatus ($socket);
__runServicesIfNeededExceptNode ($services,(0x04dd+ 5843-0x1baf));if (
clientIsWaitingForReply ($socket)){(my $answer=
__prepareAnswerWithServicesStatusForStartupDontWaitForLocalNode ($services));
Logger::debug (((
"\x41\x6e\x73\x77\x65\x72\x20\x66\x6f\x72\x20\x73\x65\x72\x76\x69\x63\x65\x20\x73\x74\x61\x74\x75\x73\x20\x71\x75\x65\x72\x79\x20\x69\x73\x20\x27"
.$answer)."\x27"));main::nxwrite ($socket,$answer);}clearAcceptFDBuffer ($socket
);removeClientFDFromSelector ($socket);main::nxclose ($socket);}sub 
responseToAllServicesStatusAndCloseConnection{if (
shouldNotWaitLocalSessionForStatusResponse ()){foreach my $socket (keys (
%$clientDescriptorsWaitingForStatusReport)){
__raportServicesStatusAndCloseConnection ($socket);}}}sub 
__addClientDescriptorWaitingForLocalNodeStatus{(my $socket=shift (@_));(my $timeout
=shift (@_));(my $serviceName=shift (@_));(my $timestamp=
Common::NXTime::getSecondsSinceEpoch ());($timestamp=($timestamp+$timeout));(
$$clientDescriptorsWaitingForStatusReport{$socket}={
"\x73\x65\x72\x76\x69\x63\x65\x73",$serviceName,
"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70",$timestamp});}sub 
__getServicesWaitingForLocalNodeStatus{(my $socket=shift (@_));return (
$$clientDescriptorsWaitingForStatusReport{$socket}{
"\x73\x65\x72\x76\x69\x63\x65\x73"});}sub 
__getTimestampForSocketWaitingForLocalNodeStatus{(my $socket=shift (@_));return 
($$clientDescriptorsWaitingForStatusReport{$socket}{
"\x74\x69\x6d\x65\x73\x74\x61\x6d\x70"});}sub isSocketWaitingForLocalNodeStatus{
(my $socket=shift (@_));if (defined ($$clientDescriptorsWaitingForStatusReport{
$socket})){return ((0x15c2+ 2468-0x1f65));}return ((0x130f+ 1570-0x1931));}sub 
__removeSocketWaitingForLocalNodeStatus{(my $socket=shift (@_));delete (
$$clientDescriptorsWaitingForStatusReport{$socket});}sub 
__isWaitingForLocalNodeRun{if (scalar (keys (
%$clientDescriptorsWaitingForStatusReport))){return ((0x0036+ 6610-0x1a07));}
return ((0x039d+ 1501-0x097a));}sub isAdminModeEnabled{if (
Common::NXFile::isExists ($adminModeFlag)){return ((0x19c1+ 3369-0x26e9));}
return ((0x015b+ 2811-0x0c56));}sub getConnectionNumber{return (
$connectedToRemoteNodes);}sub getConnectionToLocalhostNumber{return (
$connectedToLocalhost);}sub setConnectionToLocalhostNumber{(my $connections=
NXSession2::getConnectionsToLocalhostWithSession ());($connectedToLocalhost=
$connections);}sub __setDaemonInitializing{($initializing=(0x1adc+ 589-0x1d28));
}sub __setDaemonInitialized{($initializing=(0x02ac+ 4218-0x1326));}sub 
isDaemonInitialized{if (($initializing==(0x0d3b+ 944-0x10eb))){return (
(0x0a45+ 3667-0x1897));}return ((0x0629+ 6772-0x209d));}sub 
shouldNotWaitLocalSessionForStatusResponse{if (((not (checkLocalSessionIsEnabled
 ()))or NXLocalSession::isAnyLocalSessionStarted ())){return (
(0x0bbd+ 6284-0x2448));}if (NXLocalSession::isStartSessionServersFinished ()){
return ((0x0947+ 7487-0x2685));}return ((0x1249+ 1159-0x16d0));}sub 
saveServerDaemonLangEnvInDb{(my $envLang=libnxh::NXTransGetEnvironment (
"\x4c\x41\x4e\x47"));if ((defined ($envLang)and ($envLang ne ("")))){
NXRedis::sendToDb (((
"\x63\x6f\x6d\x6d\x61\x6e\x64\x3d\x73\x65\x74\x2c\x73\x65\x72\x76\x69\x63\x65\x3d\x64\x62\x2c\x6b\x65\x79\x3d\x65\x6e\x76\x2e\x6c\x61\x6e\x67\x2c\x76\x61\x6c\x75\x65\x3d"
.$envLang)."\x0a"));}}sub handleDisconnectedFromMachine{($connectedToLocalhost-=
(0x0fd5+ 4551-0x219b));main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74");
NXAnywhereDefault::sendConnections ($connectedToLocalhost);}sub 
handleConnectedToMachine{($connectedToLocalhost+=(0x0d11+ 5033-0x20b9));
main::nxrequire (
"\x4e\x58\x41\x6e\x79\x77\x68\x65\x72\x65\x44\x65\x66\x61\x75\x6c\x74");
NXAnywhereDefault::sendConnections ($connectedToLocalhost);}((%systemLoadFds)=()
);sub saveReportSystemLoadReceivedFd{(my $FD=shift (@_));Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x53\x61\x76\x65\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x46\x44\x23"
.$FD)."\x2e"));($systemLoadFds{$FD}=$FD);}sub isReportSystemLoadRequestReceived{
if (%systemLoadFds){Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x53\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x72\x65\x63\x65\x69\x76\x65\x64\x2e"
);return ((0x0122+ 657-0x03b2));}Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x4e\x6f\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
);return ((0x0003+ 197-0x00c8));}sub isReportSystemLoadFD{(my $FD=shift (@_));if
 ((defined ($systemLoadFds{$FD})and ($systemLoadFds{$FD}>(0x013b+ 9631-0x26da)))
){Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x46\x44\x23".
$FD).
"\x20\x69\x73\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x2e"
));return ((0x0324+ 7147-0x1f0e));}return ((0x0bd0+ 5391-0x20df));}sub 
removeReportSystemLoadFD{(my $FD=shift (@_));Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x52\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x79\x73\x74\x65\x6d\x2d\x6c\x6f\x61\x64\x20\x73\x63\x72\x69\x70\x74\x20\x72\x65\x71\x75\x65\x73\x74\x20\x46\x44\x23"
.$FD)."\x2e"));($systemLoadFds{$FD}=undef);delete ($systemLoadFds{$FD});if ((not
 (NXScripts::isRunNXReportSystemLoadScriptEnabled ()))){
NXScripts::terminateNXReportSystemLoadScriptIfRunning ();}}sub 
setSendErrorToAdmin{($errorToAdmin=shift (@_));}sub getErrorToAdmin{return (
$errorToAdmin);}sub isSendErrorToAdminMode{if (($errorToAdmin eq (""))){return (
(0x1ddb+  96-0x1e3b));}return ((0x0f3a+ 4774-0x21df));}sub checkGuestsExpiryDate
{Logger::debug (
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x63\x68\x65\x63\x6b\x69\x6e\x67\x20\x67\x75\x65\x73\x74\x73\x20\x65\x78\x70\x69\x72\x79\x20\x64\x61\x74\x65\x2e"
);(my (@keys)=());(my (@arguments)=());push (@arguments,
"\x67\x75\x65\x73\x74\x73");main::nxrequire (
"\x4e\x58\x52\x65\x64\x69\x73\x53\x63\x72\x69\x70\x74");(my $returnValue=
NXRedisScript::executeScript (
"\x67\x65\x74\x41\x6c\x6c\x44\x61\x74\x61\x46\x72\x6f\x6d\x53\x65\x74",(\@keys),
(\@arguments)));($returnValue=~ s/^"// );($returnValue=~ s/"$// );(my (
@guestsData)=split ( /" "/ ,$returnValue,(0x0429+ 6030-0x1bb7)));(my $current=
Common::NXTime::getSecondsSinceEpoch ());foreach my $guest (@guestsData){if (((
$guest=~ /^\s*$/ )or ($guest eq ("")))){Logger::warning (
"\x4e\x6f\x64\x65\x20\x67\x6f\x74\x20\x63\x6f\x72\x72\x75\x70\x74\x65\x64\x20\x64\x61\x74\x61\x2e\x20\x53\x6b\x69\x70\x70\x69\x6e\x67\x2e"
);next;}(my (%hash)=split ( / / ,$guest,(0x0714+ 1847-0x0e4b)));if (($hash{
"\x65\x78\x70\x69\x72\x65"}le $current)){Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x64\x65\x6c\x65\x74\x69\x6e\x67\x20\x65\x78\x70\x69\x72\x65\x64\x20\x75\x73\x65\x72\x20"
.$hash{"\x6c\x6f\x67\x69\x6e"})."\x2e"));NXShell::handle_command (
"\x67\x75\x65\x73\x74\x64\x65\x6c",$hash{"\x6c\x6f\x67\x69\x6e"});}elsif ((not (
NXEvent::isEventExist (NXEvent::getGuestExpiryDateEventName ($hash{
"\x6c\x6f\x67\x69\x6e"}))))){Logger::debug (((
"\x4e\x58\x53\x65\x72\x76\x65\x72\x44\x61\x65\x6d\x6f\x6e\x3a\x20\x63\x72\x65\x61\x74\x69\x6e\x67\x20\x6e\x65\x77\x20\x65\x76\x65\x6e\x74\x20\x66\x6f\x72\x20\x67\x75\x65\x73\x74\x20"
.$hash{"\x6c\x6f\x67\x69\x6e"})."\x2e"));NXEvent::createEventOnTimeAndSubscribe 
(NXEvent::getGuestExpiryDateEventName ($hash{"\x6c\x6f\x67\x69\x6e"}),$hash{
"\x65\x78\x70\x69\x72\x65"},
"\x4e\x58\x45\x76\x65\x6e\x74\x3a\x3a\x61\x66\x74\x65\x72\x47\x75\x65\x73\x74\x45\x78\x70\x69\x72\x65\x64"
);NXUsersManager::reloadUsersDB ();}}}sub runCommandAsDaemon{(my $socketToReply=
shift (@_));(my $messageBody=shift (@_));my ($commandToRun);my (%parameters);if 
(($messageBody=~ /command=(.*) parameters=(.*)/ )){($commandToRun=$1);(my $urlParams
=$2);((%parameters)=NXShell::urlParameter2Hash ($urlParams));}else{
Logger::warning (((
"\x55\x6e\x6b\x6e\x6f\x77\x6e\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x20\x72\x65\x71\x75\x65\x73\x74\x3a\x20"
.$messageBody)."\x2e"));return ((0x05fb+ 7744-0x243a));}(my $currentSTDOUT=
main::nxgetSTDOUT ());(my $currentLang=Common::NXTranslator::getLanguage ());if 
(($parameters{"\x6c\x61\x6e\x67"}eq "\x43")){($parameters{"\x6c\x61\x6e\x67"}=
"\x65\x6e\x5f\x55\x53");}if ((($parameters{"\x6c\x61\x6e\x67"}ne (""))and (
$parameters{"\x6c\x61\x6e\x67"}ne $currentLang))){Common::NXTranslator::init (
$parameters{"\x6c\x61\x6e\x67"});}($parameters{
"\x6f\x75\x74\x70\x75\x74\x53\x6f\x63\x6b\x65\x74"}=$socketToReply);
__checkParametersForDaemonRequest ((\%parameters));NXShell::handle_command (
$commandToRun,%parameters);if ((main::nxwrite (main::nxgetSTDOUT (),((
"\x4e\x58\x3e\x20".$GLOBAL::MSG_DAEMON_RUN_COMMAND_REQUEST).
"\x20\x46\x69\x6e\x69\x73\x68\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x0a"))==(-
(0x023b+ 1415-0x07c1)))){NXShell::setExitRequest ($ExitRequests::closedSTDOUT);
return ((-(0x20c9+ 539-0x22e3)));}__cleanStdOutAfterRequestDaemonCommand (
$currentSTDOUT);if ((($parameters{"\x6c\x61\x6e\x67"}ne (""))and ($parameters{
"\x6c\x61\x6e\x67"}ne $currentLang))){Common::NXTranslator::init ($currentLang);
}removeFdFromSelector ($socketToReply);return ((0x0841+ 6286-0x20cf));}sub 
prepareStdOutForRequestDaemonCommand{(my $sock=shift (@_));
Common::NXCore::nxsetSTDOUT ($sock);Server::setConnectionTypeSTD ();
NXShell::setIgnoreExitRequestForDaemonCommands ((0x064d+ 8176-0x263c));}sub 
__cleanStdOutAfterRequestDaemonCommand{(my $previousSocket=shift (@_));
Server::setConnectionType ("\x44\x49\x53\x43\x4f\x4e\x4e\x45\x43\x54\x45\x44");
Common::NXCore::nxsetSTDOUT ($previousSocket);
NXShell::setIgnoreExitRequestForDaemonCommands ((0x05ba+ 7891-0x248d));}sub 
__checkParametersForDaemonRequest{(my $ref_parameters=shift (@_));if (((not (
defined ($$ref_parameters{"\x65\x78\x74\x65\x6e\x64\x65\x64"})))or (
$$ref_parameters{"\x65\x78\x74\x65\x6e\x64\x65\x64"}eq ("")))){($$ref_parameters
{"\x65\x78\x74\x65\x6e\x64\x65\x64"}=(0x0f7a+ 5686-0x25b0));}if (((not (defined 
($$ref_parameters{"\x61\x6c\x6c"})))or ($$ref_parameters{"\x61\x6c\x6c"}eq (""))
)){($$ref_parameters{"\x61\x6c\x6c"}=(0x05dd+ 632-0x0855));}if (((not (defined (
$$ref_parameters{"\x74\x72\x65\x65"})))or ($$ref_parameters{"\x74\x72\x65\x65"}
eq ("")))){($$ref_parameters{"\x74\x72\x65\x65"}=(0x10e9+ 5098-0x24d3));}if (((
not (defined ($$ref_parameters{"\x72\x61\x77"})))or ($$ref_parameters{
"\x72\x61\x77"}eq ("")))){($$ref_parameters{"\x72\x61\x77"}=
(0x02f9+ 4469-0x146e));}}"\x3f\x3f\x3f";
