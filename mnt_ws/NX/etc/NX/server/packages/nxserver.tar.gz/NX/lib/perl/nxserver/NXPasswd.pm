############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXPasswd;no warnings;$pass_STDIN;$pass_WRITE;$user;$passPid;(
$SystemPasswordChanged=(0x1d9c+ 1391-0x230b));($Correct=(0x0af6+ 5040-0x1ea6));(
$WrongFormat=(0x0148+ 3636-0x0f7b));($Mismatch=(0x2419+  86-0x246d));(
$nxshellMode=(0x1578+ 3903-0x24b7));($consoleMode=(0x0b02+ 4698-0x1d5b));($mode=
$consoleMode);($passSavedGuestPassword=(0x0526+ 3478-0x12bc));($guestPassword=
(""));($filterMessages=(0x03d2+ 1138-0x0844));($filterMessagesUseradd=
(0x0465+ 5040-0x1814));($filterMessagesGuest=(0x09e1+ 3644-0x181b));(
$filterMessagesOkta=(0x0469+ 6108-0x1c42));($oktaPassword=(""));sub 
handleSystemPasswd{($user=shift (@_));__resetSystemPasswordChanged ();runPasswd 
();readStdin ();changeNXPasswordAsk ($user);__resetParameters ();}sub 
handleSystemPasswdByConsole{(my $user=shift (@_));__setConsoleMode ();return (
handleSystemPasswd ($user));}sub handleSystemPasswdByNXShell{(my $user=shift (@_
));__setNXShellMode ();return (handleSystemPasswd ($user));}sub runPasswd{
createPasswdPipe ();my (@command,@parameters);if (__isNXShellMode ()){push (
@command,$GLOBAL::CommandNXexec);push (@command,$GLOBAL::SCRIPT_NXPASSWD);push (
@command,$user);push (@parameters,
"\x75\x73\x65\x20\x73\x63\x72\x69\x70\x74\x20\x74\x6f\x20\x6b\x69\x6c\x6c");}
else{push (@command,(((($GLOBAL::NODE_ROOT.$GLOBAL::DIRECTORY_SLASH).
"\x62\x69\x6e").$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x73\x65\x72\x76\x65\x72"));
push (@command,"\x2d\x2d\x70\x61\x73\x73\x77\x64");push (@command,$user);push (
@command,"\x2d\x2d\x73\x79\x73\x74\x65\x6d");}push (@command,
"\x2d\x2d\x72\x75\x6e\x70\x61\x73\x73\x77\x64");push (@parameters,
"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x69\x6e",$pass_WRITE);push (
@parameters,"\x75\x73\x65\x20\x61\x73\x20\x73\x74\x64\x6f\x75\x74",$pass_WRITE);
push (@parameters,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x69\x6e\x20\x6f\x70\x65\x6e");push (
@parameters,
"\x6c\x65\x61\x76\x65\x20\x73\x74\x64\x6f\x75\x74\x20\x6f\x70\x65\x6e");push (
@parameters,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x44\x49\x53\x50\x4c\x41\x59\x3d\x3a".$ENV{
"\x44\x49\x53\x50\x4c\x41\x59"}));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".$ENV{
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48"}));push (
@parameters,"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d\x3d".$ENV{
"\x4e\x58\x5f\x53\x59\x53\x54\x45\x4d"}));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74\x3d".
libnxh::NXTransGetEnvironment ("\x53\x79\x73\x74\x65\x6d\x52\x6f\x6f\x74")));
push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x44\x49\x52\x3d".
$ENV{"\x4e\x4f\x44\x45\x5f\x52\x4f\x4f\x54"}));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x52\x4f\x4f\x54\x3d".$ENV{
"\x4e\x58\x5f\x52\x4f\x4f\x54"}));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x58\x41\x55\x54\x48\x4f\x52\x49\x54\x59\x3d".
$ENV{"\x58\x41\x55\x54\x48\x4f\x52\x49\x54\x59"}));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x4e\x58\x5f\x48\x4f\x4d\x45\x3d".$ENV{
"\x4e\x58\x5f\x48\x4f\x4d\x45"}));push (@parameters,
"\x73\x65\x74\x20\x65\x6e\x76",("\x48\x4f\x4d\x45\x3d".$ENV{"\x48\x4f\x4d\x45"})
);push (@parameters,"\x73\x65\x74\x20\x65\x6e\x76",("\x50\x41\x54\x48\x3d".$ENV{
"\x50\x41\x54\x48"}));push (@parameters,
"\x63\x6c\x6f\x73\x65\x41\x66\x74\x65\x72\x52\x75\x6e",$pass_WRITE);push (
@parameters,
"\x61\x6e\x64\x20\x63\x61\x6c\x6c\x20\x66\x75\x6e\x63\x74\x69\x6f\x6e",
"\x4e\x58\x50\x61\x73\x73\x77\x64\x3a\x3a\x73\x65\x74\x50\x69\x64");
main::nxRunCommand ((\@command),(\@parameters));}sub setPid{($passPid=shift (@_)
);Logger::debug (((
"\x4e\x58\x50\x61\x73\x73\x20\x70\x69\x64\x20\x73\x65\x74\x20\x74\x6f\x20\x5b".
$passPid)."\x5d"));}sub readStdin{(my $selector=
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x6c\x65\x63\x74\x6f\x72"->new)
;$selector->add (main::nxgetSTDIN ());$selector->add ($pass_STDIN);(my $signalFd
=$$NXBegin::parser{"\x53\x69\x67\x6e\x61\x6c"});$selector->add ($signalFd);my (
$buf_stdout);my ($buf_agent);(my $read_buf=(""));my ($bytes_read);my ($password)
;while (($selector->count>(0x1521+ 3773-0x23de))){if ((my (@ready)=$selector->
can_read ((0x1232+ 8125-0x2637)))){foreach my $f (@ready){($bytes_read=
main::nxread ($f,(\$read_buf),(0x10e2+ 2607-0x0b11)));Logger::debug (((((((
"\x5b\x4e\x58\x50\x61\x73\x73\x5d\x20\x72\x65\x61\x64\x20\x5b".$bytes_read).
"\x5d\x20\x62\x79\x74\x65\x73\x20\x62\x75\x66\x66\x65\x72\x20\x69\x73\x20\x5b").
$read_buf)."\x5d\x20\x6f\x6e\x20\x5b").$f)."\x5d"));if (($bytes_read==
(0x0b83+ 5215-0x1fe2))){if (($f==$pass_STDIN)){$selector->remove ($pass_STDIN);
$selector->remove ($signalFd);$selector->remove (main::nxgetSTDIN ());}if (($f==
main::nxgetSTDIN ())){Logger::debug ((("\x53\x74\x64\x69\x6e\x20\x5b".
$buf_stdout)."\x5d\x20\x63\x6c\x6f\x73\x65\x64\x2e"));$selector->remove (
main::nxgetSTDIN ());}}elsif (($f==main::nxgetSTDIN ())){($buf_stdout=$read_buf)
;Logger::debug (((
"\x4e\x58\x50\x61\x73\x73\x20\x67\x6f\x74\x20\x6f\x6e\x20\x73\x74\x64\x69\x6e\x20\x5b"
.$buf_stdout)."\x5d"));}elsif (($f==$pass_STDIN)){(my (@buffs)=split ( /\n/ ,
$read_buf,(0x0d2c+ 2111-0x156b)));($read_buf=(""));foreach $_ (@buffs){(
$buf_agent=$_);($buf_agent=~ s/^\s+// );($buf_agent.="\x0a");if ((length (
$buf_agent)>(0x1845+ 539-0x1a60))){Logger::debug (((
"\x4e\x58\x50\x61\x73\x73\x20\x67\x6f\x74\x20\x66\x72\x6f\x6d\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x5b"
.$buf_agent)."\x5d"));if (($buf_agent=~ /NX> 114/i )){if (__isNotFilterMessages 
()){NXMsg::send_response (
"\x69\x43\x68\x61\x6e\x67\x69\x6e\x67\x50\x61\x73\x73\x77\x6f\x72\x64\x4d\x53\x47"
,"\x4e\x58\x53\x68\x65\x6c\x6c",$user);}}elsif (__isPasswordMessage ($buf_agent)
){if (__isPassSavedGuestPassword ()){($password=__getGuestPassword ());(my $passMsg
=("\x50\x41\x53\x53\x20".$password));main::nxwrite ($pass_STDIN,$passMsg);}elsif
 ((getOktaPassword ()ne (""))){(my $passMsg=("\x50\x41\x53\x53\x20".
getOktaPassword ()));main::nxwrite ($pass_STDIN,$passMsg);}else{if ((($buf_agent
=~ /Retype new.*password:/i )or ($buf_agent=~ /Reenter new.*password:/i ))){(
$password=NXMsg::send_hrequest (
"\x68\x52\x65\x74\x79\x70\x65\x53\x79\x73\x74\x65\x6d\x50\x61\x73\x73\x77\x6f\x72\x64"
,"\x4e\x58\x53\x68\x65\x6c\x6c"));}elsif ((($buf_agent=~ /Enter new.*password:/i )
or ($buf_agent=~ /New.*password:/i ))){($password=NXMsg::send_hrequest (
"\x68\x45\x6e\x74\x65\x72\x53\x79\x73\x74\x65\x6d\x50\x61\x73\x73\x77\x6f\x72\x64"
,"\x4e\x58\x53\x68\x65\x6c\x6c"));}elsif (($buf_agent=~ /Kerberos password/i )){
($password=NXMsg::send_hrequest (
"\x68\x43\x4d\x44\x4b\x65\x72\x62\x65\x72\x6f\x73\x50\x61\x73\x73\x77\x6f\x72\x64\x4d\x53\x47"
,"\x4e\x58\x53\x68\x65\x6c\x6c"));}else{($password=NXMsg::send_hrequest (
"\x68\x43\x4d\x44\x43\x75\x72\x72\x65\x6e\x74\x50\x61\x73\x73\x77\x6f\x72\x64\x4d\x53\x47"
,"\x4e\x58\x53\x68\x65\x6c\x6c"));}(my $passMsg=("\x50\x41\x53\x53\x20".
$password));main::nxwrite ($pass_STDIN,$passMsg);}}elsif (($buf_agent=~ /NX> 137/i )
){if (__isNotFilterMessagesForGuestAndOkta ()){NXMsg::send_response (
"\x69\x50\x61\x73\x73\x77\x6f\x72\x64\x43\x68\x61\x6e\x67\x65\x64\x4d\x53\x47",
"\x4e\x58\x53\x68\x65\x6c\x6c");}($SystemPasswordChanged=(0x0bf8+ 6484-0x254b));
}elsif ((($buf_agent=~ /NX> 500 NX> 500 ERROR: (.*)\n/g )or ($buf_agent=~ /NX> 500 (.*)\n/g )
)){NXMsg::send_response ("\x69\x52\x65\x70\x65\x61\x74\x45\x72\x72",
"\x4e\x58\x50\x61\x73\x73\x77\x64",$1);}elsif (($buf_agent=~ /NX> 511 (.*)\n/g )
){NXMsg::send_response ("\x69\x52\x65\x70\x65\x61\x74\x35\x31\x31",
"\x4e\x58\x50\x61\x73\x73\x77\x64",$1);}elsif (($buf_agent=~ /NX> 538/i )){
NXMsg::send_response (
"\x65\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72\x31",
"\x4e\x58\x50\x61\x73\x73\x77\x64",$user);}}else{Logger::debug (((((((
"\x5b\x4e\x58\x50\x61\x73\x73\x5d\x20\x63\x6c\x6f\x73\x69\x6e\x67\x20\x68\x61\x6e\x64\x6c\x65\x72\x20\x5b"
.$pass_STDIN)."\x5d\x20\x72\x65\x6d\x6f\x76\x69\x6e\x67\x20\x5b").$signalFd).
"\x5d\x20\x5b").main::nxgetSTDIN ())."\x5d"));if (defined ($pass_STDIN)){
$selector->remove ($pass_STDIN);}if (defined ($signalFd)){$selector->remove (
$signalFd);}if (defined (main::nxgetSTDIN ())){$selector->remove (
main::nxgetSTDIN ());}}}($buf_agent=(""));}Logger::debug (((
"\x5b\x4e\x58\x50\x61\x73\x73\x5d\x20\x62\x75\x66\x20\x6c\x65\x66\x74\x20\x5b".
$buf_agent)."\x5d"));}}}Logger::debug (((
"\x4e\x58\x50\x61\x73\x73\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x66\x6f\x72\x20\x5b"
.$passPid)."\x5d"));main::nxclose ($pass_STDIN);waitKill ($passPid);}sub 
__isPasswordMessage{(my $buf_agent=shift (@_));if (((((($buf_agent=~ /NX> $GLOBAL::MSG_CURRENT_PASSWORD/g )
or ($buf_agent=~ /NX> $GLOBAL::MSG_ENTER_NEW_SYSTEM_PASSWORD/g ))or ($buf_agent
=~ /NX> $GLOBAL::MSG_RETYPE_NEW_SYSTEM_PASSWORD/g ))or ($buf_agent=~ /NX> $GLOBAL::MSG_CHECK_PASSWORD/g )
)or ($buf_agent=~ /NX> $GLOBAL::MSG_KERBEROS_PASSWORD/g ))){return (
(0x0272+ 9070-0x25df));}return ((0x1b6d+ 1718-0x2223));}sub changeNXPasswordAsk{
(my $user=shift (@_));if (($SystemPasswordChanged and ($GLOBAL::EnablePasswordDB
==(0x178a+ 345-0x18e2)))){if (askToSetNXPassword ($user)){changeNXPassword (
$user);}}}sub askToSetNXPassword{(my $user=shift (@_));
NXMsg::send_response_no_newline ("\x72\x4e\x6f\x50\x61\x73\x73\x77\x6f\x72\x64",
"\x4e\x58\x50\x61\x73\x73\x77\x64",$user);my ($answer);
Common::NXCore::readInputTillNewline (main::nxgetSTDIN (),(\$answer));($answer=
lc ($answer));while (((not (Common::NXMsg::checkIfAnswerIsYes ($answer)))and (
not (Common::NXMsg::checkIfAnswerIsNo ($answer))))){if ((not (
NXMsg::isMessageRegistered ("\x72\x57\x72\x6f\x6e\x67\x41\x6e\x73\x77\x65\x72"))
)){NXMsg::register_response ("\x4e\x58\x50\x61\x73\x73\x77\x64",
"\x72\x57\x72\x6f\x6e\x67\x41\x6e\x73\x77\x65\x72",
$GLOBAL::MSG_CHANGEUSERPASSWORD);}NXMsg::send_response_no_newline (
"\x72\x57\x72\x6f\x6e\x67\x41\x6e\x73\x77\x65\x72",
"\x4e\x58\x50\x61\x73\x73\x77\x64");Common::NXCore::readInputTillNewline (
main::nxgetSTDIN (),(\$answer));($answer=lc ($answer));}if (
Common::NXMsg::checkIfAnswerIsYes ($answer)){return ((0x0246+ 8285-0x22a2));}
return ((0x0206+ 6320-0x1ab6));}sub changeNXPassword{(my $user=shift (@_));
removeNXPassword ($user);NXShell::handle_command (
"\x73\x65\x74\x70\x61\x73\x73\x77\x6f\x72\x64",$user);}sub removeNXPassword{(my $user
=shift (@_));if (NXPwUserManager::get (("\x6c\x6f\x67\x69\x6e\x3d".$user))){
NXPwUserManager::del (("\x6c\x6f\x67\x69\x6e\x3d".$user));}}sub waitKill{(my $pid
=shift (@_));Common::NXProcess::nxwaitpid ($pid,$NXBits::WAIT_UNTRACED,
(0x04a2+ 3799-0x1374));if (Common::NXProcess::isProcessRunning ($pid)){if (
Common::NXProcess::sigkill ($pid)){Logger::debug (((
"\x4b\x69\x6c\x6c\x65\x64\x20\x73\x65\x74\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x2e"));}else{Logger::error (((
"\x43\x61\x6e\x6e\x6f\x74\x20\x6b\x69\x6c\x6c\x20\x73\x65\x74\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x20\x70\x72\x6f\x63\x65\x73\x73\x20\x77\x69\x74\x68\x20\x70\x69\x64\x20"
.$pid)."\x2e"));}}}sub getPassFromUser{(my $password=__getNewPassword ());(my $error
=$WrongFormat);if (defined ($password)){(my $chk_password=__confirmPassword ());
if (defined ($chk_password)){if (($password eq $chk_password)){($error=$Correct)
;}else{($error=$Mismatch);}}}return ($password,$error);}sub __getNewPassword{
return (NXMsg::send_hrequest (
"\x68\x50\x61\x73\x73\x77\x6f\x72\x64\x4e\x6f\x6c\x69\x6d\x69\x74",
"\x4e\x58\x50\x61\x73\x73\x77\x64"));}sub __confirmPassword{return (
NXMsg::send_hrequest (
"\x68\x43\x6f\x6e\x66\x69\x72\x6d\x50\x61\x73\x73\x77\x6f\x72\x64",
"\x4e\x58\x53\x68\x65\x6c\x6c"));}sub getPasswdPid{return ($passPid);}sub 
isMismatch{(my $error=shift (@_));if (($error==$Mismatch)){return (
(0x12c7+ 1076-0x16fa));}return ((0x1aa5+ 2569-0x24ae));}sub isWrongFormat{(my $error
=shift (@_));if (($error==$WrongFormat)){return ((0x067d+ 4154-0x16b6));}return 
((0x04e0+ 7009-0x2041));}sub setSystemPasswordChanged{($SystemPasswordChanged=
(0x1bdd+  95-0x1c3b));}sub isNotSystemPasswordChanged{return ((!
$SystemPasswordChanged));}sub __resetSystemPasswordChanged{(
$SystemPasswordChanged=(0x1282+ 3358-0x1fa0));}sub changeGuestPassword{(my $user
=shift (@_));(my $password=NXGuestsManager::getBasicGuestPasswd ($user));if ((
not (NXLogin::isUseNXPasswords ()))){__setPassSavedGuestPassword ();
__setGuestPasswdParameters ($password);handleSystemPasswdByNXShell ($user);if (
isNotSystemPasswordChanged ()){
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4c\x6f\x67"->throw ((
"\x63\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x73\x79\x73\x74\x65\x6d\x20\x70\x61\x73\x73\x77\x6f\x72\x64\x3a\x20"
.$cmd_err));return ((0x09ca+ 1871-0x1119));}}else{if (NXPwUserManager::get ((
"\x6c\x6f\x67\x69\x6e\x3d".$user))){NXPwUserManager::update ((
"\x6c\x6f\x67\x69\x6e\x3d".$user),("\x70\x61\x73\x73\x77\x6f\x72\x64\x3d".
Common::NXCore::digestMd5Hex (($user.Common::NXCore::digestMd5Hex (($user.
$password))))));}else{NXPwUserManager::put (("\x6c\x6f\x67\x69\x6e\x3d".$user),(
"\x70\x61\x73\x73\x77\x6f\x72\x64\x3d".Common::NXCore::digestMd5Hex (($user.
Common::NXCore::digestMd5Hex (($user.$password))))));}}return ($password);}sub 
createPasswdPipe{if (main::nxPipeCreateBi ((\$pass_STDIN),(\$pass_WRITE))){
Logger::debug (((((
"\x4e\x58\x50\x61\x73\x73\x20\x63\x72\x65\x61\x74\x65\x64\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x5b"
.$pass_STDIN)."\x2f").$pass_WRITE)."\x5d"));}else{Logger::error (
"\x4e\x58\x50\x61\x73\x73\x20\x55\x6e\x61\x62\x6c\x65\x20\x74\x6f\x20\x63\x72\x65\x61\x74\x65\x20\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x73\x20\x70\x61\x69\x72\x2e"
);main::nxexit ((0x0168+ 5966-0x18b6));}(my $setInheritableReturn=
libnxh::NXDescriptorInheritable ($pass_STDIN,(0x0252+ 2253-0x0b1e)));}sub 
getPassWrite{return ($pass_WRITE);}sub getPassStdin{return ($pass_STDIN);}sub 
__resetParameters{__resetGuestPassword ();__resetFilterMessages ();}sub 
__setNXShellMode{($mode=$nxshellMode);}sub __setConsoleMode{($mode=$consoleMode)
;}sub __isNXShellMode{if (($mode==$nxshellMode)){return ((0x1848+ 1499-0x1e22));
}return ((0x12ef+ 1198-0x179d));}sub __setGuestPassword{($guestPassword=shift (
@_));}sub __getGuestPassword{return ($guestPassword);}sub __resetGuestPassword{(
$guestPassword=(""));}sub __resetFilterMessages{($filterMessages=
(0x04c9+ 5821-0x1b86));}sub setFilterMessagesForUseradd{($filterMessages=
$filterMessagesUseradd);}sub setFilterMessagesForOkta{($filterMessages=
$filterMessagesOkta);}sub __setFilterMessagesForGuest{($filterMessages=
$filterMessagesGuest);}sub __isNotFilterMessagesForGuestAndOkta{if (((
$filterMessages!=$filterMessagesGuest)and ($filterMessages!=$filterMessagesOkta)
)){return ((0x0065+ 5649-0x1675));}return ((0x02f0+ 426-0x049a));}sub 
__isNotFilterMessages{if (($filterMessages==(0x03ff+ 6549-0x1d94))){return (
(0x10d9+ 4236-0x2164));}return ((0x04bf+ 1559-0x0ad6));}sub 
__setGuestPasswdParameters{(my $password=shift (@_));__setGuestPassword (
$password);__setFilterMessagesForGuest ();}sub __setPassSavedGuestPassword{(
$passSavedGuestPassword=(0x0e80+ 5859-0x2562));}sub __isPassSavedGuestPassword{
return ($passSavedGuestPassword);}sub setOktaPassword{($oktaPassword=shift (@_))
;}sub getOktaPassword{return ($oktaPassword);}sub resetOktaPassword{(
$oktaPassword=(""));}NXMsg::register_response (
"\x4e\x58\x50\x61\x73\x73\x77\x64","\x69\x52\x65\x70\x65\x61\x74\x45\x72\x72",
$GLOBAL::MSG_ERROR);NXMsg::register_response ("\x4e\x58\x50\x61\x73\x73\x77\x64"
,"\x69\x52\x65\x70\x65\x61\x74\x35\x31\x31",
$GLOBAL::MSG_ERROR_NEW_PASSWORD_MISSMATCH);NXMsg::register_response (
"\x4e\x58\x50\x61\x73\x73\x77\x64",
"\x65\x4e\x6f\x74\x53\x79\x73\x74\x65\x6d\x55\x73\x65\x72\x31",
$GLOBAL::MSG_ERROR_TOO_MANY_USERS);NXMsg::register_response (
"\x4e\x58\x50\x61\x73\x73\x77\x64",
"\x72\x4e\x6f\x50\x61\x73\x73\x77\x6f\x72\x64",$GLOBAL::MSG_USER_NEW_PASSWORD);
NXMsg::register_response ("\x4e\x58\x50\x61\x73\x73\x77\x64",
"\x68\x50\x61\x73\x73\x77\x6f\x72\x64\x4e\x6f\x6c\x69\x6d\x69\x74",
$GLOBAL::MSG_PASSWORD_NOLIMIT,"\x5e\x2e\x7b\x30\x2c\x31\x32\x38\x7d\x24");return
 ((0x17d2+ 3798-0x26a7));
