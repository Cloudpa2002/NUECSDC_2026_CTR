############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXTwoFactorLoginDB::BEGIN{package NXTwoFactorLoginDB;no warnings;require 
Error;do{"\x45\x72\x72\x6f\x72"->import ("\x3a\x74\x72\x79")};}sub 
NXTwoFactorLoginDB::savePublicKey{package NXTwoFactorLoginDB;no warnings;(my $user
=main::urlencode (shift (@_)));(my $key=main::urlencode (shift (@_)));if (($user
 eq (""))){Logger::warning (
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x55\x73\x65\x72\x6e\x61\x6d\x65\x20\x69\x73\x20\x65\x6d\x70\x74\x79\x2e\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x61\x76\x65\x20\x74\x68\x65\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x2e"
);return ((0x046b+ 5340-0x1947));}if (($key eq (""))){Logger::warning (((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x73\x61\x76\x65\x20\x65\x6d\x70\x74\x79\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x27"
.$user)."\x27\x2e"));return ((0x07e9+ 2524-0x11c5));}__lock ();(my $file=
NXPaths::getTwoFactorPublicKeys ());(my $openMode=(($NXBits::O_CREAT+
$NXBits::O_WRONLY)+$NXBits::O_APPEND));(my $FD=main::nxopen ($file,$openMode,
$NXBits::UserReadWrite));if ((not (defined ($FD)))){(my $error=
libnxh::NXGetError ());(my $errorName=libnxh::NXGetErrorName ());(my $errorString
=libnxh::NXGetErrorString ());if ((not (defined ($FD)))){Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x74\x6f\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x2e").(((("\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".
$errorString)."\x27\x2c\x20").$error)."\x2e")));__unlock ();return (
(0x005b+ 3663-0x0eaa));}}(my $data=((($user."\x20").$key)."\x0a"));if ((
main::nxwrite ($FD,$data)==(-(0x057b+ 5252-0x19fe)))){(my $error=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
main::nxclose ($FD);Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x77\x72\x69\x74\x65\x20\x70\x75\x62\x6c\x69\x63\x20\x6b\x65\x79\x20\x74\x6f\x20\x74\x68\x65\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x2e").(((("\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".
$errorString)."\x27\x2c\x20").$error)."\x2e")));__unlock ();return (
(0x065b+ 692-0x090f));}main::nxclose ($FD);__unlock ();return (
(0x0238+ 7772-0x2093));}sub NXTwoFactorLoginDB::getPublicKeys{package 
NXTwoFactorLoginDB;no warnings;(my $user=shift (@_));(my (@keys)=
getAllPublicKeys ());(my (@userKeys)=());for ((my $i=(0x0ffb+ 2243-0x18be));($i<
@keys);($i=($i+(0x032f+ 3761-0x11de)))){if (($user eq @keys[$i])){push (
@userKeys,$keys[$i+(0x0ac7+ 3821-0x19b3)]);}}return (@userKeys);}sub 
NXTwoFactorLoginDB::getAllPublicKeys{package NXTwoFactorLoginDB;no warnings;(my $file
=NXPaths::getTwoFactorPublicKeys ());unless (Common::NXFile::isExists ($file)){
Logger::debug (((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"))
;return (());}__lockShared ();(my $fileHandle=main::nxopen ($file,
$NXBits::O_RDONLY));unless (defined ($fileHandle)){(my $errorNumber=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::debug ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x27"
.$file)."\x27\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x2e").((((
"\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".$errorString)."\x27\x2c\x20").
$errorNumber)."\x2e")));__unlock ();return (());}(my (@content)=());while (
main::nxreadLine ($fileHandle,(\$_))){chomp ($_);(my ($user,$key)=split ( / / ,
$_,(0x06b5+ 2756-0x1176)));($user=main::urldecode ($user));($key=main::urldecode
 ($key));Logger::debug3 (((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x55\x73\x65\x72\x20\x27"
.$user)."\x27\x20\x6b\x65\x79\x20\x27").$key)."\x27\x2e"));push (@content,$user,
$key);}main::nxclose ($fileHandle);__unlock ();return (@content);}sub 
NXTwoFactorLoginDB::removeUserKeys{package NXTwoFactorLoginDB;no warnings;(my $username
=shift (@_));(my $file=NXPaths::getTwoFactorPublicKeys ());(my $tempFile=(($file
."\x2e\x74\x6d\x70\x2e").$ $));
 unless (Common::NXFile::isExists ($file)){
Logger::warning (((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x46\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x64\x6f\x65\x73\x20\x6e\x6f\x74\x20\x65\x78\x69\x73\x74\x2e"))
;return ((0x06f9+ 3735-0x1590));}__lock ();(my $FD=main::nxopen ($file,
$NXBits::O_RDONLY));unless (defined ($FD)){(my $errorNumber=libnxh::NXGetError 
());(my $errorString=libnxh::NXGetErrorString ());Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x27"
.$file)."\x27\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x2e").((((
"\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".$errorString)."\x27\x2c\x20").
$errorNumber)."\x2e")));__unlock ();return ((0x11ec+ 164-0x1290));}if (
Common::NXFile::isExists ($tempFile)){unlink ($tempFile);}(my $openMode=((
$NXBits::O_CREAT+$NXBits::O_WRONLY)+$NXBits::O_APPEND));(my $tempFD=main::nxopen
 ($tempFile,$openMode,$NXBits::UserReadWrite));unless (defined ($tempFD)){(my $errorNumber
=libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x44\x42\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x27"
.$tempFile)."\x27\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x65\x2e").((((
"\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".$errorString)."\x27\x2c\x20").
$errorNumber)."\x2e")));__unlock ();return ((0x0e92+ 3272-0x1b5a));}&try (sub{
while (main::nxreadLine ($FD,(\$_))){(my $line=$_);chomp ($line);(my ($keyUser,
$key)=split ( / / ,$line,(0x105c+ 219-0x1134)));($keyUser=main::urldecode (
$keyUser));if (($keyUser eq $username)){($flag_del=(0x20aa+ 1390-0x2617));}else{
Common::NXCore::nxwriteOrThrowException ($tempFD,$_);}}},&otherwise (sub{(my $error
=shift (@_));main::nxclose ($tempFD);main::nxclose ($FD);__unlock ();
Logger::error (((
"\x55\x6e\x65\x78\x70\x65\x63\x65\x64\x20\x65\x72\x72\x6f\x72\x20\x77\x68\x69\x6c\x65\x20\x72\x65\x6d\x6f\x76\x69\x6e\x67\x20\x73\x61\x76\x65\x64\x20\x75\x73\x65\x72\x20\x74\x77\x6f\x20\x66\x61\x63\x74\x6f\x72\x20\x6b\x65\x79\x2e\x20"
.$error)."\x2e"));return ((0x11af+ 4953-0x2508));}));main::nxclose ($tempFD);
main::nxclose ($FD);if ((not (rename ($tempFile,$file)))){__unlock ();
Logger::error ((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x72\x65\x6e\x61\x6d\x65\x20\x66\x69\x6c\x65\x20\x27"
.$tempFile)."\x27\x20\x74\x6f\x20\x27").$file)."\x27\x2e\x20").$!));return (
(0x053c+ 4327-0x1623));}(my ($errorName),$errorCode);if ((
Common::NXFile::setOwnerShipAndPermissionsForNX ($file,(\$errorName),(
\$errorCode))==(-(0x1c84+ 770-0x1f85)))){__unlock ();Logger::error ((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x73\x65\x74\x20\x6f\x77\x6e\x65\x72\x73\x68\x69\x70\x20\x27\x6e\x78\x27\x20\x6f\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$file)."\x27\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x20\x6e\x78\x2e\x20").
$errorName));return ((0x156c+ 2539-0x1f57));}__unlock ();return ($flag_del);}
package NXTwoFactorLoginDB;no warnings;my ($lockFD);sub __lock{(my $lockMode=(
shift (@_)||$NXBits::LOCK_EX));(my $lockFile=(NXPaths::getTwoFactorPublicKeys ()
."\x2e\x6c\x6f\x63\x6b"));(my $openMode=(($NXBits::O_CREAT+$NXBits::O_WRONLY)+
$NXBits::O_APPEND));($lockFD=main::nxopen ($lockFile,$openMode,
$NXBits::UserReadWrite));if ((not (defined ($lockFD)))){(my $error=
libnxh::NXGetError ());(my $errorString=libnxh::NXGetErrorString ());
Logger::warning ((((
"\x4e\x58\x54\x77\x6f\x46\x61\x63\x74\x6f\x72\x4c\x6f\x67\x69\x6e\x3a\x20\x43\x61\x6e\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x27"
.$lockFile)."\x27\x2e").(((("\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20\x27".
$errorString)."\x27\x2c\x20").$error)."\x2e")));return ((0x0f1c+ 1443-0x14bf));}
main::nxflock ($lockFD,$lockMode);}sub __lockShared{return (__lock (
$NXBits::LOCK_SH));}sub __unlock{if (defined ($lockFD)){main::nxclose ($lockFD);
}($lockFD=undef);}return ((0x12b0+ 855-0x1606));
