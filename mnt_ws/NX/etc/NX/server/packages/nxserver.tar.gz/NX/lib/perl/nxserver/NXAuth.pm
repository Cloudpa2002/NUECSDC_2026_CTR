############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXAuth::BEGIN{package NXAuth;no warnings;require warnings;do{
"\x77\x61\x72\x6e\x69\x6e\x67\x73"->import};}sub NXAuth::BEGIN{package NXAuth;no
 warnings;require Exporter;do{"\x45\x78\x70\x6f\x72\x74\x65\x72"->import};}sub 
NXAuth::BEGIN{package NXAuth;no warnings;require NXMsg;do{"\x4e\x58\x4d\x73\x67"
->import};}sub NXAuth::BEGIN{package NXAuth;no warnings;require Common::NXInfo;
do{"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x49\x6e\x66\x6f"->import};}package 
NXAuth;no warnings;(our (@ISA)="\x45\x78\x70\x6f\x72\x74\x65\x72");(our (@EXPORT
)=("\x67\x65\x74\x4e\x58\x41\x75\x74\x68\x54\x79\x70\x65",
"\x69\x73\x53\x53\x48\x44\x41\x75\x74\x68",
"\x69\x73\x4e\x6f\x74\x53\x53\x48\x44\x41\x75\x74\x68","\x69\x73\x4e\x58\x44",
"\x69\x73\x4e\x6f\x74\x4e\x58\x44",
"\x69\x73\x4e\x6f\x6d\x61\x63\x68\x69\x6e\x65",
"\x69\x73\x53\x79\x73\x74\x65\x6d"));($type=(""));($typeNomachine=
"\x6e\x6f\x6d\x61\x63\x68\x69\x6e\x65");($typeSystem="\x73\x79\x73\x74\x65\x6d")
;($typeNXD="\x6e\x78\x64");($salt=(""));($sshConnection=(-(0x184b+ 1390-0x1db8))
);sub init{(my $environmentValue=libnxh::NXTransGetEnvironment (
"\x4e\x58\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if (defined (
$environmentValue)){if (($environmentValue ne (""))){setNXD ();}}}sub 
isSSHConnection{if (($sshConnection!=(-(0x0fcf+ 375-0x1145)))){return (
$sshConnection);}($sshConnection=(0x0534+ 491-0x071f));(my $env=
libnxh::NXTransGetEnvironment (
"\x53\x53\x48\x5f\x43\x4f\x4e\x4e\x45\x43\x54\x49\x4f\x4e"));if (defined ($env))
{if (($env ne (""))){($sshConnection=(0x005c+ 522-0x0265));}}return (
$sshConnection);}sub initConnectionType{if (isNotNXD ()){if ((defined (
$GLOBAL::LOGGED_USER)and ($GLOBAL::LOGGED_USER ne ("")))){setSystem ();}else{
setNomachine ();}}}sub getNXAuthType{return ($type);}sub isSSHDAuth{if ((defined
 ($GLOBAL::UseSSHAuthentication)and ($GLOBAL::UseSSHAuthentication eq 
"\x65\x6e\x61\x62\x6c\x65\x64"))){return ((0x0887+ 7171-0x2489));}else{return (
(0x16d7+ 2367-0x2016));}}sub isNotSSHDAuth{return ((!isSSHDAuth ()));}sub setNXD
{Logger::debug (((
"\x4e\x58\x41\x75\x74\x68\x3a\x20\x53\x65\x74\x20\x74\x79\x70\x65\x20\x27".
$typeNXD)."\x27\x2e"));($type=$typeNXD);}sub isTypeSet{if ((getNXAuthType ()ne 
(""))){return ((0x085d+ 1069-0x0c89));}return ((0x0250+ 489-0x0439));}sub isNXD{
if (($type eq $typeNXD)){return ((0x203a+ 1612-0x2685));}return (
(0x0688+ 142-0x0716));}sub isNotNXD{return ((!isNXD ()));}sub 
getActiveConnectionPort{if ((isNXD ()eq "\x31")){return (NXNodeInfo::getNxdPort 
());}else{return ($GLOBAL::SSHPort);}}sub setNomachine{if ((not (isTypeSet ())))
{Logger::debug (((
"\x4e\x58\x41\x75\x74\x68\x3a\x20\x53\x65\x74\x20\x74\x79\x70\x65\x20\x27".
$typeNomachine)."\x27\x2e"));($type=$typeNomachine);}}sub isNomachine{if (($type
 eq $typeNomachine)){return ((0x0abb+ 6919-0x25c1));}return (
(0x0b8f+ 694-0x0e45));}sub getTypeNomachine{return ($typeNomachine);}sub 
setSystem{if ((not (isTypeSet ()))){Logger::debug (((
"\x4e\x58\x41\x75\x74\x68\x3a\x20\x53\x65\x74\x20\x74\x79\x70\x65\x20\x27".
$typeSystem)."\x27\x2e"));($type=$typeSystem);}}sub isSystem{if (($type eq 
$typeSystem)){return ((0x09c7+ 7484-0x2702));}return ((0x01d1+ 8113-0x2182));}
sub getTypeSystem{return ($typeSystem);}sub checkIsSshAvailable{
initConnectionType ();if (isSystem ()){if (NXLicense::isSshFeature ()){if ((not 
(NXSystemDaemons::isSSHEnabledInConfig ()))){Logger::debug (
"\x53\x53\x48\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x64\x69\x73\x61\x62\x6c\x65\x64"
);return ((0x0166+ 4824-0x143d));}}else{Logger::debug (
"\x53\x53\x48\x20\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x20\x6e\x6f\x74\x20\x73\x75\x70\x70\x6f\x72\x74\x65\x64"
);return ((0x00cf+ 9729-0x26ce));}}return ((0x06b1+ 2903-0x1208));}sub 
NxServerUserSystemAuth{(my $hello_data=shift (@_));(my $helloMessage=((((
"\x68\x65\x6c\x6c\x6f\x20".$GLOBAL::MESSAGES_FORMAT{$GLOBAL::MSG_LOGIN_LOGIN}).
"\x20").$GLOBAL::LOGGED_USER).("\x20".$hello_data)));(my ($error_msg,$result)=
NXServer2Server::execute ($GLOBAL::MSG_GET_COMMAND,$helloMessage,"\x32\x35\x30",
(""),$GLOBAL::MSG_LOGIN_PASSWORD_AUTH_COOKIE,(""),"\x32\x35\x30",(""),
$GLOBAL::MSG_LOGIN_OK,("")));if ($result){NXMsg::register_error (
"\x4e\x58\x41\x75\x74\x68",
"\x65\x43\x61\x6e\x6e\x6f\x74\x41\x75\x74\x68\x6f\x72\x69\x7a\x65",
(0x120a+ 4005-0x1fbb),
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x75\x74\x68\x6f\x72\x69\x7a\x65\x20\x77\x69\x74\x68\x20\x63\x6f\x6f\x6b\x69\x65"
);NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x41\x75\x74\x68\x6f\x72\x69\x7a\x65",
"\x4e\x58\x41\x75\x74\x68");NXShell::handle_command ("\x65\x78\x69\x74");}return
 ((0x2475+ 370-0x25e7));}sub addCookie{(my $inputfilename=shift (@_));(my $dpyname
=shift (@_));(my $protoname=shift (@_));(my $hexkey=shift (@_));if (((not (
defined ($inputfilename)))or ($inputfilename eq ("")))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x2c\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x69\x6e\x70\x75\x74\x20\x66\x69\x6c\x65\x20\x6e\x61\x6d\x65\x2e"
);return ((0x0371+ 5479-0x18d7));}if (((not (defined ($dpyname)))or ($dpyname eq
 ("")))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x2c\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x64\x69\x73\x70\x6c\x61\x79\x2e"
);return ((0x0879+ 5212-0x1cd4));}if (((not (defined ($protoname)))or (
$protoname eq ("")))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x2c\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x70\x72\x6f\x74\x6f\x6e\x61\x6d\x65\x2e"
);return ((0x232f+ 813-0x265b));}if (((not (defined ($hexkey)))or ($hexkey eq 
("")))){Logger::warning (
"\x43\x61\x6e\x6e\x6f\x74\x20\x61\x64\x64\x20\x63\x6f\x6f\x6b\x69\x65\x2c\x20\x6d\x69\x73\x73\x69\x6e\x67\x20\x68\x65\x78\x6b\x65\x79\x2e"
);return ((0x054f+ 3415-0x12a5));}(my $returnValue=libnxh::NXAddCookie (
$inputfilename,$dpyname,$protoname,$hexkey));if (($returnValue!=
(0x0576+ 3215-0x1205))){(my $errorInt=libnxh::NXGetError ());(my $errorString=
libnxh::NXGetErrorString ());Logger::warning (((((
"\x6c\x69\x62\x6e\x78\x68\x3a\x3a\x4e\x58\x41\x64\x64\x43\x6f\x6f\x6b\x69\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x63\x6f\x64\x65\x20\x5b"
.$errorInt)."\x5d\x20\x5b").$errorString)."\x5d"));}return ($returnValue);}sub 
isKnowHostSet{if ((defined ($setKnownhostNul)and ($setKnownhostNul==
(0x09fa+ 5059-0x1dbc)))){return ((0x0783+ 7641-0x255b));}return (
(0x0d8f+ 3651-0x1bd2));}sub generateSalt{Logger::debug (
"\x47\x65\x6e\x65\x72\x61\x74\x69\x6e\x67\x20\x73\x61\x6c\x74\x2e");($salt=
main::get_unique_id ());}sub getSalt{return ($salt);}return (
(0x2200+ 349-0x235c));
