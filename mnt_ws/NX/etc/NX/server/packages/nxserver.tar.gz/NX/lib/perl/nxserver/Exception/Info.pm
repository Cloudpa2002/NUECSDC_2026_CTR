############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::Info::BEGIN{package Exception::Info;no warnings;require base;do{
"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x42\x61\x73\x65")};}sub 
Exception::Info::BEGIN{package Exception::Info;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub Exception::Info::BEGIN{package 
Exception::Info;no warnings;require NXMsg;do{"\x4e\x58\x4d\x73\x67"->import};}
sub Exception::Info::notify{package Exception::Info;no warnings;(my $self=shift 
(@_));(my $text=$self->text);NXMsg::send_response ("\x65\x49\x6e\x66\x6f",
"\x67\x65\x6e\x65\x72\x61\x6c",$text);}package Exception::Info;no warnings;
NXMsg::register_response ((""),"\x65\x49\x6e\x66\x6f",(0x2134+ 2039-0x25a7));
return ((0x0960+ 6414-0x226d));
