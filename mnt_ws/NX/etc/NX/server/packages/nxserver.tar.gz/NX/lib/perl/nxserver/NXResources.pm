############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub NXResources::BEGIN{package NXResources;no warnings;require NXProfilesManager
;do{"\x4e\x58\x50\x72\x6f\x66\x69\x6c\x65\x73\x4d\x61\x6e\x61\x67\x65\x72"->
import};}package NXResources;no warnings;$username;($restoreType=(""));(my $__lengthClass
=(0x16c0+ 280-0x17d3));sub BEGIN{require Common::NXSessionType;do{
"\x43\x6f\x6d\x6d\x6f\x6e\x3a\x3a\x4e\x58\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65"
->import};}sub BEGIN{require NXServices;do{
"\x4e\x58\x53\x65\x72\x76\x69\x63\x65\x73"->import};}sub BEGIN{require NXMsg;do{
"\x4e\x58\x4d\x73\x67"->import};}(my $__lengthType=(0x024c+ 2159-0x0ab7));(my $__lengthValue
=(0x1516+ 4498-0x26a3));($GLOBAL::NXMANAGER_FORMAT_OUTPUT=(0x1c63+ 1837-0x2390))
;sub __getResources{(my $profile=shift (@_));(my $class=shift (@_));(my $node=
shift (@_));(my (%resources)=());my ($resourcesList);my ($nodeGroupsList);if ((
$class eq "\x73\x65\x73\x73\x69\x6f\x6e")){($resourcesList=shift (@_));}elsif ((
$class eq "\x73\x65\x72\x76\x69\x63\x65")){($resourcesList=
NXServices::getAllPosibleServicesList ());}elsif (($class eq 
"\x66\x65\x61\x74\x75\x72\x65")){($resourcesList=
$GLOBAL::ALL_POSSIBLE_FEATURES_LIST);if (Server::isConnectedToConsole ()){(
$resourcesList=~ s/,enable-multiserver// );}if (
NXProfiles::isInternalKeyForSystem ($profile)){($resourcesList.=("\x2c".
$GLOBAL::SYSTEM_POSSIBLE_FEATURES_LIST));}Logger::debug (((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x46\x65\x61\x74\x75\x72\x65\x20\x6c\x69\x73\x74\x20\x27"
.$resourcesList)."\x27\x2e"));}elsif (($class eq "\x6e\x6f\x64\x65")){if (
NXLicense::isMultiNodeFeature ()){($resourcesList=NXNodes::getAllNodesList ());(
$resourcesList=~ s/:/\//g );main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73","\x69\x6e\x69\x74");(
$nodeGroupsList=NXNodeGroups::getGroupsListStringByNode ());if ($nodeGroupsList)
{if ($resourcesList){($resourcesList.="\x2c");}($resourcesList.=$nodeGroupsList)
;}}else{(my $node=NXNodes::getLocalNodeFromDatabase ());if (defined ($node)){(
$resourcesList=$node);}}}else{return ((0x0c8b+ 3455-0x1a09),%resources);}(
$resourcesList and (my (@arr_resources)=split ( /,/ ,$resourcesList,
(0x0112+ 4759-0x13a9))));my ($nodeList);if ((not (defined ($node)))){if (
NXLicense::isMultiNodeFeature ()){($nodeList=NXNodes::getNodesList ());}else{(my $node
=NXNodes::getLocalNodeFromDatabase ());if (defined ($node)){($nodeList=$node);}}
}else{($nodeList=$node);if (NXLicense::isMultiNodeFeature ()){main::nxrequire (
"\x4e\x58\x4e\x6f\x64\x65\x47\x72\x6f\x75\x70\x73","\x69\x6e\x69\x74");(
$nodeGroupsList=NXNodeGroups::getGroupsListStringByNode ($node));}}Logger::debug
 (((((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x43\x68\x65\x63\x6b\x20\x63\x6c\x61\x73\x73\x20\x27"
.$class).
"\x27\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x73\x20\x27"
).$nodeList)."\x27\x2e"));foreach my $res (@arr_resources){($resources{$res}=
(0x06b1+ 2728-0x1159));}(my (@nodes)=split ( /,/ ,$nodeList,
(0x0148+ 7419-0x1e43)));(my (@nodeGroups)=split ( /,/ ,$nodeGroupsList,
(0x178c+ 2814-0x228a)));if ((($class eq "\x66\x65\x61\x74\x75\x72\x65")and (
scalar (@nodes)==(0x1786+ 1653-0x1dfb)))){foreach my $res (@arr_resources){if (
NXProfilesManager::isFeatureAvailableForUserGroupAndSystem ($res,$profile)){(
$resources{$res}=(0x08ad+ 4160-0x18ec));}}}if (($class eq "\x6e\x6f\x64\x65")){
foreach my $node (@nodes){if (
NXProfilesManager::isTypeAvaibleOnClassForUserOrNode ($node,$class,$profile)){(
$resources{$node}=(0x15f3+ 1458-0x1ba4));}}foreach my $nodeGroup (@nodeGroups){
if (NXProfilesManager::isTypeAvaibleOnClassForUserOrNode ($nodeGroup,$class,
$profile)){($resources{$nodeGroup}=(0x03ff+ 3495-0x11a5));}}}else{foreach my $node
 (@nodes){foreach my $res (@arr_resources){if (
NXProfilesManager::isTypeAvaibleOnClassForUserOrNode ($res,$class,$profile,$node
)){($resources{$res}=(0x0615+ 2737-0x10c5));}}}}my ($error_code);return (
$error_code,%resources);}sub __formatResourceOutput{(my $class=shift (@_));(my $filtered_value
=shift (@_));(my (%resources)=@_);my (@out_resources);my ($printItem);foreach my $key
 (keys (%resources)){(my $value=$resources{$key});($printItem=
(0x067a+ 3250-0x132c));if (($value==(0x0785+ 6433-0x20a5))){($value=
"\x79\x65\x73");if ((($filtered_value eq "\x79\x65\x73")or ($filtered_value eq 
("")))){($printItem=(0x08a0+ 858-0x0bf9));}}elsif (($value==
(0x159d+ 2161-0x1e0e))){($value="\x6e\x6f");if ((($filtered_value eq "\x6e\x6f")
or ($filtered_value eq ("")))){($printItem=(0x1327+ 4647-0x254d));}}if ((
$printItem==(0x0a6a+ 990-0x0e47))){if (($class eq "\x73\x65\x73\x73\x69\x6f\x6e"
)){($key=Common::NXSessionType::convertToExternal ($key));}push (@out_resources,
{"\x63\x6c\x61\x73\x73",$class,"\x74\x79\x70\x65",$key,"\x76\x61\x6c\x75\x65",
$value});}}return (@out_resources);}sub __formatRuleValueOutput{(my $class=shift
 (@_));(my $filtered_value=shift (@_));(my $rule_value=shift (@_));(my (
@out_resources)=());(my (%rule_value_resources)=());(my $value_list_res=(""));(my (
@arr_rule_value)=());if (($class eq "\x73\x65\x73\x73\x69\x6f\x6e")){(
$value_list_res=$GLOBAL::ALL_POSSIBLE_SESSIONS_VALUE_LIST);}elsif (($class eq 
"\x66\x65\x61\x74\x75\x72\x65")){($value_list_res=
$GLOBAL::ALL_POSSIBLE_FEATURES_VALUE_LIST);}elsif (($class eq "\x6e\x6f\x64\x65"
)){($value_list_res=$GLOBAL::ALL_POSSIBLE_NODE_VALUE_LIST);}(@arr_rule_value=())
;($value_list_res and (@arr_rule_value=split ( /,/ ,$value_list_res,
(0x0295+ 6434-0x1bb7))));foreach my $rv (@arr_rule_value){($rule_value_resources
{$rv}=(""));}if (($filtered_value eq (""))){(@arr_rule_value=());($rule_value 
and (@arr_rule_value=split ( /,/ ,$rule_value,(0x0fe3+ 742-0x12c9))));foreach my $rv
 (@arr_rule_value){(my (@item_rule)=split ( /=/ ,$rv,(0x0107+ 8552-0x226f)));(
$rule_value_resources{$item_rule[(0x0a5c+ 259-0x0b5f)]}=$item_rule[
(0x0703+ 1484-0x0cce)]);}foreach my $key (keys (%rule_value_resources)){if ((
$rule_value_resources{$key}eq (""))){($rule_value_resources{$key}="\x6e\x6f");}
push (@out_resources,{"\x63\x6c\x61\x73\x73",$class,"\x74\x79\x70\x65",$key,
"\x76\x61\x6c\x75\x65",$rule_value_resources{$key}});}}return (@out_resources);}
sub __getSessionResources{(my $user=shift (@_));(my $nodeUuid=shift (@_));(my $filtered_value
=shift (@_));Logger::debug (((((((
"\x47\x65\x74\x20\x73\x65\x73\x73\x69\x6f\x6e\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x2e\x20\x55\x73\x65\x72\x3a\x20"
.$user)."\x2c\x20\x6e\x6f\x64\x65\x3a\x20").$nodeUuid).
"\x2c\x20\x66\x69\x6c\x74\x65\x72\x65\x64\x20\x76\x61\x6c\x75\x65\x3a\x20").
$filtered_value)."\x2e"));__setUsername ($user);(my $availableSessionTypes=
NXNodes::getAvailableSessionTypes ($nodeUuid));if ((NXNodes::isStatusStopped (
$nodeUuid)and ($restoreType ne ("")))){Logger::debug (
"\x41\x64\x64\x20\x72\x65\x73\x74\x6f\x72\x65\x20\x74\x79\x70\x65\x20\x74\x6f\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x53\x65\x73\x73\x69\x6f\x6e\x54\x79\x70\x65\x73\x2e"
);($availableSessionTypes=$restoreType);}(my ($error_code,%resources)=
__getResources ($user,"\x73\x65\x73\x73\x69\x6f\x6e",$nodeUuid,
$availableSessionTypes));(my (@allSessionTypes)=split ( /,/ ,
Common::NXSessionType::getAllTypes (),(0x1881+   5-0x1886)));
__getSystemSessionTypesForLocalNode ($nodeUuid,(\@allSessionTypes));my (
%sessionClassResources);foreach my $type (@allSessionTypes){if (($resources{
$type}==(0x10a0+ 4643-0x22c2))){if (Server::isAccessOnlyToLocalPhysical ()){if (
Common::NXSessionType::isPhysical ($type)){($sessionClassResources{$type}=
(0x0c13+ 5727-0x2271));}else{Logger::debug2 (((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$type).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
));}}elsif (Server::isAccessOnlyToAttach ()){if ((
Common::NXSessionType::isPhysical ($type)or 
Common::NXSessionType::isVirtualAttach ($type))){($sessionClassResources{$type}=
(0x1a14+ 2368-0x2353));}else{Logger::debug2 (((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$type).
"\x27\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x66\x6f\x72\x20\x74\x68\x69\x73\x20\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x2e"
));}}else{Logger::debug (((
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x20\x27"
.$type)."\x27\x20\x69\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"));(
$sessionClassResources{$type}=(0x0b7d+ 2909-0x16d9));}}else{Logger::debug (((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x3a\x20".$type).
"\x20\x69\x73\x20\x6e\x6f\x74\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"));(
$sessionClassResources{$type}=(0x00dd+ 9163-0x24a8));}}foreach my $type (keys (
%resources)){if (($resources{$type}=~ /xsession-/ )){Logger::debug (((
"\x53\x65\x73\x73\x69\x6f\x6e\x20\x74\x79\x70\x65\x3a\x20".$type).
"\x20\x69\x73\x20\x61\x76\x61\x69\x6c\x61\x62\x6c\x65\x2e"));(
$sessionClassResources{$type}=(0x0028+ 8769-0x2268));}}main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x6f\x6c\x69\x63\x79");if (
(NXConnectionPolicy::isDesktopEnabled ()and Server::notShowAllResourceAvailable 
())){($sessionClassResources{Common::NXSessionType::getVirtualDefault ()}=
(0x1233+ 1073-0x1664));}my (@res);push (@res,__formatResourceOutput (
"\x73\x65\x73\x73\x69\x6f\x6e",$filtered_value,%sessionClassResources));(my $rule_value
=NXProfilesManager::getClassValues ("\x73\x65\x73\x73\x69\x6f\x6e",$user,
$nodeUuid));push (@res,__formatRuleValueOutput ("\x73\x65\x73\x73\x69\x6f\x6e",
$filtered_value,$rule_value));return (@res);}sub 
__getSystemSessionTypesForLocalNode{(my $nodeUuid=shift (@_));(my $ref_Session=
shift (@_));main::nxrequire (
"\x4e\x58\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x50\x6f\x6c\x69\x63\x79");
unless (NXConnectionPolicy::isSystemDesktopsEnabled ()){return;}if ((($nodeHost 
eq (""))or NXNodes::isLocalNode ($nodeUuid))){(my $sessions=
Common::NXSessionType::getXsessionTypes ());foreach my $name (split ( /,/ ,
$sessions,(0x15cd+ 2018-0x1daf))){push (@$ref_Session,$name);}}}sub 
__getServiceResources{(my $user=shift (@_));(my $node=shift (@_));(my $filtered_value
=shift (@_));Logger::debug (((((((
"\x5f\x5f\x67\x65\x74\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x75\x73\x65\x72\x20\x27"
.$user)."\x27\x2c\x20\x6e\x6f\x64\x65\x20\x27").$node).
"\x27\x2c\x20\x76\x61\x6c\x75\x65\x20\x27").$filtered_value)."\x27\x2e"));(my (
$error_code,%resources)=__getResources ($user,"\x73\x65\x72\x76\x69\x63\x65",
$node));(my $rule_value=NXProfilesManager::getClassValues (
"\x73\x65\x72\x76\x69\x63\x65",$user,$node));(my $services_to_check=(""));
foreach my $service (keys (%resources)){if (($resources{$service}==
(0x15f8+ 2974-0x2195))){Logger::debug2 ((("\x73\x65\x72\x76\x69\x63\x65\x20\x5b"
.$service).
"\x5d\x20\x74\x6f\x20\x63\x68\x65\x63\x6b\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x73"))
;($services_to_check.=($service."\x2c"));($resources{$service}=
(0x132f+ 1040-0x173f));}}(my (@nodes_array)=());if ((defined ($node)and length (
$node))){(@nodes_array=split ( /,/ ,$node,(0x0966+ 4788-0x1c1a)));}else{(
@nodes_array=NXNodes::getNodesArray ());}foreach my $nodeUuid (@nodes_array){
Logger::debug (((
"\x5f\x5f\x67\x65\x74\x53\x65\x72\x76\x69\x63\x65\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x67\x65\x74\x20\x66\x6f\x72\x20\x6e\x6f\x64\x65\x20\x27"
.$nodeUuid)."\x27\x2e"));(my $deny_services=NXNodes::getNodeDenyServices (
$nodeUuid));Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x73\x20\x64\x65\x6e\x69\x65\x64\x20\x69\x6e\x20\x6e\x6f\x64\x65\x20\x70\x72\x6f\x66\x69\x6c\x65\x20\x61\x6e\x64\x20\x64\x65\x6e\x79\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x3a\x20\x5b"
.$deny_services)."\x5d"));(my (@services_to_check_array)=split ( /,/ ,
$services_to_check,(0x1212+ 1438-0x17b0)));foreach my $service (
@services_to_check_array){if ((not (($deny_services=~ /$service/ )))){
Logger::debug2 ((("\x53\x65\x72\x76\x69\x63\x65\x20\x5b".$service).
"\x5d\x20\x66\x6f\x75\x6e\x64\x20\x6f\x6e\x20\x6e\x6f\x64\x65\x2e"));($resources
{$service}=(0x07d7+ 6422-0x20ec));($services_to_check=~ s/$service,// );}}}
delete ($resources{("")});my (@res);push (@res,__formatResourceOutput (
"\x73\x65\x72\x76\x69\x63\x65",$filtered_value,%resources));push (@res,
__formatRuleValueOutput ("\x73\x65\x72\x76\x69\x63\x65",$filtered_value,
$rule_value));return (@res);}sub __getFeatureResources{(my $user=shift (@_));(my $node
=shift (@_));(my $filtered_value=shift (@_));(my ($error_code,%resources)=
__getResources ($user,"\x66\x65\x61\x74\x75\x72\x65",$node));(my $rule_value=
NXProfilesManager::getClassValues ("\x66\x65\x61\x74\x75\x72\x65",$user,$node));my (
@res);push (@res,__formatResourceOutput ("\x66\x65\x61\x74\x75\x72\x65",
$filtered_value,%resources));push (@res,__formatRuleValueOutput (
"\x66\x65\x61\x74\x75\x72\x65",$filtered_value,$rule_value));return (@res);}sub 
__getNodeResources{(my $user=shift (@_));(my $node=shift (@_));(my $filtered_value
=shift (@_));my (@res);(my ($error_code,%resources)=__getResources ($user,
"\x6e\x6f\x64\x65"));(my $rule_value=NXProfilesManager::getClassValues (
"\x6e\x6f\x64\x65",$user,$node));($rule_value=~ s/\//:/g );foreach my $key (keys
 (%resources)){(my $value=$resources{$key});delete ($resources{$key});($key=~ s/\//:/g )
;($resources{$key}=$value);}push (@res,__formatResourceOutput (
"\x6e\x6f\x64\x65",$filtered_value,%resources));push (@res,
__formatRuleValueOutput ("\x6e\x6f\x64\x65",$filtered_value,$rule_value));return
 (@res);}sub printResources{(my (@param)=@_);my (%parameters);if ((scalar (
@param)eq (0x017b+ 5797-0x181f))){((%parameters)=NXShell::urlParameter2Hash (
NXShell::getLastParameters (@param)));Logger::debug (((
"\x52\x65\x73\x6f\x75\x72\x63\x65\x20\x6c\x69\x73\x74\x3a\x20\x6f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x20\x70\x61\x72\x61\x6d\x20\x5b"
.join ($",@param))."\x5d\x2e"),(0x149d+ 4561-0x266e));(
$GLOBAL::NXMANAGER_FORMAT_OUTPUT=(0x0296+ 8029-0x21f2));if (((not (defined (
$parameters{"\x75\x73\x65\x72"})))or ($parameters{"\x75\x73\x65\x72"}eq ("")))){
if (defined ($parameters{"\x67\x75\x65\x73\x74"})){($parameters{
"\x75\x73\x65\x72"}=NXProfiles::getInternalGuestKey ());}elsif (defined (
$parameters{"\x73\x79\x73\x74\x65\x6d"})){($parameters{"\x75\x73\x65\x72"}=
NXProfiles::getInternalSystemKey ());}else{($parameters{"\x75\x73\x65\x72"}=
NXLogin::get ()->getLogin);}}if ((not (NXLogin::isAdministrator ()))){if (((
$parameters{"\x75\x73\x65\x72"}ne NXLogin::get ()->getLogin)and ($parameters{
"\x6e\x6f\x64\x65"}eq ("")))){NXMsg::error (
"\x65\x44\x69\x66\x66\x65\x72\x65\x6e\x74\x55\x73\x65\x72\x52\x65\x73\x6f\x75\x72\x63\x65"
,"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73");return ((0x0259+ 7257-0x1eb1));
}}}else{Logger::debug (
"\x52\x65\x73\x6f\x75\x72\x63\x65\x20\x6c\x69\x73\x74\x3a\x20\x6d\x6f\x72\x65\x20\x74\x68\x65\x6e\x20\x6f\x6e\x65\x20\x70\x61\x72\x61\x6d\x65\x74\x65\x72\x2e"
,(0x0df2+ 2778-0x18cc));((%parameters)=@param);if (((not (defined ($parameters{
"\x75\x73\x65\x72"})))or ($parameters{"\x75\x73\x65\x72"}eq ("")))){($parameters
{"\x75\x73\x65\x72"}=NXProfiles::getInternalSystemKey ());}}if (
NXProfiles::isInternalKeyForGuest ($parameters{"\x75\x73\x65\x72"})){if ((((
$GLOBAL::EnableGuestCreateVirtualDesktop eq "\x30")or 
NXLicense::isNotGuestFeature ())or ($GLOBAL::EnableUserProfile eq "\x30"))){if (
NXLicense::isNotGuestFeature ()){NXMsg::error (
"\x65\x47\x75\x65\x73\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73");}else{NXMsg::error (
"\x65\x47\x75\x65\x73\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73");}return ((0x1dc8+ 1846-0x24fe))
;}}if (($parameters{"\x6e\x6f\x64\x65"}ne (""))){($parameters{"\x6e\x6f\x64\x65"
}=~ s/\.$//s );Logger::debug (((
"\x43\x68\x65\x63\x6b\x69\x6e\x67\x20\x6e\x6f\x64\x65\x20\x69\x6e\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x3a\x20"
.$parameters{"\x6e\x6f\x64\x65"})."\x2e"));(my ($nodeUUID,$host,$port)=
NXNodes::getHostAndPort ($parameters{"\x6e\x6f\x64\x65"}));if ((not (
NXProfilesManager::isNodeAvailableForLoggedUser ($nodeUUID,$parameters{
"\x75\x73\x65\x72"})))){Logger::warning (((
"\x4c\x6f\x67\x67\x65\x64\x20\x75\x73\x65\x72\x20\x64\x6f\x6e\x27\x74\x20\x68\x61\x76\x65\x20\x72\x69\x67\x68\x74\x73\x20\x74\x6f\x20\x70\x72\x69\x6e\x74\x20\x72\x65\x73\x6f\x75\x72\x63\x65\x73\x20\x66\x72\x6f\x6d\x20\x6e\x6f\x64\x65\x20\x27"
.$nodeUUID)."\x27\x2e"));NXMsg::error (
"\x65\x4e\x6f\x64\x65\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",$parameters{"\x6e\x6f\x64\x65"})
;return ((0x0872+ 4930-0x1bb4));}}Logger::debug (((((((((
"\x52\x65\x73\x6f\x75\x72\x63\x65\x20\x6c\x69\x73\x74\x20\x66\x6f\x72\x20\x75\x73\x65\x72\x5b"
.$parameters{"\x75\x73\x65\x72"})."\x5d\x2c\x20\x63\x6c\x61\x73\x73\x5b").
$parameters{"\x63\x6c\x61\x73\x73"})."\x5d\x2c\x20\x76\x61\x6c\x75\x65\x5b").
$parameters{"\x76\x61\x6c\x75\x65"})."\x5d\x20\x6e\x6f\x64\x65\x5b").$parameters
{"\x6e\x6f\x64\x65"})."\x5d"),(0x0769+ 1664-0x0de9));(my (@resources)=
__calculateResources ((\%parameters)));if ((Common::NXMsg::send_response (
"\x69\x52\x65\x73\x6f\x75\x72\x63\x65\x4c\x69\x73\x74")==(-(0x1803+ 3634-0x2634)
))){return ((-(0x0fef+ 472-0x11c6)));}if ((main::nxwrite (main::nxgetSTDOUT (),
"\x0a")==(-(0x00fd+ 1375-0x065b)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x0ae4+ 6016-0x2263)));}__setLength (
@resources);if ((main::nxwrite (main::nxgetSTDOUT (),sprintf (((((((((((((
"\x25\x2d".$__lengthClass)."\x2e").$__lengthClass)."\x73\x20\x25\x2d").
$__lengthType)."\x2e").$__lengthType)."\x73\x20\x25\x2d").$__lengthValue)."\x2e"
).$__lengthValue)."\x73\x0a"),"\x43\x6c\x61\x73\x73","\x54\x79\x70\x65",
"\x56\x61\x6c\x75\x65"))==(-(0x1d3c+ 304-0x1e6b)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x1152+ 4807-0x2418)));}if ((
main::nxwrite (main::nxgetSTDOUT (),sprintf ((((((((((((("\x25\x2d".
$__lengthClass)."\x2e").$__lengthClass)."\x73\x20\x25\x2d").$__lengthType).
"\x2e").$__lengthType)."\x73\x20\x25\x2d").$__lengthValue)."\x2e").
$__lengthValue)."\x73\x0a"),("\x2d" x $__lengthClass),("\x2d" x $__lengthType),(
"\x2d" x $__lengthValue)))==(-(0x020d+ 6574-0x1bba)))){NXShell::setExitRequest (
$ExitRequests::closedSTDOUT);return ((-(0x0e28+ 2542-0x1815)));}foreach my $res 
(@resources){if ((main::nxwrite (main::nxgetSTDOUT (),sprintf (((((((((((((
"\x25\x2d".$__lengthClass)."\x2e").$__lengthClass)."\x73\x20\x25\x2d").
$__lengthType)."\x2e").$__lengthType)."\x73\x20\x25\x2d").$__lengthValue)."\x2e"
).$__lengthValue)."\x73\x0a"),$$res{"\x63\x6c\x61\x73\x73"},$$res{
"\x74\x79\x70\x65"},$$res{"\x76\x61\x6c\x75\x65"}))==(-(0x0d0a+ 2489-0x16c2)))){
NXShell::setExitRequest ($ExitRequests::closedSTDOUT);return ((-
(0x1a00+ 3227-0x269a)));}}return ((0x00c3+ 8284-0x211f));}sub 
__calculateResources{(my $ref_parameters=shift (@_));(my (@resources)=());if ((
$$ref_parameters{"\x6e\x6f\x64\x65"}=~ /^(.*):(\d+)$/ )){($host=$1);($port=$2);(
$$ref_parameters{"\x6e\x6f\x64\x65"}=NXNodes::getUuid ($host,$port));}if (((
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq "\x73\x65\x73\x73\x69\x6f\x6e")or (
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq ("")))){push (@resources,
__getSessionResources ($$ref_parameters{"\x75\x73\x65\x72"},$$ref_parameters{
"\x6e\x6f\x64\x65"},$$ref_parameters{"\x76\x61\x6c\x75\x65"}));}if (((
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq "\x73\x65\x72\x76\x69\x63\x65")or (
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq ("")))){push (@resources,
__getServiceResources ($$ref_parameters{"\x75\x73\x65\x72"},$$ref_parameters{
"\x6e\x6f\x64\x65"},$$ref_parameters{"\x76\x61\x6c\x75\x65"}));}if (((
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq "\x66\x65\x61\x74\x75\x72\x65")or (
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq ("")))){push (@resources,
__getFeatureResources ($$ref_parameters{"\x75\x73\x65\x72"},$$ref_parameters{
"\x6e\x6f\x64\x65"},$$ref_parameters{"\x76\x61\x6c\x75\x65"}));}if (((
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq "\x6e\x6f\x64\x65")or (
$$ref_parameters{"\x63\x6c\x61\x73\x73"}eq ("")))){push (@resources,
__getNodeResources ($$ref_parameters{"\x75\x73\x65\x72"},$$ref_parameters{
"\x6e\x6f\x64\x65"},$$ref_parameters{"\x76\x61\x6c\x75\x65"}));}if ((
NXLogin::isDesktopGuestLogin ()eq (0x06e7+ 7195-0x2301))){(my (
@notAllowedResources)=split ( /,/ ,$GLOBAL::SERVICES_NOT_ALLOWED_FOR_GDS,
(0x2379+ 533-0x258e)));(my $iter=(0x02b2+ 3817-0x119b));foreach my $res (
@resources){foreach my $service (@notAllowedResources){if (($$res{
"\x74\x79\x70\x65"}eq $service)){($resources[$iter]{"\x76\x61\x6c\x75\x65"}=
"\x6e\x6f");}}(++$iter);}}NXProfiles::saveCalculatedResources (@resources);
return (@resources);}sub calculateResourcesBeforeResourcelist{(my $user=shift (
@_));(my $node=shift (@_));my (%parameters);($parameters{"\x75\x73\x65\x72"}=
$user);($parameters{"\x6e\x6f\x64\x65"}=$node);__calculateResources ((
\%parameters));}sub __setLength{(my (@resources)=@_);foreach my $line (
@resources){if ((length ($$line{"\x63\x6c\x61\x73\x73"})>$__lengthClass)){(
$__lengthClass=length ($$line{"\x63\x6c\x61\x73\x73"}));}if ((length ($$line{
"\x74\x79\x70\x65"})>$__lengthType)){($__lengthType=length ($$line{
"\x74\x79\x70\x65"}));}if ((length ($$line{"\x76\x61\x6c\x75\x65"})>
$__lengthValue)){($__lengthValue=length ($$line{"\x76\x61\x6c\x75\x65"}));}}}sub
 getUsername{return ($username);}sub __setUsername{(my $user=shift (@_));(
$username=$user);}sub setRestoreType{(my $type=shift (@_));($restoreType=$type);
}NXMsg::register_error ("\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",
"\x65\x44\x69\x66\x66\x65\x72\x65\x6e\x74\x55\x73\x65\x72\x52\x65\x73\x6f\x75\x72\x63\x65"
,(0x095f+ 3946-0x169d));NXMsg::register_error (
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",
"\x65\x47\x75\x65\x73\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,(0x1aab+ 2876-0x23be));NXMsg::register_error (
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",
"\x65\x4e\x6f\x64\x65\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x4e\x6f\x74\x50\x65\x72\x6d\x69\x74\x74\x65\x64"
,(0x04ac+ 2643-0x0cd6));NXMsg::register_error (
"\x4e\x58\x52\x65\x73\x6f\x75\x72\x63\x65\x73",
"\x65\x47\x75\x65\x73\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x6c\x69\x73\x74\x44\x69\x73\x61\x62\x6c\x65\x64"
,(0x1b92+ 1636-0x1fcd));return ((0x0a83+ 4400-0x1bb2));
