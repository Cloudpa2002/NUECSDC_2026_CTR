############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
package NXServices::NXHtd;no warnings;(my $__serviceName="\x6e\x78\x68\x74\x64")
;(my $__pid=(0x13a3+ 3363-0x20c6));(my $__disabled=(0x12ea+ 1084-0x1726));(my $__waitTime
=(0x1745+ 2990-0x22f3));(my $__nxexecPid=(0x1405+ 2007-0x1bdc));(my $__startTime
=(0x0209+ 2269-0x0ae6));(my $__silenceMode=(0x0336+ 8629-0x24eb));(my $__restartCouter
=(0x027d+ 3136-0x0ebd));(my $__isWaitingForNXHtdStart=(0x03a7+ 2770-0x0e79));(my $__handlingManualStart
=(0x1052+ 5014-0x23e8));(my $__serviceStarting=
"\x73\x74\x61\x72\x74\x69\x6e\x67");(my $__serviceWorking=
"\x77\x6f\x72\x6b\x69\x6e\x67");(my $__serviceShutdown=
"\x73\x68\x75\x74\x64\x6f\x77\x6e");(my $__serviceStatusReported=
$__serviceStarting);sub setServiceStatus{(my $status=(shift (@_)||("")));if ((
$status eq (""))){return;}($__serviceStatusReported=$status);}sub 
getServiceStatus{return ($__serviceStatusReported);}sub isServicesStatusWorking{
if ((getServiceStatus ()eq $__serviceWorking)){return ((0x194c+ 512-0x1b4b));}
return ((0x1369+ 1559-0x1980));}sub isEnabled{if (($__disabled==
(0x0510+ 2535-0x0ef6))){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x74\x64\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6e\x78\x73\x65\x72\x76\x65\x72\x20\x2d\x2d\x64\x61\x65\x6d\x6f\x6e\x2e"
);return ((0x0206+ 3765-0x10bb));}if (NXSystemDaemons::isServiceDisabled (
$__serviceName)){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x74\x64\x20\x64\x69\x73\x61\x62\x6c\x65\x64\x20\x62\x79\x20\x6c\x69\x63\x65\x6e\x73\x65\x20\x6f\x72\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x2e"
);return ((0x05a2+ 1123-0x0a05));}if (NXSystemDaemons::isHttpdStartupKeyDisabled
 ()){if (__isHandlingManualStart ()){return ((0x1842+ 2895-0x2390));}
Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x74\x64\x20\x69\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x72\x75\x6e\x20\x6d\x61\x6e\x75\x61\x6c\x6c\x79\x2e"
);return ((0x0023+ 995-0x0406));}return ((0x19f5+ 2080-0x2214));}sub isDisabled{
return ((!isEnabled ()));}sub setEnabled{($__disabled=(0x02d9+ 8488-0x2401));}
sub setDisabled{setServiceStatus ($__serviceShutdown);($__disabled=
(0x0117+ 6696-0x1b3e));}sub start{if (isEnabled ()){
NXSystemDaemons::removeStopFlag ($__serviceName);if (__isHandlingManualStart ())
{main::nxrequire ("\x4e\x58\x46\x69\x72\x65\x77\x61\x6c\x6c");
NXFirewall::addFirewallNXHtdPort ();}(my $nxhtdPid=__runNXHtd ());if (($nxhtdPid
>(0x04fc+ 8015-0x244b))){__handleNXHtdStartedWithPid ($nxhtdPid);return (
(0x0702+ 1283-0x0c04));}__handleNXHtdNotStarted ();return ((0x2560+ 213-0x2635))
;}return ((0x1d5a+ 1234-0x222b));}sub stop{NXSystemDaemons::setStopFlag (
$__serviceName);setDisabled ();(my $ret=__closeNXHtd ());main::nxrequire (
"\x4e\x58\x53\x68\x75\x74\x64\x6f\x77\x6e");if ((($ret==(0x116c+ 3090-0x1d7e))
and NXShutdown::serviceWasDisabled ("\x6e\x78\x68\x74\x64"))){setPid (
(0x0538+ 1191-0x09df));__handleNXHtdAlreadyClosed ();return (
(0x1159+ 4906-0x2483));}elsif (($ret==(0x0882+ 5021-0x1c1f))){setPid (
(0x0b80+ 1413-0x1105));__handleNXHtdClosed ();return ((0x03e2+ 8132-0x23a6));}
__handleNXHtdNotClosed ();return ((0x1b78+ 1875-0x22ca));}sub getPid{if (($__pid
>(0x01d6+ 3594-0x0fe0))){Logger::debug (((
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x74\x44\x20\x50\x49\x44\x20\x66\x72\x6f\x6d\x20\x6d\x65\x6d\x6f\x72\x79\x3a\x20"
.$__pid)."\x2e"));return ($__pid);}($__pid=NXSystemDaemons::readPid (
$__serviceName));return ($__pid);}sub setPid{($__pid=shift (@_));}sub 
__setStartTime{($__startTime=Common::NXTime::getSecondsSinceEpoch ());}sub 
isSilenceMode{if (($__silenceMode==(0x0421+ 3184-0x1090))){return (
(0x156c+ 2136-0x1dc3));}if (Server::isClientConnectionClosed ()){($__silenceMode
=(0x0659+ 2230-0x0f0e));}return ($__silenceMode);}sub setSilentMode{(
$__silenceMode=(0x0a2f+ 2063-0x123d));}sub __closeNXHtd{(my $nxhtdPid=getPid ())
;if ((($nxhtdPid==(0x0b5f+ 4293-0x1c24))or (not (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName))))){return ((0x0eec+ 3749-0x1d91));}if ((__sendStopNXHtdCommand 
($nxhtdPid)==(0x0be6+ 883-0x0f59))){NXSystemDaemons::waitForServiceClosure (
$nxhtdPid,$__serviceName);}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName)){Common::NXProcess::signalProcessByRestrictedScript ($nxhtdPid,
Common::NXProcess::getSignalKill (),(0x0f45+ 5932-0x2670));}else{return (
(0x03ea+ 6429-0x1d07));}if (
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName)){return ((0x185a+ 2118-0x209f));}return ((0x01a5+ 2129-0x09f6));
}sub __sendStopNXHtdCommand{(my $nxhtdPid=shift (@_));(my (@command)=
__getCommandStop ());(my (@options)=__getCommandOptions ("\x73\x74\x6f\x70"));(my $uid
=Common::NXCore::NXFileUid (("\x2f\x70\x72\x6f\x63\x2f".$nxhtdPid)));if (($uid 
eq (0x0cf9+ 3986-0x1c8b))){(@command=($GLOBAL::CommandNXexec,
$GLOBAL::SCRIPT_NXHTD_ROOT,"\x73\x74\x6f\x70"));}(my ($cmd_err,$cmd_out,
$exit_value)=main::run_command ((\@command),(\@options)));return ($exit_value);}
sub __handleNXHtdClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x44\x69\x73\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);}
NXSystemDaemons::removePidFile ($__serviceName);main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ($__serviceName);}
sub __handleNXHtdAlreadyClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x41\x6c\x72\x65\x61\x64\x79\x44\x69\x73\x61\x62\x6c\x65\x64"
,"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);
}NXSystemDaemons::removePidFile ($__serviceName);main::nxrequire (
"\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToRemove ($__serviceName);}
sub __handleNXHtdNotClosed{if ((not (isSilenceMode ()))){NXMsg::info (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x6f\x70\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);}
}sub __handleNXHtdStartedWithPid{(my $htdPid=shift (@_));Logger::debug (((
"\x4e\x58\x48\x54\x44\x20\x69\x73\x20\x72\x75\x6e\x6e\x69\x6e\x67\x20\x77\x69\x74\x68\x20\x70\x69\x64\x3a\x20"
.$htdPid)."\x2e"));if ((not (isSilenceMode ()))){NXMsg::info (
"\x69\x53\x65\x72\x76\x69\x63\x65\x45\x6e\x61\x62\x6c\x65\x64",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);}
__setStartTime ();setPid ($htdPid);__resetHandlingManualStart ();main::nxrequire
 ("\x4e\x58\x4c\x6f\x63\x61\x74\x65");NXLocate::requestToAdd ($__serviceName);}
sub __handleNXHtdNotStarted{if ((not (isSilenceMode ($__serviceName)))){
NXMsg::error (
"\x65\x43\x61\x6e\x6e\x6f\x74\x53\x74\x61\x72\x74\x53\x65\x72\x76\x69\x63\x65",
"\x4e\x58\x53\x79\x73\x74\x65\x6d\x44\x61\x65\x6d\x6f\x6e\x73",$__serviceName);}
}sub __runNXHtd{(my $nxhtdPid=getPid ());if ((($nxhtdPid>(0x141b+ 2185-0x1ca4))
and Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName))){if (((not (Common::NXProcess::isChildProcess ($nxhtdPid)))and 
(not (Common::NXProcess::isOnWatchdogProcess ($nxhtdPid))))){setServiceStatus (
$__serviceWorking);Common::NXProcess::addWatchdog ($nxhtdPid,$NXBITS::SIGCHLD);
Common::NXProcess::setCallbackSIGCHLD ($nxhtdPid,(\&nxhtdSIGCHLDHandler));}
Logger::debug (
"\x4e\x58\x48\x54\x44\x20\x69\x73\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x72\x75\x6e\x6e\x69\x6e\x67\x2e"
);return ($nxhtdPid);}if (($__isWaitingForNXHtdStart!=(0x0658+ 2740-0x110b))){(my (
@command)=__getCommandStart ());(my (@options)=__getCommandOptions ());push (
@options,"\x67\x65\x74\x20\x70\x69\x64",(\$__nxexecPid));Logger::debug (
"\x53\x74\x61\x72\x74\x69\x6e\x67\x20\x4e\x58\x48\x54\x44\x2e");
main::nxRunCommand ((\@command),(\@options));($__waitTime=(0x034f+ 5251-0x17d2))
;($__isWaitingForNXHtdStart=(0x219a+ 736-0x2479));__setStartTime ();if ((
$__nxexecPid<=(0x103c+ 4847-0x232b))){setDisabled ();return (
(0x120d+ 3647-0x204c));}Common::NXProcess::setExitCallback ($__nxexecPid,(
\&nxhtdSIGCHLDHandler));Common::NXProcess::setErrorCallback ($__nxexecPid,(
\&nxhtdSIGCHLDHandler));}if (NXSystemDaemons::isDisabled ($__serviceName)){(
$__isWaitingForNXHtdStart=(0x0214+ 1596-0x0850));return ((0x003f+ 4224-0x10bf));
}($nxhtdPid=__waitForNXHtdPid ());return ($nxhtdPid);}sub __waitForNXHtdPid{(my $waitTimeout
=(0x00d5+ 7043-0x1c53));(my $waitInterval=0.1);for (;($__waitTime<$waitTimeout);
($__waitTime+=$waitInterval)){if (NXSystemDaemons::isDisabled ($__serviceName)){
($__isWaitingForNXHtdStart=(0x0b08+ 3835-0x1a03));return ((0x1276+ 3953-0x21e7))
;}(my $nxhtdPid=NXSystemDaemons::readPid ($__serviceName));if ((($nxhtdPid>
(0x0b09+ 3174-0x176f))and 
Common::NXCore::isProcessRunnningAndExpectedNameMatchSilent ($nxhtdPid,
$__serviceName))){($__isWaitingForNXHtdStart=(0x04a5+ 2036-0x0c99));
setServiceStatus ($__serviceWorking);return ($nxhtdPid);}main::nxsleep (
$waitInterval);}Logger::warning (
"\x54\x69\x6d\x65\x6f\x75\x74\x20\x66\x6f\x72\x20\x77\x61\x69\x74\x69\x6e\x67\x20\x6f\x6e\x20\x6e\x78\x68\x74\x64\x20\x70\x69\x64\x20\x72\x65\x61\x63\x68\x65\x64\x2e"
);($__isWaitingForNXHtdStart=(0x010a+ 4734-0x1388));return (
(0x0df3+ 2051-0x15f6));}sub __getCommandStart{(my (@command)=());(my $htdPort=
NXTools::getNXHtdPort ());if (($htdPort<=(0x2261+ 1059-0x2284))){(@command=(
$GLOBAL::CommandNXexec,$GLOBAL::SCRIPT_NXHTD_ROOT,"\x73\x74\x61\x72\x74"));}else
{(@command=($GLOBAL::CommandNXexec,$GLOBAL::SCRIPT_NXHTD,"\x73\x74\x61\x72\x74")
);}return (@command);}sub __getCommandOptions{(my $command=shift (@_));(my (
@options)=());(my $path=($GLOBAL::NODE_ROOT."\x2f\x6c\x69\x62\x3a"));($path.=(
$GLOBAL::NODE_ROOT."\x2f\x6c\x69\x62\x2f\x70\x65\x72\x6c\x3a"));($path.=
libnxh::NXTransGetEnvironment (
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48"));push (@options,
"\x73\x65\x74\x20\x65\x6e\x76",(
"\x4c\x44\x5f\x4c\x49\x42\x52\x41\x52\x59\x5f\x50\x41\x54\x48\x3d".$path));push 
(@options,"\x73\x74\x64\x69\x6e\x6e\x6f\x72\x65\x64\x69\x72\x65\x63\x74");push (
@options,"\x73\x74\x64\x6f\x75\x74",__getStdoutFile ());push (@options,
"\x73\x74\x64\x65\x72\x72",__getStderrFile ());if (($command ne 
"\x73\x74\x6f\x70")){push (@options,"\x72\x75\x6e\x20\x69\x6e\x20\x62\x67");}
return (@options);}sub __getStdoutFile{return (
Common::NXPaths::getNXServerLogPath ());}sub __getStderrFile{return (
Common::NXPaths::getNXServerLogPath ());}sub __getCommandStop{(my (@command)=())
;(my $htdPort=NXTools::getNXHtdPort ());if (($htdPort<=(0x20c1+ 746-0x1fab))){(
@command=($GLOBAL::CommandNXexec,$GLOBAL::SCRIPT_NXHTD_ROOT,"\x73\x74\x6f\x70"))
;}else{(@command=($GLOBAL::CommandNXexec,$GLOBAL::SCRIPT_NXHTD,
"\x73\x74\x6f\x70"));}return (@command);}sub nxhtdSIGCHLDHandler{(my $pid=shift 
(@_));(my $code=shift (@_));($__isWaitingForNXHtdStart=(0x10f2+ 2823-0x1bf9));
Logger::debug (((((((
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x54\x44\x20\x77\x69\x74\x68\x20\x50\x49\x44\x20"
.$pid)."\x20\x61\x6e\x64\x20\x73\x74\x61\x67\x65\x20\x27").
$__serviceStatusReported).
"\x27\x20\x6a\x75\x73\x74\x20\x64\x69\x65\x64\x20\x77\x69\x74\x68\x20\x65\x78\x69\x74\x20\x63\x6f\x64\x65\x20"
).$code)."\x2e"));NXSystemDaemons::removePidFile ($__serviceName);setPid (
(0x17c0+ 1752-0x1e98));if (($GLOBAL::REQUEST_TERMINATE==(0x142d+ 1729-0x1aed))){
return ((0x06e1+ 8098-0x2683));}if (isDisabled ()){return;}if (
NXSystemDaemons::isStopFlag ($__serviceName)){Logger::debug (
"\x53\x65\x72\x76\x69\x63\x65\x20\x4e\x58\x48\x54\x44\x20\x68\x61\x73\x20\x73\x74\x6f\x70\x20\x66\x6c\x61\x67\x2e"
);return;}if (__isMaximumRestartCounterReached ()){setDisabled ();return;}if ((
isServicesStatusWorking ()==(0x117d+ 1298-0x168e))){start ();}else{setDisabled 
();}}sub __isMaximumRestartCounterReached{(my $lifeTime=(
Common::NXTime::getSecondsSinceEpoch ()-$__startTime));if (($lifeTime<
$GLOBAL::TooShortServiceLifeTime)){($__restartCouter+=(0x0d14+ 2262-0x15e9));}
else{($__restartCouter=(0x0414+ 8134-0x23da));}if (($__restartCouter>
$GLOBAL::MaximumServiceRestartCounter)){Logger::warning (
"\x52\x65\x61\x63\x68\x65\x64\x20\x6d\x61\x78\x69\x6d\x75\x6d\x20\x4e\x58\x48\x54\x44\x20\x72\x65\x73\x74\x61\x72\x74\x20\x63\x6f\x75\x6e\x74\x65\x72\x2e"
);return ((0x0571+ 5241-0x19e9));}return ((0x0874+ 1364-0x0dc8));}sub 
setHandlingManualStart{($__handlingManualStart=(0x06cc+ 8185-0x26c4));}sub 
__isHandlingManualStart{if (($__handlingManualStart==(0x0f8b+ 4140-0x1fb6))){
return ((0x0250+ 5146-0x1669));}return ((0x114c+ 2720-0x1bec));}sub 
__resetHandlingManualStart{($__handlingManualStart=(0x001d+ 316-0x0159));}sub 
setNXHtdLogPermissionByAdmin{if ((not (
NXSystemDaemons::isHttpdEnabledInLicenceAndConfig ()))){return;}if ((not (
main::effectiveUserIsAdministrator ()))){return;}(my $__logfile=((((
$GLOBAL::VAR_ROOT.$GLOBAL::DIRECTORY_SLASH)."\x6c\x6f\x67").
$GLOBAL::DIRECTORY_SLASH)."\x6e\x78\x68\x74\x64\x2e\x6c\x6f\x67"));Logger::debug
 (((
"\x73\x65\x74\x4e\x58\x48\x74\x64\x4c\x6f\x67\x50\x65\x72\x6d\x69\x73\x73\x69\x6f\x6e\x42\x79\x41\x64\x6d\x69\x6e\x20\x6e\x78\x68\x74\x64\x20\x6c\x6f\x67\x20\x66\x69\x6c\x65\x3a\x20"
.$__logfile)."\x2e"));(my $permissions=($NXBits::UserReadWrite+
$NXBits::GroupReadWrite));if ((not (Common::NXFile::fileExists ($__logfile)))){(my $FH
=main::nxopen ($__logfile,$NXBits::O_CREAT,$permissions,{
"\x45\x41\x43\x43\x45\x53","\x73\x69\x6c\x65\x6e\x74"}));if ((not (defined ($FH)
))){(my $errorString=libnxh::NXGetErrorString ());(my $errorNumber=
libnxh::NXGetError ());Logger::warning (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x72\x65\x61\x74\x65\x20\x66\x69\x6c\x65\x3a\x20"
.$__logfile)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errorNumber).
"\x2c\x20").$errorString)."\x2e"));}else{main::nxclose ($FH);}}else{my (
$errorNumber);my ($errorString);(my $silent=(0x03f6+ 6260-0x1c69));(my $permissions
=($NXBits::UserReadWrite+$NXBits::GroupReadWrite));if ((
Common::NXFile::setPermissions_unix ($__logfile,$permissions,(\$errorNumber),(
\$errorString),$silent)==(-(0x18fc+ 1294-0x1e09)))){Logger::debug (((((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x61\x63\x63\x65\x73\x73\x20\x72\x69\x67\x68\x74\x73\x3a\x20"
.$__logfile)."\x20\x74\x6f\x20").$permissions).
"\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errorNumber)."\x2c\x20").
$errorString)."\x2e"));return;}}(my (@htdUsers)=NXTools::getNXHtdUser ());my (
$errorString);my ($errorNumber);(my $silent=(0x0046+ 1867-0x0790));if ((
Common::NXFile::setOwnershipForUser ($__logfile,$htdUsers[(0x0ba9+ 5643-0x21b4)]
,(\$errorString),(\$errorNumber),$silent)==(-(0x107a+ 2676-0x1aed)))){
Logger::debug (((((((
"\x43\x61\x6e\x6e\x6f\x74\x20\x63\x68\x61\x6e\x67\x65\x20\x6f\x77\x6e\x65\x72\x20\x6f\x66\x20"
.$__logfile)."\x2e\x20\x45\x72\x72\x6f\x72\x20\x69\x73\x20").$errorNumber).
"\x2c\x20").$errorString)."\x2e"));return;}}return ((0x1a2b+ 1882-0x2184));
