############################################################################
#                                                                          #
#  Copyright (c) 2001, 2025 NoMachine, http://www.nomachine.com.           #
#                                                                          #
#  NXSERVER, NX protocol compression and NX extensions to this software    #
#  are copyright of NoMachine. Redistribution and use of the present       #
#  software is allowed according to terms specified in the file LICENSE    #
#  which comes in the source distribution.                                 #
#                                                                          #
#  Check http://www.nomachine.com/licensing.html for applicability.        #
#                                                                          #
#  NX and NoMachine are trademarks of NoMachine S.a.r.l.                   #
#                                                                          #
#  All rights reserved.                                                    #
#                                                                          #
############################################################################
sub Exception::NXNodeExecCannotConnect::BEGIN{package 
Exception::NXNodeExecCannotConnect;no warnings;require 
Exception::NXNodeExecCannotConnect;do{
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x6e\x6e\x65\x63\x74"
->import};}sub Exception::NXNodeExecCannotConnect::BEGIN{package 
Exception::NXNodeExecCannotConnect;no warnings;require base;do{
"\x62\x61\x73\x65"->import (
"\x45\x78\x63\x65\x70\x74\x69\x6f\x6e\x3a\x3a\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x43\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e\x46\x61\x69\x6c\x65\x64"
)};}sub Exception::NXNodeExecCannotConnect::BEGIN{package 
Exception::NXNodeExecCannotConnect;no warnings;require overload;do{
"\x6f\x76\x65\x72\x6c\x6f\x61\x64"->import ("\x22\x22",
"\x73\x74\x72\x69\x6e\x67\x69\x66\x79")};}sub 
Exception::NXNodeExecCannotConnect::notify{package 
Exception::NXNodeExecCannotConnect;no warnings;(my $self=shift (@_));(my $indexString
=$$self{"\x69\x6e\x64\x65\x78\x53\x74\x72\x69\x6e\x67"});(my $ref_parameters=
$$self{"\x72\x65\x66\x50\x61\x72\x61\x6d\x65\x74\x65\x72\x73"});if (
Common::NXMsg::check_msg ($indexString)){Common::NXMsg::error ($indexString,
@$ref_parameters);}else{NXMsg::register_response ((""),
"\x65\x47\x55\x49\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x6e\x6e\x65\x63\x74"
,$GLOBAL::MSG_ERROR);NXMsg::send_response (
"\x65\x47\x55\x49\x4e\x58\x4e\x6f\x64\x65\x45\x78\x65\x63\x43\x61\x6e\x6e\x6f\x74\x43\x6f\x6e\x6e\x65\x63\x74"
,"\x67\x65\x6e\x65\x72\x61\x6c",$self->text);}}package 
Exception::NXNodeExecCannotConnect;no warnings;return ((0x0393+ 4877-0x169f));
